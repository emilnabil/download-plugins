# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: '/usr/lib/enigma2/python/Plugins/SystemPlugins/SoftwareManager/__init__.py'
# Bytecode version: 3.12.0rc2 (3531)
# Source timestamp: 2096-04-18 06:16:26 UTC (3985568186)

pass