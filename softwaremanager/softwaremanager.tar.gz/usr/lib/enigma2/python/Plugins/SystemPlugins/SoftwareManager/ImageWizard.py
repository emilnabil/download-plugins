# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: '/usr/lib/enigma2/python/Plugins/SystemPlugins/SoftwareManager/ImageWizard.py'
# Bytecode version: 3.12.0rc2 (3531)
# Source timestamp: 2001-11-06 06:34:42 UTC (1005028482)

from os import W_OK, R_OK, access
from os.path import isfile, join as pathjoin
from Components.config import config
from Components.Harddisk import harddiskmanager
from Components.Pixmap import Pixmap
from Components.SystemInfo import BoxInfo
from Screens.HelpMenu import ShowRemoteControl
from Screens.Wizard import wizardManager, Wizard
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from .BackupRestore import getBackupFilename, InitConfig as BackupRestore_InitConfig
BACKUP_FILE = getBackupFilename()
BOX_TYPE = BoxInfo.getItem('machinebuild')
DISTRO = BoxInfo.getItem('distro')
config.plugins.configurationbackup = BackupRestore_InitConfig()
def checkConfigBackup():
    partitions = [(x.description, x.mountpoint) for x in harddiskmanager.getMountedPartitions(onlyhotplug=False) if x.mountpoint!= '/']
    if BOX_TYPE in ['maram9', 'classm', 'axodin', 'axodinc', 'starsatlx', 'genius', 'evo', 'galaxym6']:
        partitions.append(('mtd backup', '/media/backup'))
    if partitions:
        for partition in partitions:
            fullBackupFile1 = pathjoin(partition[1], 'backup_%s_%s' % (DISTRO, BOX_TYPE), BACKUP_FILE)
            fullBackupFile2 = pathjoin(partition[1], 'backup', BACKUP_FILE)
            if isfile(fullBackupFile1) or isfile(fullBackupFile2):
                config.plugins.configurationbackup.backuplocation.setValue(partition[1])
                config.plugins.configurationbackup.backuplocation.save()
                config.plugins.configurationbackup.save()
                return partition
def checkBackupFile():
    backupLocation = config.plugins.configurationbackup.backuplocation.value
    fullBackupFile1 = pathjoin(backupLocation, 'backup_%s_%s' % (DISTRO, BOX_TYPE), BACKUP_FILE)
    fullBackupFile2 = pathjoin(backupLocation, 'backup', BACKUP_FILE)
    return isfile(fullBackupFile1) or isfile(fullBackupFile2)
class ImageWizard(Wizard, ShowRemoteControl):
    skin = '\n\t\t<screen name=\"ImageWizard\" position=\"0,0\" size=\"720,576\" title=\"Welcome...\" flags=\"wfNoBorder\" resolution=\"720,576\">\n\t\t\t<widget name=\"text\" position=\"153,40\" size=\"340,330\" font=\"Regular;22\" />\n\t\t\t<widget source=\"list\" render=\"Listbox\" position=\"43,340\" size=\"490,180\" scrollbarMode=\"showOnDemand\">\n\t\t\t\t<convert type=\"StringList\" />\n\t\t\t</widget>\n\t\t\t<widget name=\"config\" position=\"53,340\" zPosition=\"1\" size=\"440,180\" transparent=\"1\" scrollbarMode=\"showOnDemand\" />\n\t\t\t<widget name=\"wizard\" pixmap=\"wizard.png\" position=\"40,50\" zPosition=\"10\" size=\"110,174\" alphatest=\"on\" />\n\t\t\t<widget name=\"rc\" pixmaps=\"rc.png,rcold.png\" position=\"530,50\" zPosition=\"10\" size=\"154,500\" alphatest=\"on\" />\n\t\t\t<widget name=\"arrowdown\" pixmap=\"arrowdown.png\" position=\"-100,-100\" zPosition=\"11\" size=\"37,70\" alphatest=\"on\" />\n\t\t\t<widget name=\"arrowdown2\" pixmap=\"arrowdown.png\" position=\"-100,-100\" zPosition=\"11\" size=\"37,70\" alphatest=\"on\" />\n\t\t\t<widget name=\"arrowup\" pixmap=\"arrowup.png\" position=\"-100,-100\" zPosition=\"11\" size=\"37,70\" alphatest=\"on\" />\n\t\t\t<widget name=\"arrowup2\" pixmap=\"arrowup.png\" position=\"-100,-100\" zPosition=\"11\" size=\"37,70\" alphatest=\"on\" />\n\t\t</screen>'
    def __init__(self, session):
        self.xmlfile = resolveFilename(SCOPE_PLUGINS, 'SystemPlugins/SoftwareManager/imagewizard.xml')
        Wizard.__init__(self, session, showSteps=False, showStepSlider=False)
        ShowRemoteControl.__init__(self)
        self.session = session
        self['wizard'] = Pixmap()
        self['HelpWindow'] = Pixmap()
        self['HelpWindow'].hide()
        self.setTitle(_('ImageWizard'))
        self.selectedDevice = None
    def markDone(self):
        return
    def listDevices(self):
        partitions = [(x.description, x.mountpoint) for x in harddiskmanager.getMountedPartitions(onlyhotplug=False) if x.mountpoint!= '/']
        for partition in partitions:
            if access(partition[1], W_OK) and access(partition[1], R_OK):
                    continue
            partitions.remove(partition)
        for partition in partitions:
            if partition[1].startswith('/autofs/'):
                partitions.remove(partition)
        return partitions
    def deviceSelectionMade(self, index):
        self.deviceSelect(index)
    def deviceSelectionMoved(self):
        self.deviceSelect(self.selection)
    def deviceSelect(self, device):
        self.selectedDevice = device
        config.plugins.configurationbackup.backuplocation.setValue(self.selectedDevice)
        config.plugins.configurationbackup.backuplocation.save()
        config.plugins.configurationbackup.save()
if config.misc.firstrun.value:
    wizardManager.registerWizard(ImageWizard, 0 if checkConfigBackup() is None else 1, priority=10)