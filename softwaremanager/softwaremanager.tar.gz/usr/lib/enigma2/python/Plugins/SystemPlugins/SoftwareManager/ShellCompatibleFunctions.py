# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: '/usr/lib/enigma2/python/Plugins/SystemPlugins/SoftwareManager/ShellCompatibleFunctions.py'
# Bytecode version: 3.12.0rc2 (3531)
# Source timestamp: 2008-12-24 20:27:57 UTC (1230150477)

import subprocess
import shutil
import os
MANDATORY_RIGHTS = 'chown -R root:root /home/root /etc/auto.network /etc/default/dropbear /etc/dropbear ; chmod 600 /etc/auto.network /etc/dropbear/* /home/root/.ssh/* ; chmod 700 /home/root /home/root/.ssh'
BLACKLISTED = ['home/root/.cache', 'etc/passwd', 'etc/shadow', 'etc/group', 'etc/samba/distro', 'etc/samba/smb.conf', 'home/root/FastRestore.log', 'etc/enigma2/profile']
IMAGE_INSTALL = ['openatv-base', 'enigma2-plugin-settings-defaultsat', 'run-postinsts']
PACKAGES = '/var/lib/opkg/lists'
INSTALLEDPACKAGES = '/var/lib/opkg/status'
def backupUserDB():
    oldpasswd = ()
    oldshadow = ()
    oldgroups = ()
    neededgroups = []
    tmppasswd = []
    tmpgroups = []
    with open('/etc/passwd') as f:
        oldpasswd = f.readlines()
        oldpasswd = [x.strip() for x in oldpasswd]
    with open('/etc/shadow') as f:
        oldshadow = f.readlines()
        oldshadow = [x.strip() for x in oldshadow]
    with open('/etc/group') as f:
        oldgroups = f.readlines()
        oldgroups = [x.strip() for x in oldgroups]
    for x in oldpasswd:
        name, passwd, uid, gid, gecos, home, shell = x.split(':')
        if int(uid) < 1000 and name!= 'root' and (name!= 'kids') or name == 'nobody':
            continue
        else:
            for y in oldshadow:
                sname, spasswd, bullshit = y.split(':', 2)
                if name == sname:
                    passwd = spasswd
            for z in oldgroups:
                gname, gpasswd, ggid, bullshit = z.split(':', 3)
                if gid == ggid:
                    if gname not in neededgroups and gname!= 'root' and (gname!= 'kids') and (gname!= 'nogroup'):
                                    neededgroups.append(gname)
                    newpwd = ':'.join((name, passwd, uid, gid, gname, gecos, home, shell))
                    tmppasswd.append(newpwd)
    for x in oldgroups:
        name, rest = x.split(':', 1)
        if name in neededgroups:
            tmpgroups.append(x)
    passwdtxt = open('/tmp/passwd.txt', 'w')
    for item in tmppasswd:
        passwdtxt.write('%s\n' % item)
    passwdtxt.close()
    groupstxt = open('/tmp/groups.txt', 'w')
    for item in tmpgroups:
        groupstxt.write('%s\n' % item)
    groupstxt.close()
def restoreUserDB():
    if not os.path.isfile('/tmp/passwd.txt') or not os.path.isfile('/tmp/groups.txt'):
        return None
    else:
        oldpasswd = []
        oldgroups = []
        newpasswd = []
        newgroups = []
        takenuids = []
        takengids = []
        successusers = []
        with open('/tmp/passwd.txt') as f:
            oldpasswd = f.readlines()
            oldpasswd = [x.strip() for x in oldpasswd]
        with open('/tmp/groups.txt') as f:
            oldgroups = f.readlines()
            oldgroups = [x.strip() for x in oldgroups]
        with open('/etc/passwd') as f:
            newpasswd = f.readlines()
            for x in newpasswd:
                name, passwd, uid, gid, gecos, home, shell = x.strip().split(':')
                takenuids.append(uid)
        with open('/etc/group') as f:
            newgroups = f.readlines()
            for x in newgroups:
                name, passwd, gid, rest = x.strip().split(':', 3)
                takengids.append(gid)
        for x in oldpasswd:
            usersuccess = False
            groupsuccess = False
            oldname, oldpasswd, olduid, oldgid, oldgname, oldgecos, oldhome, oldshell = x.split(':')
            for y in newpasswd:
                if y.startswith(oldname + ':'):
                    usersuccess = True
                    groupsuccess = True
                    break
            if not usersuccess:
                groupsuccess = False
                for y in newgroups:
                    gname, gpasswd, gid, grest = y.split(':', 3)
                    if oldgname == gname:
                        groupsuccess = True
                        break
                if not groupsuccess:
                    cmd = ['/bin/busybox', 'addgroup']
                    if oldgid not in takengids:
                        cmd.append('-g' + oldgid)
                    cmd.append(oldgname)
                    try:
                        subprocess.check_call(cmd)
                        groupsuccess = True
                    except:
                        groupsuccess = False
                if groupsuccess:
                    cmd = ['/bin/busybox', 'adduser', '-H', '-D', '-G', oldgname]
                    if oldhome!= '':
                        cmd.append('-h' + oldhome)
                    if oldgecos!= '':
                        cmd.append('-g' + oldgecos)
                    if oldshell!= '':
                        cmd.append('-s' + oldshell)
                    if olduid not in takenuids:
                        cmd.append('-u' + olduid)
                    cmd.append(oldname)
                    try:
                        subprocess.check_call(cmd)
                        usersuccess = True
                    except:
                        usersuccess = False
            if usersuccess:
                successusers.append([oldname, oldpasswd])
        shadow = []
        with open('/etc/shadow') as f:
            shadow = f.readlines()
            shadow = [x.strip() for x in shadow]
        newshadowfile = open('/tmp/shadow.new', 'w')
        for x in shadow:
            name, passwd, rest = x.split(':', 2)
            for y in successusers:
                if y[0] == name:
                    passwd = y[1]
                    break
            newshadowfile.write('%s:%s:%s\n' % (name, passwd, rest))
        newshadowfile.close()
        shutil.move('/tmp/shadow.new', '/etc/shadow')
def listpkg(type='installed'):
    pkgs = []
    ret = []
    for line in open(INSTALLEDPACKAGES):
        if line.startswith('Package:'):
            package = line.split(':', 1)[1].strip()
            version = ''
            status = ''
            autoinstalled = False
        else:
            if package is None:
                continue
            else:
                if line.startswith('Version:'):
                    version = line.split(':', 1)[1].strip()
                if line.startswith('Auto-Installed:'):
                    auto = line.split(':', 1)[1].strip()
                    if auto == 'yes':
                        autoinstalled = True
                else:
                    if len(line) <= 1:
                        pkgs.append({'package': package, 'version': version, 'status': status, 'autoinstalled': autoinstalled})
                        package = None
    for package in pkgs:
        if type == 'installed':
            ret.append(package['package'])
        else:
            if type == 'auto':
                if package['autoinstalled']:
                    ret.append(package['package'])
            else:
                if type == 'user':
                    if not package['autoinstalled']:
                        if package['package'] not in IMAGE_INSTALL:
                            ret.append(package['package'])
    return sorted(ret)