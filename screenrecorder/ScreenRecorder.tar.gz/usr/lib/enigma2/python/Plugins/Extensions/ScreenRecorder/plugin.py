from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.LocationBox import LocationBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigInteger, ConfigDirectory, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from enigma import eTimer, gRGB
from Tools.Directories import fileExists
import subprocess
import signal
import time
import os
import requests
import re

PLUGIN_VERSION = "4.1.0"
VERSION_URL = "https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/screenrecorder/version.txt"
UPDATE_SCRIPT_URL = "https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/screenrecorder/installer.sh"
PID_FILE = "/tmp/screen_recorder.pid"

config.plugins.ScreenRecorder = ConfigSubsection()
config.plugins.ScreenRecorder.bitrate = ConfigInteger(default=2, limits=(1, 10))
config.plugins.ScreenRecorder.resolution = ConfigSelection(choices={
    "1280x720": "1280x720",
    "720x576": "720x576", 
    "640x480": "640x480"
}, default="1280x720")
config.plugins.ScreenRecorder.framerate = ConfigSelection(choices={
    "25": "25",
    "30": "30",
    "20": "20",
    "15": "15"
}, default="25")
config.plugins.ScreenRecorder.video_format = ConfigSelection(choices={
    "mp4": "MP4",
    "mkv": "MKV",
    "ts": "TS"
}, default="mp4")
config.plugins.ScreenRecorder.preset = ConfigSelection(choices={
    "ultrafast": "ultrafast",
    "superfast": "superfast",
    "veryfast": "veryfast",
    "medium": "medium",
    "slow": "slow"
}, default="veryfast")
config.plugins.ScreenRecorder.crf = ConfigInteger(default=28, limits=(18, 35))
config.plugins.ScreenRecorder.path = ConfigDirectory(default="/media/hdd/recordings/")

class ScreenRecorder(Screen):
    skin = """
        <screen name="ScreenRecorder" position="center,center" size="1400,850" title="E2 Screen Recorder By Emil Nabil">
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/ScreenRecorder/background.png" position="0,0" size="1400,850" zPosition="-1" />
            <widget name="status" position="200,50" size="1000,70" font="Bold;45" halign="center" valign="center" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="recording_timer" position="200,150" size="1000,70" font="Bold;50" halign="center" valign="center" foregroundColor="#FFFFFF" transparent="1"/>
            <widget name="key_menu" position="550,600" size="300,90" font="Bold;40" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#800080" transparent="0" text="Menu"/>
            <widget name="key_red" position="150,700" size="300,90" font="Bold;35" halign="center" valign="center" backgroundColor="red" text="Stop"/>
            <widget name="key_green" position="950,700" size="300,90" font="Bold;35" halign="center" valign="center" backgroundColor="green" text="Normal Recorder"/>
            <widget name="key_blue" position="550,700" size="300,90" font="Bold;35" halign="center" valign="center" backgroundColor="blue" text="Explanation Recorder"/>
        </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self["status"] = Label("Ready to record")
        self["recording_timer"] = Label("")
        self["key_red"] = Label("Stop")
        self["key_green"] = Label("Normal Recorder")
        self["key_blue"] = Label("Explanation Recorder")
        self["key_menu"] = Label("Settings")
        
        self.record_start_time = None
        self.timer = eTimer()
        self.timer.callback.append(self.updateRecordingTimer)
        self.update_timer = eTimer()
        self.update_timer.callback.append(self.checkForUpdates)

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions"],
        {
            "red": self.stopRecording,
            "green": self.startRecording,
            "blue": self.startExplanation,
            "menu": self.showSettings,
            "cancel": self.exit
        }, -2)

        self.onFirstExecBegin.append(self.startUpdateCheck)

    def startUpdateCheck(self):
        self.update_timer.start(1000, True)  # Check after 1 second

    def versionToTuple(self, version):
        try:
            version = re.sub(r'[^0-9.]', '', version)
            return tuple(map(int, version.split('.')))
        except:
            return (0, 0, 0)

    def checkForUpdates(self):
        try:
            print("[ScreenRecorder] Checking for updates...")
            response = requests.get(VERSION_URL, timeout=10)
            if response.status_code == 200:
                latest_version = response.text.strip()
                print(f"[ScreenRecorder] Current version: {PLUGIN_VERSION}, Latest version: {latest_version}")
                
                current = self.versionToTuple(PLUGIN_VERSION)
                latest = self.versionToTuple(latest_version)
                
                if latest > current:
                    message = f"New version {latest_version} available!\nCurrent version: {PLUGIN_VERSION}\nDo you want to update now?"
                    self.session.openWithCallback(self.startUpdate, MessageBox, message, MessageBox.TYPE_YESNO)
                else:
                    print("[ScreenRecorder] Plugin is up to date")
            else:
                print(f"[ScreenRecorder] Failed to check version. Status code: {response.status_code}")
        except Exception as e:
            print(f"[ScreenRecorder] Update check failed: {str(e)}")

    def startUpdate(self, answer):
        if answer:
            try:
                self.session.open(MessageBox, "Downloading update, please wait...", MessageBox.TYPE_INFO)
                
                if os.system(f"wget -q -O /tmp/updater.sh {UPDATE_SCRIPT_URL}") != 0:
                    raise Exception("Failed to download update script")
                
                os.chmod("/tmp/updater.sh", 0o755)
                os.system("/tmp/updater.sh &")
                
                self.session.open(MessageBox, "Update started. Please restart the plugin.", MessageBox.TYPE_INFO)
                self.close()
            except Exception as e:
                self.session.open(MessageBox, f"Update failed: {str(e)}", MessageBox.TYPE_ERROR)
                print(f"[ScreenRecorder] Update error: {str(e)}")

    def exit(self):
        self.close()

    def playSound(self, sound="/usr/lib/enigma2/python/Plugins/Extensions/ScreenRecorder/beep.wav"):
        if os.path.exists(sound):
            subprocess.Popen(["aplay", sound], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def get_ffmpeg_cmd(self, output_path):
        resolution = config.plugins.ScreenRecorder.resolution.value.replace("x", ":")
        cmd = [
            "/usr/bin/ffmpeg",
            "-f", "fbdev",
            "-framerate", config.plugins.ScreenRecorder.framerate.value,
            "-i", "/dev/fb0",
            "-vf", f"scale={resolution}",
            "-c:v", "libx264",
            "-preset", config.plugins.ScreenRecorder.preset.value,
            "-crf", str(config.plugins.ScreenRecorder.crf.value),
            "-b:v", f"{config.plugins.ScreenRecorder.bitrate.value}M",
            "-pix_fmt", "yuv420p",
            "-y", output_path
        ]
        return cmd

    def startRecording(self, record_type="normal"):
        if os.path.exists(PID_FILE):
            self["status"].setText("Recording already running!")
            return

        output_dir = config.plugins.ScreenRecorder.path.value
        if not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)

        timestamp = time.strftime("%Y%m%d-%H%M%S")
        output_path = os.path.join(output_dir, f"{record_type}_recording_{timestamp}.{config.plugins.ScreenRecorder.video_format.value}")

        try:
            cmd = self.get_ffmpeg_cmd(output_path)
            process = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, preexec_fn=os.setsid)
            
            with open(PID_FILE, "w") as f:
                f.write(str(process.pid))
            
            self.record_start_time = time.time()
            self.timer.start(1000)
            self.playSound()
            self["status"].setText(f"{record_type.capitalize()} recording started")
            
        except Exception as e:
            self["status"].setText(f"Error: {str(e)}")
            self.session.open(MessageBox, f"Failed to start recording:\n{str(e)}", MessageBox.TYPE_ERROR)

    def startExplanation(self):
        self.startRecording("explanation")

    def updateRecordingTimer(self):
        if self.record_start_time:
            elapsed = int(time.time() - self.record_start_time)
            mins, secs = divmod(elapsed, 60)
            self["recording_timer"].setText(f"Recording: {mins:02d}:{secs:02d}")

    def stopRecording(self):
        if not os.path.exists(PID_FILE):
            self["status"].setText("No active recording")
            return

        try:
            with open(PID_FILE, "r") as f:
                pid = int(f.read().strip())
            os.killpg(pid, signal.SIGTERM)
            os.remove(PID_FILE)
            self.timer.stop()
            self.record_start_time = None
            self["recording_timer"].setText("")
            self.playSound()
            self["status"].setText("Recording stopped")
        except Exception as e:
            self["status"].setText(f"Stop error: {str(e)}")

    def showSettings(self):
        try:
            self.session.open(ScreenRecorderSettings)
        except Exception as e:
            print(f"Error opening settings: {str(e)}")
            self["status"].setText(f"Settings error: {str(e)}")
            self.session.open(MessageBox, f"Failed to open settings:\n{str(e)}", MessageBox.TYPE_ERROR)

class ScreenRecorderSettings(ConfigListScreen, Screen):
    skin = """
        <screen name="ScreenRecorderSettings" position="center,center" size="1400,850" title="Screen Recorder Settings">
            <widget name="config" position="50,50" size="1300,600" scrollbarMode="showOnDemand" itemHeight="75"
  font="Bold;40"
  valueFont="Regular;40" />
            <widget name="key_red" position="200,700" size="300,80" font="Bold;35" halign="center" valign="center" backgroundColor="red" foregroundColor="#ffffff" transparent="0" />
            <widget name="key_green" position="900,700" size="300,80" font="Bold;35" halign="center" valign="center" backgroundColor="green" foregroundColor="#ffffff" transparent="0" />
        </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setup_title = "Screen Recorder Settings"
        
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session)
        
        self["key_red"] = Label(_("Cancel"))
        self["key_green"] = Label(_("Save"))
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
        {
            "save": self.save,
            "cancel": self.cancel,
            "ok": self.keyOk,
            "green": self.save,
            "red": self.cancel,
        }, -2)
        
        self.createSetup()

    def createSetup(self):
        self.list = [
            getConfigListEntry("Bitrate (Mbps)", config.plugins.ScreenRecorder.bitrate),
            getConfigListEntry("Resolution", config.plugins.ScreenRecorder.resolution),
            getConfigListEntry("Framerate", config.plugins.ScreenRecorder.framerate),
            getConfigListEntry("Video Format", config.plugins.ScreenRecorder.video_format),
            getConfigListEntry("Encoder Preset", config.plugins.ScreenRecorder.preset),
            getConfigListEntry("CRF Quality", config.plugins.ScreenRecorder.crf),
            getConfigListEntry("Save Location", config.plugins.ScreenRecorder.path),
        ]
        self["config"].list = self.list
        self["config"].l.setList(self.list)

    def keyOk(self):
        current = self["config"].getCurrent()
        if current and current[1] == config.plugins.ScreenRecorder.path:
            self.session.openWithCallback(
                self.pathSelected,
                LocationBox,
                "Select recording directory",
                config.plugins.ScreenRecorder.path.value
            )

    def pathSelected(self, res):
        if res is not None:
            config.plugins.ScreenRecorder.path.value = res
            config.plugins.ScreenRecorder.path.save()
            self.createSetup()

    def save(self):
        if hasattr(self, "list") and self.list:
            for x in self.list:
                x[1].save()
        self.close(True)

    def cancel(self):
        self.close(False)

def stopRecording(session, **kwargs):
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE, "r") as f:
                pid = int(f.read().strip())
            os.killpg(pid, signal.SIGTERM)
            os.remove(PID_FILE)
            session.open(MessageBox, "Recording stopped", MessageBox.TYPE_INFO)
        except Exception as e:
            session.open(MessageBox, f"Error stopping recording: {str(e)}", MessageBox.TYPE_ERROR)
    else:
        session.open(MessageBox, "No active recording", MessageBox.TYPE_INFO)

def main(session, **kwargs):
    session.open(ScreenRecorder)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Screen Recorder",
            description="Record your screen",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="Stop Recording",
            description="Stop active recording",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="stop.png",
            fnc=stopRecording
        )
    ]

