from distutils.core import setup

setup(
    name="E2ScreenRecorder",
    version="1.0",
    description="Enigma2 Screen Recorder Plugin",
    author="Emil Nabil",
    packages=["E2ScreenRecorder"],
)
