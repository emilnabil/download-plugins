#!/usr/bin/env python
# -*- coding: UTF-8 -*-

# HISNMUSLIM - حصن المسلم (عرض الأذكار اليومية)
# Version: Offline Edition (Local Database Only)

from __future__ import print_function, unicode_literals, division, absolute_import
import gettext
import os
import json
import time
import sys
import glob
import re
from os.path import dirname, join, exists
from datetime import datetime
from itertools import repeat

# Python 2/3 compatibility
PY3 = sys.version_info[0] >= 3
if PY3:
    from functools import cached_property
else:
    def cached_property(func):
        return property(func)

from enigma import getDesktop, gFont, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, addFont
from Components.ActionMap import ActionMap
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, ConfigSelection, ConfigText, ConfigInteger, NoSave
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest

UNSHAPED = 255
ISOLATED = 0
INITIAL = 1
MEDIAL = 2
FINAL = 3

TATWEEL = '\u0640'
ZWJ = '\u200D'

LETTERS_ARABIC = {
    '\u0621': ('\uFE80', '', '', ''),
    '\u0622': ('\uFE81', '', '', '\uFE82'),
    '\u0623': ('\uFE83', '', '', '\uFE84'),
    '\u0624': ('\uFE85', '', '', '\uFE86'),
    '\u0625': ('\uFE87', '', '', '\uFE88'),
    '\u0626': ('\uFE89', '\uFE8B', '\uFE8C', '\uFE8A'),
    '\u0627': ('\uFE8D', '', '', '\uFE8E'),
    '\u0628': ('\uFE8F', '\uFE91', '\uFE92', '\uFE90'),
    '\u0629': ('\uFE93', '', '', '\uFE94'),
    '\u062A': ('\uFE95', '\uFE97', '\uFE98', '\uFE96'),
    '\u062B': ('\uFE99', '\uFE9B', '\uFE9C', '\uFE9A'),
    '\u062C': ('\uFE9D', '\uFE9F', '\uFEA0', '\uFE9E'),
    '\u062D': ('\uFEA1', '\uFEA3', '\uFEA4', '\uFEA2'),
    '\u062E': ('\uFEA5', '\uFEA7', '\uFEA8', '\uFEA6'),
    '\u062F': ('\uFEA9', '', '', '\uFEAA'),
    '\u0630': ('\uFEAB', '', '', '\uFEAC'),
    '\u0631': ('\uFEAD', '', '', '\uFEAE'),
    '\u0632': ('\uFEAF', '', '', '\uFEB0'),
    '\u0633': ('\uFEB1', '\uFEB3', '\uFEB4', '\uFEB2'),
    '\u0634': ('\uFEB5', '\uFEB7', '\uFEB8', '\uFEB6'),
    '\u0635': ('\uFEB9', '\uFEBB', '\uFEBC', '\uFEBA'),
    '\u0636': ('\uFEBD', '\uFEBF', '\uFEC0', '\uFEBE'),
    '\u0637': ('\uFEC1', '\uFEC3', '\uFEC4', '\uFEC2'),
    '\u0638': ('\uFEC5', '\uFEC7', '\uFEC8', '\uFEC6'),
    '\u0639': ('\uFEC9', '\uFECB', '\uFECC', '\uFECA'),
    '\u063A': ('\uFECD', '\uFECF', '\uFED0', '\uFECE'),
    TATWEEL: (TATWEEL, TATWEEL, TATWEEL, TATWEEL),
    '\u0641': ('\uFED1', '\uFED3', '\uFED4', '\uFED2'),
    '\u0642': ('\uFED5', '\uFED7', '\uFED8', '\uFED6'),
    '\u0643': ('\uFED9', '\uFEDB', '\uFEDC', '\uFEDA'),
    '\u0644': ('\uFEDD', '\uFEDF', '\uFEE0', '\uFEDE'),
    '\u0645': ('\uFEE1', '\uFEE3', '\uFEE4', '\uFEE2'),
    '\u0646': ('\uFEE5', '\uFEE7', '\uFEE8', '\uFEE6'),
    '\u0647': ('\uFEE9', '\uFEEB', '\uFEEC', '\uFEEA'),
    '\u0648': ('\uFEED', '', '', '\uFEEE'),
    '\u0649': ('\uFEEF', '\uFBE8', '\uFBE9', '\uFEF0'),
    '\u064A': ('\uFEF1', '\uFEF3', '\uFEF4', '\uFEF2'),
    '\u0671': ('\uFB50', '', '', '\uFB51'),
    '\u0677': ('\uFBDD', '', '', ''),
    '\u0679': ('\uFB66', '\uFB68', '\uFB69', '\uFB67'),
    '\u067A': ('\uFB5E', '\uFB60', '\uFB61', '\uFB5F'),
    '\u067B': ('\uFB52', '\uFB54', '\uFB55', '\uFB53'),
    '\u067E': ('\uFB56', '\uFB58', '\uFB59', '\uFB57'),
    '\u067F': ('\uFB62', '\uFB64', '\uFB65', '\uFB63'),
    '\u0680': ('\uFB5A', '\uFB5C', '\uFB5D', '\uFB5B'),
    '\u0683': ('\uFB76', '\uFB78', '\uFB79', '\uFB77'),
    '\u0684': ('\uFB72', '\uFB74', '\uFB75', '\uFB73'),
    '\u0686': ('\uFB7A', '\uFB7C', '\uFB7D', '\uFB7B'),
    '\u0687': ('\uFB7E', '\uFB80', '\uFB81', '\uFB7F'),
    '\u0688': ('\uFB88', '', '', '\uFB89'),
    '\u068C': ('\uFB84', '', '', '\uFB85'),
    '\u068D': ('\uFB82', '', '', '\uFB83'),
    '\u068E': ('\uFB86', '', '', '\uFB87'),
    '\u0691': ('\uFB8C', '', '', '\uFB8D'),
    '\u0698': ('\uFB8A', '', '', '\uFB8B'),
    '\u06A4': ('\uFB6A', '\uFB6C', '\uFB6D', '\uFB6B'),
    '\u06A6': ('\uFB6E', '\uFB70', '\uFB71', '\uFB6F'),
    '\u06A9': ('\uFB8E', '\uFB90', '\uFB91', '\uFB8F'),
    '\u06AD': ('\uFBD3', '\uFBD5', '\uFBD6', '\uFBD4'),
    '\u06AF': ('\uFB92', '\uFB94', '\uFB95', '\uFB93'),
    '\u06B1': ('\uFB9A', '\uFB9C', '\uFB9D', '\uFB9B'),
    '\u06B3': ('\uFB96', '\uFB98', '\uFB99', '\uFB97'),
    '\u06BA': ('\uFB9E', '', '', '\uFB9F'),
    '\u06BB': ('\uFBA0', '\uFBA2', '\uFBA3', '\uFBA1'),
    '\u06BE': ('\uFBAA', '\uFBAC', '\uFBAD', '\uFBAB'),
    '\u06C0': ('\uFBA4', '', '', '\uFBA5'),
    '\u06C1': ('\uFBA6', '\uFBA8', '\uFBA9', '\uFBA7'),
    '\u06C5': ('\uFBE0', '', '', '\uFBE1'),
    '\u06C6': ('\uFBD9', '', '', '\uFBDA'),
    '\u06C7': ('\uFBD7', '', '', '\uFBD8'),
    '\u06C8': ('\uFBDB', '', '', '\uFBDC'),
    '\u06C9': ('\uFBE2', '', '', '\uFBE3'),
    '\u06CB': ('\uFBDE', '', '', '\uFBDF'),
    '\u06CC': ('\uFBFC', '\uFBFE', '\uFBFF', '\uFBFD'),
    '\u06D0': ('\uFBE4', '\uFBE6', '\uFBE7', '\uFBE5'),
    '\u06D2': ('\uFBAE', '', '', '\uFBAF'),
    '\u06D3': ('\uFBB0', '', '', '\uFBB1'),
    ZWJ: (ZWJ, ZWJ, ZWJ, ZWJ),
}

LETTERS_ARABIC_V2 = {
    '\u0621': ('\uFE80', '', '', ''),
    '\u0622': ('\u0622', '', '', '\uFE82'),
    '\u0623': ('\u0623', '', '', '\uFE84'),
    '\u0624': ('\u0624', '', '', '\uFE86'),
    '\u0625': ('\u0625', '', '', '\uFE88'),
    '\u0626': ('\u0626', '\uFE8B', '\uFE8C', '\uFE8A'),
    '\u0627': ('\u0627', '', '', '\uFE8E'),
    '\u0628': ('\u0628', '\uFE91', '\uFE92', '\uFE90'),
    '\u0629': ('\u0629', '', '', '\uFE94'),
    '\u062A': ('\u062A', '\uFE97', '\uFE98', '\uFE96'),
    '\u062B': ('\u062B', '\uFE9B', '\uFE9C', '\uFE9A'),
    '\u062C': ('\u062C', '\uFE9F', '\uFEA0', '\uFE9E'),
    '\u062D': ('\uFEA1', '\uFEA3', '\uFEA4', '\uFEA2'),
    '\u062E': ('\u062E', '\uFEA7', '\uFEA8', '\uFEA6'),
    '\u062F': ('\u062F', '', '', '\uFEAA'),
    '\u0630': ('\u0630', '', '', '\uFEAC'),
    '\u0631': ('\u0631', '', '', '\uFEAE'),
    '\u0632': ('\u0632', '', '', '\uFEB0'),
    '\u0633': ('\u0633', '\uFEB3', '\uFEB4', '\uFEB2'),
    '\u0634': ('\u0634', '\uFEB7', '\uFEB8', '\uFEB6'),
    '\u0635': ('\u0635', '\uFEBB', '\uFEBC', '\uFEBA'),
    '\u0636': ('\u0636', '\uFEBF', '\uFEC0', '\uFEBE'),
    '\u0637': ('\u0637', '\uFEC3', '\uFEC4', '\uFEC2'),
    '\u0638': ('\u0638', '\uFEC7', '\uFEC8', '\uFEC6'),
    '\u0639': ('\u0639', '\uFECB', '\uFECC', '\uFECA'),
    '\u063A': ('\u063A', '\uFECF', '\uFED0', '\uFECE'),
    TATWEEL: (TATWEEL, TATWEEL, TATWEEL, TATWEEL),
    '\u0641': ('\u0641', '\uFED3', '\uFED4', '\uFED2'),
    '\u0642': ('\u0642', '\uFED7', '\uFED8', '\uFED6'),
    '\u0643': ('\u0643', '\uFEDB', '\uFEDC', '\uFEDA'),
    '\u0644': ('\u0644', '\uFEDF', '\uFEE0', '\uFEDE'),
    '\u0645': ('\u0645', '\uFEE3', '\uFEE4', '\uFEE2'),
    '\u0646': ('\u0646', '\uFEE7', '\uFEE8', '\uFEE6'),
    '\u0647': ('\u0647', '\uFEEB', '\uFEEC', '\uFEEA'),
    '\u0648': ('\u0648', '', '', '\uFEEE'),
    '\u0649': ('\u0649', '\uFBE8', '\uFBE9', '\uFEF0'),
    '\u064A': ('\u064A', '\uFEF3', '\uFEF4', '\uFEF2'),
    '\u0671': ('\u0671', '', '', '\uFB51'),
    '\u0677': ('\u0677', '', '', ''),
    '\u0679': ('\u0679', '\uFB68', '\uFB69', '\uFB67'),
    '\u067A': ('\u067A', '\uFB60', '\uFB61', '\uFB5F'),
    '\u067B': ('\u067B', '\uFB54', '\uFB55', '\uFB53'),
    '\u067E': ('\u067E', '\uFB58', '\uFB59', '\uFB57'),
    '\u067F': ('\u067F', '\uFB64', '\uFB65', '\uFB63'),
    '\u0680': ('\u0680', '\uFB5C', '\uFB5D', '\uFB5B'),
    '\u0683': ('\u0683', '\uFB78', '\uFB79', '\uFB77'),
    '\u0684': ('\u0684', '\uFB74', '\uFB75', '\uFB73'),
    '\u0686': ('\u0686', '\uFB7C', '\uFB7D', '\uFB7B'),
    '\u0687': ('\u0687', '\uFB80', '\uFB81', '\uFB7F'),
    '\u0688': ('\u0688', '', '', '\uFB89'),
    '\u068C': ('\u068C', '', '', '\uFB85'),
    '\u068D': ('\u068D', '', '', '\uFB83'),
    '\u068E': ('\u068E', '', '', '\uFB87'),
    '\u0691': ('\u0691', '', '', '\uFB8D'),
    '\u0698': ('\u0698', '', '', '\uFB8B'),
    '\u06A4': ('\u06A4', '\uFB6C', '\uFB6D', '\uFB6B'),
    '\u06A6': ('\u06A6', '\uFB70', '\uFB71', '\uFB6F'),
    '\u06A9': ('\u06A9', '\uFB90', '\uFB91', '\uFB8F'),
    '\u06AD': ('\u06AD', '\uFBD5', '\uFBD6', '\uFBD4'),
    '\u06AF': ('\u06AF', '\uFB94', '\uFB95', '\uFB93'),
    '\u06B1': ('\u06B1', '\uFB9C', '\uFB9D', '\uFB9B'),
    '\u06B3': ('\u06B3', '\uFB98', '\uFB99', '\uFB97'),
    '\u06BA': ('\u06BA', '', '', '\uFB9F'),
    '\u06BB': ('\u06BB', '\uFBA2', '\uFBA3', '\uFBA1'),
    '\u06BE': ('\u06BE', '\uFBAC', '\uFBAD', '\uFBAB'),
    '\u06C0': ('\u06C0', '', '', '\uFBA5'),
    '\u06C1': ('\u06C1', '\uFBA8', '\uFBA9', '\uFBA7'),
    '\u06C5': ('\u06C5', '', '', '\uFBE1'),
    '\u06C6': ('\u06C6', '', '', '\uFBDA'),
    '\u06C7': ('\u06C7', '', '', '\uFBD8'),
    '\u06C8': ('\u06C8', '', '', '\uFBDC'),
    '\u06C9': ('\u06C9', '', '', '\uFBE3'),
    '\u06CB': ('\u06CB', '', '', '\uFBDF'),
    '\u06CC': ('\u06CC', '\uFBFE', '\uFBFF', '\uFBFD'),
    '\u06D0': ('\u06D0', '\uFBE6', '\uFBE7', '\uFBE5'),
    '\u06D2': ('\u06D2', '', '', '\uFBAF'),
    '\u06D3': ('\u06D3', '', '', '\uFBB1'),
    '\u06ce': ('\uE004', '\uE005', '\uE006', '\uE004'),
    '\u06d5': ('\u06d5', '', '', '\uE000'),
    ZWJ: (ZWJ, ZWJ, ZWJ, ZWJ),
}

LETTERS_KURDISH = {
    '\u0621': ('\uFE80', '', '', ''),
    '\u0622': ('\u0622', '', '', '\uFE82'),
    '\u0623': ('\u0623', '', '', '\uFE84'),
    '\u0624': ('\u0624', '', '', '\uFE86'),
    '\u0625': ('\u0625', '', '', '\uFE88'),
    '\u0626': ('\u0626', '\uFE8B', '\uFE8C', '\uFE8A'),
    '\u0627': ('\u0627', '', '', '\uFE8E'),
    '\u0628': ('\u0628', '\uFE91', '\uFE92', '\uFE90'),
    '\u0629': ('\u0629', '', '', '\uFE94'),
    '\u062A': ('\u062A', '\uFE97', '\uFE98', '\uFE96'),
    '\u062B': ('\u062B', '\uFE9B', '\uFE9C', '\uFE9A'),
    '\u062C': ('\u062C', '\uFE9F', '\uFEA0', '\uFE9E'),
    '\u062D': ('\uFEA1', '\uFEA3', '\uFEA4', '\uFEA2'),
    '\u062E': ('\u062E', '\uFEA7', '\uFEA8', '\uFEA6'),
    '\u062F': ('\u062F', '', '', '\uFEAA'),
    '\u0630': ('\u0630', '', '', '\uFEAC'),
    '\u0631': ('\u0631', '', '', '\uFEAE'),
    '\u0632': ('\u0632', '', '', '\uFEB0'),
    '\u0633': ('\u0633', '\uFEB3', '\uFEB4', '\uFEB2'),
    '\u0634': ('\u0634', '\uFEB7', '\uFEB8', '\uFEB6'),
    '\u0635': ('\u0635', '\uFEBB', '\uFEBC', '\uFEBA'),
    '\u0636': ('\u0636', '\uFEBF', '\uFEC0', '\uFEBE'),
    '\u0637': ('\u0637', '\uFEC3', '\uFEC4', '\uFEC2'),
    '\u0638': ('\u0638', '\uFEC7', '\uFEC8', '\uFEC6'),
    '\u0639': ('\u0639', '\uFECB', '\uFECC', '\uFECA'),
    '\u063A': ('\u063A', '\uFECF', '\uFED0', '\uFECE'),
    TATWEEL: (TATWEEL, TATWEEL, TATWEEL, TATWEEL),
    '\u0641': ('\u0641', '\uFED3', '\uFED4', '\uFED2'),
    '\u0642': ('\u0642', '\uFED7', '\uFED8', '\uFED6'),
    '\u0643': ('\u0643', '\uFEDB', '\uFEDC', '\uFEDA'),
    '\u0644': ('\u0644', '\uFEDF', '\uFEE0', '\uFEDE'),
    '\u0645': ('\u0645', '\uFEE3', '\uFEE4', '\uFEE2'),
    '\u0646': ('\u0646', '\uFEE7', '\uFEE8', '\uFEE6'),
    '\u0647': ('\uFBAB', '\uFBAB', '\uFBAB', '\uFBAB'),
    '\u0648': ('\u0648', '', '', '\uFEEE'),
    '\u0649': ('\u0649', '\uFBE8', '\uFBE9', '\uFEF0'),
    '\u064A': ('\u064A', '\uFEF3', '\uFEF4', '\uFEF2'),
    '\u0671': ('\u0671', '', '', '\uFB51'),
    '\u0677': ('\u0677', '', '', ''),
    '\u0679': ('\u0679', '\uFB68', '\uFB69', '\uFB67'),
    '\u067A': ('\u067A', '\uFB60', '\uFB61', '\uFB5F'),
    '\u067B': ('\u067B', '\uFB54', '\uFB55', '\uFB53'),
    '\u067E': ('\u067E', '\uFB58', '\uFB59', '\uFB57'),
    '\u067F': ('\u067F', '\uFB64', '\uFB65', '\uFB63'),
    '\u0680': ('\u0680', '\uFB5C', '\uFB5D', '\uFB5B'),
    '\u0683': ('\u0683', '\uFB78', '\uFB79', '\uFB77'),
    '\u0684': ('\u0684', '\uFB74', '\uFB75', '\uFB73'),
    '\u0686': ('\u0686', '\uFB7C', '\uFB7D', '\uFB7B'),
    '\u0687': ('\u0687', '\uFB80', '\uFB81', '\uFB7F'),
    '\u0688': ('\u0688', '', '', '\uFB89'),
    '\u068C': ('\u068C', '', '', '\uFB85'),
    '\u068D': ('\u068D', '', '', '\uFB83'),
    '\u068E': ('\u068E', '', '', '\uFB87'),
    '\u0691': ('\u0691', '', '', '\uFB8D'),
    '\u0698': ('\u0698', '', '', '\uFB8B'),
    '\u06A4': ('\u06A4', '\uFB6C', '\uFB6D', '\uFB6B'),
    '\u06A6': ('\u06A6', '\uFB70', '\uFB71', '\uFB6F'),
    '\u06A9': ('\u06A9', '\uFB90', '\uFB91', '\uFB8F'),
    '\u06AD': ('\u06AD', '\uFBD5', '\uFBD6', '\uFBD4'),
    '\u06AF': ('\u06AF', '\uFB94', '\uFB95', '\uFB93'),
    '\u06B1': ('\u06B1', '\uFB9C', '\uFB9D', '\uFB9B'),
    '\u06B3': ('\u06B3', '\uFB98', '\uFB99', '\uFB97'),
    '\u06BA': ('\u06BA', '', '', '\uFB9F'),
    '\u06BB': ('\u06BB', '\uFBA2', '\uFBA3', '\uFBA1'),
    '\u06BE': ('\u06BE', '\uFBAC', '\uFBAD', '\uFBAB'),
    '\u06C0': ('\u06C0', '', '', '\uFBA5'),
    '\u06C1': ('\u06C1', '\uFBA8', '\uFBA9', '\uFBA7'),
    '\u06C5': ('\u06C5', '', '', '\uFBE1'),
    '\u06C6': ('\u06C6', '', '', '\uFBDA'),
    '\u06C7': ('\u06C7', '', '', '\uFBD8'),
    '\u06C8': ('\u06C8', '', '', '\uFBDC'),
    '\u06C9': ('\u06C9', '', '', '\uFBE3'),
    '\u06CB': ('\u06CB', '', '', '\uFBDF'),
    '\u06CC': ('\u06CC', '\uFBFE', '\uFBFF', '\uFBFD'),
    '\u06D0': ('\u06D0', '\uFBE6', '\uFBE7', '\uFBE5'),
    '\u06D2': ('\u06D2', '', '', '\uFBAF'),
    '\u06D3': ('\u06D3', '', '', '\uFBB1'),
    '\u06ce': ('\uE004', '\uE005', '\uE006', '\uE004'),
    '\u06d5': ('\u06d5', '', '', '\uE000'),
    ZWJ: (ZWJ, ZWJ, ZWJ, ZWJ),
}

def connects_with_letter_before(letter, letters):
    if letter not in letters:
        return False
    forms = letters[letter]
    return forms[FINAL] or forms[MEDIAL]

def connects_with_letter_after(letter, letters):
    if letter not in letters:
        return False
    forms = letters[letter]
    return forms[INITIAL] or forms[MEDIAL]

def connects_with_letters_before_and_after(letter, letters):
    if letter not in letters:
        return False
    forms = letters[letter]
    return forms[MEDIAL]

from itertools import chain

SENTENCES_LIGATURES = (
    ('ARABIC LIGATURE BISMILLAH AR-RAHMAN AR-RAHEEM', (
        '\u0628\u0633\u0645\u0020\u0627\u0644\u0644\u0647\u0020\u0627\u0644\u0631\u062D\u0645\u0646\u0020\u0627\u0644\u0631\u062D\u064A\u0645',
        ('\uFDFD', '', '', '')
    )),
    ('ARABIC LIGATURE JALLAJALALOUHOU', ('\u062C\u0644\u0020\u062C\u0644\u0627\u0644\u0647', ('\uFDFB', '', '', ''))),
    ('ARABIC LIGATURE SALLALLAHOU ALAYHE WASALLAM', ('\u0635\u0644\u0649\u0020\u0627\u0644\u0644\u0647\u0020\u0639\u0644\u064A\u0647\u0020\u0648\u0633\u0644\u0645', ('\uFDFA', '', '', ''))),
)

WORDS_LIGATURES = (
    ('ARABIC LIGATURE ALLAH', ('\u0627\u0644\u0644\u0647', ('\uFDF2', '', '', ''))),
    ('ARABIC LIGATURE AKBAR', ('\u0623\u0643\u0628\u0631', ('\uFDF3', '', '', ''))),
    ('ARABIC LIGATURE ALAYHE', ('\u0639\u0644\u064A\u0647', ('\uFDF7', '', '', ''))),
    ('ARABIC LIGATURE MOHAMMAD', ('\u0645\u062D\u0645\u062F', ('\uFDF4', '', '', ''))),
    ('ARABIC LIGATURE RASOUL', ('\u0631\u0633\u0648\u0644', ('\uFDF6', '', '', ''))),
    ('ARABIC LIGATURE SALAM', ('\u0635\u0644\u0639\u0645', ('\uFDF5', '', '', ''))),
    ('ARABIC LIGATURE SALLA', ('\u0635\u0644\u0649', ('\uFDF9', '', '', ''))),
    ('ARABIC LIGATURE WASALLAM', ('\u0648\u0633\u0644\u0645', ('\uFDF8', '', '', ''))),
    ('RIAL SIGN', ('\u0631[\u06CC\u064A]\u0627\u0644', ('\uFDFC', '', '', ''))),
)

LETTERS_LIGATURES = (
    ('ARABIC LIGATURE AIN WITH ALEF MAKSURA', ('\u0639\u0649', ('\uFCF7', '', '', '\uFD13'))),
    ('ARABIC LIGATURE AIN WITH JEEM', ('\u0639\u062C', ('\uFC29', '\uFCBA', '', ''))),
    ('ARABIC LIGATURE AIN WITH JEEM WITH MEEM', ('\u0639\u062C\u0645', ('', '\uFDC4', '', '\uFD75'))),
    ('ARABIC LIGATURE AIN WITH MEEM', ('\u0639\u0645', ('\uFC2A', '\uFCBB', '', ''))),
    ('ARABIC LIGATURE AIN WITH MEEM WITH ALEF MAKSURA', ('\u0639\u0645\u0649', ('', '', '', '\uFD78'))),
    ('ARABIC LIGATURE AIN WITH MEEM WITH MEEM', ('\u0639\u0645\u0645', ('', '\uFD77', '', '\uFD76'))),
    ('ARABIC LIGATURE AIN WITH MEEM WITH YEH', ('\u0639\u0645\u064A', ('', '', '', '\uFDB6'))),
    ('ARABIC LIGATURE AIN WITH YEH', ('\u0639\u064A', ('\uFCF8', '', '', '\uFD14'))),
    ('ARABIC LIGATURE ALEF MAKSURA WITH SUPERSCRIPT ALEF', ('\u0649\u0670', ('\uFC5D', '', '', '\uFC90'))),
    ('ARABIC LIGATURE ALEF WITH FATHATAN', ('\u0627\u064B', ('\uFD3D', '', '', '\uFD3C'))),
    ('ARABIC LIGATURE BEH WITH ALEF MAKSURA', ('\u0628\u0649', ('\uFC09', '', '', '\uFC6E'))),
    ('ARABIC LIGATURE BEH WITH HAH', ('\u0628\u062D', ('\uFC06', '\uFC9D', '', ''))),
    ('ARABIC LIGATURE BEH WITH HAH WITH YEH', ('\u0628\u062D\u064A', ('', '', '', '\uFDC2'))),
    ('ARABIC LIGATURE BEH WITH HEH', ('\u0628\u0647', ('', '\uFCA0', '\uFCE2', ''))),
    ('ARABIC LIGATURE BEH WITH JEEM', ('\u0628\u062C', ('\uFC05', '\uFC9C', '', ''))),
    ('ARABIC LIGATURE BEH WITH KHAH', ('\u0628\u062E', ('\uFC07', '\uFC9E', '', ''))),
    ('ARABIC LIGATURE BEH WITH KHAH WITH YEH', ('\u0628\u062E\u064A', ('', '', '', '\uFD9E'))),
    ('ARABIC LIGATURE BEH WITH MEEM', ('\u0628\u0645', ('\uFC08', '\uFC9F', '\uFCE1', '\uFC6C'))),
    ('ARABIC LIGATURE BEH WITH NOON', ('\u0628\u0646', ('', '', '', '\uFC6D'))),
    ('ARABIC LIGATURE BEH WITH REH', ('\u0628\u0631', ('', '', '', '\uFC6A'))),
    ('ARABIC LIGATURE BEH WITH YEH', ('\u0628\u064A', ('\uFC0A', '', '', '\uFC6F'))),
    ('ARABIC LIGATURE BEH WITH ZAIN', ('\u0628\u0632', ('', '', '', '\uFC6B'))),
    ('ARABIC LIGATURE DAD WITH ALEF MAKSURA', ('\u0636\u0649', ('\uFD07', '', '', '\uFD23'))),
    ('ARABIC LIGATURE DAD WITH HAH', ('\u0636\u062D', ('\uFC23', '\uFCB5', '', ''))),
    ('ARABIC LIGATURE DAD WITH HAH WITH ALEF MAKSURA', ('\u0636\u062D\u0649', ('', '', '', '\uFD6E'))),
    ('ARABIC LIGATURE DAD WITH HAH WITH YEH', ('\u0636\u062D\u064A', ('', '', '', '\uFDAB'))),
    ('ARABIC LIGATURE DAD WITH JEEM', ('\u0636\u062C', ('\uFC22', '\uFCB4', '', ''))),
    ('ARABIC LIGATURE DAD WITH KHAH', ('\u0636\u062E', ('\uFC24', '\uFCB6', '', ''))),
    ('ARABIC LIGATURE DAD WITH KHAH WITH MEEM', ('\u0636\u062E\u0645', ('', '\uFD70', '', '\uFD6F'))),
    ('ARABIC LIGATURE DAD WITH MEEM', ('\u0636\u0645', ('\uFC25', '\uFCB7', '', ''))),
    ('ARABIC LIGATURE DAD WITH REH', ('\u0636\u0631', ('\uFD10', '', '', '\uFD2C'))),
    ('ARABIC LIGATURE DAD WITH YEH', ('\u0636\u064A', ('\uFD08', '', '', '\uFD24'))),
    ('ARABIC LIGATURE FEH WITH ALEF MAKSURA', ('\u0641\u0649', ('\uFC31', '', '', '\uFC7C'))),
    ('ARABIC LIGATURE FEH WITH HAH', ('\u0641\u062D', ('\uFC2E', '\uFCBF', '', ''))),
    ('ARABIC LIGATURE FEH WITH JEEM', ('\u0641\u062C', ('\uFC2D', '\uFCBE', '', ''))),
    ('ARABIC LIGATURE FEH WITH KHAH', ('\u0641\u062E', ('\uFC2F', '\uFCC0', '', ''))),
    ('ARABIC LIGATURE FEH WITH KHAH WITH MEEM', ('\u0641\u062E\u0645', ('', '\uFD7D', '', '\uFD7C'))),
    ('ARABIC LIGATURE FEH WITH MEEM', ('\u0641\u0645', ('\uFC30', '\uFCC1', '', ''))),
    ('ARABIC LIGATURE FEH WITH MEEM WITH YEH', ('\u0641\u0645\u064A', ('', '', '', '\uFDC1'))),
    ('ARABIC LIGATURE FEH WITH YEH', ('\u0641\u064A', ('\uFC32', '', '', '\uFC7D'))),
    ('ARABIC LIGATURE GHAIN WITH ALEF MAKSURA', ('\u063A\u0649', ('\uFCF9', '', '', '\uFD15'))),
    ('ARABIC LIGATURE GHAIN WITH JEEM', ('\u063A\u062C', ('\uFC2B', '\uFCBC', '', ''))),
    ('ARABIC LIGATURE GHAIN WITH MEEM', ('\u063A\u0645', ('\uFC2C', '\uFCBD', '', ''))),
    ('ARABIC LIGATURE GHAIN WITH MEEM WITH ALEF MAKSURA', ('\u063A\u0645\u0649', ('', '', '', '\uFD7B'))),
    ('ARABIC LIGATURE GHAIN WITH MEEM WITH MEEM', ('\u063A\u0645\u0645', ('', '', '', '\uFD79'))),
    ('ARABIC LIGATURE GHAIN WITH MEEM WITH YEH', ('\u063A\u0645\u064A', ('', '', '', '\uFD7A'))),
    ('ARABIC LIGATURE GHAIN WITH YEH', ('\u063A\u064A', ('\uFCFA', '', '', '\uFD16'))),
    ('ARABIC LIGATURE HAH WITH ALEF MAKSURA', ('\u062D\u0649', ('\uFCFF', '', '', '\uFD1B'))),
    ('ARABIC LIGATURE HAH WITH JEEM', ('\u062D\u062C', ('\uFC17', '\uFCA9', '', ''))),
    ('ARABIC LIGATURE HAH WITH JEEM WITH YEH', ('\u062D\u062C\u064A', ('', '', '', '\uFDBF'))),
    ('ARABIC LIGATURE HAH WITH MEEM', ('\u062D\u0645', ('\uFC18', '\uFCAA', '', ''))),
    ('ARABIC LIGATURE HAH WITH MEEM WITH ALEF MAKSURA', ('\u062D\u0645\u0649', ('', '', '', '\uFD5B'))),
    ('ARABIC LIGATURE HAH WITH MEEM WITH YEH', ('\u062D\u0645\u064A', ('', '', '', '\uFD5A'))),
    ('ARABIC LIGATURE HAH WITH YEH', ('\u062D\u064A', ('\uFD00', '', '', '\uFD1C'))),
    ('ARABIC LIGATURE HEH WITH ALEF MAKSURA', ('\u0647\u0649', ('\uFC53', '', '', ''))),
    ('ARABIC LIGATURE HEH WITH JEEM', ('\u0647\u062C', ('\uFC51', '\uFCD7', '', ''))),
    ('ARABIC LIGATURE HEH WITH MEEM', ('\u0647\u0645', ('\uFC52', '\uFCD8', '', ''))),
    ('ARABIC LIGATURE HEH WITH MEEM WITH JEEM', ('\u0647\u0645\u062C', ('', '\uFD93', '', ''))),
    ('ARABIC LIGATURE HEH WITH MEEM WITH MEEM', ('\u0647\u0645\u0645', ('', '\uFD94', '', ''))),
    ('ARABIC LIGATURE HEH WITH SUPERSCRIPT ALEF', ('\u0647\u0670', ('', '\uFCD9', '', ''))),
    ('ARABIC LIGATURE HEH WITH YEH', ('\u0647\u064A', ('\uFC54', '', '', ''))),
    ('ARABIC LIGATURE JEEM WITH ALEF MAKSURA', ('\u062C\u0649', ('\uFD01', '', '', '\uFD1D'))),
    ('ARABIC LIGATURE JEEM WITH HAH', ('\u062C\u062D', ('\uFC15', '\uFCA7', '', ''))),
    ('ARABIC LIGATURE JEEM WITH HAH WITH ALEF MAKSURA', ('\u062C\u062D\u0649', ('', '', '', '\uFDA6'))),
    ('ARABIC LIGATURE JEEM WITH HAH WITH YEH', ('\u062C\u062D\u064A', ('', '', '', '\uFDBE'))),
    ('ARABIC LIGATURE JEEM WITH MEEM', ('\u062C\u0645', ('\uFC16', '\uFCA8', '', ''))),
    ('ARABIC LIGATURE JEEM WITH MEEM WITH ALEF MAKSURA', ('\u062C\u0645\u0649', ('', '', '', '\uFDA7'))),
    ('ARABIC LIGATURE JEEM WITH MEEM WITH HAH', ('\u062C\u0645\u062D', ('', '\uFD59', '', '\uFD58'))),
    ('ARABIC LIGATURE JEEM WITH MEEM WITH YEH', ('\u062C\u0645\u064A', ('', '', '', '\uFDA5'))),
    ('ARABIC LIGATURE JEEM WITH YEH', ('\u062C\u064A', ('\uFD02', '', '', '\uFD1E'))),
    ('ARABIC LIGATURE KAF WITH ALEF', ('\u0643\u0627', ('\uFC37', '', '', '\uFC80'))),
    ('ARABIC LIGATURE KAF WITH ALEF MAKSURA', ('\u0643\u0649', ('\uFC3D', '', '', '\uFC83'))),
    ('ARABIC LIGATURE KAF WITH HAH', ('\u0643\u062D', ('\uFC39', '\uFCC5', '', ''))),
    ('ARABIC LIGATURE KAF WITH JEEM', ('\u0643\u062C', ('\uFC38', '\uFCC4', '', ''))),
    ('ARABIC LIGATURE KAF WITH KHAH', ('\u0643\u062E', ('\uFC3A', '\uFCC6', '', ''))),
    ('ARABIC LIGATURE KAF WITH LAM', ('\u0643\u0644', ('\uFC3B', '\uFCC7', '\uFCEB', '\uFC81'))),
    ('ARABIC LIGATURE KAF WITH MEEM', ('\u0643\u0645', ('\uFC3C', '\uFCC8', '\uFCEC', '\uFC82'))),
    ('ARABIC LIGATURE KAF WITH MEEM WITH MEEM', ('\u0643\u0645\u0645', ('', '\uFDC3', '', '\uFDBB'))),
    ('ARABIC LIGATURE KAF WITH MEEM WITH YEH', ('\u0643\u0645\u064A', ('', '', '', '\uFDB7'))),
    ('ARABIC LIGATURE KAF WITH YEH', ('\u0643\u064A', ('\uFC3E', '', '', '\uFC84'))),
    ('ARABIC LIGATURE KHAH WITH ALEF MAKSURA', ('\u062E\u0649', ('\uFD03', '', '', '\uFD1F'))),
    ('ARABIC LIGATURE KHAH WITH HAH', ('\u062E\u062D', ('\uFC1A', '', '', ''))),
    ('ARABIC LIGATURE KHAH WITH JEEM', ('\u062E\u062C', ('\uFC19', '\uFCAB', '', ''))),
    ('ARABIC LIGATURE KHAH WITH MEEM', ('\u062E\u0645', ('\uFC1B', '\uFCAC', '', ''))),
    ('ARABIC LIGATURE KHAH WITH YEH', ('\u062E\u064A', ('\uFD04', '', '', '\uFD20'))),
    ('ARABIC LIGATURE LAM WITH ALEF', ('\u0644\u0627', ('\uFEFB', '', '', '\uFEFC'))),
    ('ARABIC LIGATURE LAM WITH ALEF MAKSURA', ('\u0644\u0649', ('\uFC43', '', '', '\uFC86'))),
    ('ARABIC LIGATURE LAM WITH ALEF WITH HAMZA ABOVE', ('\u0644\u0623', ('\uFEF7', '', '', '\uFEF8'))),
    ('ARABIC LIGATURE LAM WITH ALEF WITH HAMZA BELOW', ('\u0644\u0625', ('\uFEF9', '', '', '\uFEFA'))),
    ('ARABIC LIGATURE LAM WITH ALEF WITH MADDA ABOVE', ('\u0644\u0622', ('\uFEF5', '', '', '\uFEF6'))),
    ('ARABIC LIGATURE LAM WITH HAH', ('\u0644\u062D', ('\uFC40', '\uFCCA', '', ''))),
    ('ARABIC LIGATURE LAM WITH HAH WITH ALEF MAKSURA', ('\u0644\u062D\u0649', ('', '', '', '\uFD82'))),
    ('ARABIC LIGATURE LAM WITH HAH WITH MEEM', ('\u0644\u062D\u0645', ('', '\uFDB5', '', '\uFD80'))),
    ('ARABIC LIGATURE LAM WITH HAH WITH YEH', ('\u0644\u062D\u064A', ('', '', '', '\uFD81'))),
    ('ARABIC LIGATURE LAM WITH HEH', ('\u0644\u0647', ('', '\uFCCD', '', ''))),
    ('ARABIC LIGATURE LAM WITH JEEM', ('\u0644\u062C', ('\uFC3F', '\uFCC9', '', ''))),
    ('ARABIC LIGATURE LAM WITH JEEM WITH JEEM', ('\u0644\u062C\u062C', ('', '\uFD83', '', '\uFD84'))),
    ('ARABIC LIGATURE LAM WITH JEEM WITH MEEM', ('\u0644\u062C\u0645', ('', '\uFDBA', '', '\uFDBC'))),
    ('ARABIC LIGATURE LAM WITH JEEM WITH YEH', ('\u0644\u062C\u064A', ('', '', '', '\uFDAC'))),
    ('ARABIC LIGATURE LAM WITH KHAH', ('\u0644\u062E', ('\uFC41', '\uFCCB', '', ''))),
    ('ARABIC LIGATURE LAM WITH KHAH WITH MEEM', ('\u0644\u062E\u0645', ('', '\uFD86', '', '\uFD85'))),
    ('ARABIC LIGATURE LAM WITH MEEM', ('\u0644\u0645', ('\uFC42', '\uFCCC', '\uFCED', '\uFC85'))),
    ('ARABIC LIGATURE LAM WITH MEEM WITH HAH', ('\u0644\u0645\u062D', ('', '\uFD88', '', '\uFD87'))),
    ('ARABIC LIGATURE LAM WITH MEEM WITH YEH', ('\u0644\u0645\u064A', ('', '', '', '\uFDAD'))),
    ('ARABIC LIGATURE LAM WITH YEH', ('\u0644\u064A', ('\uFC44', '', '', '\uFC87'))),
    ('ARABIC LIGATURE MEEM WITH ALEF', ('\u0645\u0627', ('', '', '', '\uFC88'))),
    ('ARABIC LIGATURE MEEM WITH ALEF MAKSURA', ('\u0645\u0649', ('\uFC49', '', '', ''))),
    ('ARABIC LIGATURE MEEM WITH HAH', ('\u0645\u062D', ('\uFC46', '\uFCCF', '', ''))),
    ('ARABIC LIGATURE MEEM WITH HAH WITH JEEM', ('\u0645\u062D\u062C', ('', '\uFD89', '', ''))),
    ('ARABIC LIGATURE MEEM WITH HAH WITH MEEM', ('\u0645\u062D\u0645', ('', '\uFD8A', '', ''))),
    ('ARABIC LIGATURE MEEM WITH HAH WITH YEH', ('\u0645\u062D\u064A', ('', '', '', '\uFD8B'))),
    ('ARABIC LIGATURE MEEM WITH JEEM', ('\u0645\u062C', ('\uFC45', '\uFCCE', '', ''))),
    ('ARABIC LIGATURE MEEM WITH JEEM WITH HAH', ('\u0645\u062C\u062D', ('', '\uFD8C', '', ''))),
    ('ARABIC LIGATURE MEEM WITH JEEM WITH KHAH', ('\u0645\u062C\u062E', ('', '\uFD92', '', ''))),
    ('ARABIC LIGATURE MEEM WITH JEEM WITH MEEM', ('\u0645\u062C\u0645', ('', '\uFD8D', '', ''))),
    ('ARABIC LIGATURE MEEM WITH JEEM WITH YEH', ('\u0645\u062C\u064A', ('', '', '', '\uFDC0'))),
    ('ARABIC LIGATURE MEEM WITH KHAH', ('\u0645\u062E', ('\uFC47', '\uFCD0', '', ''))),
    ('ARABIC LIGATURE MEEM WITH KHAH WITH JEEM', ('\u0645\u062E\u062C', ('', '\uFD8E', '', ''))),
    ('ARABIC LIGATURE MEEM WITH KHAH WITH MEEM', ('\u0645\u062E\u0645', ('', '\uFD8F', '', ''))),
    ('ARABIC LIGATURE MEEM WITH KHAH WITH YEH', ('\u0645\u062E\u064A', ('', '', '', '\uFDB9'))),
    ('ARABIC LIGATURE MEEM WITH MEEM', ('\u0645\u0645', ('\uFC48', '\uFCD1', '', '\uFC89'))),
    ('ARABIC LIGATURE MEEM WITH MEEM WITH YEH', ('\u0645\u0645\u064A', ('', '', '', '\uFDB1'))),
    ('ARABIC LIGATURE MEEM WITH YEH', ('\u0645\u064A', ('\uFC4A', '', '', ''))),
    ('ARABIC LIGATURE NOON WITH ALEF MAKSURA', ('\u0646\u0649', ('\uFC4F', '', '', '\uFC8E'))),
    ('ARABIC LIGATURE NOON WITH HAH', ('\u0646\u062D', ('\uFC4C', '\uFCD3', '', ''))),
    ('ARABIC LIGATURE NOON WITH HAH WITH ALEF MAKSURA', ('\u0646\u062D\u0649', ('', '', '', '\uFD96'))),
    ('ARABIC LIGATURE NOON WITH HAH WITH MEEM', ('\u0646\u062D\u0645', ('', '\uFD95', '', ''))),
    ('ARABIC LIGATURE NOON WITH HAH WITH YEH', ('\u0646\u062D\u064A', ('', '', '', '\uFDB3'))),
    ('ARABIC LIGATURE NOON WITH HEH', ('\u0646\u0647', ('', '\uFCD6', '\uFCEF', ''))),
    ('ARABIC LIGATURE NOON WITH JEEM', ('\u0646\u062C', ('\uFC4B', '\uFCD2', '', ''))),
    ('ARABIC LIGATURE NOON WITH JEEM WITH ALEF MAKSURA', ('\u0646\u062C\u0649', ('', '', '', '\uFD99'))),
    ('ARABIC LIGATURE NOON WITH JEEM WITH HAH', ('\u0646\u062C\u062D', ('', '\uFDB8', '', '\uFDBD'))),
    ('ARABIC LIGATURE NOON WITH JEEM WITH MEEM', ('\u0646\u062C\u0645', ('', '\uFD98', '', '\uFD97'))),
    ('ARABIC LIGATURE NOON WITH JEEM WITH YEH', ('\u0646\u062C\u064A', ('', '', '', '\uFDC7'))),
    ('ARABIC LIGATURE NOON WITH KHAH', ('\u0646\u062E', ('\uFC4D', '\uFCD4', '', ''))),
    ('ARABIC LIGATURE NOON WITH MEEM', ('\u0646\u0645', ('\uFC4E', '\uFCD5', '\uFCEE', '\uFC8C'))),
    ('ARABIC LIGATURE NOON WITH MEEM WITH ALEF MAKSURA', ('\u0646\u0645\u0649', ('', '', '', '\uFD9B'))),
    ('ARABIC LIGATURE NOON WITH MEEM WITH YEH', ('\u0646\u0645\u064A', ('', '', '', '\uFD9A'))),
    ('ARABIC LIGATURE NOON WITH NOON', ('\u0646\u0646', ('', '', '', '\uFC8D'))),
    ('ARABIC LIGATURE NOON WITH REH', ('\u0646\u0631', ('', '', '', '\uFC8A'))),
    ('ARABIC LIGATURE NOON WITH YEH', ('\u0646\u064A', ('\uFC50', '', '', '\uFC8F'))),
    ('ARABIC LIGATURE NOON WITH ZAIN', ('\u0646\u0632', ('', '', '', '\uFC8B'))),
    ('ARABIC LIGATURE QAF WITH ALEF MAKSURA', ('\u0642\u0649', ('\uFC35', '', '', '\uFC7E'))),
    ('ARABIC LIGATURE QAF WITH HAH', ('\u0642\u062D', ('\uFC33', '\uFCC2', '', ''))),
    ('ARABIC LIGATURE QAF WITH MEEM', ('\u0642\u0645', ('\uFC34', '\uFCC3', '', ''))),
    ('ARABIC LIGATURE QAF WITH MEEM WITH HAH', ('\u0642\u0645\u062D', ('', '\uFDB4', '', '\uFD7E'))),
    ('ARABIC LIGATURE QAF WITH MEEM WITH MEEM', ('\u0642\u0645\u0645', ('', '', '', '\uFD7F'))),
    ('ARABIC LIGATURE QAF WITH MEEM WITH YEH', ('\u0642\u0645\u064A', ('', '', '', '\uFDB2'))),
    ('ARABIC LIGATURE QAF WITH YEH', ('\u0642\u064A', ('\uFC36', '', '', '\uFC7F'))),
    ('ARABIC LIGATURE QALA USED AS KORANIC STOP SIGN', ('\u0642\u0644\u06D2', ('\uFDF1', '', '', ''))),
    ('ARABIC LIGATURE REH WITH SUPERSCRIPT ALEF', ('\u0631\u0670', ('\uFC5C', '', '', ''))),
    ('ARABIC LIGATURE SAD WITH ALEF MAKSURA', ('\u0635\u0649', ('\uFD05', '', '', '\uFD21'))),
    ('ARABIC LIGATURE SAD WITH HAH', ('\u0635\u062D', ('\uFC20', '\uFCB1', '', ''))),
    ('ARABIC LIGATURE SAD WITH HAH WITH HAH', ('\u0635\u062D\u062D', ('', '\uFD65', '', '\uFD64'))),
    ('ARABIC LIGATURE SAD WITH HAH WITH YEH', ('\u0635\u062D\u064A', ('', '', '', '\uFDA9'))),
    ('ARABIC LIGATURE SAD WITH KHAH', ('\u0635\u062E', ('', '\uFCB2', '', ''))),
    ('ARABIC LIGATURE SAD WITH MEEM', ('\u0635\u0645', ('\uFC21', '\uFCB3', '', ''))),
    ('ARABIC LIGATURE SAD WITH MEEM WITH MEEM', ('\u0635\u0645\u0645', ('', '\uFDC5', '', '\uFD66'))),
    ('ARABIC LIGATURE SAD WITH REH', ('\u0635\u0631', ('\uFD0F', '', '', '\uFD2B'))),
    ('ARABIC LIGATURE SAD WITH YEH', ('\u0635\u064A', ('\uFD06', '', '', '\uFD22'))),
    ('ARABIC LIGATURE SALLA USED AS KORANIC STOP SIGN', ('\u0635\u0644\u06D2', ('\uFDF0', '', '', ''))),
    ('ARABIC LIGATURE SEEN WITH ALEF MAKSURA', ('\u0633\u0649', ('\uFCFB', '', '', '\uFD17'))),
    ('ARABIC LIGATURE SEEN WITH HAH', ('\u0633\u062D', ('\uFC1D', '\uFCAE', '\uFD35', ''))),
    ('ARABIC LIGATURE SEEN WITH HAH WITH JEEM', ('\u0633\u062D\u062C', ('', '\uFD5C', '', ''))),
    ('ARABIC LIGATURE SEEN WITH HEH', ('\u0633\u0647', ('', '\uFD31', '\uFCE8', ''))),
    ('ARABIC LIGATURE SEEN WITH JEEM', ('\u0633\u062C', ('\uFC1C', '\uFCAD', '\uFD34', ''))),
    ('ARABIC LIGATURE SEEN WITH JEEM WITH ALEF MAKSURA', ('\u0633\u062C\u0649', ('', '', '', '\uFD5E'))),
    ('ARABIC LIGATURE SEEN WITH JEEM WITH HAH', ('\u0633\u062C\u062D', ('', '\uFD5D', '', ''))),
    ('ARABIC LIGATURE SEEN WITH KHAH', ('\u0633\u062E', ('\uFC1E', '\uFCAF', '\uFD36', ''))),
    ('ARABIC LIGATURE SEEN WITH KHAH WITH ALEF MAKSURA', ('\u0633\u062E\u0649', ('', '', '', '\uFDA8'))),
    ('ARABIC LIGATURE SEEN WITH KHAH WITH YEH', ('\u0633\u062E\u064A', ('', '', '', '\uFDC6'))),
    ('ARABIC LIGATURE SEEN WITH MEEM', ('\u0633\u0645', ('\uFC1F', '\uFCB0', '\uFCE7', ''))),
    ('ARABIC LIGATURE SEEN WITH MEEM WITH HAH', ('\u0633\u0645\u062D', ('', '\uFD60', '', '\uFD5F'))),
    ('ARABIC LIGATURE SEEN WITH MEEM WITH JEEM', ('\u0633\u0645\u062C', ('', '\uFD61', '', ''))),
    ('ARABIC LIGATURE SEEN WITH MEEM WITH MEEM', ('\u0633\u0645\u0645', ('', '\uFD63', '', '\uFD62'))),
    ('ARABIC LIGATURE SEEN WITH REH', ('\u0633\u0631', ('\uFD0E', '', '', '\uFD2A'))),
    ('ARABIC LIGATURE SEEN WITH YEH', ('\u0633\u064A', ('\uFCFC', '', '', '\uFD18'))),
    ('ARABIC LIGATURE SHADDA WITH DAMMATAN ISOLATED FORM', ('(?:\u064C\u0651|\u0651\u064C)', ('\uFC5E', '\uFC5E', '\uFC5E', '\uFC5E'))),
    ('ARABIC LIGATURE SHADDA WITH KASRATAN ISOLATED FORM', ('(?:\u064D\u0651|\u0651\u064D)', ('\uFC5F', '\uFC5F', '\uFC5F', '\uFC5F'))),
    ('ARABIC LIGATURE SHADDA WITH FATHA ISOLATED FORM', ('(?:\u064E\u0651|\u0651\u064E)', ('\uFC60', '\uFC60', '\uFC60', '\uFC60'))),
    ('ARABIC LIGATURE SHADDA WITH DAMMA ISOLATED FORM', ('(?:\u064F\u0651|\u0651\u064F)', ('\uFC61', '\uFC61', '\uFC61', '\uFC61'))),
    ('ARABIC LIGATURE SHADDA WITH KASRA ISOLATED FORM', ('(?:\u0650\u0651|\u0651\u0650)', ('\uFC62', '\uFC62', '\uFC62', '\uFC62'))),
    ('ARABIC LIGATURE SHADDA WITH SUPERSCRIPT ALEF', ('(?:\u0651\u0670|\u0670\u0651)', ('\uFC63', '', '', ''))),
    ('ARABIC LIGATURE SHADDA WITH FATHA MEDIAL FORM', ('\u0640(?:\u064E\u0651|\u0651\u064E)', ('\uFCF2', '\uFCF2', '\uFCF2', '\uFCF2'))),
    ('ARABIC LIGATURE SHADDA WITH DAMMA MEDIAL FORM', ('\u0640(?:\u064F\u0651|\u0651\u064F)', ('\uFCF3', '\uFCF3', '\uFCF3', '\uFCF3'))),
    ('ARABIC LIGATURE SHADDA WITH KASRA MEDIAL FORM', ('\u0640(?:\u0650\u0651|\u0651\u0650)', ('\uFCF4', '\uFCF4', '\uFCF4', '\uFCF4'))),
    ('ARABIC LIGATURE SHADDA WITH FATHA', ('\u0640(?:\u064E\u0651|\u0651\u064E)', ('\uFCF2', '\uFCF2', '\uFCF2', '\uFCF2'))),
    ('ARABIC LIGATURE SHADDA WITH DAMMA', ('\u0640(?:\u064F\u0651|\u0651\u064F)', ('\uFCF3', '\uFCF3', '\uFCF3', '\uFCF3'))),
    ('ARABIC LIGATURE SHADDA WITH KASRA', ('\u0640(?:\u0650\u0651|\u0651\u0650)', ('\uFCF4', '\uFCF4', '\uFCF4', '\uFCF4'))),
    ('ARABIC LIGATURE SHEEN WITH ALEF MAKSURA', ('\u0634\u0649', ('\uFCFD', '', '', '\uFD19'))),
    ('ARABIC LIGATURE SHEEN WITH HAH', ('\u0634\u062D', ('\uFD0A', '\uFD2E', '\uFD38', '\uFD26'))),
    ('ARABIC LIGATURE SHEEN WITH HAH WITH MEEM', ('\u0634\u062D\u0645', ('', '\uFD68', '', '\uFD67'))),
    ('ARABIC LIGATURE SHEEN WITH HAH WITH YEH', ('\u0634\u062D\u064A', ('', '', '', '\uFDAA'))),
    ('ARABIC LIGATURE SHEEN WITH HEH', ('\u0634\u0647', ('', '\uFD32', '\uFCEA', ''))),
    ('ARABIC LIGATURE SHEEN WITH JEEM', ('\u0634\u062C', ('\uFD09', '\uFD2D', '\uFD37', '\uFD25'))),
    ('ARABIC LIGATURE SHEEN WITH JEEM WITH YEH', ('\u0634\u062C\u064A', ('', '', '', '\uFD69'))),
    ('ARABIC LIGATURE SHEEN WITH KHAH', ('\u0634\u062E', ('\uFD0B', '\uFD2F', '\uFD39', '\uFD27'))),
    ('ARABIC LIGATURE SHEEN WITH MEEM', ('\u0634\u0645', ('\uFD0C', '\uFD30', '\uFCE9', '\uFD28'))),
    ('ARABIC LIGATURE SHEEN WITH MEEM WITH KHAH', ('\u0634\u0645\u062E', ('', '\uFD6B', '', '\uFD6A'))),
    ('ARABIC LIGATURE SHEEN WITH MEEM WITH MEEM', ('\u0634\u0645\u0645', ('', '\uFD6D', '', '\uFD6C'))),
    ('ARABIC LIGATURE SHEEN WITH REH', ('\u0634\u0631', ('\uFD0D', '', '', '\uFD29'))),
    ('ARABIC LIGATURE SHEEN WITH YEH', ('\u0634\u064A', ('\uFCFE', '', '', '\uFD1A'))),
    ('ARABIC LIGATURE TAH WITH ALEF MAKSURA', ('\u0637\u0649', ('\uFCF5', '', '', '\uFD11'))),
    ('ARABIC LIGATURE TAH WITH HAH', ('\u0637\u062D', ('\uFC26', '\uFCB8', '', ''))),
    ('ARABIC LIGATURE TAH WITH MEEM', ('\u0637\u0645', ('\uFC27', '\uFD33', '\uFD3A', ''))),
    ('ARABIC LIGATURE TAH WITH MEEM WITH HAH', ('\u0637\u0645\u062D', ('', '\uFD72', '', '\uFD71'))),
    ('ARABIC LIGATURE TAH WITH MEEM WITH MEEM', ('\u0637\u0645\u0645', ('', '\uFD73', '', ''))),
    ('ARABIC LIGATURE TAH WITH MEEM WITH YEH', ('\u0637\u0645\u064A', ('', '', '', '\uFD74'))),
    ('ARABIC LIGATURE TAH WITH YEH', ('\u0637\u064A', ('\uFCF6', '', '', '\uFD12'))),
    ('ARABIC LIGATURE TEH WITH ALEF MAKSURA', ('\u062A\u0649', ('\uFC0F', '', '', '\uFC74'))),
    ('ARABIC LIGATURE TEH WITH HAH', ('\u062A\u062D', ('\uFC0C', '\uFCA2', '', ''))),
    ('ARABIC LIGATURE TEH WITH HAH WITH JEEM', ('\u062A\u062D\u062C', ('', '\uFD52', '', '\uFD51'))),
    ('ARABIC LIGATURE TEH WITH HAH WITH MEEM', ('\u062A\u062D\u0645', ('', '\uFD53', '', ''))),
    ('ARABIC LIGATURE TEH WITH HEH', ('\u062A\u0647', ('', '\uFCA5', '\uFCE4', ''))),
    ('ARABIC LIGATURE TEH WITH JEEM', ('\u062A\u062C', ('\uFC0B', '\uFCA1', '', ''))),
    ('ARABIC LIGATURE TEH WITH JEEM WITH ALEF MAKSURA', ('\u062A\u062C\u0649', ('', '', '', '\uFDA0'))),
    ('ARABIC LIGATURE TEH WITH JEEM WITH MEEM', ('\u062A\u062C\u0645', ('', '\uFD50', '', ''))),
    ('ARABIC LIGATURE TEH WITH JEEM WITH YEH', ('\u062A\u062C\u064A', ('', '', '', '\uFD9F'))),
    ('ARABIC LIGATURE TEH WITH KHAH', ('\u062A\u062E', ('\uFC0D', '\uFCA3', '', ''))),
    ('ARABIC LIGATURE TEH WITH KHAH WITH ALEF MAKSURA', ('\u062A\u062E\u0649', ('', '', '', '\uFDA2'))),
    ('ARABIC LIGATURE TEH WITH KHAH WITH MEEM', ('\u062A\u062E\u0645', ('', '\uFD54', '', ''))),
    ('ARABIC LIGATURE TEH WITH KHAH WITH YEH', ('\u062A\u062E\u064A', ('', '', '', '\uFDA1'))),
    ('ARABIC LIGATURE TEH WITH MEEM', ('\u062A\u0645', ('\uFC0E', '\uFCA4', '\uFCE3', '\uFC72'))),
    ('ARABIC LIGATURE TEH WITH MEEM WITH ALEF MAKSURA', ('\u062A\u0645\u0649', ('', '', '', '\uFDA4'))),
    ('ARABIC LIGATURE TEH WITH MEEM WITH HAH', ('\u062A\u0645\u062D', ('', '\uFD56', '', ''))),
    ('ARABIC LIGATURE TEH WITH MEEM WITH JEEM', ('\u062A\u0645\u062C', ('', '\uFD55', '', ''))),
    ('ARABIC LIGATURE TEH WITH MEEM WITH KHAH', ('\u062A\u0645\u062E', ('', '\uFD57', '', ''))),
    ('ARABIC LIGATURE TEH WITH MEEM WITH YEH', ('\u062A\u0645\u064A', ('', '', '', '\uFDA3'))),
    ('ARABIC LIGATURE TEH WITH NOON', ('\u062A\u0646', ('', '', '', '\uFC73'))),
    ('ARABIC LIGATURE TEH WITH REH', ('\u062A\u0631', ('', '', '', '\uFC70'))),
    ('ARABIC LIGATURE TEH WITH YEH', ('\u062A\u064A', ('\uFC10', '', '', '\uFC75'))),
    ('ARABIC LIGATURE TEH WITH ZAIN', ('\u062A\u0632', ('', '', '', '\uFC71'))),
    ('ARABIC LIGATURE THAL WITH SUPERSCRIPT ALEF', ('\u0630\u0670', ('\uFC5B', '', '', ''))),
    ('ARABIC LIGATURE THEH WITH ALEF MAKSURA', ('\u062B\u0649', ('\uFC13', '', '', '\uFC7A'))),
    ('ARABIC LIGATURE THEH WITH HEH', ('\u062B\u0647', ('', '', '\uFCE6', ''))),
    ('ARABIC LIGATURE THEH WITH JEEM', ('\u062B\u062C', ('\uFC11', '', '', ''))),
    ('ARABIC LIGATURE THEH WITH MEEM', ('\u062B\u0645', ('\uFC12', '\uFCA6', '\uFCE5', '\uFC78'))),
    ('ARABIC LIGATURE THEH WITH NOON', ('\u062B\u0646', ('', '', '', '\uFC79'))),
    ('ARABIC LIGATURE THEH WITH REH', ('\u062B\u0631', ('', '', '', '\uFC76'))),
    ('ARABIC LIGATURE THEH WITH YEH', ('\u062B\u064A', ('\uFC14', '', '', '\uFC7B'))),
    ('ARABIC LIGATURE THEH WITH ZAIN', ('\u062B\u0632', ('', '', '', '\uFC77'))),
    ('ARABIC LIGATURE UIGHUR KIRGHIZ YEH WITH HAMZA ABOVE WITH ALEF MAKSURA', ('\u0626\u0649', ('\uFBF9', '\uFBFB', '', '\uFBFA'))),
    ('ARABIC LIGATURE YEH WITH ALEF MAKSURA', ('\u064A\u0649', ('\uFC59', '', '', '\uFC95'))),
    ('ARABIC LIGATURE YEH WITH HAH', ('\u064A\u062D', ('\uFC56', '\uFCDB', '', ''))),
    ('ARABIC LIGATURE YEH WITH HAH WITH YEH', ('\u064A\u062D\u064A', ('', '', '', '\uFDAE'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH AE', ('\u0626\u06D5', ('\uFBEC', '', '', '\uFBED'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH ALEF', ('\u0626\u0627', ('\uFBEA', '', '', '\uFBEB'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH ALEF MAKSURA', ('\u0626\u0649', ('\uFC03', '', '', '\uFC68'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH E', ('\u0626\u06D0', ('\uFBF6', '\uFBF8', '', '\uFBF7'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH HAH', ('\u0626\u062D', ('\uFC01', '\uFC98', '', ''))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH HEH', ('\u0626\u0647', ('', '\uFC9B', '\uFCE0', ''))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH JEEM', ('\u0626\u062C', ('\uFC00', '\uFC97', '', ''))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH KHAH', ('\u0626\u062E', ('', '\uFC99', '', ''))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH MEEM', ('\u0626\u0645', ('\uFC02', '\uFC9A', '\uFCDF', '\uFC66'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH NOON', ('\u0626\u0646', ('', '', '', '\uFC67'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH OE', ('\u0626\u06C6', ('\uFBF2', '', '', '\uFBF3'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH REH', ('\u0626\u0631', ('', '', '', '\uFC64'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH U', ('\u0626\u06C7', ('\uFBF0', '', '', '\uFBF1'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH WAW', ('\u0626\u0648', ('\uFBEE', '', '', '\uFBEF'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH YEH', ('\u0626\u064A', ('\uFC04', '', '', '\uFC69'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH YU', ('\u0626\u06C8', ('\uFBF4', '', '', '\uFBF5'))),
    ('ARABIC LIGATURE YEH WITH HAMZA ABOVE WITH ZAIN', ('\u0626\u0632', ('', '', '', '\uFC65'))),
    ('ARABIC LIGATURE YEH WITH HEH', ('\u064A\u0647', ('', '\uFCDE', '\uFCF1', ''))),
    ('ARABIC LIGATURE YEH WITH JEEM', ('\u064A\u062C', ('\uFC55', '\uFCDA', '', ''))),
    ('ARABIC LIGATURE YEH WITH JEEM WITH YEH', ('\u064A\u062C\u064A', ('', '', '', '\uFDAF'))),
    ('ARABIC LIGATURE YEH WITH KHAH', ('\u064A\u062E', ('\uFC57', '\uFCDC', '', ''))),
    ('ARABIC LIGATURE YEH WITH MEEM', ('\u064A\u0645', ('\uFC58', '\uFCDD', '\uFCF0', '\uFC93'))),
    ('ARABIC LIGATURE YEH WITH MEEM WITH MEEM', ('\u064A\u0645\u0645', ('', '\uFD9D', '', '\uFD9C'))),
    ('ARABIC LIGATURE YEH WITH MEEM WITH YEH', ('\u064A\u0645\u064A', ('', '', '', '\uFDB0'))),
    ('ARABIC LIGATURE YEH WITH NOON', ('\u064A\u0646', ('', '', '', '\uFC94'))),
    ('ARABIC LIGATURE YEH WITH REH', ('\u064A\u0631', ('', '', '', '\uFC91'))),
    ('ARABIC LIGATURE YEH WITH YEH', ('\u064A\u064A', ('\uFC5A', '', '', '\uFC96'))),
    ('ARABIC LIGATURE YEH WITH ZAIN', ('\u064A\u0632', ('', '', '', '\uFC92'))),
    ('ARABIC LIGATURE ZAH WITH MEEM', ('\u0638\u0645', ('\uFC28', '\uFCB9', '\uFD3B', ''))),
)

LIGATURES = tuple(chain(SENTENCES_LIGATURES, WORDS_LIGATURES, LETTERS_LIGATURES))

default_config = {
    'language': 'Arabic',
    'delete_harakat': True,
    'shift_harakat_position': False,
    'delete_tatweel': False,
    'support_zwj': True,
    'use_unshaped_instead_of_isolated': False,
    'support_ligatures': True,
    'ARABIC LIGATURE ALLAH': False,
    'ARABIC LIGATURE BISMILLAH AR-RAHMAN AR-RAHEEM': False,
    'ARABIC LIGATURE JALLAJALALOUHOU': False,
    'ARABIC LIGATURE SALLALLAHOU ALAYHE WASALLAM': False,
    'ARABIC LIGATURE AKBAR': False,
    'ARABIC LIGATURE ALAYHE': False,
    'ARABIC LIGATURE MOHAMMAD': False,
    'ARABIC LIGATURE RASOUL': False,
    'ARABIC LIGATURE SALAM': False,
    'ARABIC LIGATURE SALLA': False,
    'ARABIC LIGATURE WASALLAM': False,
    'RIAL SIGN': False,
    'ARABIC LIGATURE LAM WITH ALEF': True,
    'ARABIC LIGATURE LAM WITH ALEF WITH HAMZA ABOVE': True,
    'ARABIC LIGATURE LAM WITH ALEF WITH HAMZA BELOW': True,
    'ARABIC LIGATURE LAM WITH ALEF WITH MADDA ABOVE': True,
}

def auto_config(configuration=None, configuration_file=None):
    if configuration and isinstance(configuration, dict):
        merged = default_config.copy()
        merged.update(configuration)
        return merged
    return default_config.copy()

HARAKAT_RE = re.compile(
    u'[' u'\u0610-\u061a' u'\u064b-\u065f' u'\u0670' u'\u06d6-\u06dc' u'\u06df-\u06e8' u'\u06ea-\u06ed' u'\u08d4-\u08e1' u'\u08d4-\u08ed' u'\u08e3-\u08ff' u']', re.UNICODE | re.X
)

class ArabicReshaper:
    def __init__(self, configuration=None, configuration_file=None):
        self.configuration = auto_config(configuration, configuration_file)
        self.language = self.configuration.get('language')
        if self.language == 'ArabicV2':
            self.letters = LETTERS_ARABIC_V2
        elif self.language == 'Kurdish':
            self.letters = LETTERS_KURDISH
        else:
            self.letters = LETTERS_ARABIC

    def _get_bool(self, key, default=False):
        val = self.configuration.get(key, default)
        if isinstance(val, str):
            return val.lower() in ('true', '1', 'yes', 'on')
        return bool(val)

    @cached_property
    def _ligatures_re(self):
        patterns = []
        self._re_group_index_to_ligature_forms = {}
        index = 0
        FORMS = 1
        MATCH = 0
        for ligature, replacement in LIGATURES:
            if not self._get_bool(ligature, False):
                continue
            self._re_group_index_to_ligature_forms[index] = replacement[FORMS]
            patterns.append(u'({})'.format(replacement[MATCH]))
            index += 1
        return re.compile(u'|'.join(patterns), re.UNICODE)

    def _get_ligature_forms_from_re_group_index(self, group_index):
        if group_index == -1:
            return None
        return self._re_group_index_to_ligature_forms.get(group_index, None)

    def reshape(self, text):
        if not text:
            return u''
        output = []
        LETTER = 0
        FORM = 1
        NOT_SUPPORTED = -1

        delete_harakat = self._get_bool('delete_harakat', True)
        delete_tatweel = self._get_bool('delete_tatweel', False)
        support_zwj = self._get_bool('support_zwj', True)
        shift_harakat_position = self._get_bool('shift_harakat_position', False)
        use_unshaped_instead_of_isolated = self._get_bool('use_unshaped_instead_of_isolated', False)

        positions_harakat = {}
        isolated_form = (UNSHAPED if use_unshaped_instead_of_isolated else ISOLATED)

        for letter in text:
            if HARAKAT_RE.match(letter):
                if not delete_harakat:
                    position = len(output) - 1
                    if shift_harakat_position:
                        position -= 1
                    if position not in positions_harakat:
                        positions_harakat[position] = []
                    if shift_harakat_position:
                        positions_harakat[position].insert(0, letter)
                    else:
                        positions_harakat[position].append(letter)
            elif letter == TATWEEL and delete_tatweel:
                pass
            elif letter == ZWJ and not support_zwj:
                pass
            elif letter not in self.letters:
                output.append((letter, NOT_SUPPORTED))
            elif not output:
                output.append((letter, isolated_form))
            else:
                previous_letter = output[-1]
                if previous_letter[FORM] == NOT_SUPPORTED:
                    output.append((letter, isolated_form))
                elif not connects_with_letter_before(letter, self.letters):
                    output.append((letter, isolated_form))
                elif not connects_with_letter_after(previous_letter[LETTER], self.letters):
                    output.append((letter, isolated_form))
                elif (previous_letter[FORM] == FINAL and not
                      connects_with_letters_before_and_after(previous_letter[LETTER], self.letters)):
                    output.append((letter, isolated_form))
                elif previous_letter[FORM] == isolated_form:
                    output[-1] = (previous_letter[LETTER], INITIAL)
                    output.append((letter, FINAL))
                else:
                    output[-1] = (previous_letter[LETTER], MEDIAL)
                    output.append((letter, FINAL))
            if support_zwj and len(output) > 1 and output[-2][LETTER] == ZWJ:
                output.pop(len(output) - 2)

        if support_zwj and output and output[-1][LETTER] == ZWJ:
            output.pop()

        if self._get_bool('support_ligatures', True):
            text = HARAKAT_RE.sub('', text)
            if delete_tatweel:
                text = text.replace(TATWEEL, '')
            for match in re.finditer(self._ligatures_re, text):
                group_index = next((i for i, group in enumerate(match.groups()) if group), -1)
                forms = self._get_ligature_forms_from_re_group_index(group_index)
                if forms is None:
                    continue
                a, b = match.span()
                a_form = output[a][FORM]
                b_form = output[b - 1][FORM]
                ligature_form = None
                if a_form in (isolated_form, INITIAL):
                    if b_form in (isolated_form, FINAL):
                        ligature_form = ISOLATED
                    else:
                        ligature_form = INITIAL
                else:
                    if b_form in (isolated_form, FINAL):
                        ligature_form = FINAL
                    else:
                        ligature_form = MEDIAL
                if not forms[ligature_form]:
                    continue
                output[a] = (forms[ligature_form], NOT_SUPPORTED)
                output[a+1:b] = repeat((u'', NOT_SUPPORTED), b - 1 - a)

        result = []
        if not delete_harakat and -1 in positions_harakat:
            result.extend(positions_harakat[-1])
        for i, o in enumerate(output):
            if o[LETTER]:
                if o[FORM] == NOT_SUPPORTED or o[FORM] == UNSHAPED:
                    result.append(o[LETTER])
                else:
                    result.append(self.letters[o[LETTER]][o[FORM]])
            if not delete_harakat:
                if i in positions_harakat:
                    result.extend(positions_harakat[i])
        return u''.join(result)

default_reshaper = ArabicReshaper()
reshape = default_reshaper.reshape

LOG_FILE = "/tmp/hisnmuslim.log"

def log_message(msg):
    try:
        with open(LOG_FILE, "a") as f:
            f.write("[{}] {}\n".format(time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except:
        pass

def _(txt):
    t = gettext.dgettext("HisnMuslim", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t

SETTINGS_FILE = "/tmp/hisnmuslim_settings.json"

LANG_CODE_TO_NAME = {
    "ar": "العربية",
    "en": "English",
}

def get_language_full_name(lang_code):
    return LANG_CODE_TO_NAME.get(lang_code, lang_code)

def get_plugin_path():
    return dirname(__file__)

def get_local_db_path(lang="ar"):
    return join(get_plugin_path(), "database", lang)

def ensure_local_db_dir(lang="ar"):
    db_path = get_local_db_path(lang)
    if not exists(db_path):
        os.makedirs(db_path, mode=0o755)
    return db_path

def load_chapters_from_local(lang="ar"):
    db_path = get_local_db_path(lang)
    index_path = join(db_path, "index.json")
    if not exists(index_path):
        log_message("index.json not found for lang {} at {}".format(lang, index_path))
        return None
    try:
        with open(index_path, "r", encoding="utf-8") as f:
            index_data = json.load(f)
        chapters = []
        for key, value in index_data.items():
            if isinstance(value, list):
                chapters = value
                break
        if not chapters:
            log_message("No chapters found in index for lang {}".format(lang))
            return None
        log_message("Loaded {} chapters from local index for lang {}".format(len(chapters), lang))
        return chapters
    except Exception as e:
        log_message("Error loading local index for {}: {}".format(lang, str(e)))
        return None

def fetch_hisn_data(force_refresh=False):
    settings = load_settings()
    lang_code = settings.get("language", "ar")
    local_chapters = load_chapters_from_local(lang_code)
    if local_chapters:
        log_message("Loaded {} chapters from local for lang {}".format(len(local_chapters), lang_code))
        return local_chapters
    else:
        raise Exception("No local data found for language {}. Please ensure database/{} exists.".format(lang_code, lang_code))

def get_plugin_icon():
    plugin_path = get_plugin_path()
    icon_path = join(plugin_path, "images", "hisnmuslim.png")
    if exists(icon_path):
        return LoadPixmap(cached=True, path=icon_path)
    return None

class FontManager:
    def __init__(self, plugin_path, prefix=""):
        self.plugin_path = plugin_path
        self.fonts_folder = join(plugin_path, "fonts")
        self.prefix = prefix
        self.loaded_fonts = {}
        self._load_fonts()

    def _load_fonts(self):
        if not os.path.isdir(self.fonts_folder):
            log_message("Fonts folder not found: {}".format(self.fonts_folder))
            return
        font_files = glob.glob(join(self.fonts_folder, "*.ttf")) + glob.glob(join(self.fonts_folder, "*.otf"))
        if not font_files:
            log_message("No font files found in {}".format(self.fonts_folder))
            return
        for font_path in font_files:
            base_name = os.path.splitext(os.path.basename(font_path))[0]
            face_name = self.prefix + base_name
            try:
                addFont(font_path, face_name, 100, 0)
                self.loaded_fonts[face_name] = font_path
                log_message("Font loaded: {} as {}".format(font_path, face_name))
            except Exception as e:
                log_message("Failed to load font {}: {}".format(font_path, str(e)))

    def list_fonts(self):
        return list(self.loaded_fonts.keys())

    def get_font_path(self, face_name):
        return self.loaded_fonts.get(face_name)

font_loaded = False
font_manager = None

def load_custom_fonts():
    global font_loaded, font_manager
    if font_loaded:
        return True
    plugin_path = get_plugin_path()
    font_manager = FontManager(plugin_path, prefix="")
    if "AmiriCustom" in font_manager.loaded_fonts:
        font_loaded = True
        log_message("AmiriCustom font already loaded")
        return True

    font_dir = join(plugin_path, "fonts")
    font_file = join(font_dir, "Amiri-Regular.ttf")
    if exists(font_file):
        try:
            addFont(font_file, "AmiriCustom", 100, 0)
            font_manager.loaded_fonts["AmiriCustom"] = font_file
            font_loaded = True
            log_message("Font loaded successfully: {} as AmiriCustom".format(font_file))
            return True
        except Exception as e:
            log_message("Failed to load font {}: {}".format(font_file, str(e)))
    else:
        log_message("Amiri-Regular.ttf not found in {}".format(font_dir))
    other_fonts = glob.glob(join(font_dir, "*.ttf"))
    if other_fonts:
        try:
            addFont(other_fonts[0], "AmiriCustom", 100, 0)
            font_manager.loaded_fonts["AmiriCustom"] = other_fonts[0]
            font_loaded = True
            log_message("Font loaded from fallback: {}".format(other_fonts[0]))
            return True
        except Exception as e:
            log_message("Failed to load fallback font: {}".format(str(e)))
    log_message("No Amiri font found, fallback to system font")
    return False

def get_default_settings():
    return {
        "language": "ar",
        "font": "AmiriCustom",
        "size": 40,
        "color": "#00FF00"
    }

def load_settings():
    if not exists(SETTINGS_FILE):
        return get_default_settings()
    try:
        with open(SETTINGS_FILE, "r") as f:
            data = json.load(f)
        default = get_default_settings()
        for key in default:
            if key not in data:
                data[key] = default[key]
        return data
    except:
        return get_default_settings()

def save_settings(settings):
    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(settings, f, indent=2)
        log_message("Settings saved: {}".format(settings))
        return True
    except Exception as e:
        log_message("Error saving settings: {}".format(str(e)))
        return False

def get_chapter_title(chapter):
    if isinstance(chapter, dict):
        for key in ["TITLE", "title", "name", "label", "chapter", "id"]:
            if key in chapter and chapter[key]:
                return chapter[key]
        if chapter:
            first_key = next(iter(chapter))
            if isinstance(chapter[first_key], str):
                return chapter[first_key]
    elif isinstance(chapter, str):
        return chapter
    return _("Untitled")

class SettingsScreen(ConfigListScreen, Screen):
    skin_1920 = """
    <screen name="SettingsScreen" position="center,center" size="800,600" title="الإعدادات">
        <widget source="Redkey" render="Label" position="0,540" size="200,45" zPosition="11" font="Regular; 26" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <eLabel backgroundColor="#00ff0000" position="0,585" size="200,6" zPosition="12" />
        <widget source="Greenkey" render="Label" position="200,540" size="200,45" zPosition="11" font="Regular; 26" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <eLabel backgroundColor="#0000ff00" position="200,585" size="200,6" zPosition="12" />
        <widget name="config" position="20,10" size="760,510" scrollbarMode="showOnDemand" />
    </screen>
    """
    skin_default = """
    <screen name="SettingsScreen" position="center,center" size="600,500" title="الإعدادات">
        <widget source="Redkey" render="Label" position="0,440" size="150,35" zPosition="11" font="Regular; 22" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <eLabel backgroundColor="#00ff0000" position="0,475" size="150,6" zPosition="12" />
        <widget source="Greenkey" render="Label" position="150,440" size="150,35" zPosition="11" font="Regular; 22" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <eLabel backgroundColor="#0000ff00" position="150,475" size="150,6" zPosition="12" />
        <widget name="config" position="10,10" size="580,410" scrollbarMode="showOnDemand" />
    </screen>
    """

    def __init__(self, session):
        self.session = session
        self.settings = load_settings()

        language_choices = [
            ("ar", "العربية"),
            ("en", "English"),
        ]
        self.language = NoSave(ConfigSelection(choices=language_choices, default=self.settings.get("language", "ar")))

        font_names = font_manager.list_fonts() if font_manager else ["AmiriCustom"]
        if not font_names:
            font_names = ["AmiriCustom"]
        font_choices = [(name, name) for name in font_names]

        self.font_selection = NoSave(ConfigSelection(choices=font_choices, default=self.settings.get("font", "AmiriCustom")))
        self.font_size = NoSave(ConfigInteger(default=self.settings.get("size", 40), limits=(16, 64)))
        self.font_color = NoSave(ConfigSelection(
            choices=[("#FFFFFF", "أبيض"), ("#FFFF00", "أصفر"), ("#00FF00", "أخضر"), ("#FF0000", "أحمر"), ("#00FFFF", "سماوي")],
            default=self.settings.get("color", "#00FF00")
        ))

        self.list = [
            getConfigListEntry(_("Language:"), self.language),
            getConfigListEntry(_("Font:"), self.font_selection),
            getConfigListEntry(_("Size:"), self.font_size),
            getConfigListEntry(_("Color:"), self.font_color),
        ]

        sz_w = getDesktop(0).size().width()
        self.skin = self.skin_1920 if sz_w >= 1920 else self.skin_default
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, self.list, session=self.session)

        self["actions"] = ActionMap(
            ["SetupActions", "OkCancelActions", "ColorActions"],
            {
                "cancel": self.cancel,
                "ok": self.save,
                "green": self.save,
                "red": self.cancel
            },
            -2
        )

        self["Redkey"] = StaticText(_("Exit"))
        self["Greenkey"] = StaticText(_("Save"))
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(_("Settings"))

    def save(self):
        self.settings["language"] = self.language.value
        self.settings["font"] = self.font_selection.value
        self.settings["size"] = self.font_size.value
        self.settings["color"] = self.font_color.value
        save_settings(self.settings)
        self.session.open(MessageBox, _("Settings saved successfully!"), MessageBox.TYPE_INFO, timeout=2)
        self.close()

    def cancel(self):
        self.close()

class HisnMuslimMainScreen(Screen):
    skin_1920 = """
    <screen name="HisnMuslimMainScreen" position="center,center" size="1000,880" title="حصن المسلم - الأذكار">
        <widget source="Redkey" render="Label" position="0,814" size="250,45" zPosition="11" font="Regular; 26" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <widget source="Greenkey" render="Label" position="252,813" size="250,45" zPosition="11" font="Regular; 26" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <widget source="Yellowkey" render="Label" position="499,814" size="250,45" zPosition="11" font="Regular; 26" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <widget source="Bluekey" render="Label" position="746,814" size="250,45" zPosition="11" font="Regular; 26" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <eLabel backgroundColor="#00ff0000" position="0,858" size="250,6" zPosition="12" />
        <eLabel backgroundColor="#0000ff00" position="250,858" size="250,6" zPosition="12" />
        <eLabel backgroundColor="#00ffff00" position="500,858" size="250,6" zPosition="12" />
        <eLabel backgroundColor="#0000ffff" position="746,858" size="250,6" zPosition="12" />
        <widget source="menu" render="Listbox" position="20,10" size="961,781" scrollbarMode="showOnDemand">
        <convert type="TemplatedMultiContent">
        {"template": [MultiContentEntryText(pos = (10, 2), size = (911, 34), font=0, flags = RT_HALIGN_RIGHT, text = 0)], "fonts": [gFont("Regular", 30)], "itemHeight": 50}
        </convert>
        </widget>
    </screen>
    """
    skin_default = """
    <screen name="HisnMuslimMainScreen" position="center,center" size="640,586" title="حصن المسلم">
        <widget source="Redkey" render="Label" position="6,536" size="160,35" zPosition="11" font="Regular; 22" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <widget source="Greenkey" render="Label" position="166,536" size="160,35" zPosition="11" font="Regular; 22" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <widget source="Yellowkey" render="Label" position="325,536" size="160,35" zPosition="11" font="Regular; 22" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <widget source="Bluekey" render="Label" position="485,536" size="150,35" zPosition="11" font="Regular; 22" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
        <eLabel backgroundColor="#00ff0000" position="5,570" size="160,6" zPosition="12" />
        <eLabel backgroundColor="#0000ff00" position="165,570" size="160,6" zPosition="12" />
        <eLabel backgroundColor="#00ffff00" position="325,570" size="160,6" zPosition="12" />
        <eLabel backgroundColor="#0000ffff" position="485,570" size="150,6" zPosition="12" />
        <widget source="menu" render="Listbox" position="13,6" size="613,517" scrollbarMode="showOnDemand">
        <convert type="TemplatedMultiContent">
        {"template": [MultiContentEntryText(pos = (10, 1), size = (583, 22), font=0, flags = RT_HALIGN_RIGHT, text = 0)], "fonts": [gFont("Regular", 18)], "itemHeight": 40}
        </convert>
        </widget>
    </screen>
    """

    def __init__(self, session):
        log_message("HisnMuslimMainScreen: Initializing")
        load_custom_fonts()
        self.session = session
        sz_w = getDesktop(0).size().width()
        self.skin = self.skin_1920 if sz_w >= 1920 else self.skin_default
        Screen.__init__(self, session)
        self["shortcuts"] = ActionMap(
            ["ShortcutActions", "WizardActions", "EPGSelectActions", "ColorActions"],
            {"ok": self.Ok, "cancel": self.exit, "back": self.exit, "red": self.exit, "green": self.Ok, "yellow": self.refresh_data, "blue": self.open_settings}
        )
        self["Redkey"] = StaticText(_("Close"))
        self["Greenkey"] = StaticText(_("View"))
        self["Yellowkey"] = StaticText(_("Refresh"))
        self["Bluekey"] = StaticText(_("Settings"))
        self.list = []
        self["menu"] = List(self.list)
        self.chapters_data = []
        self.loading = False
        self.onLayoutFinish.append(self.load_or_fetch)

    def load_or_fetch(self):
        if self.loading:
            return
        self.loading = True
        try:
            chapters = fetch_hisn_data(force_refresh=False)
            self.chapters_data = chapters
            self.populate_list()
        except Exception as e:
            log_message("Error loading local data: {}".format(str(e)))
            self.list = [(_("No local data found. Please ensure database folder exists."),)]
            self["menu"].setList(self.list)
        self.loading = False

    def refresh_data(self):
        if self.loading:
            return
        self.loading = True
        try:
            settings = load_settings()
            lang_code = settings.get("language", "ar")
            chapters = load_chapters_from_local(lang_code)
            if chapters:
                self.chapters_data = chapters
                self.populate_list()
                self.session.open(MessageBox, _("Data refreshed from local storage."), MessageBox.TYPE_INFO, timeout=2)
            else:
                self.list = [(_("No local data found."),)]
                self["menu"].setList(self.list)
                self.session.open(MessageBox, _("No local data found for language: ") + lang_code, MessageBox.TYPE_INFO, timeout=2)
        except Exception as e:
            log_message("Refresh error: {}".format(str(e)))
            self.list = [(_("Error refreshing data: ") + str(e),)]
            self["menu"].setList(self.list)
        self.loading = False

    def open_settings(self):
        self.session.open(SettingsScreen)

    def populate_list(self):
        log_message("populate_list: Populating list")
        self.list = []
        if not self.chapters_data:
            self.list.append((_("No data available. Press Refresh to load."),))
        else:
            for chapter in self.chapters_data:
                title = get_chapter_title(chapter)
                self.list.append((title,))
        self["menu"].setList(self.list)

    def Ok(self):
        item = self["menu"].getCurrent()
        if not item or not item[0]:
            return
        title = item[0]
        for chapter in self.chapters_data:
            if get_chapter_title(chapter) == title:
                self.session.open(ChapterViewer, chapter)
                return

    def exit(self):
        log_message("HisnMuslimMainScreen: Exiting")
        self.close()

class ChapterViewer(Screen):
    def __init__(self, session, chapter_data):
        self.chapter = chapter_data
        title = get_chapter_title(chapter_data)
        log_message("ChapterViewer: Opening for {}".format(title))
        self.session = session
        settings = load_settings()
        lang = settings.get("language", "ar")
        font_name = settings.get("font", "AmiriCustom")
        font_size = settings.get("size", 40)
        font_color = settings.get("color", "#00FF00")

        sz_w = getDesktop(0).size().width()
        if sz_w < 1920:
            font_size = max(20, font_size - 10)

        if sz_w >= 1920:
            self.skin = """
            <screen name="ChapterViewer" position="center,center" size="1880,980" title="حصن المسلم - الأذكار">
                <widget source="Redkey" render="Label" position="16,919" size="250,45" zPosition="11" font="Regular; 30" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
                <eLabel backgroundColor="#00ff0000" position="20,963" size="250,6" zPosition="12" />
                <widget name="text" position="10,70" size="1860,840" font="%s; %d" foregroundColor="%s" halign="right" valign="top" />
            </screen>
            """ % (font_name, font_size, font_color)
        else:
            self.skin = """
            <screen name="ChapterViewer" position="center,center" size="1253,653" title="حصن المسلم">
                <widget source="Redkey" render="Label" position="19,609" size="172,33" zPosition="11" font="Regular; 22" valign="center" halign="center" backgroundColor="#050c101b" transparent="1" foregroundColor="white" />
                <eLabel backgroundColor="#00ff0000" position="20,643" size="172,6" zPosition="12" />
                <widget name="text" position="6,50" size="1240,550" font="%s; %d" foregroundColor="%s" halign="right" valign="top" />
            </screen>
            """ % (font_name, font_size, font_color)

        Screen.__init__(self, session)
        self.setTitle("حصن المسلم - " + title)
        self["actions"] = ActionMap(["DirectionActions", "OkCancelActions"], {"cancel": self.exit, "ok": self.exit, "up": self.pageUp, "down": self.pageDown, "left": self.pageUp, "right": self.pageDown})
        self["Redkey"] = StaticText(_("Close"))
        self["text"] = ScrollLabel("")
        self.content = ""
        self.lang = lang
        self.onLayoutFinish.append(self.loadText)

    def pageUp(self):
        self["text"].pageUp()

    def pageDown(self):
        self["text"].pageDown()

    def exit(self):
        log_message("ChapterViewer: Closing")
        self.close()

    def _extract_items(self, data):
        original_data = data
        items = []
        if isinstance(data, dict):
            possible_keys = ["items", "duas", "supplications", "content", "texts", "list", "data", "dua_list"]
            for key in possible_keys:
                if key in data:
                    val = data[key]
                    if isinstance(val, list):
                        items = val
                        log_message("Found items under key: {}, count: {}".format(key, len(items)))
                        break
                    elif isinstance(val, dict):
                        sub_items, _ = self._extract_items(val)
                        if sub_items:
                            items = sub_items
                            break
            if not items:
                for key, val in data.items():
                    if isinstance(val, list) and val:
                        items = val
                        log_message("Found list under key: {}, count: {}".format(key, len(items)))
                        break
            if not items and "TEXT" in data and isinstance(data["TEXT"], str):
                items = [{"text": data["TEXT"]}]
                log_message("Using TEXT field as single item")
        elif isinstance(data, list):
            items = data
            log_message("Data is a list directly, count: {}".format(len(items)))
        else:
            items = [{"text": str(data)}]
            log_message("Data is not dict/list, converted to string")
        return items, original_data

    def _format_items(self, items):
        if not items:
            return _("No supplications found.")
        
        settings = load_settings()
        lang = settings.get("language", "ar")
        
        parts = []
        for idx, item in enumerate(items, 1):
            if isinstance(item, dict):
                arabic = item.get("ARABIC_TEXT", "").strip()
                transliteration = item.get("LANGUAGE_ARABIC_TRANSLATED_TEXT", "").strip()
                translation = item.get("TRANSLATED_TEXT", "").strip()
                
                text_parts = []
                
                if lang == "ar":
                    if arabic:
                        text_parts.append(arabic)
                else:
                    if arabic:
                        text_parts.append(arabic)
                    if translation:
                        text_parts.append(translation)
                    elif transliteration:
                        text_parts.append("[" + transliteration + "]")
                
                if text_parts:
                    parts.append("{}- {}".format(idx, "\n\n".join(text_parts)))
                    
            elif isinstance(item, str):
                if item.strip():
                    parts.append("{}- {}".format(idx, item.strip()))
            else:
                parts.append("{}- {}".format(idx, str(item)))
        
        return "\n\n".join(parts) if parts else _("No content available.")

    def loadText(self):
        reshaper = ArabicReshaper({
            "language": "Arabic",
            "delete_harakat": False,
            "delete_tatweel": True,
            "support_zwj": True,
            "support_ligatures": True,
            "ARABIC LIGATURE ALLAH": False
        })

        content = ""
        if isinstance(self.chapter, dict) and "TEXT" in self.chapter:
            file_name = self.chapter["TEXT"]
            if file_name.startswith("http"):
                content = _("Online content is not supported in offline mode.")
            else:
                db_path = get_local_db_path(self.lang)
                file_path = join(db_path, file_name)
                if exists(file_path):
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            data = json.load(f)
                            items, _ = self._extract_items(data)
                            if items:
                                content = self._format_items(items)
                    except Exception as e:
                        content = _("Error reading file: ") + str(e)
                else:
                    content = _("File not found locally: ") + file_name
        else:
            items, _ = self._extract_items(self.chapter)
            content = self._format_items(items) if items else _("No content.")

        if not content:
            content = _("No content available for this chapter.")

        reshaped_content = reshaper.reshape(content)
        log_message("ChapterViewer: Loaded text, length: {}".format(len(reshaped_content)))
        self["text"].setText(reshaped_content)
        try:
            self["text"].moveToTop()
        except AttributeError:
            try:
                self["text"].firstPage()
            except AttributeError:
                self["text"].pageUp()

def main(session, **kwargs):
    log_message("HISNMUSLIM plugin started")
    session.open(HisnMuslimMainScreen)

def Plugins(**kwargs):
    log_message("HISNMUSLIM plugin loaded")
    return PluginDescriptor(
        name=_("HisnMuslim - حصن المسلم"),
        description=_("عرض الأذكار من الكتاب والسنة"),
        where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
        icon="hisnmuslim.png",
        fnc=main
    )