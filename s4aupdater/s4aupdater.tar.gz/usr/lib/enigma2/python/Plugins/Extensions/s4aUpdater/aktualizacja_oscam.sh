# Fri Aug 16 09:55:00 AM CEST 2024
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
# Fri Aug 16 09:55:37 AM CEST 2024
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
. $PLUGIN_FOLDER/functions.sh
OSCAM_VERSION='CAMNAME="OScam '

find_oscam
identify_platform
function_oscam_edition
identify_CPU
return_distro
znajdz_sciezke_oscam_config
check_beta_release
identify_ssl

function_download_file "$HTTP_ADDRESS/version" $s4aupdater_version
OSCAM_WERSJA_ZDALNA=$(cat $s4aupdater_version |grep $oscam_version|cut -d '=' -f2| sed -n 1p)
debug "oscam pobrany z pliku  $OSCAM_WERSJA_ZDALNA"
OSCAM_VERSION=$OSCAM_VERSION$OSCAM_WERSJA_ZDALNA'"'
OSCAM_WERSJA_ZDALNA=oscam-$CyCeC$OSCAM_WERSJA_ZDALNA$EMU

debug "oscam z dodanym emu  $OSCAM_WERSJA_ZDALNA"

LIBUSB=true
[ $Processor == sh4 ] &&  LIBUSB=false

debug "OSCAM_WERSJA_ZDALNA $OSCAM_WERSJA_ZDALNA"
[[ $(cat $s4aupdater_version |grep 'libusb'|cut -d '=' -f2) == *"no"* ]] && LIBUSB=false
[[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |grep force_libusb |cut -d '=' -f2) == *"yes"* ]] && LIBUSB=true
if [[ "$OSCAM_EDITION" == *"jejon"* ]]; then
  check_if_ssl_installed
fi
echo -e "_(Your CPU is):                    $Processor"
echo -e "_(Your SSL version is):               $ssl"
echo -e "_(Your oscam config dir is): $config_dir"
echo -e "_(OsCam binary):                        $OSCAMBIN"

[ -d /tmp/s4aUpdater ] || mkdir -p /tmp/s4aUpdater
OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA-$Processor
debug "oscam z dodanym procesorem  $OSCAM_WERSJA_ZDALNA"

case $OSCCAM_EDITION in
  "samur"|"mohamed"|"kitte888")
    temp=''
    LIBUSB=false
    if [ $OSCAM_EDITION == 'kitte888' ] ; then
      if [ $Processor == sh4 ]; then 
        echo "_(Unsupported CPU)"
        exit 0
      fi
    fi
    ;;
  *)  
    [ $ssl != none ] &&  temp="-$ssl"
    ;;
esac

if $LIBUSB ; then
  $OPKGLIST |grep libpcsclite1 || $OPKGINSTALL libpcsclite1 
  temp="$temp-libusb"
fi

if ! [ $Processor == sh4 ]; then    
    if ls /lib/libusb* 1> /dev/null 2>&1; then
        OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA$temp
    else
        if $LIBUSB ; then 
            $OPKGUPDATE && $OPKGINSTALL  libpcsclite1 libusb1 1>/dev/null 2>&1
        fi
        OSCAM_WERSJA_ZDALNA=$OSCAM_WERSJA_ZDALNA$temp
    fi
fi
debug " co pobrac ${HTTP_ADDRESS%l*}l/$OSCAM_BINARIES/$OSCAM_WERSJA_ZDALNA.tar.gz"
savedate=$(stat -c %Y $OSCAM_WITH_PATH )
function_download_file  "${HTTP_ADDRESS%l*}l/$OSCAM_BINARIES/$OSCAM_WERSJA_ZDALNA.tar.gz" /tmp/oscam.tar.gz
tar zxvf   /tmp/oscam.tar.gz  --directory=/tmp 1>/dev/null 2>&1
if [ $? -gt 0 ]; then 
  echo "_(Downloaded archive is corrupted)";
  exit 0;
fi
chmod a+x /tmp/oscam* 1>/dev/null 2>&1

if [ $Processor != sh4 ]; then    
  backup_oscam_file=$OSCAM_WITH_PATH.$(date +"%Y-%m-%d")
  cp -f $OSCAM_WITH_PATH $backup_oscam_file  1>/dev/null 2>&1
  touch -d @${savedate} $backup_oscam_file
fi
kill $oscam_pid
sleep 1
#[ "$OSCAM_EDITION" == 'samur' ] && sed -i 's/cwekey0 /cwekey  /g' $config_dir/oscam.server || sed -i 's/cwekey  /cwekey0 /g' $config_dir/oscam.server
rm -f /tmp/oscam.tar.gz 1>/dev/null 2>&1
cp -f /tmp/oscam* $OSCAM_WITH_PATH 1>/dev/null 2>&1
debug "oscam with path $OSCAM_WITH_PATH"
$OSCAM_WITH_PATH --daemon --restart 2 --pidfile /tmp/.oscam/oscam.pid  --config-dir $config_dir
echo "_(Previous oscam binary saved as:)" $OSCAM_WITH_PATH.$(date +"%Y-%m-%d")
wersja_wtyczki
rm -f  /tmp/oscam* 1>/dev/null 2>&1
