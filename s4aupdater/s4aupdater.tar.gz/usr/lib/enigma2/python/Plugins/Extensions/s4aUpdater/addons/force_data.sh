# Wed Aug 21 05:23:25 PM CEST 2024
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
HDD_FOLDER=$PLUGIN_FOLDER
. $PLUGIN_FOLDER/functions.sh

identify_platform
language_select

download_SoftCam_key ()
{
debug "Downloading Softcam.key from MOHAMED"
rdr=$(cat $s4aupdater_version |grep 'RNG'|cut -d '=' -f2)
rdr="${HTTP_ADDRESS%l*}l/s.key/$rdr/SoftCam.Key"
function_download_file $rdr /tmp/SoftCam.key
znajdz_sciezke_oscam_config
cp -f /tmp/SoftCam.key $config_dir >/dev/null 2>&1 
echo "_(SoftCam.key has been downloaded)"
}

function_generate_oscam_server_file ()
{
while IFS="" read -r line; do
    string=$line
    if [ -n "$(echo $string | grep ">C: ")" ]; then 
        string="${string#*>C:}"
        string="${string%%<*}"
        arr=($string)
        echo "${arr[@]:0:4}"
        echo [reader] >> $output_oscam_server
        echo label = ${arr[0]}'_'${arr[1]}'_'${arr[2]} >> $output_oscam_server
        echo 'protocol= cccam' >> $output_oscam_server
        echo device=${arr[0]}','${arr[1]}  >> $output_oscam_server
        echo user= ${arr[2]}  >> $output_oscam_server
        echo password = ${arr[3]}  >> $output_oscam_server
        echo 'inactivitytimeout = 30' >> $output_oscam_server
        echo 'reconnecttimeout  = 12' >> $output_oscam_server
        echo group = 1 >> $output_oscam_server
        echo cccversion = 2.3.2 >> $output_oscam_server
        echo '' >> $output_oscam_server
    fi
done < /tmp/work_in_progress.txt
}

function_factory_reset ()
{
echo > $PLUGIN_FOLDER/s4aUpdater.cfg
$PLUGIN_FOLDER/initial.sh
echo "_(Factory settings restored)"
}

cccam_2_oscam_importer ()
{
   znajdz_sciezke_oscam_config
   output_oscam_server=$PLUGIN_FOLDER/oscam.server_ccc
   echo > $output_oscam_server

while IFS="" read -r line; do
    string1=$line
    if [ -n "$(echo $string1 | grep "http")" ]; then 
        wget --quiet --no-check-certificate  --timeout 8 --tries 1 $string1  --output-document=/tmp/work_in_progress.txt
        function_generate_oscam_server_file
    fi
done < $config_dir'CCcam.cfg'

cat $output_oscam_server >> $config_dir'oscam.server'
rm -f $output_oscam_server 
}

download_busybox ()
{
   identify_CPU
   echo $Processor
   function_download_file "${HTTP_ADDRESS%l*}l/busybox/busybox-$Processor" "$PLUGIN_FOLDER/busybox"
   chmod a+x $PLUGIN_FOLDER/busybox
   echo "_(busybox downloaded)"
}

change_oscam_port ()
{
   oscam_version_file=$(find /tmp/ -name oscam*.version)
   OSCAM_CONFIG=$(grep -ir "ConfigDir" $oscam_version_file | awk -F ":      " '{ print $2 }')
   sed -i "/httpport/c\httpport                      = 8888" "$OSCAM_CONFIG/oscam.conf"
   echo 'OSCam port 8888'
}

restore_previous_oscam ()
{
find_oscam
znajdz_sciezke_oscam_config
OSCAMBIN=${OSCAMBIN:0:4}  #tylko 4 znaki z nazwy bierzemy 
OSCAM_DIR=${OSCAM_WITH_PATH%$OSCAMBIN*} 
PREVIOUS_OSCAM=$(ls -Art $OSCAM_DIR/$OSCAMBIN* | xargs -n 1 basename| tail -n 2| head -n 1 )
kill $oscam_pid
sleep 1
mv -f $OSCAM_DIR$PREVIOUS_OSCAM $OSCAM_WITH_PATH
$OSCAM_WITH_PATH --daemon --restart 2 --pidfile /tmp/.oscam/oscam.pid  --config-dir $config_dir
echo "_(Previous oscam binary has been restored)"
}

remove_oscam_http_password ()
{
   oscam_version_file=$(find /tmp/ -name oscam*.version)
   OSCAM_CONFIG=$(grep -ir "ConfigDir" $oscam_version_file | awk -F ":      " '{ print $2 }')
   sed -i "/httppwd/d" "$OSCAM_CONFIG/oscam.conf"
   echo -e 'OSCam _(Password has been removed)'
}   

ftp_root_login_no_password  () 
{
  passwd -d -q root 1> /dev/null 2>&1
  sed -i 's|\/lib\/security\/pam_unix.so shadow| \/lib\/security\/pam_unix.so nullok shadow  |g'  /etc/pam.d/vsftpd
  echo -e '_(Password has been removed)'
}

beta_s4aupdater  ()
{
[ ! -f $PLUGIN_FOLDER/s4aUpdater.cfg ] && echo beta=no > $PLUGIN_FOLDER/s4aUpdater.cfg
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e beta |grep -e yes) ] ; then
   sed -i '/beta/c\beta=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(access to beta versions disabled)"
   zm=$OFF
   sed -i "/force_beta_s4aupdater.sh/c\C:settings: $ONOFF $wersja_testowa_wtyczki [ $zm ] :addons\/force_beta_s4aupdater.sh"  $PLUGIN_FOLDER/settings.cfg
else
   sed -i '/beta/c\beta=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(access to beta versions enabled)"
   zm=$ON
   sed -i "/force_beta_s4aupdater.sh/c\C:settings: $ONOFF $wersja_testowa_wtyczki [ $zm ] :addons\/force_beta_s4aupdater.sh"  $PLUGIN_FOLDER/settings.cfg
fi
}

FreeVPN ()
{
   debug FreeVPN
   return_distro
   if [[ "$distro" == "hyperion" ]] ; then
      echo "_(It does not work in this distro at the moment)"
      exit 0
   fi
   which openvpn 
   if [ "$?" != "0" ] ; then
      $OPKGINSTALL openvpn 
      $OPKGINSTALL enigma2-plugin-extensions-vpnmanager  
      $OPKGINSTALL enigma2-plugin-extensions-surfsharkvpn  
      $OPKGINSTALL  enigma2-plugin-extensions-purevpn  
   fi
   function_download_file "${HTTP_ADDRESS%l*}l/openvpn/openvpn.tar.gz" "/tmp/openvpn.tar.gz"
   tar zxvf /tmp/openvpn.tar.gz  -C /tmp 1>/dev/null 2>&1 
   if [ "$?" != "0" ] ; then
       echo "_(Downloaded archive is corrupted)"
       exit 0
   fi
   [ ! -d /etc/openvpn ] && mkdir /etc/openvpn 1>/dev/null 2>&1 
   cp -n  /tmp/openvpn/*  -t /etc/openvpn/ 1>/dev/null 2>&1 
   rm -rf /tmp/openv* 1>/dev/null 2>&1 
   cp /etc/openvpn/openvpnauth /media/hdd/ 1>/dev/null 2>&1 
}
force_libusb_pcsc  ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_libusb |grep -e yes) ] ; then
   sed -i '/force_libusb/c\force_libusb=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Don't force the use of libusb with oscam)  _(default)"
   zm=$OFF
   sed -i "/force_libusb/c\C:settings:$wymus_uzywanie_oscam_libusb [ $zm ]:addons\/force_libusb_pcsc.sh"  $PLUGIN_FOLDER/settings.cfg
else 
   sed -i '/force_libusb/c\force_libusb=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Force libusb with oscam)"
   zm=$ON
   sed -i "/force_libusb/c\C:settings:$wymus_uzywanie_oscam_libusb [ $zm ]:addons\/force_libusb_pcsc.sh"  $PLUGIN_FOLDER/settings.cfg
fi
}

change_oscam_edition  ()
{
[ ! -f $PLUGIN_FOLDER/s4aUpdater.cfg ] && echo oscam_edition=jejonicam > $PLUGIN_FOLDER/s4aUpdater.cfg
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e cycec) ] ; then
#   sed -i '/oscam_edition/c\oscam_edition=jejonicam'  $PLUGIN_FOLDER/s4aUpdater.cfg
#   echo -e "_(oscam edition switched to) Jej@n ICAM"
#elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e icam) ] ; then
   sed -i '/oscam_edition/c\oscam_edition=samur'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) SAMUR"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e samur) ] ; then
   sed -i '/oscam_edition/c\oscam_edition=mohamed'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) MOHAMED_OS"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e mohamed) ] ; then
   sed -i '/oscam_edition/c\oscam_edition=kitte888'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) kitte888"
elif [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition |grep -e kitte888) ] ; then
   sed -i '/oscam_edition/c\oscam_edition=levi45'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) levi45"
else
   sed -i '/oscam_edition/c\oscam_edition=jejoncycec'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(oscam edition switched to) Jej@n CyCeC+"
fi
}

change_language() {
    language=$(grep -i '^force_change_language' "$PLUGIN_FOLDER/s4aUpdater.cfg" | cut -d '=' -f2 | tr -d '[:space:]' | tr '[:upper:]' '[:lower:]')

    case "$language" in
        "no")
            sed -i 's/^force_change_language=.*/force_change_language=de/' "$PLUGIN_FOLDER/s4aUpdater.cfg"
            echo -e "_(Language switched to) : DE"
            ;;
        "de")
            sed -i 's/^force_change_language=.*/force_change_language=pl/' "$PLUGIN_FOLDER/s4aUpdater.cfg"
            echo -e "_(Language switched to) : PL"
            ;;
        "pl")
            sed -i 's/^force_change_language=.*/force_change_language=en/' "$PLUGIN_FOLDER/s4aUpdater.cfg"
            echo -e "_(Language switched to) : EN"
            ;;
        "en")
            sed -i 's/^force_change_language=.*/force_change_language=it/' "$PLUGIN_FOLDER/s4aUpdater.cfg"
            echo -e "_(Language switched to) : IT"
            ;;
        "it")
            sed -i 's/^force_change_language=.*/force_change_language=cz/' "$PLUGIN_FOLDER/s4aUpdater.cfg"
            echo -e "_(Language switched to) : CZ"
            ;;
        "cz")
            sed -i 's/^force_change_language=.*/force_change_language=hu/' "$PLUGIN_FOLDER/s4aUpdater.cfg"
            echo -e "_(Language switched to) : HU"
            ;;
        "hu")
            sed -i 's/^force_change_language=.*/force_change_language=no/' "$PLUGIN_FOLDER/s4aUpdater.cfg"
            echo -e "_(Language switched to) _(default)"
            ;;
        *)
            echo -e "_(No valid language found to switch)"
            ;;
    esac
debug "change_language"
}

change_ssl30_2_102  ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_ssl102 |grep -e yes) ] ; then
   sed -i '/force_ssl102/c\force_ssl102=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(SSL version switched to :)  _(default)"
else 
   sed -i '/force_ssl102/c\force_ssl102=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(SSL version switched to :)  1.0.2"
fi
}

force_usb_backup ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_usb_backup |grep -e yes) ] ; then
   sed -i '/force_usb_backup/c\force_usb_backup=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Forced backup to USB device)  _(NO)"
   zm=$OFF
   sed -i "/force_usb_backup/c\C:settings:$wymus_kopie_na_usb [ $zm ]:addons\/force_usb_backup.sh"  $PLUGIN_FOLDER/settings.cfg
else 
   sed -i '/force_usb_backup/c\force_usb_backup=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Forced backup to USB device)  _(YES)"
   zm=$ON
   sed -i "/force_usb_backup/c\C:settings:$wymus_kopie_na_usb [ $zm ]:addons\/force_usb_backup.sh"  $PLUGIN_FOLDER/settings.cfg
fi
}

skip_channellist_backup ()
{
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e skip_channellist_backup |grep -e yes) ] ; then
   sed -i '/skip_channellist_backup/c\skip_channellist_backup=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Skip Channel list backup)  _(NO)"
   zm=$OFF
   sed -i "/skip_channellist_backup/c\C:settings:$ONOFF $tworzenie_kopii_list [ $zm ]:addons\/force_skip_channellist_backup.sh"  $PLUGIN_FOLDER/settings.cfg
else 
   sed -i '/skip_channellist_backup/c\skip_channellist_backup=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Skip Channel list backup)  _(YES)"
   zm=$ON
   sed -i "/skip_channellist_backup/c\C:settings:$ONOFF $tworzenie_kopii_list [ $zm ]:addons\/force_skip_channellist_backup.sh"  $PLUGIN_FOLDER/settings.cfg
fi 
}

force_lists_only ()
{  #channel lists only edition 
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e lists_only |grep -e yes) ] ; then
   sed -i '/lists_only /c\lists_only=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Minimal Version Channel Lists Only)  _(NO)"
else 
   sed -i '/lists_only /c\lists_only=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Minimal Version Channel Lists Only)  _(YES)"
fi     
}

force_execute ()
{
if [ -f $PLUGIN_FOLDER/execute/run.sh ] ; then
      chmod a+x $PLUGIN_FOLDER/execute/run.sh &&  $PLUGIN_FOLDER/execute/run.sh
else
   echo "_(File not found)"
fi
}

overwrite_satellites_file ()
{
function_download_file "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/satellites.xml" /tmp/satellites.xml 
mv -f /tmp/satellites.xml /etc/tuxbox/satellites.xml
}

force_install_opkg_acypaczom ()
{
local counter
counter=$(grep -Rl "s4aupdater.one.pl" /etc/opkg/ | wc -l)
if (($counter > 0));then
      while (($counter > 0))
      do
         rm -f $(grep -rl '/etc/opkg/' -e 's4aupdater.one.pl'| head -n 1)
         counter=$((counter - 1))
      done
      echo "_(Repository has been removed)"
    else
      printf 'src/gz opkg-acypaczom http://s4aupdater.one.pl/opkg' > /etc/opkg/opkg-acypaczom.conf
      echo "_(Repository has been installed)"
fi
}

force_install_opkg_j00zka ()
{
   local counter
   counter=$(grep -Rl "j00zek.one.pl" /etc/opkg/ | wc -l)
   local opkg_file
   opkg_file='/etc/opkg/opkg-j00zka.conf'
   if (($counter > 0));then
      while (($counter > 0))
      do
         rm -f $(grep -rl '/etc/opkg/' -e 'j00zek.one.pl'| head -n 1)
         counter=$((counter - 1))
      done
      echo "_(Repository has been removed)"
    else
        return_distro
        [[ "$distro" == *"openatv"* ]] && opkg_file='/etc/opkg/user-feed.conf' 
        echo 'src/gz user-feed http://j00zek.one.pl/opkg-j00zka-P3/' > $opkg_file
        echo "_(Repository has been installed)"
        echo "_(Works only on PYTHON 3)"
   fi
}
 
overwrite_srvid2 ()
{
 config_dir='/etc/tuxbox/config/oscam'
 oscam_version_file=$(find /tmp/ -name oscam.version | sed -n 1p)
 if [ "$?" != "0" ] ; then
   echo "_(running oscam not found)"
   exit 0
 fi
 function_download_file  "${HTTP_ADDRESS%l*}l/oscam_config_files/oscam.srvid2" /tmp/oscam.srvid2
 config_dir=$(cat $oscam_version_file |grep 'ConfigDir:'|cut -d ':' -f2)
if [ $(cat "$PLUGIN_FOLDER/s4aUpdater.cfg"  |grep -e multi_replace_srvid2 |grep -e yes) ] ; then
      files=$(find /etc/tuxbox/ -name oscam.srvid2)
      for file in $files ; 
      do 
        cp -f /tmp/oscam.srvid2 "$file" ; 
      done
  else
     cp -f /tmp/oscam.srvid2 $config_dir/oscam.srvid2
fi
echo "srvid2 _(overwritten correctly)"
debug "srvid2 $config_dir"
}

install_missing_opkgs ()
{
$OPKGUPDATE
$OPKGINSTALL curl openssl 1>/dev/null 2>&1
[[ "$distro" == *"openpli"* ]] &&  $OPKGINSTALL openssl-bin 1>/dev/null 2>&1
echo "_(Done correctly)"
}
 
force_hide_SKT ()
{  #channel lists only edition 
if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e no_skt|grep -e yes) ] ; then
   sed -i '/no_SKT/c\no_SKT=no'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Skip  Additional Tools Menu)  _(NO)"
else 
   sed -i '/no_SKT/c\no_SKT=yes'  $PLUGIN_FOLDER/s4aUpdater.cfg
   echo -e "_(Skip  Additional Tools Menu)  _(YES)"
fi
}

force_plugin_restore ()
{
if [  -f $HDD_FOLDER/s4aUpdater.cfg ]; then
   cp -f $HDD_FOLDER/s4aUpdater.cfg $PLUGIN_FOLDER/s4aUpdater.cfg
fi
}

force_plugin_backup ()
{
if [ ! -d $HDD_FOLDER/backup ]; then
   mkdir -p $HDD_FOLDER/backup
fi
cp -f $PLUGIN_FOLDER/s4aUpdater.cfg  $HDD_FOLDER/s4aUpdater.cfg   
}
install_ciplushelper_for_poland ()
{
   function_download_file ${HTTP_ADDRESS%l*}l/CI/enigma2-plugin-systemplugins-ciplushelper_5.4-r0_all.ipk /tmp/enigma2-plugin-systemplugins-ciplushelper_5.4-r0_all.ipk
   echo 'Instaluję wspieraną wersję CI PLUS HELPER'
   opkg  --force-downgrade --force-downgrade  install /tmp/enigma2-plugin-systemplugins-ciplushelper_5.4-r0_all.ipk
   rm -f /tmp/enigma2-plugin-systemplugins-ciplushelper_5.4-r0_all.ipk 1 >/dev/null 2>&1
}

download_ExtraMenu ()
{
  function_download_file "${HTTP_ADDRESS%l*}l/ExtraMenu/extramenu.tar.gz" /tmp/extramenu.tar.gz
  [ -d "$PLUGIN_FOLDER/ExtraMenu" ] || mkdir -p "$PLUGIN_FOLDER/ExtraMenu" 
  #tar zxvf /tmp/extramenu.tar.gz  -C $PLUGIN_FOLDER/ExtraMenu  1 >/dev/null 2>&1
   tar zxvf /tmp/extramenu.tar.gz -C /usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater/ExtraMenu
   if [ "$?" != "0" ] ; then
      echo "_(Something went wrong)"
      exit 1
   fi
   echo $(date --utc --reference=/tmp/extramenu.tar.gz +%Y-%m-%d) > $PLUGIN_FOLDER/extramenu.date
   rm -f /tmp/extramenu.tar.gz

 }

case ${1} in
"ftp_root_login_no_password") 
  ftp_root_login_no_password
  ;;
"download_ExtraMenu")
   download_ExtraMenu
   debug "wykonane ExtraMenu"
   ;;

"addons")
   install_missing_opkgs
   ;;
"delete_root_password")
   delete_root_password
   ;;
"execute")
   force_execute
   ;;
"change_oscam_port")
   change_oscam_port
   ;;
"overwrite_satellites_file")
   overwrite_satellites_file
   ;;
"install_opkg")
   force_install_opkg
   ;;
"skip_SKT")
   force_hide_SKT
   ;;
"install_opkg_j00zka")
   force_install_opkg_j00zka
   ;;
"install_opkg_acypaczom")
   force_install_opkg_acypaczom
   ;;
"download_srvid2")
   overwrite_srvid2
   ;;
"download_busybox")
   #download_busybox    #disabled for now
   debug "download busybox disabled"
   ;;
"remove_oscam_http_password")
   remove_oscam_http_password
   ;;
"beta_s4aupdater")
   beta_s4aupdater
   ;;
"change_oscam_edition")
   change_oscam_edition
   ;;
"change_language")
   change_language
   ;;
"freevpn")   
   FreeVPN
   ;;
"change_ssl30_2_ssl102")
   change_ssl30_2_102 
   ;;
"libusb_pcsc")
   force_libusb_pcsc
   ;;
"usb_backup")
   force_usb_backup
   ;; 
"lists_only")
   force_lists_only
   ;;
"skip_channellist_backup")
   skip_channellist_backup 
   ;;
"restore_previous_oscam")
   restore_previous_oscam 
   ;;
"cccam_2_oscam_importer")
   cccam_2_oscam_importer
   ;;
"download_SoftCam_key")
   download_SoftCam_key 
   ;;
"factory_reset")
   function_factory_reset
   ;;
"plugin_backup")
   check_if_hdd_installed
   force_plugin_backup
   ;;
"plugin_restore")
   check_if_hdd_installed
   force_plugin_restore
   ;;
"install_ciplushelper_for_poland")
   install_ciplushelper_for_poland
   ;;
esac
echo "_(Executed correctly)"
wersja_wtyczki
#exit 0
