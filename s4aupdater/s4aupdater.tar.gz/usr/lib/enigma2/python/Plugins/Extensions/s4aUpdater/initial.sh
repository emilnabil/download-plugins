# Sun Dec 3 12:00:00 AM CET 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
# Sun Dec 3 12:45:40 PM CET 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
#set -e 
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater

. $PLUGIN_FOLDER/functions.sh

#chown -R root $PLUGIN_FOLDER
#identify_platform
#which bash
#if [ "$?" != "0" ] ; then
#  $OPKGINSTALL bash
#fi

touch $PLUGIN_FOLDER/s4aUpdater.cfg
 identify_CPU      #2023-09-30
update_s4aUpdater_configfile beta
update_s4aUpdater_configfile logfile
update_s4aUpdater_configfile force_change_language
update_s4aUpdater_configfile force_usb_backup
update_s4aUpdater_configfile force_libusb 
update_s4aUpdater_configfile multi_replace_srvid2  
update_s4aUpdater_configfile skip_channellist_backup
update_s4aUpdater_configfile backup_copies 6
update_s4aUpdater_configfile oscam_edition jejon
update_s4aUpdater_configfile lists_only
update_s4aUpdater_configfile no_SKT
update_s4aUpdater_configfile skip_channel_list "empty empty1"

#[[ -d $PLUGIN_FOLDER/dodatki ]] && rm -rf "$PLUGIN_FOLDER/dodatki"  1>/dev/null 2>&1 
return_distro 
if [ "$distro" == "openpli" ]; then
    PYTHON_VERSION=$(python -c 'import sys; print(sys.version_info[0])')
    (( "$PYTHON_VERSION" != "3" )) && python_requests='python-requests' || python_requests='python3-requests' 
    opkg list-installed |grep $python_requests
    if [ "$?" != "0" ]; then
        opkg update 
        opkg install $python_requests 
    else
         debug "znaleziono $python_requests"
    fi 
fi

language_select
function_generate_menu
check_beta_release
#function_download_file "$HTTP_ADDRESS/version" $s4aupdater_version
#function_download_file "${HTTP_ADDRESS%l*}l/s4aupdater_list.txt" $s4aupdater_lista
function_oscam_edition
modify_menu
#ln_sf
