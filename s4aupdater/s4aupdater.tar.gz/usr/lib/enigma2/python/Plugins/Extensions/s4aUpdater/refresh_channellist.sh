# Tue Sep 26 09:21:31 AM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
FOLDER_LIST=/tmp/lists
[ ! -d $FOLDER_LIST ] && mkdir -p $FOLDER_LIST

. $PLUGIN_FOLDER/functions.sh

function_download_file "$HTTP_ADDRESS/s4aupdater_list.txt"  $s4aupdater_lista
#LANGUAGE_IDENT=$(wget -q -O - "http://localhost/web/settings" | grep -A 1 config.osd.language)

return_distro
language_select

if test -f $PLUGIN_FOLDER/first ; then
    data_listy_epox=00000001 #random date in past.
    touch $s4aupdater_lista
    rm -f $PLUGIN_FOLDER/first
    debug "first run, date rolled back"
else
    data_listy_epox=$(date -r $LISTY_KANALOW "+%s" )
    echo biore z pliku
fi
SKIP_CHANNEL_LISTS=$(cat $PLUGIN_FOLDER/s4aUpdater.cfg |grep 'skip_channel_lists'|cut -d '=' -f2)

#[[  "$data_listy_epox" >  "$(date -r $s4aupdater_lista "+%s" )" ]]  &&   exit 0 #jesli lista_kanalow.cfg nowsza niz s4aupdater_lista, to wyjdz
echo $build_list >$LISTY_KANALOW
format=" %-13s %4s %14s"
while IFS="" read -r line; do
    string=$line
    if [ -n "$(echo $string | grep "_version:")" ]; then 
        a=$string #"jakis text1 _ potem drugi"
        b=${a%_version*}   #tu wycinamy nazwe listy , wszystko przed _version
        lista_autor=${b%_*}
        if [[ "$SKIP_CHANNEL_LISTS" != *"$lista_autor"* ]]; then
            printf "C:listy_kanalow:" >>$LISTY_KANALOW
            lista_autor=$(printf "%-15s" "$lista_autor")
            lista_data=${a#*:} # remove prefix ending in ":"  zostaje data - zostaje za znakiem
            lista_data=$(echo "$lista_data"|xargs ) #wycinamy zbedne spacje w dacie, ktore mieszaja w ukladzie list
            lista_data=$lista_data'  ' #' | '
            b=${a%_version*}  #tu wycinamy nazwe listy , wszystko przed _version
            tmp=${b#*_}   # zostawiamy tylko ile jest satelit
            function_case $tmp
            b=$tmp
            lista_autor=$(printf "%-11s " $lista_autor)
            lista_liczba_sat=$PRINT_LIST
            lista_autor="$lista_autor""$lista_data"" ""$lista_liczba_sat"
            printf "$lista_autor" >>$LISTY_KANALOW
            b=${a%_version*}   #tu wycinamy nazwe listy , wszystko przed _version
            printf " :$FOLDER_LIST/" >>$LISTY_KANALOW
            printf $b >>$LISTY_KANALOW
            printf '.sh :Pobieranie Listy Kanałów'>>$LISTY_KANALOW
            printf "\n" >>$LISTY_KANALOW
        fi
    fi
done < $s4aupdater_lista

while read line; do
    string=$line
    if [ -n "$(echo $string | grep "_version:")" ]; then 
        b=${string%_version*}
        printf "$PLUGIN_FOLDER/listy_kanalow.sh  " >$FOLDER_LIST/$b.sh
        printf $b >>$FOLDER_LIST/$b.sh
    fi
done < $s4aupdater_lista
chmod a+x $FOLDER_LIST/*.sh
