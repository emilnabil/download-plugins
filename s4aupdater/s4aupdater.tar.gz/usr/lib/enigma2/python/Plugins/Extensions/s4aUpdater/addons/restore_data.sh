# Sun Oct 29 12:10:39 PM CET 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater
PICON_FOLDER='/usr/share/enigma2/picon'
is_oscam=false
. $PLUGIN_FOLDER/functions.sh

SRVID2=$(cat $s4aupdater_version|grep srvid2_jejon|cut -d '=' -f2)
sed -i "s|oscam.srvid2:|oscam.srvid2 ($SRVID2):| g" $PLUGIN_FOLDER/SKT.cfg
language_select
ver_plugin=$(cat $PLUGIN_FOLDER/version.py|grep Version|cut -d '=' -f2)
ver_plugin=${ver_plugin:1:13} 

restore_channellist_function ()
{
[ -d /tmp/backup_scripts ] && rm -fr  /tmp/backup_scripts/* >/dev/null 2>&1 ||  mkdir /tmp/backup_scripts
[ -d $HDD_FOLDER/backup ] ||  mkdir $HDD_FOLDER/backup
ls -A $HDD_FOLDER/backup > /tmp/s4aupdater_channellistbackup
echo "S:restore_list:$przywracanie_kopii:addons/restore_channellist.sh" > $PLUGIN_FOLDER/restore_channellist.cfg
oscam_pid=$(find /tmp/ -name "oscam*.pid")
if test $oscam_pid ; then
  oscam_pid=`cat $(find /tmp/ -name "oscam*.pid")`
  OSCAM_WITH_PATH=$($REALPATH /proc/$oscam_pid/exe  )
  config_dir=$(cat $(find /tmp/ -name oscam.version |sed -n 1p)|grep ConfigDir| awk -F ":      " '{ print $2 }')
  is_oscam=true
fi

while IFS= read -r line; do
  printf 'C:restore_channellist:' >> $PLUGIN_FOLDER/restore_channellist.cfg
  var1=$line
  case $var1 in 
    *"list"*) 
      printf  ${var1::-7}| sed 's/backup_//' >> $PLUGIN_FOLDER/restore_channellist.cfg  #wycinamy z nazwy pokazywanej backup_list - jest czytelniej
      echo  ":/tmp/backup_scripts/$var1.sh :$przywracanie_list_kanalow" >> $PLUGIN_FOLDER/restore_channellist.cfg
      echo 'mkdir -p /tmp/s4aupdater /tmp/temp_files' > /tmp/backup_scripts/$var1'.sh'
      echo 'tar zxvf '$HDD_FOLDER/backup/$var1' -C /tmp/s4aupdater >/dev/null 2>&1  ' >> /tmp/backup_scripts/$var1'.sh'
      echo 'rm -f /etc/enigma2/lista_* /etc/enigma2/userbou* /etc/enigma2/altern* /etc/enigma2/bouque* /etc/enigma2/lamed*  >/dev/null 2>&1 '>> /tmp/backup_scripts/$var1'.sh'
      echo 'find /tmp/s4aupdater -type f -exec mv -f {} /tmp/temp_files \;' >> /tmp/backup_scripts/$var1'.sh'
      echo 'mv -f /tmp/temp_files/*.xml /etc/tuxbox/' >> /tmp/backup_scripts/$var1'.sh'
      echo 'cp -fr /tmp/temp_files/* /etc/enigma2/ ' >> /tmp/backup_scripts/$var1'.sh'
      echo "echo  $lista_kanalow_przywrocona"  >> /tmp/backup_scripts/$var1'.sh'
      echo 'wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1'>>/tmp/backup_scripts/$var1'.sh' 
      echo 'sleep 1' >>/tmp/backup_scripts/$var1'.sh' 
      echo 'wget -qO - http://127.0.0.1/web/servicelistreload?mode=4 > /dev/null 2>&1 '>>/tmp/backup_scripts/$var1'.sh'   
      echo "echo s4aUpdater  $ver_plugin" >> /tmp/backup_scripts/$var1'.sh'
      echo 'rm -rf /tmp/temp_files /tmp/s4aupdater' >> /tmp/backup_scripts/$var1'.sh'
      ;;
  *"oscam"* )
      if $is_oscam ;  then
        printf  ${var1::-7}| sed 's/backup_//' >> $PLUGIN_FOLDER/restore_channellist.cfg  #wycinamy z nazwy pokazywanej backup_list - jest czytelniej
        printf  ":/tmp/backup_scripts/$var1.sh :Przywracanie_konfiguracji_oscam \n" >> $PLUGIN_FOLDER/restore_channellist.cfg
        echo 'mkdir -p /tmp/s4aupdater /tmp/temp_files' >> /tmp/backup_scripts/$var1'.sh'
        echo 'tar zxvf '$HDD_FOLDER/backup/$var1' -C /tmp/s4aupdater >/dev/null 2>&1  ' >> /tmp/backup_scripts/$var1'.sh'
        echo 'find /tmp/s4aupdater -type f -exec mv -f {} /tmp/temp_files \;' >> /tmp/backup_scripts/$var1'.sh'
        echo "cp -fr /tmp/temp_files/* $config_dir" >> /tmp/backup_scripts/$var1'.sh'
        echo 'kill  '$oscam_pid >> /tmp/backup_scripts/$var1'.sh'
        echo "$OSCAM_WITH_PATH  --daemon  --restart 2 --config-dir $config_dir"  >> /tmp/backup_scripts/$var1'.sh'
        echo  "echo $konfiguracja_oscama_przywrocona">> /tmp/backup_scripts/$var1'.sh'
        echo "echo s4aUpdater  $ver_plugin" >> /tmp/backup_scripts/$var1'.sh'
        echo 'rm -rf /tmp/temp_files /tmp/s4aupdater' >> /tmp/backup_scripts/$var1'.sh'
      fi
      ;;
  *)
      printf  ${var1} >> $PLUGIN_FOLDER/restore_channellist.cfg
      printf  ':/tmp/backup_scripts/'$var1'.sh :Przywracanie danych \n' >> $PLUGIN_FOLDER/restore_channellist.cfg
      echo "tar zxvf $HDD_FOLDER/backup/$var1 -C / >/dev/null 2>&1  " >> /tmp/backup_scripts/$var1'.sh'
      echo "echo Data copy restored" >> /tmp/backup_scripts/$var1'.sh'
      echo "echo s4aUpdater  $ver_plugin" >> /tmp/backup_scripts/$var1'.sh'
      ;;
  esac
done < /tmp/s4aupdater_channellistbackup
chmod -R a+x /tmp/backup_scripts
}

restore_picons ()
{
[ -d /tmp/s4aUpdater/picon ] && rm -rf /tmp/s4aUpdater/picon/* >/dev/null 2>&1  || mkdir -p /tmp/s4aUpdater/picon
[ -d /tmp/s4aUpdater/tmp ] && rm -rf /tmp/s4aUpdater/tmp/* >/dev/null 2>&1  || mkdir -p /tmp/s4aUpdater/tmp  
if [ -f $HDD_FOLDER/backup/picon.tar.gz ] ; then
  unzip -o $HDD_FOLDER/backup/picon.zip  -d /tmp/s4aUpdater/tmp 
  [[ -d ${HDD_FOLDER::11}/picon ]] && PICON_FOLDER=${HDD_FOLDER::11}/picon
  find /tmp/s4aUpdater/tmp -type f -exec mv -f {} /tmp/s4aUpdater/picon \  >/dev/null 2>&1
  cp -fr /tmp/s4aUpdater/picon/* $PICON_FOLDER  >/dev/null 2>&1 
  sync && rm -rf /tmp/s4aUpdater  >/dev/null 2>&1
else
  echo -e "_(File not found) picon.zip"
fi 
}

 
check_if_hdd_installed
case ${1} in 
  "picon")
      restore_picons
      ;;
  *) 
      restore_channellist_function
      ;;
esac