# Tue Sep 12 12:00:00 AM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER=/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater

. $PLUGIN_FOLDER/functions.sh
iptv=false
lista_='lista_'
lista_do_pobrania=$1
if [[ $lista_do_pobrania == *"_ipt_"* ]]; then
   iptv=true
   make_backup=false
   lista_=iptv_lista_
fi  #sprawdzamy, czy iptv, nie kasujemy innych list
[ ! -d $PLUGIN_FOLDER/backup ] &&  mkdir -p $PLUGIN_FOLDER/backup  >/dev/null 2>&1
[ ! -d /tmp/backup_scripts ] && mkdir -p /tmp/backup_scripts  >/dev/null 2>&1

identify_list_to_download ()
{
if [[ "$lista_do_pobrania" == "" ]] ; then
  ls /etc/enigma2/lista_* >/dev/null 2>&1
  if [ $? -ne 0 ]; then
       echo "_(No list found, exiting)"
       exit 0
  else
      make_backup=false
      lista_do_pobrania=$(ls /etc/enigma2/$lista_*)
      lista_do_pobrania=${lista_do_pobrania#*_}
   fi
fi
[ -f /etc/enigma2/lista_$lista_do_pobrania ] && make_backup=false
}

download_selected_list ()
{
   local co_wyswietlic 
   function_case ${lista_do_pobrania#*_} 
   #co_wyswietlic="$PRINT_LIST"
   co_wyswietlic="$PRINT_LIST"
   echo "_(Downloading)   ${lista_do_pobrania%_*} $co_wyswietlic"           #$lista_do_pobrania czyja i ile satelit rozdzilone
   function_download_file $wynik_test_gdzie_plik $FILE
   debug 'debug lista do pobrania '$lista_do_pobrania
}
identify_CPU
identify_list_to_download
adres_pliku='_url:'
 if [[ "$1" == "" ]] ; then
    function_download_file "${HTTP_ADDRESS%l*}l/s4aupdater_list.txt" "$s4aupdater_lista"
 fi
[ -f /etc/enigma2/lista_$lista_do_pobrania ]  &&  make_backup=false

adres_pliku=$lista_do_pobrania$adres_pliku
wynik_test_gdzie_plik=''

while IFS= read -r line; do
   [ -n "$(echo $line | grep $adres_pliku )" ] && wynik_test_gdzie_plik=${line#*:}
done < $s4aupdater_lista
[ -d /tmp/tmp ] && rm -rf /tmp/tmp/* || mkdir -p /tmp/tmp
[ -d /tmp/s4aUpdater ] && rm -rf /tmp/s4aUpdater/* || mkdir -p /tmp/s4aUpdater

FILE=/tmp/lista
if [ -n "$(echo $wynik_test_gdzie_plik | grep ".gz" )" ]; then
   FILE=$FILE'.tar.gz'
   download_selected_list 
   tar -zxvf $FILE -C /tmp/tmp >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf /tmp/tmp  >/dev/null 2>&1
      rm -f $FILE 
      exit 0
   fi

 elif [ -n "$(echo $wynik_test_gdzie_plik | grep ".zip" )" ]; then
   FILE=$FILE'.zip'
   download_selected_list
   unzip  $FILE  -d /tmp/tmp  >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf /tmp/tmp  >/dev/null 2>&1
      rm -f $FILE 
      exit 0
   fi

 elif [ -n "$(echo $wynik_test_gdzie_plik | grep ".xz" )" ]; then
   FILE=$FILE'.tar.xz'
   download_selected_list
   tar -xJf $FILE -C /tmp/tmp >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf /tmp/tmp  >/dev/null 2>&1
      rm -f $FILE 
      exit 0
   fi

 elif [ -n "$(echo $wynik_test_gdzie_plik | grep ".bz2" )" ]; then
   FILE=$FILE'.tar.bz2'
   download_selected_list
   tar -xjf $FILE -C /tmp/tmp >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf $/tmp/tmp  >/dev/null 2>&1
      rm -f $FILE 
      exit 0
   fi

 elif [ -n "$(echo $wynik_test_gdzie_plik | grep ".rar" )" ]; then
   FILE=$FILE'.rar'
   download_selected_list
   which unrar 1>/dev/null 2>&1
   if [ $? -gt 0 ] ; then
      opkg install unrar >/dev/null 2>&1
   fi
   unrar e $FILE  >/dev/null 2>&1
   if [ $? -gt 0 ]; then
      echo "_(Corrupted archive)"
      rm -rf /tmp/tmp  >/dev/null 2>&1
      rm -f $FILE 
      exit 0
   fi

 else 
   echo "_(Corrupted archive)"
   rm -rf /tmp/tmp  >/dev/null 2>&1
   rm -f $FILE 
   exit 0
fi
rm -f $FILE  >/dev/null 2>&1
find /tmp/tmp -type f -exec mv -f  {} /tmp/s4aUpdater \;
rm -rf /tmp/tmp   >/dev/null 2>&1
#sleep 1
if $make_backup ; then
   check_if_hdd_installed
   backup_channel_list
fi
if $iptv ; then 
   mv -f /tmp/s4aUpdater/*.m3u   /etc/enigma2 >/dev/null 2>&1
   if [[ -s "/etc/enigma2/bouquets.tv" && -z "$(tail -c 1 "/etc/enigma2/bouquets.tv")" ]]; then
      debug 'jest pusta linia w bouquets'
   else 
      printf "\n">>/etc/enigma2/bouquets.tv
   fi
   rm -f /tmp/s4aUpdater/*.md
   tabela=$(find /tmp/s4aUpdater -name userb*.tv)
   for i in $tabela ; do
      printf "#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET \"$(basename $i)\" ORDER BY bouquet\n"  >>/etc/enigma2/bouquets.tv
   done
else
   debug usuwanie zawartosci /etc/enigma2/
   rm -f /etc/enigma2/lista_*
   rm -f /etc/enigma2/*.tv
   rm -f /etc/enigma2/*.radio
   rm -f /etc/enigma2/*.del
   [ -f /etc/enigma2/lamedb5 ] &&  rm -f /etc/enigma2/lamedb5
   ls /etc/enigma2/$lista_*  >/dev/null 2>&1
   if [ $? == 0 ] ; then
      rm -f $(ls /etc/enigma2/$lista_*);
   fi 
   cp -f /tmp/s4aUpdater/*.radio   /etc/enigma2 
fi
cp -f /tmp/s4aUpdater/*.tv   /etc/enigma2
[ -f /tmp/s4aUpdater/lamedb ] && cp -f /tmp/s4aUpdater/lamedb   /etc/enigma2
[ -f /tmp/s4aUpdater/lamedb5 ] &&  cp -f /tmp/s4aUpdater/lamedb5   /etc/enigma2
[ -f /tmp/s4aUpdater/satellites.xml ] &&  cp -f /tmp/s4aUpdater/satellites.xml   /etc/tuxbox
[ -f /tmp/s4aUpdater/terrestrial.xml ] &&  cp -f /tmp/s4aUpdater/terrestrial.xml   /etc/tuxbox
[ -f /tmp/s4aUpdater/cables.xml ] &&  cp -f /tmp/s4aUpdater/cables.xml   /etc/tuxbox
[ -f /tmp/s4aUpdater/atsc.xml ] &&  cp -f /tmp/s4aUpdater/atsc.xml   /etc/tuxbox

date +%Y-%m-%d > /etc/enigma2/$lista_$lista_do_pobrania
rm -rf /tmp/s4aUpdater   >/dev/null 2>&1
echo -e "_(Channel list actualised)"
echo -e "_(Press EXIT button)"
wget -qO - "http://127.0.0.1/web/servicelistreload?mode=0" > /dev/null 2>&1                   # przeladowanie: userbouquet.*.tv ; userbouquets.tv ; lamedb
sleep 1
wget -qO - "http://127.0.0.1/web/servicelistreload?mode=4" > /dev/null 2>&1                   # przeladowanie: blacklist ; whitelist
wersja_wtyczki
