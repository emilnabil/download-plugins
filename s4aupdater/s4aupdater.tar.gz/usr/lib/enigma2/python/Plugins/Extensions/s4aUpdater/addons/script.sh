# Wed Sep 20 06:19:57 PM CEST 2023
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
tmpval=$(basename $0)
str=${tmpval%%_*}'_data.sh'
tmpval=${tmpval#*_}
tmpval=${tmpval%.*}
/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater/addons/$str $tmpval