# -*- coding: utf-8 -*-
#!/usr/bin/env python
from __future__ import absolute_import
import gettext, os, sys #, stat
pyVersion = sys.version_info[0] #konstrukcja wspierajaca nboxa
 
## Print total number of arguments
#print ('Total number of arguments:', format(len(sys.argv)))
 
## Print all arguments
#print ('Argument List:', str(sys.argv))
 
## Print arguments one by one
#print ('First argument:',  str(sys.argv[0]))
#print ('Second argument:',  str(sys.argv[1]))
#print ('Third argument:',  str(sys.argv[2]))
#print ('Fourth argument:',  str(sys.argv[3]))

from Components.ActionMap import ActionMap, HelpableActionMap, NumberActionMap
from Components.Button import Button
from Components.config import config, ConfigBoolean, ConfigClock
from Components.GUIComponent import *
from Components.Input import Input
from Components.Label import Label
from Components.Language import language
from Components.MenuList import MenuList
from Components.ScrollLabel import ScrollLabel
from Components.SystemInfo import SystemInfo
from enigma import *
from Plugins.Plugin import PluginDescriptor
#from RecordTimer import *
from Screens.ChoiceBox import ChoiceBox
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import *
from time import *
import subprocess


#if pyVersion == 2:
#    import urllib2
#else:
#    import urllib.request as urllib2

from .version import Version
from .s4afunctions import *

pluginpath = '/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater'
s4aUpdater_pluginversion = 's4aUpdater'
s4aUpdater_readme = os.path.join(pluginpath, 'readme.txt')
splitchar = ':'
session = None
plugin_title = 's4aUpdater v. %s' % Version
s4av_url='http://s4aupdater.one.pl/'

s4aupdater_cfg = os.path.join(pluginpath, 's4aUpdater.cfg')
if not os.path.exists(s4aupdater_cfg):
    with open(s4aupdater_cfg, "w") as file:
        file.write("beta=no\n")

OPKGUPDATE, OPKGUPGRADE, OPKGINSTALL, OPKGLIST = identify_platform()
PY3 = True
try:
    # Python 3
    from subprocess import run
except ImportError:
    # Python 2
    PY3 = False


if PY3:
    subprocess.run(["chown", "-R", "root", pluginpath])
    try:
        subprocess.run(["which", "bash"], check=True)
    except subprocess.CalledProcessError:
        subprocess.run(OPKGINSTALL.split() + ["bash"])


# Update s4aUpdater config file with 'beta' and 'logfile' parameters
update_s4aUpdater_configfile("beta")
update_s4aUpdater_configfile("logfile")
update_s4aUpdater_configfile("force_change_language")
update_s4aUpdater_configfile("force_usb_backup") 
update_s4aUpdater_configfile("force_libusb")
update_s4aUpdater_configfile("multi_replace_srvid2") 
update_s4aUpdater_configfile("skip_channellist_backup")
update_s4aUpdater_configfile("backup_copies", "6") 
update_s4aUpdater_configfile("oscam_edition", "jejon")
update_s4aUpdater_configfile("lists_only") 
update_s4aUpdater_configfile("no_SKT")
update_s4aUpdater_configfile("skip_channel_list", "empty empty1")

ln_sf()

Processor=identify_CPU ()
distro, config_dir, usr_bin = return_distro()

s4aupdater_list = os.path.join(pluginpath, 's4aupdater_lista')
s4aupdater_version = os.path.join(pluginpath, 's4aupdater_version')


if os.path.exists('/usr/lib/enigma2/python/Plugins/SystemPlugins/Videomode') is True:
    try:
        from Plugins.SystemPlugins.Videomode.plugin import *
    except:
        pass


make_executable (os.path.join(pluginpath,'plugin_update.sh'))
make_executable (os.path.join(pluginpath,'initial.sh'))

#ClearMemory() # j00zek: dla pewności

def localeInit():
	gettext.bindtextdomain("s4aUpdater", os.path.join(pluginpath, 'locale'))

def _(txt):
	t = gettext.dgettext("s4aUpdater", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)

def autostart(reason, **kwargs):
    global session
    if reason == 0 and 'session' in kwargs:
        session = kwargs['session']
        session.open(s4aUpdaterBoot)





def Plugins(**kwargs):
    return [
            PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc=autostart), 
            PluginDescriptor(name='s4aUpdater', description='Channel List & OSCam Updates', where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='icon_s4aupdater.png', fnc=main), 
            PluginDescriptor(name='s4aUpdater', description='Channel List & OSCam Updates', where=PluginDescriptor.WHERE_PLUGINMENU, icon='s4aupdater.png', fnc=main)
        ]

def main(session, **kwargs):
    try:
        ClearMemory

        os.system(os.path.join(pluginpath,'initial.sh'))
        
        function_download_file (s4av_url + 's4aupdater_list.txt', s4aupdater_list)
        function_download_file (s4av_url + 'version.txt', s4aupdater_version)

        ClearMemory

        session.open(s4aUpdater)
    except:
        print('[s4aUpdater] Plugin execution failed')

from Tools.BoundFunction import boundFunction
from Components.PluginComponent import plugins

class s4aUpdater(Screen):
    EXTENSION_SINGLE = 0
    EXTENSION_LIST = 1
## check fullHD  
    ScreenResolution = getDesktop(0).size().width()
    if ScreenResolution > 1900:
        skin = """
                <screen name="s4aUpdater" position="center,center" size="810,350" title="%s" >
                    <ePixmap pixmap="%s/logo.png" position="50,10" size="350,50" alphatest="on" />
                    <widget name="menu" position="10,70" size="970,556" itemHeight="45" font="Regular;30"  scrollbarMode="showOnDemand" />
               </screen>
               """ % (plugin_title, pluginpath)
    else:
        skin = """
                <screen name="s4aUpdater" position="center,center" size="600,350" title="%s" >
                <ePixmap pixmap="%s/logo.png" position="50,10" size="350,50" alphatest="on" />   
                 <widget name="menu" position="10,70" size="1098,556" itemHeight="45" font="Regular;24"  scrollbarMode="showOnDemand" />
                </screen>
               """ % (plugin_title, pluginpath)

    def __init__(self, session, args = 0):
        global mfmenuold
        global pluginlist
        global mfmenudescr
        global mfintargument
        global mfcommand
        global mfmenu
        global mfexecute
        global videomode
        global mftextargument
        self.menu = args
        self.skin = s4aUpdater.skin
        self.session = session
        Screen.__init__(self, session)
        mfmenu = 'main'
        mfmenuold = 'main'
        mfmenudescr = 's4aUpdater'
        mfexecute = ' '
        mfintargument = 0
        mftextargument = ' '
        mainmenu = []
        #self['txt_red']      = StaticText(_('Settings'))
        #self['txt_green']    = StaticText(_('Exit'))
        #self['txt_yellow']   = StaticText(_('Update plugin'))
        #self['txt_blue']     = StaticText(_('Update test'))
        menufile = '%s/%s.cfg' % (pluginpath, mfmenu)
        if os.path.exists(menufile) is True:
            mf = open(menufile, 'r')
            for line in mf:
                parts = line.split(splitchar, 3) # limit to 3 parts only
                index = len(parts)
                if index > 1:
                    command = parts[0].upper().rstrip()
                    mfcommand = command[0]
                    if mfcommand !='S': #                    if mfcommand is not 'S' execute script :

                        if index > 2:
                            mainmenu.append((_(str(parts[2])), line))
                        else:
                            mainmenu.append((_(str(parts[1])), line))
            mf.close()
#            mainmenu.append(_("PLUGIN UPDATE"))
        else:
            mainmenu.append(('no %s.cfg found - select for details' % mfmenu, 'mfnomenu'))
        if mfmenudescr == 's4aUpdater':
            pass
        else:
            mainmenu.append(('Show readme.txt', 'mfreadme'))
            mainmenu.append(('about %s' % s4aUpdater_pluginversion, 'mfabout'))
        pluginlist = 'False'
        videomode = '1'
        self.list = []
        self['key_green'] = Button('Video Mode')
        self['key_red'] = Button('Media Player')
        self['key_yellow'] = Button('SleepTimer')
        self['key_blue'] = Button('Extensions')
        self['menu'] = MenuList(mainmenu)
        self['actions'] = ActionMap(['Actions', 'WizardActions', 'DirectionActions'], {'mplayer': self.setMediaPlayer,
         'videomode': self.setVideoMode,
         'sleeptimer': self.setSleepTimer,
         'extensions': self.showExtensionSelection,
         'ok': self.s4aUpdaterMainMenu,
         'back': self.close}, -1)

    def setSleepTimer(self):
        self.session.open(SleepTimerEdit)

    def setMediaPlayer(self):
        self.session.open(MediaPlayer)

    def setVideoMode(self):
        global videomode
        global aspect
        from enigma import eAVSwitch
        from Screens.MessageBox import MessageBox
        aspect = '16:9'
        if aspect == '16:9':
            if videomode == '1':
                eAVSwitch.getInstance().setAspectRatio(2)
                session.open(MessageBox, _('NonLinear'), type=MessageBox.TYPE_INFO, timeout=2)
                videomode = '2'
            elif videomode == '2':
                eAVSwitch.getInstance().setAspectRatio(3)
                session.open(MessageBox, _('Pan&Scan'), type=MessageBox.TYPE_INFO, timeout=2)
                videomode = '3'
            elif videomode == '3':
                eAVSwitch.getInstance().setAspectRatio(4)
                session.open(MessageBox, _('Pillarbox'), type=MessageBox.TYPE_INFO, timeout=2)
                videomode = '4'
            elif videomode == '4':
                eAVSwitch.getInstance().setAspectRatio(1)
                session.open(MessageBox, _('JustScale'), type=MessageBox.TYPE_INFO, timeout=2)
                videomode = '1'

    def s4aUpdaterMainMenu(self):
        mfselected = self['menu'].l.getCurrentSelection()[1]
        if mfselected != None:
            if mfselected == 'mfreadme':
                self.session.open(Console, _('Showing s4aUpdater readme.txt'), ['cat %s' % s4aUpdater_readme])
            elif mfselected == 'mfnomenu':
                title1 = _('Menu s4aUpdater Plugin')
                title2 = _('needs a %s.cfg file at' % mfmenu)
                title3 = _('%s' % pluginpath)
                title = '%s\n%s\n%s' % (title1, title2, title3)
                self.session.open(MessageBox, '%s' % title, MessageBox.TYPE_INFO)
            elif mfselected == 'mfabout':
                title1 = _('Menu s4aUpdater Plugin %s') % s4aUpdater_pluginversion
                title2 = _('use at your own risk !')
                title = '%s\n%s' % (title1, title2)
                self.session.open(MessageBox, '%s' % title, MessageBox.TYPE_INFO)
            else:
                self.s4aUpdaterMenuSelected(mfselected)
        return

    def s4aUpdaterMenu(self, status):
        global mfmenudescr
        if mfmenu is None:
            self.skipMF('No menu passed, returning')
        else:
            mfmenufile = '%s/%s.cfg' % (pluginpath, mfmenu.rstrip())
            if os.path.exists(mfmenufile) is True:
                mf = open(mfmenufile, 'r')
                line = mf.readline()
                mf.close()
                parts = line.split(splitchar, 3)
                index = len(parts)
                if index > 1:
                    command = parts[0].upper().rstrip()
                    if command[0] == 'S':
                        if index > 3:
                            cmd = parts[3].rstrip()
                            if mfmenu == mfmenuold:
                                pass
                            elif mfmenu == 'main':
                                pass
                            elif os.path.exists('%s/%s' % (pluginpath, cmd)) is True:
                                os.system('%s/%s %s' % (pluginpath, cmd, mftextargument))
                            else:
                                os.system('%s %s' % (cmd, mftextargument))
                            mfmenudescr = parts[2].rstrip()
                        elif index == 3:
                            mfmenudescr = parts[2].rstrip()
                        else:
                            mfmenudescr = parts[1].rstrip()
            if os.path.exists('%s/%s.cfg' % (pluginpath, mfmenu.rstrip())) is True:
                if mfmenu == 'main':
                    pass
                else:
                    self.session.openWithCallback(self.s4aUpdaterMenuSelected, ChoiceBox, mfmenudescr, self.ListMenus4aUpdater())
            else:
                self.skipMF('no Menufile %s.cfg' % mfmenu)
        return

    def s4aUpdaterMenuSelected(self, mfselected):
        global mfintargument
        global mfcommand
        global mfmenu
        global mfexecute
        global mfmenudescr
        global mfmenuold
        global mftextargument
        if mfselected is None:
            mfmenu = 'main'
        else:
            try:
                parts = mfselected.split(splitchar, 4)
            except:
                parts = mfselected[1].split(splitchar, 4)

            mfcommand = ' '
            mfexecute = ' '
            mfintargument = 0
            mftextargument = ' '
            index = len(parts)
            if index > 1:
                command = parts[0].upper().rstrip()
                mfcommand = command[0]
            else:
                command = ' '
                mfcommand = command[0]
            if index > 1:
                mfmenuold = mfmenu
                mfmenu = parts[1].rstrip()
            if index > 2:
                mfmenudescr = parts[2].rstrip()
            else:
                mfmenudescr = parts[1].rstrip()
            if index > 3:
                mfexecute = parts[3].rstrip()
                mftextargument = parts[3].rstrip()
            if index > 4:
                mftextargument = parts[4].rstrip()  #tu dopisac 
                try:
                    mfintargument = int(mftextargument)
                except:
                    mfintargument = 0

            elif index == 4:
                mftextargument = parts[3].rstrip()    
                try:
                    mfintargument = int(mftextargument)
                except:
                    mfintargument = 0

            # j00zek: tak na wszelki wypadek
            ClearMemory() 
            
            if mfcommand == 'E':
                if os.path.exists('%s/%s' % (pluginpath, mfexecute)) is True:
                    os.system('%s/%s %s' % (pluginpath, mfexecute, mftextargument))
                else:
                    os.system('%s %s' % (mfexecute, mftextargument))
                self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, '%s %s was executed !' % (mfexecute, mftextargument), MessageBox.TYPE_INFO, timeout=mfintargument)
            elif mfcommand == 'U':
                if os.path.exists('%s/%s' % (pluginpath, mfexecute)) is True:
                    os.system('%s/%s %s' % (pluginpath, mfexecute, mftextargument))
                else:
                    os.system('%s %s' % (mfexecute, mftextargument))
                if os.path.exists('%s.reste2' % mfexecute) is True:
                    mfintargument = 3
                    self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, 'Restarting Enigma2', MessageBox.TYPE_INFO, timeout=5)
                    TryQuitMainloop(self.session, mfintargument)
                elif os.path.exists('%s.txt' % mfexecute) is True:
                    menufile = '%s.txt' % mfexecute
                    mf = open(menufile, 'r')
                    mfexecute = mf.readline()
                    mf.close()
                    self.session.openWithCallback(self.s4aUpdaterMenu(''), MessageBox, mfexecute, MessageBox.TYPE_INFO, timeout=4)
                self.s4aUpdaterMenu('')
            elif mfcommand == '#':
                self.s4aUpdaterMenu('')

            elif mfcommand == 'C':
                if os.path.exists('%s/%s' % (pluginpath, mfexecute)) is True:
                    self.session.openWithCallback(self.s4aUpdaterMenu(''), Console, _(' %s' % mftextargument), ['%s/%s %s' % (pluginpath, mfexecute, mftextargument)])
                else:
                    self.session.openWithCallback(self.s4aUpdaterMenu(''), Console, _('Executing %s %s' % (mfexecute, mftextargument)), ['%s %s' % (mfexecute, mftextargument)])

            #Uruchomienie skryptu w konsoli i pytanie o restart E2
            elif mfcommand == 'J':
                def czyRestart():
                    def doRestart(answer):
                        if answer is True:
                            TryQuitMainloop(self.session, 3)
                    self.session.openWithCallback(doRestart, MessageBox, "Restart E2?", MessageBox.TYPE_YESNO, timeout=5, default = False)
                if os.path.exists('%s/%s' % (pluginpath, mfexecute)) is True:
                    self.session.openWithCallback(czyRestart, Console, _(' %s' % mftextargument), ['%s/%s %s' % (pluginpath, mfexecute, mftextargument)])
                else:
                    self.session.openWithCallback(czyRestart, Console, _('Executing %s %s' % (mfexecute, mftextargument)), ['%s %s' % (mfexecute, mftextargument)])

            elif mfcommand == 'A':
                s4aUpdaterApplication(self.session)
                self.s4aUpdaterMenu('')
            elif mfcommand == 'P':
                plugininstalled = False   #tu poprawic z pluginpath na /usr/lib/enigma2/python/Plugins
                if os.path.exists('%s/Extensions/%s' % (pluginpath, mftextargument)) is True:
                    plugininstalled = True
                if os.path.exists('%s/SystemPlugins/%s' % (pluginpath, mftextargument)) is True:
                    plugininstalled = True
                if plugininstalled is True:
                    if mftextargument == 'Tuxtxt':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), ShellStarter)
                    elif mftextargument == 'Multiboot':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), Multiboot)
                    elif mftextargument == 'MediaPlayer':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), MediaPlayer)
                    elif mftextargument == 'SpiderFan':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), SpiderFan)
                    elif mftextargument == 'Shell':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), Shell)
                    elif mftextargument == 'PicturePlayer':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), picmain)
                    elif mftextargument == 'MOUNTmanager':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), Mountman)
                    elif mftextargument == 'ConfigurationBackup':
                        try:
                            self.session.openWithCallback(self.s4aUpdaterMenu(''), BackupSetup)
                        except:
                            pass
                    elif mftextargument == 'GboxSuite':
                        try:
                            self.session.openWithCallback(self.s4aUpdaterMenu(''), GboxSuite)
                        except:
                            pass
                    elif mftextargument == 'KeyUpdater':
                        try:
                            self.session.openWithCallback(self.s4aUpdaterMenu(''), KeyUpdater)
                        except:
                            pass
                    elif mftextargument == 'CCcamInfo':
                        try:
                            self.session.openWithCallback(self.s4aUpdaterMenu(''), CCcamInfo)
                        except:
                            pass
                    elif mftextargument == 'LasMail':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), LasMail)
                    elif mftextargument == 'Tuxcom':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), TuxComStarter)
                    elif mftextargument == 'Cronmanager':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), Cronmanager)
                    elif mftextargument == 'TuxboxGames':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), GameStarter)
                    elif mftextargument == 'FrontprocessorUpgrade':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), FPUpgrade)
                    elif mftextargument == 'SoftwareUpdate':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), UpdatePluginMenu)
                    elif mftextargument == 'weinbergtagger':
                        self.session.openWithCallback(self.s4aUpdaterMenu(''), weinbergtagger)
                    elif mftextargument == 'SkinSelector':
                        try:
                            self.session.openWithCallback(self.s4aUpdaterMenu(''), SkinSelector)
                        except:
                            self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, 'Plugin %s is not wrapped !' % mftextargument, MessageBox.TYPE_INFO)

                    else:
                        self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, 'Plugin %s is not wrapped !' % mftextargument, MessageBox.TYPE_INFO)
                elif mftextargument == 'Ci':
                    self.session.openWithCallback(self.s4aUpdaterMenu(''), CiSelection)
                elif mftextargument == 'PluginBrowser':
                    self.session.openWithCallback(self.s4aUpdaterMenu(''), PluginBrowser)
                elif mftextargument == 'NetworkSetup':
                    self.session.openWithCallback(self.s4aUpdaterMenu(''), NetworkAdapterSelection)
                elif mftextargument == 'LanguageSelection':
                    self.session.openWithCallback(self.s4aUpdaterMenu(''), LanguageSelection)
                elif mftextargument == 'SleepTimerEdit':
                    self.session.openWithCallback(self.s4aUpdaterMenu(''), SleepTimerEdit)
                elif mftextargument == 'BP':
                    if os.path.exists('/usr/lib/enigma2/python/Bp') is True:
                        try:
                            self.session.openWithCallback(self.s4aUpdaterMenu(''), BPmenu)
                        except:
                            self.session.openWithCallback(self.s4aUpdaterMenu(''), BP_Menu)

                    else:
                        self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, 'Plugin %s is not available !' % mftextargument, MessageBox.TYPE_INFO)
                else:
                    self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, 'Plugin %s is not installed !' % mftextargument, MessageBox.TYPE_INFO)
            elif mfcommand == 'R':
                if mfintargument == 3:
                    self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, 'Restarting Enigma2', MessageBox.TYPE_INFO, timeout=5)
                    TryQuitMainloop(self.session, mfintargument)
                elif mfintargument == 2:
                    self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, 'Restarting IPbox', MessageBox.TYPE_INFO, timeout=5)
                    TryQuitMainloop(self.session, mfintargument)
                elif mfintargument == 1:
                    self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, 'Entering Deepstandby', MessageBox.TYPE_INFO, timeout=5)
                    TryQuitMainloop(self.session, mfintargument)
            elif mfcommand == 'I':
                if os.path.exists('%s/%s.txt' % (pluginpath, mfexecute)) is True:
                    menufile = '%s/%s.txt' % (pluginpath, mfexecute)
                    mf = open(menufile, 'r')
                    mfexecute = mf.readline()
                    mf.close()
                    self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, mfexecute, MessageBox.TYPE_INFO, timeout=mfintargument)
                elif os.path.exists('/tmp/%s.txt' % mfexecute) is True:
                    menufile = '/tmp/%s.txt' % mfexecute
                    mf = open(menufile, 'r')
                    mfexecute = mf.readline()
                    mf.close()
                    self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, mfexecute, MessageBox.TYPE_INFO, timeout=mfintargument)
                else:
                    self.session.openWithCallback(self.s4aUpdaterMenu, MessageBox, mfexecute, MessageBox.TYPE_INFO, timeout=mfintargument)
            elif mfcommand == 'D':
                self.session.openWithCallback(self.s4aUpdaterMenu(''), s4aUpdaterLCD, mftextargument)
            elif mfcommand == 'L':
                if mftextargument == 'log':
                    os.system('echo %s > /tmp/s4aUpdaterlog.txt' % mfexecute)
                elif mftextargument == 'logappend':
                    os.system('echo %s >> /tmp/s4aUpdaterlog.txt' % mfexecute)
                elif mftextargument == 'reset':
                    if os.path.exists('/tmp/s4aUpdaterlog.txt') is True:
                        os.system('rm /tmp/s4aUpdaterlog.txt')
                elif mftextargument == 'wall':
                    os.system('wall %s' % mfexecute)
                else:
                    print('[s4aUpdater] Logging: %s' % mfexecute)
                self.s4aUpdaterMenu('')
            elif mfcommand == 'M':
                self.s4aUpdaterMenu('')
            elif mfcommand == 'T':
                self.session.openWithCallback(self.s4aUpdaterEnterText, InputBox, title=mfmenudescr, text=mftextargument, maxSize=False, type=Input.TEXT)
            elif mfcommand == 'Y':
                self.session.openWithCallback(self.s4aUpdaterYN, MessageBox, mfmenudescr, MessageBox.TYPE_YESNO)
        return

    def ListMenus4aUpdater(self):
        menu = []
        menufile = '%s/%s.cfg' % (pluginpath, mfmenu)
        mf = open(menufile, 'r')
        for line in mf:
            parts = line.split(splitchar, 3)
            index = len(parts)
            if index > 1:
                command = parts[0].upper().rstrip()
                if command[0] != 'S':
                    if index > 2:
                        menu.append((_(str(parts[2])), line))
                    else:
                        menu.append((_(str(parts[1])), line))

        mf.close()
        return menu

    def s4aUpdaterEnterText(self, mftext):
        global mfmenu
        global mftextargument
        if mftext is None:
            mftextargument = None
            mfmenu = 'main'
            self.skipMF('No text passed, Exiting menu %s' % mfmenu)
        else:
            mftextargument = mftext
            self.s4aUpdaterMenu('')
        return

    def s4aUpdaterYN(self, mfanswer):
        global mfmenu
        if mfanswer is False:
            if mftextargument != None:
                if mftextargument != ' ':
                    mfmenu = mftextargument
        self.s4aUpdaterMenu('')
        return

    def skipMF(self, reason):
        self.session.open(MessageBox, _('Menu s4aUpdater exits, because %s') % reason, MessageBox.TYPE_WARNING)

    def addExtension(self, extension, key = None, type = EXTENSION_SINGLE):
        self.list.append((type, extension, key))

    def updateExtension(self, extension, key = None):
        self.extensionsList.append(extension)
        if key is not None:
            if key in self.extensionKeys:
                key = None
        if key is None:
            for x in self.availableKeys:
                if x not in self.extensionKeys:
                    key = x
                    break

        if key is not None:
            self.extensionKeys[key] = len(self.extensionsList) - 1
        return

    def updateExtensions(self):
        self.extensionsList = []
        self.availableKeys = ['red',
         'green',
         'yellow',
         'blue',
         '1',
         '2',
         '3',
         '4',
         '5',
         '6',
         '7',
         '8',
         '9',
         '0']
        self.extensionKeys = {}
        for x in self.list:
            if x[0] == self.EXTENSION_SINGLE:
                self.updateExtension(x[1], x[2])
            else:
                for y in x[1]():
                    self.updateExtension(y[0], y[1])

    def showExtensionSelection(self):
        global pluginlist
        if pluginlist == 'False':
            self.Plugins()
        pluginlist = 'True'
        self.updateExtensions()
        extensionsList = self.extensionsList[:]
        keys = []
        list = []
        for x in self.availableKeys:
            if x in self.extensionKeys:
                entry = self.extensionKeys[x]
                extension = self.extensionsList[entry]
                if extension[2]():
                    name = str(extension[0]())
                    list.append((extension[0](), extension))
                    keys.append(x)
                    extensionsList.remove(extension)
                else:
                    extensionsList.remove(extension)

        for x in extensionsList:
            list.append((x[0](), x))

        keys += [''] * len(extensionsList)
        self.session.openWithCallback(self.extensionCallback, ChoiceBox, title=_('Please choose an extension...'), list=list, keys=keys)

    def extensionCallback(self, answer):
        if answer is not None:
            answer[1][1]()
            self.close()
        return

    def Plugins(self):
        self.addExtension(extension=self.getPluginList, type=s4aUpdater.EXTENSION_LIST)

    def getPluginName(self, name):
        return name

    def getPluginList(self):
        list = []
        for p in plugins.getPlugins(where=PluginDescriptor.WHERE_EXTENSIONSMENU):
            list.append(((boundFunction(self.getPluginName, p.name), boundFunction(self.runPlugin, p), lambda : True), None))

        return list

    def runPlugin(self, plugin):
        plugin(session=self.session, servicelist=servicelist)


class s4aUpdaterServiceList(Screen):

    def __init__(self, session, service):
        global servicelist
        Screen.__init__(self, session)
        self.session = session
        if service is not None:
            servicelist = service
        else:
            servicelist = None
        return


class s4aUpdaterButton(Screen):

    def __init__(self, session, button):
        global mfmenuold
        global mfmenudescr
        global mfmenu
        Screen.__init__(self, session)
        self.session = session
        if button is not None:
            mfmenuold = button
            mfmenu = button
            mfmenudescr = 'Menu s4aUpdater %s Button Menu' % button
        else:
            mfmenuold = 'main'
            mfmenu = 'main'
            mfmenudescr = 'Menu s4aUpdater Main Menu'
        return


class s4aUpdaterBoot(Screen):

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        mainmenufile = '%s/%s.cfg' % (pluginpath, 'main')
        if os.path.exists(mainmenufile) is True:
            mfmain = open(mainmenufile, 'r')
            line = mfmain.readline()
            parts = line.split(splitchar, 3)
            index = len(parts)
            if index > 1:
                command = parts[0].upper().rstrip()
                if command[0] == 'S':
                    if index > 3:
                        cmd = parts[3].rstrip()
                        if os.path.exists('%s/%s' % (pluginpath, cmd)) is True:
                            os.system('%s/%s' % (pluginpath, cmd))
                        else:
                            os.system('%s' % cmd)
                    mfmain.close()


class s4aUpdaterApplication(Screen):

    def __init__(self, session):
        self.session = session
        self.skin = s4aUpdater.skin
        Screen.__init__(self, session)
        self.container = eConsoleAppContainer()
        self.container.appClosed.get().append(self.finished)
        self.runapp()

    def runapp(self):
        eDBoxLCD.getInstance().lock()
        eRCInput.getInstance().lock()
        fbClass.getInstance().lock()
        self.session.nav.stopService()
        if os.path.exists(mfexecute) is True:
            self.container.execute('%s %s' % (mfexecute, mftextargument))
        else:
            self.container.execute('%s/%s %s' % (pluginpath, mfexecute, mftextargument))

    def finished(self, retval):
        fbClass.getInstance().unlock()
        eRCInput.getInstance().unlock()
        eDBoxLCD.getInstance().unlock()
        self.session.nav.playService(eServiceReference(config.tv.lastservice.value))

class s4aUpdaterLCD(Screen):
    skin = '\n\t\t<screen position="0,0" size="0,0" title="s4aUpdater" >\n\t\t\t<widget name="text" position="0,0" size="0,0" font="Regular;14" halign="center"/>\n\t\t</screen>'

    def __init__(self, session, title = 's4aUpdater'):
        self.skin = s4aUpdaterLCD.skin
        Screen.__init__(self, session)
        self['text'] = Label('')
        self['actions'] = ActionMap(['WizardActions', 'DirectionActions'], {'ok': self.cancel,
         'back': self.cancel}, -1)
        self.newtitle = title
        self.onShown.append(self.updateTitle)

    def updateTitle(self):
        self.setTitle(self.newtitle)

    def cancel(self):
        self.close()

######################################################################################################
##### konsola obslugująca lokalizacje tekstów
######################################################################################################
def ensure_str(text, encoding='utf-8', errors='strict'):
    if type(text) is str:
        return text
    if pyVersion == 2:
        if isinstance(text, unicode):
            try:
                return text.encode(encoding, errors)
            except Exception:
                return text.encode(encoding, 'ignore')
    else: #PY3
        if isinstance(text, bytes):
            try:
                return text.decode(encoding, errors)
            except Exception:
                return text.decode(encoding, 'ignore')
    return text
    
def substring_2_translate(text):
    to_translate = text.split('_(', 2)
    text = to_translate[1]
    to_translate = text.split(')', 2)
    text = to_translate[0]
    return text
    
def __(txt):
    if txt.find('_(') == -1:
        txt = _(txt)
    else:
        index = 0
        while txt.find('_(') != -1:
            tmptxt = substring_2_translate(txt)
            translated_tmptxt = _(tmptxt)
            txt = txt.replace('_(' + tmptxt + ')', translated_tmptxt)
            index += 1
            if index == 10:
                break

    return txt


class Console(Screen):
    skin = """
        <screen position="center,center" size="550,450" title="Command execution..." >
            <widget name="text" position="center,center" size="550,450" font="Console;14" />
        </screen>"""
        
    def __init__(self, session, title = "console", cmdlist = None, finishedCallback = None, closeOnSuccess = False):
        Screen.__init__(self, session)

        self.finishedCallback = finishedCallback
        self.closeOnSuccess = closeOnSuccess
        self.errorOcurred = False

        self["text"] = ScrollLabel("")
        self["actions"] = ActionMap(["WizardActions", "DirectionActions"], 
        {
            "ok": self.cancel,
            "back": self.cancel,
            "up": self["text"].pageUp,
            "down": self["text"].pageDown
        }, -1)
        
        self.cmdlist = cmdlist
        self.newtitle = title
        
        self.onShown.append(self.updateTitle)
        
        self.container = eConsoleAppContainer()
        self.run = 0
        self.container.appClosed.append(self.runFinished)
        self.container.dataAvail.append(self.dataAvail)
        self.onLayoutFinish.append(self.startRun) # dont start before gui is finished

    def updateTitle(self):
        self.setTitle(self.newtitle)

    def startRun(self):
        self["text"].setText("" + "\n\n")
        print("ExtConsole: executing in run", self.run, " the command:", self.cmdlist[self.run])
        if self.container.execute(self.cmdlist[self.run]): #start of container application failed...
            self.runFinished(-1) # so we must call runFinished manual

    def runFinished(self, retval):
        if retval:
            self.errorOcurred = True
        self.run += 1
        if self.run != len(self.cmdlist):
            if self.container.execute(self.cmdlist[self.run]): #start of container application failed...
                self.runFinished(-1) # so we must call runFinished manual
        else:
            #lastpage = self["text"].isAtLastPage()
            #str = self["text"].getText()
            #str += _("\nUse up/down arrows to scroll text. OK closes window");
            #self["text"].setText(str)
            #if lastpage:
            self["text"].lastPage()
            if self.finishedCallback is not None:
                self.finishedCallback()
            if not self.errorOcurred and self.closeOnSuccess:
                self.cancel()

    def cancel(self):
        if self.run == len(self.cmdlist):
            self.close()
            self.container.appClosed.remove(self.runFinished)
            self.container.dataAvail.remove(self.dataAvail)

    def dataAvail(self, outText):
        #lastpage = self["text"].isAtLastPage()
        outText = ensure_str(outText)
        tmpText = self["text"].getText()
        if tmpText.count('\n') > 200: # za dlugie teksty powoduja ze wszystko ginie, jakby bufor sie przepelnial
            tmpText = "...\n" + "\n".join(tmpText.split("\n")[20:])
        self["text"].setText( tmpText + __(outText))
        #if lastpage:
        self["text"].lastPage()
