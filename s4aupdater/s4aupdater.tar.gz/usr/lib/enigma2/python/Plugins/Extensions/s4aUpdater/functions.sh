# Fri Aug 16 09:46:00 AM CEST 2024
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
# Fri Aug 16 09:46:18 AM CEST 2024
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
HTTP_ADDRESS='http://s4aupdater.one.pl'
PLUGIN_FOLDER='/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater'
is_curl=false
is_fullwget=false
iptv=false
debug_mode=false
make_backup=true
ssl='none'
WGET=$(which wget)
REALPATH=realpath
OSCAM_BINARIES='oscam_binaries'
OSCAM_EDITION="jejon"
CyCeC=''
oscam_version='oscam_version_jejon'
oscam_value='oscam_cycec'
EMU=''
whats_new='co_nowego'
Processor=arm
LISTY_KANALOW="$PLUGIN_FOLDER/listy_kanalow.cfg"
FOLDER_LIST=/tmp/lists
#s4aupdater_lista='/tmp/s4aupdater_lista'
#s4aupdater_version='/tmp/s4aupdater_version'
s4aupdater_lista="$PLUGIN_FOLDER/s4aupdater_lista"
s4aupdater_version="$PLUGIN_FOLDER/s4aupdater_version"

if test -f $PLUGIN_FOLDER/busybox ; then
    WGET="$PLUGIN_FOLDER/busybox wget"
    REALPATH="$PLUGIN_FOLDER/busybox realpath"
fi

[ -f $PLUGIN_FOLDER/debug ] && debug_mode=true 

curl --help > /dev/null 2>&1 && is_curl=true 
#if [ "$?" == "0" ] ; then 
#is_curl=true
#else
#   which fullwget 1>/dev/null 2>&1
#  if [ "$?" == "0" ] ; then
#    is_fullwget=true
#    FULLWGET=$(which fullwget) 
#   else
#    if test -f $PLUGIN_FOLDER/fullwget  ; then 
#        FULLWGET=$PLUGIN_FOLDER/fullwget
#        is_fullwget=true
#    fi
#  fi  
#fi

delete_1st_x_chars_from_string ()
{
    #nbox ash workaround  1st par is a str, 2nd is number to be stripped
    echo ${1:$2:${#1}}
}

debug () 
{ 
$debug_mode  && echo -e "debug $1"
}

function_generate_ExtraMenu ()
{
#skip if sh4
if [[ $Processor != 'sh4' ]]; then
    if [[ -d $PLUGIN_FOLDER/ExtraMenu ]]; then
        #FILES="$PLUGIN_FOLDER/ExtraMenu/*.sh" 
        FILES=$(find $PLUGIN_FOLDER/ExtraMenu -print)
        words=( $FILES )
        counter=${#words[@]}
        which_file=$PLUGIN_FOLDER/ExtraMenu.cfg
        (($counter > 0)) &&  printf '' >$which_file || rm -f $which_file   1>/dev/null 2>&1
        while [ $counter -gt 0 ]
        do
            counter=$((counter - 1))
            aa=${words[$counter]}
            chmod a+x $aa 1>/dev/null 2>&1
            aa=$(cat $aa)
            aa=$( echo "$aa" | grep 'ExtraMenu' |head -n 1 |cut -d '=' -f2)
            aa=${aa//\/ExtraMenu/ExtraMenu}
            
            [ ! -z "$aa" ] &&  echo "C:ExtraMenu: $aa" >>$which_file
        done
        (($(wc -c <"$which_file")==0)) &&  rm -f $which_file   1>/dev/null 2>&1
    fi
fi
}

update_s4aUpdater_configfile ()
{
local par2
[[ "$2" == "" ]] && par2='no' || par2=$2 
if [ ! "$(cat $PLUGIN_FOLDER/s4aUpdater.cfg| grep $1)" ] ; then 
	echo "$1=$par2" >> $PLUGIN_FOLDER/s4aUpdater.cfg
	debug "dodane $1=$par2"
fi 
}

function_case ()
{
local xp
local counter
ile_satelit_liczba=$((${#1}/3))
PRINT_LIST=''
counter=0
xp=0
while [ $counter -lt $ile_satelit_liczba ]
do
    xp=$(($counter*3))
    case ${1:$xp:3} in   #wczytujemy $1 
        '45w') PRINT_LIST=$PRINT_LIST' 45°W' ;;
        '08w') PRINT_LIST=$PRINT_LIST' 0.8°W' ;;
        '04w') PRINT_LIST=$PRINT_LIST' 4°W' ;;
        '05w') PRINT_LIST=$PRINT_LIST' 5°W' ;;
        '30w') PRINT_LIST=$PRINT_LIST' 30°W' ;;
        '1.e') PRINT_LIST=$PRINT_LIST' 1.6°E' ;;
        'i.e') PRINT_LIST=$PRINT_LIST' 1.9°E' ;;
        '4.e') PRINT_LIST=$PRINT_LIST' 4.8°E' ;;
        '07e') PRINT_LIST=$PRINT_LIST' 7°E' ;;
        '09e') PRINT_LIST=$PRINT_LIST' 9°E' ;;
        '10e') PRINT_LIST=$PRINT_LIST' 10°E' ;;
        '13e') PRINT_LIST=$PRINT_LIST' 13°E' ;;
        '16e') PRINT_LIST=$PRINT_LIST' 16°E' ;;
        '19e') PRINT_LIST=$PRINT_LIST' 19.2°E' ;;
        '21e') PRINT_LIST=$PRINT_LIST' 21.6°E' ;; 
        '23e') PRINT_LIST=$PRINT_LIST' 23.5°E' ;; 
        '26e') PRINT_LIST=$PRINT_LIST' 26°E' ;; 
        '28e') PRINT_LIST=$PRINT_LIST' 28°E' ;; 
        '31e') PRINT_LIST=$PRINT_LIST' 31.5°E' ;;
        '33e') PRINT_LIST=$PRINT_LIST' 33°E' ;;
        '36e') PRINT_LIST=$PRINT_LIST' 36°E' ;;
        '42e') PRINT_LIST=$PRINT_LIST' 42°E' ;;
        '48e') PRINT_LIST=$PRINT_LIST' 48°E' ;;
        '62e') PRINT_LIST=$PRINT_LIST' 62°E' ;;
        '66e') PRINT_LIST=$PRINT_LIST' 66°E' ;;
        '68e') PRINT_LIST=$PRINT_LIST' 68.5°E' ;;
        '75e') PRINT_LIST=$PRINT_LIST' 75°E' ;;
        '76e') PRINT_LIST=$PRINT_LIST' 76°E' ;;
        'mot') PRINT_LIST=$PRINT_LIST' MOTOR' ;;
        'ipt') PRINT_LIST=$PRINT_LIST' IPTV' 
               iptv=true ;;
        'ipv') PRINT_LIST=$PRINT_LIST' IPTV'  ;;
    esac
    counter=$((counter + 1))
    #((counter++))
done
#debug "wyswietl satelity $PRINT_LIST"
sat_number=$(($ile_satelit_liczba+1))
}

function_generate_menu ()
{
if [[ $Processor != 'sh4' ]]; then
    if [[ -d $PLUGIN_FOLDER/ExtraMenu ]]; then
        #FILES="$PLUGIN_FOLDER/ExtraMenu/*.sh" 
        FILES=$(find $PLUGIN_FOLDER/ExtraMenu -print)
        words=( $FILES )
        counter=${#words[@]}
        which_file=$PLUGIN_FOLDER/ExtraMenu.cfg
        (($counter > 0)) &&  printf '' >$which_file || rm -f $which_file   1>/dev/null 2>&1
        while [ $counter -gt 0 ]
        do
            counter=$((counter - 1))
            aa=${words[$counter]}
            chmod a+x $aa 1>/dev/null 2>&1
            if test -f "$aa"; then
                aa=$(cat $aa)
                aa=$( echo "$aa" | grep 'ExtraMenu' |head -n 1 |cut -d '=' -f2)
                aa=${aa//\/ExtraMenu/ExtraMenu}
                [ ! -z "$aa" ] &&  echo "C:ExtraMenu: $aa" >>$which_file
            fi
        done
        (($(wc -c <"$which_file") == 0)) &&  rm -f $which_file   1>/dev/null 2>&1
    fi
fi
local which_file
local zm
zm=''
local zmj
zmj=''
which_file=$PLUGIN_FOLDER/settings.cfg
[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e beta |grep -e yes) ] && zm=$ON || zm=$OFF
echo "C:settings: $ONOFF $wersja_testowa_wtyczki [ $zm ] :addons/force_beta_s4aupdater.sh" >$which_file
echo "C:settings: $wymus_zmiane_jezyka PL/EN/DE/IT/CZ/HU :addons/force_addons.sh" >>$which_file
[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_libusb |grep -e yes) ] && zm=$ON || zm=$OFF
echo "C:settings:$wymus_uzywanie_oscam_libusb [ $zm ]:addons/force_libusb_pcsc.sh" >>$which_file
[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_usb_backup |grep -e yes) ] && zm=$ON || zm=$OFF
echo "C:settings:$wymus_kopie_na_usb [ $zm ]:addons/force_usb_backup.sh" >>$which_file
[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e skip_channellist_backup |grep -e yes) ] && zm=$ON || zm=$OFF
echo "C:settings:$ONOFF $tworzenie_kopii_list [ $zm ]:addons/force_skip_channellist_backup.sh" >>$which_file
case $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition) in
 #   *"icam"*) 
 #       zm='Jej@n ICAM'
 #       ;;
    *"samur"*) 
        zm='SAMUR'
        ;;
    *"mohamed"*) 
        zm='MOHAMED_OS'
        ;;
     *"levi45"*) 
        zm='levi45'
        ;;
    *" kitte888"*) 
        zm='kitte888'
        ;;
    *)
        zm='Jej@n'
        ;;
esac
echo "C:settings:$uzyj_oscam Jejon/samur/kitte888/levi45 [ $zm ]:addons/force_change_oscam_edition.sh" >>$which_file
#echo "C:settings:$uzyj_oscam Jejon/Jej@nICAM/samur/kitte888/levi45 [ $zm ]:addons/force_change_oscam_edition.sh" >>$which_file

#[ -f /etc/opkg/opkg-acypaczom.conf ] && zm=$ON || zm=$OFF
 if [ `cat /etc/opkg/* | grep -c 's4aupdater.one.pl'` -gt 0 ];then
        dodaj_repo="$usun $dodaj_repo"
 else
        dodaj_repo="$dodaj $dodaj_repo"
fi
echo "C:settings:$dodaj_repo :addons/force_install_opkg_acypaczom.sh" >>$which_file
if test -f /usr/bin/python3 ; then
    if [ `cat /etc/opkg/* | grep -c 'j00zek.one.pl'` -gt 0 ];then
        #zm=$ON
        dodaj_repo_j00zek="$usun $dodaj_repo_j00zek"
    else
        dodaj_repo_j00zek="$dodaj $dodaj_repo_j00zek"
    fi
    echo "C:settings:$dodaj_repo_j00zek :addons/force_install_opkg_j00zka.sh:$dodaj_repo_j00zek" >>$which_file
fi
[ -d $PLUGIN_FOLDER/ExtraMenu ] && echo "C:settings: $aktualizuj EXTRA MENU :addons/force_download_ExtraMenu.sh" >>$which_file || echo "C:settings: $dodaj EXTRA MENU :addons/force_download_ExtraMenu.sh" >>$which_file
[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e no_skt |grep -e yes) ] && zm=$ON || zm=$OFF

echo "C:settings: $ONOFF $skip_SKT_menu [ $zm ] :addons/force_skip_SKT.sh" >>$which_file
echo "C:settings:$backup_plugin:addons/force_plugin_backup.sh:$backup_plugin" >>$which_file
check_if_hdd_installed
if [  -f $HDD_FOLDER/s4aUpdater.cfg ]; then
   echo "C:settings:$restore_plugin:addons/force_plugin_restore.sh:$restore_plugin" >>$which_file  
fi
echo "C:settings: Factory reset :addons/force_factory_reset.sh" >>$which_file

if ! [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e no_skt|grep -e yes) ] ;then
    which_file=$PLUGIN_FOLDER/SKT.cfg
    echo "S:SKT:$narzedzia_dodatkowe:addons/restore_data.sh" >$which_file
    echo "M:restore_channellist:$przywracanie_z_kopii" >>$which_file
    echo "C:SKT:$utworz_kopie_listy_kanalow:addons/backup_channel_list.sh:$utworz_kopie_listy_kanalow" >>$which_file
    echo "C:SKT:$utworz_kopie_konf_oscam:addons/backup_oscam_config.sh:$utworz_kopie_konf_oscam" >>$which_file
    echo "C:SKT:$utworz_kopie_picon:addons/backup_picon.sh:$utworz_kopie_picon" >>$which_file
    echo "C:SKT:$ftp_bez_hasla:addons/force_ftp_root_login_no_password.sh:$ftp_bez_hasla" >>$which_file
    if test -f "$PLUGIN_FOLDER/ExtraMenu.cfg"; then
        ExtraMenuDate=$(cat $s4aupdater_version |grep 'EXTRAMENU_DATE'|cut -d '=' -f2)
        ExtraMenuDate=${ExtraMenuDate:0:10}
        ExtraMenuSavedDate=$(cat $PLUGIN_FOLDER/extramenu.date)
        ExtraMenuSavedDate=${ExtraMenuSavedDate:0:10}
        if [[ "$ExtraMenuDate" = "$ExtraMenuSavedDate" ]]; then
            echo "M:ExtraMenu:EXTRA MENU" >>$which_file
        else
            echo "M:ExtraMenu:EXTRA MENU ($ExtraMenuDate)" >>$which_file
        fi
    fi
    echo "C:SKT:$zmien_oscam_port 8888:addons/force_change_oscam_port.sh:$zmien_oscam_port 8888" >>$which_file
    echo "C:SKT:$usun_haslo_oscam:addons/force_remove_oscam_http_password.sh:$usun_haslo_oscam" >>$which_file
    echo "C:SKT:$aktualizuj oscam.srvid2:addons/force_download_srvid2.sh:$aktualizuj oscam.srvid2" >>$which_file
    echo "C:SKT:$aktualizuj satellites.xml:addons/force_overwrite_satellites_file.sh:$aktualizuj satellites.xml" >>$which_file
    echo "C:SKT:CI PLUS HELPER POLSKA:addons/force_install_ciplushelper_for_poland.sh:CI PLUS HELPER POLSKA" >>$which_file
    echo "C:SKT:$pokaz_oscam_info:addons/info_oscam_port.sh:$pokaz_oscam_info" >>$which_file
    echo "C:SKT:$pokaz_ssl_info:addons/info_openssl.sh:$pokaz_ssl_info" >>$which_file
    echo "C:SKT:$pokaz_publiczne_ip:addons/info_show_public_ip.sh:$pokaz_publiczne_ip" >>$which_file
    echo "C:SKT:$instaluj_niezbedne_biblioteki:addons/force_addons.sh:$instaluj_niezbedne_biblioteki" >>$which_file
    if [[ $distro == openatv ]]; then
        echo "C:SKT:FreeVPN:addons/force_freevpn.sh:FreeVPN" >>$which_file
    fi
    echo "C:SKT:$pokaz_upr_kart:addons/entitlements.sh:$pokaz_upr_kart" >>$which_file
    echo "C:SKT:$tivu:addons/hw_emm_sender_s4a.sh:$tivu" >>$which_file
    echo "C:SKT:$softcam:addons/force_download_SoftCam_key.sh:$softcam" >>$which_file
    echo "C:SKT:$generuj_czytniki_ccc:addons/force_cccam_2_oscam_importer.sh:$generuj_czytniki_ccc" >>$which_file
    echo "C:SKT:$poprzedni_oscam:addons/force_restore_previous_oscam.sh:$poprzedni_oscam" >>$which_file
    echo "J:SKT:$aktualizacja:plugin_update.sh:$aktualizacja" >>$which_file
fi
which_file=$PLUGIN_FOLDER/main.cfg
echo "M:listy_kanalow:$Listy_Kanalow" >$which_file
oscam_version_file=$(find /tmp/ -name oscam.version |sed -n 1p)
if  test $oscam_version_file; then 
    echo "C:main:$aktualizuj OSCam:aktualizacja_oscam.sh" >>$which_file
else
    echo "C:main:$Nowa_instalacja OSCam:czysty_system_oscam.sh" >>$which_file
fi  
if ! [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e no_skt|grep -e yes) ] ;then
    echo "M:SKT:$narzedzia_dodatkowe" >>$which_file
fi
echo "M:settings:$ustawienia_wtyczki" >>$which_file
#echo "P:SettingsMenu:$ustawienia_wtyczki" >>$which_file
debug "generuj menu"
}

function_download_file ()
{
TIMESTAMPING=''
if test -f /usr/bin/python3 ; then
    PYTHON=pyt3
else
    PYTHON=pyt2
fi
local rel
rel="/1.23.10_$PYTHON"
local h
h=${1#*pl} 
h=${h#*listy_kanalow}
if $iptv ; then  # fixme temprorary fix for github download
    is_curl=false
    is_fullwget=false
fi
if $is_curl ; then
    curl --silent --remote-time  --output $2  $1  --user-agent "cs4aUpdater$rel"
    [ $? -gt 0 ] &&  echo "_(Downloaded archive is corrupted)"
    debug "curl $h $2"
#elif $is_fullwget ; then     #work in progress    
#    $FULLWGET --quiet --output-document=$2  $1  --user-agent="fs4aUpdater$rel"
#    [ $? -gt 0 ] &&  echo "_(Downloaded archive is corrupted)"
#    debug "fullwget $h  $2" 
else
#busybox wget bez --help w opli 8
    TIMESTAMPING=''
    NO_CHECK_CERTIFICATE='--no-check-certificate'
    #if [[ -L $WGET ]]; then
    #    debug  "wget is symlink"
    #else
        $WGET --help | grep 'timestamping' 1>/dev/null 2>&1
        [ $? -gt 0 ] || TIMESTAMPING='--timestamping' 
    #fi 
    $WGET $TIMESTAMPING -q $NO_CHECK_CERTIFICATE  $1  --output-document=$2 --user-agent="ws4aUpdater$rel"
    #$WGET -q  $1  --output-document=$2 --user-agent="ws4aUpdater$rel"
    [ $? -gt 0 ] &&  echo "_(Downloaded archive is corrupted)"
    debug "wget $h  $2"
fi
}

identify_platform () 
{
if [ -f /etc/opkg/opkg.conf ]; then
    OPKGUPDATE='opkg -V0 update'
    OPKGUPGRADE='opkg -V0 upgrade'
    OPKGINSTALL='opkg -V0 install'
    OPKGLIST='opkg list-installed'
else 
    OPKGUPDATE='apt-get update'
    OPKGUPGRADE='apt-get upgrade'
    OPKGINSTALL='apt-get install'
    OPKGLIST='apt-get list-installed'
fi
}

check_if_hdd_installed ()
{
HDD_FOLDER="/media"
case $(cat /proc/self/mounts) in 
    *"media/hdd"*) 
        HDD_FOLDER="$HDD_FOLDER/hdd/s4aupdater"
        ;;
    *"media/mmc"*) 
        HDD_FOLDER="$HDD_FOLDER/mmc/s4aupdater"
        ;;
    *"media/usb"*) 
        HDD_FOLDER="$HDD_FOLDER/usb/s4aupdater"
        ;;
    *"media/sda1"*) 
        HDD_FOLDER="$HDD_FOLDER/sda1/s4aupdater"
        ;;
    *"media/sda2"*) 
        HDD_FOLDER="$HDD_FOLDER/sda2/s4aupdater"
        ;;
    *) 
        HDD_FOLDER=$PLUGIN_FOLDER
        ;;
esac

[ ! -d $HDD_FOLDER/backup ] &&  mkdir -p  $HDD_FOLDER/backup

if [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_usb_backup|grep -e yes) ] ;then
    if mountpoint -q "/media/usb"; then
        HDD_FOLDER='/media/usb/s4aupdater'
    else
        echo "_(No USB mounted device found)"
    fi
else
    echo "_(Backup device mounted as) $HDD_FOLDER"
fi
debug "check_if_hdd_installed $HDD_FOLDER"
}

znajdz_sciezke_oscam_config  ()
{
oscam_version_file=$(find /tmp/ -name oscam.version |sed -n 1p)
if ! test $oscam_version_file; then 
    echo "_(running oscam not found)" ;
    exit 0 
fi
config_dir=$(cat $oscam_version_file|grep 'ConfigDir:'|cut -d ':' -f2)
debug znajdz_sciezke_oscam_config $config_dir
}   

language_select ()
{
local lang_
lang_=$(cat /etc/enigma2/settings |grep osd.language) 
[[ "$lang_" == "" ]] && lang_='unknown'
case $lang_ in 
    *"de"*)
        language='de' 
        ;;
    *"pl"*)
        language='pl' 
        ;;
     *"it"*)
        language='it'
        ;;
     *"cz"*)
        language='cz'
        ;;
    *"cs"*)
        language='cs'
    ;;
    *)  
        language='en'
        ;;
esac

if [ "$distro" == "openatv" ] && [ "$lang_" == "unknown" ]; then
    language='de'
elif [ "$distro" == "openvix" ] && [ "$lang_" == "unknown" ]; then
    language='en'
fi

if [ -f $PLUGIN_FOLDER/s4aUpdater.cfg ] ; then
   lang_=$(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e force_change_language|cut -d '=' -f2 )
   if [[ "$lang_" == *"no"* ]] ; then
      debug "_(language not forced)"
   else
        case $lang_ in 
            *"de"*)
                language='de'
                ;;
            *"pl"*)
                language='pl'
                ;;
            *"it"*)
                language='it'
                ;;
            *"hu"*)
                language='hu'
                ;;
            *"cz"*|*"cs"*)
                language='cz'
                ;;    
            *)
                language='en'
                ;;
        esac
   fi
fi

wersja_wtyczki='You have the current version of the plugin:plugin_update.sh:Plugin Update'
aktualizacja='Update '
aktualizacja_listy='Channell list actualisation '
build_list='S:listy_kanalow:Supported Channel Lists:refresh_channellist.sh'
whats_new='co_nowego'
przywracanie_kopii='restoring a copy'
przywracanie_list_kanalow='Restore channel lists'
lista_kanalow_przywrocona='Channel list backup restored'
konfiguracja_oscama_przywrocona='Oscam configuration restored'
pokaz_publiczne_ip='Show public IP'
tivu='hwemm for prov 183E'
ONOFF='Enable/Disable'
wersja_testowa_wtyczki='Plugin test vesrsion' 
wymus_zmiane_jezyka='Force the plugin to use language'
wymus_uzywanie_oscam_libusb='Force use oscam with libusb'
wymus_kopie_na_usb='Force backup to USB device'
tworzenie_kopii_list='creating of channel list backup'
uzyj_oscam='Instalable oscam edition'
dodaj_repo='acypaczom repository'
dodaj_repo_j00zek='j00zek repository'
dodaj='Add'
usun='Remove'
ON='ON'
OFF='OFF'
narzedzia_dodatkowe='Additional Tools'
przywracanie_z_kopii='Restore data from backup'
utworz_kopie_listy_kanalow='Make backup of current channel list'
utworz_kopie_konf_oscam='Make backup of current oscam config'
utworz_kopie_picon='Make picon backup - 30MB of free space required'
ftp_bez_hasla='ftp root login without password'
zmien_oscam_port='Change oscam http port to'
usun_haslo_oscam='Remove oscam http password'
aktualizuj='Update'
pokaz_oscam_info='Show OSCam Info'
pokaz_ssl_info='Show openSSL installed version'
instaluj_niezbedne_biblioteki='Install needed libraries'
pokaz_upr_kart='Show permissions of local cards'
Listy_Kanalow='Channel Lists'
Nowa_instalacja='New installation'
ustawienia_wtyczki='Plugin Settings'
poprzedni_oscam='Restore previous version of oscam'
softcam="Update SoftCam.key"
generuj_czytniki_ccc='Generate C lines from CCcam.cfg with http addresses'
skip_SKT_menu='Skip Additional Tools Menu'
restore_plugin='Restore Plugin configuration'
backup_plugin='Backup Plugin configuration'

case $language in
    pl)
        wersja_wtyczki='Posiadasz aktualną wersję wtyczki:plugin_update.sh:Aktualizacja Wtyczki'
        aktualizacja='Aktualizacja Wtyczki'
        aktualizacja_listy='Aktualizacja listy kanałów '
        build_list='S:listy_kanalow:Wspierane listy kanałów:refresh_channellist.sh'
        whats_new='co nowego'
        przywracanie_kopii='Przywracanie kopii'
        przywracanie_list_kanalow='Przywrócono kopię listy kanałów'
        lista_kanalow_przywrocona='Lista kanałów przywrócona'
        konfiguracja_oscama_przywrocona='Przywrócono konfigurację Oscam'
        pokaz_publiczne_ip='Pokaż publiczny adres  IP'
        tivu='HWemm dla prov 183E'
        ONOFF='Włącz/Wyłącz'
        wersja_testowa_wtyczki='wersję testową wtyczki' 
        wymus_zmiane_jezyka='Wymuś używanie we wtyczce języka'
        wymus_uzywanie_oscam_libusb='Wymuś używanie wersji oscam z libusb'
        wymus_kopie_na_usb='Wymuś tworzenie kopii na USB'
        tworzenie_kopii_list='tworzenie kopii list kanałów'
        uzyj_oscam='Użyj oscam edycja'
        dodaj_repo='repozytorium acypaczom'
        dodaj_repo_j00zek='repozytorium j00zek'
        dodaj='Dodaj'
        usun='Usuń'
        ON='WŁ'
        OFF='WYŁ'
        narzedzia_dodatkowe='Narzędzia dodatkowe'
        przywracanie_z_kopii='Przywracanie danych z kopii'
        utworz_kopie_listy_kanalow='Utwórz kopię bieżącej listy kanałów '
        utworz_kopie_konf_oscam='Utwórz kopię bieżącej konfiguracji oscama'
        utworz_kopie_picon='Utwórz kopię zapasową pikon- wymagane 30MB wolnego miejsca'
        ftp_bez_hasla='FTP ROOT login bez hasła'
        zmien_oscam_port='Zmień port oscam na'
        usun_haslo_oscam='Usuń hasło do oscam http'
        aktualizuj='Aktualizuj'
        pokaz_oscam_info='Pokaż Info aktualnego OsCam'
        pokaz_ssl_info='Pokaż wersję openSSL'
        instaluj_niezbedne_biblioteki='Instaluj niezbędne biblioteki'
        pokaz_upr_kart='Pokaż uprawnienia kart lokalnych'
        Listy_Kanalow='Listy Kanałów'
        Nowa_instalacja='Nowa instalacja'
        ustawienia_wtyczki='Ustawienia Wtyczki'
        poprzedni_oscam='Przywróc poprzednią wersję oscam'
        softcam="Aktualizacja SoftCam.key"
        skip_SKT_menu='Pomiń Menu Narzędzi Dodatkowych'
        restore_plugin='Przywróć konfigurację wtyczki'
        backup_plugin='Utwórz kopię konfiguracji wtyczki'
        generuj_czytniki_ccc='Wygeneruj linie C z CCcam.cfg z adresami http'
      ;;
    it)
        wersja_wtyczki='La versione installata è aggiornata:plugin_update.sh:Aggiornamento plugin'
        aktualizacja='Aggiornamento '
        aktualizacja_listy='Aggiornamento elenco canali '
        build_list='S:listy_kanalow:Elenchi canali supportati:refresh_channellist.sh'
        whats_new='Novità'
        przywracanie_kopii='Ripristino copia...'
        przywracanie_list_kanalow='Ripristinare elenco canali'
        lista_kanalow_przywrocona='Ripristinato backup elenco canali'
        konfiguracja_oscama_przywrocona='Ripristinata configurazione Oscam'
        pokaz_publiczne_ip='Mostrare IP pubblico'
        tivu='hwemm per prov 183E'
        ONOFF='Abilitare/Disabilitare'
        wersja_testowa_wtyczki='Versione di test del plugin'
        wymus_zmiane_jezyka='Forzare utilizzo lingua'
        wymus_uzywanie_oscam_libusb='Forzare Oscam con libusb'
        wymus_kopie_na_usb='Forzare backup su dispositivo USB'
        tworzenie_kopii_list='Creazione backup elenco canali'
        uzyj_oscam='Versione Oscam installabile'
        dodaj_repo='repository acypaczom'
        dodaj_repo_j00zek='repository j00zek'
        dodaj='Aggiungere'
        usun='Eliminare'
        ON='ON'
        OFF='OFF'
        narzedzia_dodatkowe='Strumenti aggiuntivi'
        przywracanie_z_kopii='Ripristinare dati da backup'
        utworz_kopie_listy_kanalow='Eseguire backup elenco canali corrente'
        utworz_kopie_konf_oscam='Eseguire backup configurazione oscam corrente'
        utworz_kopie_picon='Eseguire backup picon - necessari 30MB di spazio libero'
        ftp_bez_hasla='Login ftp root senza password'
        zmien_oscam_port='Cambiare porta http Oscam a'
        usun_haslo_oscam='Rimuovere password http Oscam'
        aktualizuj='Aggiornare'
        pokaz_oscam_info='Mostrare info OSCam'
        pokaz_ssl_info='Mostrare versione openSSL installata'
        instaluj_niezbedne_biblioteki='Installare librerie richieste'
        pokaz_upr_kart='Mostrare permessi card locale'
        Listy_Kanalow='Elenchi canali'
        Nowa_instalacja='Nuova installazione'
        ustawienia_wtyczki='Impostazioni plugin'
        poprzedni_oscam='Ripristinare versione precedente Oscam'
        softcam='Aggiornare SoftCam.key'
        generuj_czytniki_ccc='Generare C lines da CCcam.cfg con indirizzi http'
        ;;

    de)
        wersja_wtyczki='Du hast die aktuelle Version des Plugin:plugin_update.sh:Aktualizacja Wtyczki'
        aktualizacja='Aktualisieren '
        aktualizacja_listy='Aktualisierung der Kanalliste '
        build_list='S:listy_kanalow:Unterstützte Kanallisten:refresh_channellist.sh'
        przywracanie_kopii='Wiederherstellung einer Kopie'
        przywracanie_list_kanalow='Kanallisten wiederherstellen'
        ON='EIN'
        OFF='AUS'
        przywracanie_z_kopii='Daten aus Backup wiederherstellen '
        utworz_kopie_listy_kanalow='Kopie der aktuellen Kanalliste erstellen '
        utworz_kopie_konf_oscam='Kopie der aktuellen Oscam-Konfiguration erstellen'
        utworz_kopie_picon='Picon-Kopie erstellen – 30 MB freier Speicherplatz erforderlich'
        ftp_bez_hasla='FTP-root-Login ohne Passwort'
        zmien_oscam_port='ändern Oscam http auf'
        usun_haslo_oscam='Entfernst das oscam-http-Passwort'
        aktualizuj='Aktualisierst'
        pokaz_oscam_info='OSCam-Info anzeigen'
        pokaz_ssl_info='Installierte openSSL-Version anzeigen'
        instaluj_niezbedne_biblioteki='Installierst die erforderlichen Libs'
        pokaz_upr_kart='Lokale Kartenberechtigungen anzeigen'
        Listy_Kanalow='Kanallisten'
        Nowa_instalacja='Neu Installation'
        ustawienia_wtyczki='Plugin-Einstellungen'
        softcam='SoftCam.key Einstellungen'
        poprzedni_oscam='Wiederherstellung einer oscam'
        ;;
    cz)
        wersja_wtyczki='Máte aktuální verzi pluginu:plugin_update.sh:Aktualizace pluginu'
        aktualizacja='Aktualizace '
        aktualizacja_listy='Aktualizace seznamu kanálů '
        build_list='S:seznamy kanálů: Seznamy podporovaných kanálů:refresh_channellist.sh'
        whats_new='co je nového'
        przywracanie_kopii='obnovení kopie'
        przywracanie_list_kanalow='Obnovit seznamy kanálů'
        lista_kanalow_przywrocona='Záloha seznamu kanálů byla obnovena'
        konfiguracja_oscama_przywrocona='Konfigurace Oscam obnovena'
        pokaz_publiczne_ip='Zobrazit veřejnou IP adresu'
        tivu='HWemm pro prov 183E'
        ONOFF='Zapnuto/Vypnuto'
        wersja_testowa_wtyczki='Testovací verze pluginu'
        wymus_zmiane_jezyka='Přinutit plugin používat jazyk'
        wymus_uzywanie_oscam_libusb='Vynutit použití oscam z libusb'
        wymus_kopie_na_usb='Vynutit zálohování na zařízení USB'
        tworzenie_kopii_list='zálohování seznamu kanálů'
        uzyj_oscam='Instalovatelné vydání oscam'
        dodaj_repo='acypaczom úložiště'
        dodaj_repo_j00zek='j00zek úložiště'
        dodaj='Přidat'
        usun='Vymazat'
        ON='Zapnout'
        OFF='Vypnout'
        narzedzia_dodatkowe='Další nástroje'
        przywracanie_z_kopii='Obnovte data ze zálohy'
        utworz_kopie_listy_kanalow='Zálohujte aktuální seznam kanálů'
        utworz_kopie_konf_oscam='Vytvořte zálohu vaší aktuální konfigurace oscam'
        utworz_kopie_picon='Zálohujte si picon – je potřeba 30 MB volného místa'
        ftp_bez_hasla='FTP přihlášení bez root hesla '
        zmien_oscam_port='Změňte http port oscam na'
        usun_haslo_oscam='Odstraňte heslo http oscam'
        aktualizuj='Aktualizace'
        pokaz_oscam_info='Zobrazit informace o OSCam'
        pokaz_ssl_info='Zobrazit nainstalovanou verzi openSSL'
        instaluj_niezbedne_biblioteki='Nainstalujte potřebné knihovny'
        pokaz_upr_kart='Zobrazit oprávnění místní karty'
        Listy_Kanalow='Seznamy kanálů'
        Nowa_instalacja='Nová instalace'
        ustawienia_wtyczki='Nastavení pluginu'
        poprzedni_oscam='Obnovte předchozí verzi oscam'
        softcam="Aktualizace SoftCam.key"
        generuj_czytniki_ccc='Vygenerujte C řádky z CCcam.cfg s http adresami'
        skip_SKT_menu='Přeskočte nabídku dalších nástrojů'
        restore_plugin='Obnovte konfiguraci pluginu'
        backup_plugin='Konfigurace zálohovacího pluginu'
        ;; 
    hu)
        wersja_wtyczki='A beépülő modul aktuális verziójával rendelkezik:plugin_update.sh:Beépülő modul frissítése'
        aktualizacja='Frissítés '
        aktualizacja_listy='Csatornalista aktualizálása '
        build_list='S:listy_kanalow:Támogatott csatornalisták:refresh_channellist.sh'
        whats_new='Mi újság'
        przywracanie_kopii='másolat visszaállítása'
        przywracanie_list_kanalow='Csatornalisták visszaállítása'
        lista_kanalow_przywrocona='A csatornalista biztonsági mentése visszaállítva'
        konfiguracja_oscama_przywrocona='Az Oscam konfiguráció visszaállítva'
        pokaz_publiczne_ip='Nyilvános IP-cím megjelenítése'
        tivu='HWemm mert prov 183E'
        ONOFF='Bekapcsolni/Kikapcsolni'
        wersja_testowa_wtyczki='Plugin tesztverzió'
        wymus_zmiane_jezyka='Kényszerítse a beépülő modult a nyelv használatára'
        wymus_uzywanie_oscam_libusb='Az oscam használatának kényszerítése a libusb-val'
        wymus_kopie_na_usb='Biztonsági mentés kényszerítése USB-eszközre'
        tworzenie_kopii_list='csatornalista biztonsági mentésének létrehozása'
        uzyj_oscam='Telepíthető oscam kiadás'
        dodaj_repo='acypaczom adattár'
        dodaj_repo_j00zek='j00zek adattár'
        dodaj='Hozzáadás'
        usun='Távolítsa el'
        ON='TOVÁBB'
        OFF='KI'
        narzedzia_dodatkowe='További eszközök'
        przywracanie_z_kopii='Adatok visszaállítása biztonsági másolatból'
        utworz_kopie_listy_kanalow='Készítsen biztonsági másolatot az aktuális csatornalistáról'
        utworz_kopie_konf_oscam='Készítsen biztonsági másolatot az aktuális oscam konfigurációról'
        utworz_kopie_picon='Készítsen picon biztonsági másolatot – 30 MB szabad hely szükséges'
        ftp_bez_hasla='ftp root bejelentkezés jelszó nélkül'
        zmien_oscam_port='Módosítsa az oscam http portot erre'
        usun_haslo_oscam='Távolítsa el az oscam http jelszót'
        aktualizuj='Frissítés'
        pokaz_oscam_info='OSCam Info megjelenítése'
        pokaz_ssl_info='Az openSSL telepített verziójának megjelenítése'
        instaluj_niezbedne_biblioteki='Telepítse a szükséges könyvtárakat'
        pokaz_upr_kart='Helyi kártyák engedélyeinek megjelenítése'
        Listy_Kanalow='Csatornalisták'
        Nowa_instalacja='Új telepítés'
        ustawienia_wtyczki='Beépülő modul beállításai'
        poprzedni_oscam='Az oscam korábbi verziójának visszaállítása'
        softcam="Frissítés SoftCam.key"
        generuj_czytniki_ccc='Generáljon C sorokat a CCcam.cfg fájlból http címekkel'
        skip_SKT_menu='A További eszközök menü kihagyása'
        restore_plugin='A beépülő modul konfigurációjának visszaállítása'
        backup_plugin='Backup Plugin konfiguráció'
        ;; 
esac 
#whats_new='co_nowego'   #na razie wymuszamyrdhw  PL    FIXME
debug  "language $language"
}

rdhw_s4aupdater ()
{
    rdr=$(cat $s4aupdater_version |grep 'RNG'|cut -d '=' -f2)
    rdr="$HTTP_ADDRESS/emm_tivu/$rdr/emm"
}

return_distro ()
{
if ls /etc/issue 1> /dev/null 2>&1; then
    distro=$(cat /etc/issue | tr '[:upper:]' '[:lower:]') 
    case $distro in
        *openatv* ) 
            distro=openatv 
            ;;
        *openpli*|*openeight*|*opentr*)
            distro=openpli
            ;;
        *openspa*)
            distro=openspa 
            ;;
        *vision*)
            distro=openvision 
            ;;
        *openhdf*)
            distro=openhdf 
            ;;
        *cobralib*)
            distro=cobralibero 
            ;;
        *openbh*)       
            distro=openbh
                #config_dir='/etc/tuxbox/config'
            usr_bin='/usr/softcams' 
            ;;
        *openvix*)       
            distro=openvix
                #config_dir='/etc/tuxbox/config'
            usr_bin='/usr/softcams' 
            ;;
        *pkteam*|*zukon*)
            distro=hyperion
            config_dir='/var/keys'
            usr_bin='/var/emu' 
            ;;
        *egami*)
            distro=egami 
            ;;
        *pure2*)
            distro=pure2 
            ;;
        *graterlia*)
            distro=graterlia
            ;; 
        *teamblue*)
            distro=teamblue 
            ;;
        *vti*|*vuplus*)
            distro=vti
            [[  -e /usr/lib/libssl.so.1.0.2 ]] || ln -sf libssl.so.1.0.0 /usr/lib/libssl.so.1.0.2
            [[  -e /lib/libcrypto.so.1.0.2 ]]  || ln -sf libcrypto.so.1.0.0 /lib/libcrypto.so.1.0.2 
            #skrypt w /usr/scrit/nazwa_oscam_pelna dowiazanie do /etc/init.d/current_cam.sh
            ;;
        *)
            distro=unknown ;;
    esac
else 
    if ls /etc/openpli 1> /dev/null 2>&1; then   #for nbox
        if [ Processor == sh4 ]; then
            distro=openpli
            config_dir='/var/keys'
            usr_bin='/var/bin'
        fi 
    fi
fi
debug "distro $distro"
}

identify_CPU ()
{
Processor=$(uname -m | tr '[:upper:]' '[:lower:]') #x86_64
case $Processor in 
    *"armv7l"*|*"armv71"*)
        Processor=arm 
        ;;
    *"mips"*|*"sigma"*|*"7405d0-smp"*|*"7401c0"*)
        Processor=mipsel 
        ;;
    *"aarch64"*)
        Processor=aarch64 
        ;;
    *"sh4"*)                            
        Processor=sh4
        make_backup=false
             ;;
    *"x86_64"*)                         Processor=X86_64 ;;   #4 tests only ;-) 
    *)      echo  "_(Unknown CPU) $Processor" &&  exit 0 ;;
esac
debug "identify_CPU $Processor"
} 

 prefer_fullwget_than_wget ()
 {
local can_write
can_write=true
if ( ! $is_curl && ! $is_fullwget ) ;then 
    debug "sprawdzanie fullwget, curl brak "
    wget  --quiet "${HTTP_ADDRESS%l*}l/fullwget_s4a/fullwget_$Processor.tar.gz" --output-document="/tmp/fullwget.tar.gz" 
    tar zxvf   /tmp/fullwget.tar.gz --directory=/tmp  >/dev/null 2>&1
    rm -f /tmp/fullwget*.tar.gz 1 >/dev/null 2>&1
    chmod a+x /tmp/fullwg*  1 >/dev/null 2>&1
    touch /usr/bin/fullwget 
    [ $? -gt 0 ] && can_write=false
    if $can_write ; then 
        rm -f /usr/bin/fullwget >/dev/null 2>&1
        cp -f /tmp/fullwget_$Processor /usr/bin/fullwget   >/dev/null 2>&1
        chmod a+x $PLUGIN_FOLDER/fullwget
        FULLWGET=$(which fullwget)
    else
        cp  -f /tmp/fullwget_$Processor $PLUGIN_FOLDER/fullwget   >/dev/null 2>&1
        chmod a+x $PLUGIN_FOLDER/fullwget
        FULLWGET=$PLUGIN_FOLDER/fullwget    
    fi
    rm -f /tmp/fullwge*
    is_fullwget=true 
    debug " pobranie fullwget $FULLWGET" 
fi
 }

identify_ssl ()
{
ssl=$(openssl version)
case $ssl in
    *"1.1.1"*)
	    ssl=ssl111
        ;;
    *"1.0.0"*)
	    ssl=ssl100
        ;;
    *"1.0.2"*)
	    ssl=ssl102
        ;;
    *"3.0"*|*"3.1"*|*"3.2"*)
        ssl=ssl30
        cat $PLUGIN_FOLDER/s4aUpdater.cfg  |grep -e force_ssl102 |grep -e yes  && ssl=102
        ;; 
    *"0.98"*)
	    ssl=ssl098
        ;;
    *)
        #ssl=unknown
        echo "_(Unknown SSL Version) $ssl"
        exit 0
        ;;
esac
debug "ssl $ssl"
}

modify_menu ()
{
SRVID2=`cat $s4aupdater_version |grep 'srvid2_jejon'|cut -d '=' -f2`
SoftCam_Key=`cat $s4aupdater_version |grep 'SoftCamKey'|cut -d '=' -f2`
#SoftCam.key"
satellites_xml=`cat $s4aupdater_version |grep 'satellites_xml'|cut -d '=' -f2`
tivu_emm=`cat $s4aupdater_version |grep 'TIVU_EMM'|cut -d '=' -f2`


WERSJA_WTYCZKI_ZDALNA=$(cat $s4aupdater_version |grep 'plugin_version'|cut -d '=' -f2)
WERSJA_WTYCZKI_LOKALNA=$(cat $PLUGIN_FOLDER/version.py|grep Version|cut -d '=' -f2)
if  [[ "$WERSJA_WTYCZKI_LOKALNA" < "$WERSJA_WTYCZKI_ZDALNA" ]]; then    
    WERSJA_WTYCZKI_ZDALNA=${WERSJA_WTYCZKI_ZDALNA:1:${#WERSJA_WTYCZKI_ZDALNA}-2} #pokazujemy wersje bez cudzyslowow
    c_line="J:main: $aktualizacja $WERSJA_WTYCZKI_ZDALNA :plugin_update.sh:$aktualizacja"
    debug "Znaleziono wersje wtyczki $WERSJA_WTYCZKI_ZDALNA"
else
    c_line='J:main: '$aktualizacja' :plugin_update.sh:Aktualizacja Wtyczki'
fi
echo $c_line >> $PLUGIN_FOLDER/main.cfg

MEGA=$(cat $s4aupdater_version |grep 'MEGA'|cut -d '=' -f2)
OSCAM_ZDALNY=$(cat $s4aupdater_version |grep $oscam_version |cut -d '=' -f2)
OSCAM_ZDALNY="$OSCNAME $CyCeC"OSCam"$OSCAM_ZDALNY"
case $OSCAM_EDITION in
  *"jejon"*)
    MEGA="-$MEGA"
    ;;
  *)
    MEGA=''
    ;;
esac

OSCAM_ZDALNY="$OSCAM_ZDALNY$MEGA$EMU$ADDITION"
if [[ "$OSCAM_EDITION" == *"icam"* ]] ; then
    OSCAM_ZDALNY=$OSCAM_ZDALNY-$(cat $s4aupdater_version |grep 'ICAM'|cut -d '=' -f2)
fi

debug "nazwa oscam do menu $OSCAM_ZDALNY"
sed -i "s|OSCam|$OSCAM_ZDALNY| g" $PLUGIN_FOLDER/main.cfg
sed -i "s|oscam.srvid2:|oscam.srvid2 ($SRVID2):| g" $PLUGIN_FOLDER/SKT.cfg
sed -i "s|SoftCam.key:|SoftCam.key ($SoftCam_Key):| g" $PLUGIN_FOLDER/SKT.cfg
sed -i "s|satellites.xml:|satellites.xml ($satellites_xml):| g" $PLUGIN_FOLDER/SKT.cfg
sed -i "s|183E:|183E ($tivu_emm):| g" $PLUGIN_FOLDER/SKT.cfg

ls /etc/enigma2/lista_* 1> /dev/null 2>&1
if [ "$?" == "0" ] ; then
  czyja_lista=$(ls /etc/enigma2/lista_*)
  data_lista_lokalna=$(cat $czyja_lista)
  czyja_lista=${czyja_lista:19}  #tu mamy liste czyja jest wgrana
  while IFS= read -r line; do
    [[ "$line" == *"$czyja_lista"* ]] && c_line=$line
  done < $LISTY_KANALOW
  data_lista_zdalna=$(cat $s4aupdater_lista |grep $czyja_lista'_version'|cut -d ':' -f2)
  debug "czyja lista  $czyja_lista"
  debug "data zdalna  $data_lista_zdalna"
  debug "data lokalna  $data_lista_lokalna"
  c_line="C:main:$aktualizacja_listy $data_lista_zdalna:$FOLDER_LIST/$czyja_lista.sh:$aktualizacja_listy"
  if [[  "$data_lista_lokalna" <  "$data_lista_zdalna" ]]; then 
    debug "dodaje liste do main menu"
    echo $c_line >>$PLUGIN_FOLDER/main.cfg
    $PLUGIN_FOLDER/refresh_channellist.sh
  fi
fi
}

find_oscam ()
{
    oscam_pid=$(cat $(find /tmp/ -name oscam*.pid))
    OSCAMBIN=$(basename -- $($REALPATH /proc/$oscam_pid/exe ))
    OSCAM_WITH_PATH=$($REALPATH  /proc/$oscam_pid/exe  )
    debug "find_oscam $OSCAM_WITH_PATH" 
}

backup_channel_list ()
{
    local counter
    MAKE_BACKUP=false
    plik_lokalny=$HDD_FOLDER'/backup/backup_list_'  
    if [[ "$1" == *"list"* ]] ; then
        MAKE_BACKUP=true
        plik_lokalny=$plik_lokalny'M_'
    fi
    if [ -f $PLUGIN_FOLDER/s4aUpdater.cfg ] ; then
        [ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg| grep 'skip_channellist_backup=no') ] && MAKE_BACKUP=true
    fi
    if $MAKE_BACKUP ; then
        backup_copies=6
        #how many channellist backups to keep (default 6 )
        if [ -f $PLUGIN_FOLDER/s4aUpdater.cfg ] ; then
            re='^[0-9]+$'
            backup_copies=`cat $PLUGIN_FOLDER/s4aUpdater.cfg |grep 'backup_copies'|cut -d '=' -f2`
            [[ $backup_copies =~ $re ]]  || $backup_copies=6
        fi
        if [ ! -d $HDD_FOLDER/backup ]; then
            mkdir $HDD_FOLDER/backup
        else
            ls $HDD_FOLDER/backup/backup_list_2*  >/dev/null 2>&1
            if [ $? == 0 ] ;  then
                counter=$(ls -Art $HDD_FOLDER/backup/backup_list_2* |wc -l)
                while [ $counter -ge $backup_copies ]
                do
                    rm -f $(ls  -Art $HDD_FOLDER/backup/backup_list_2* | head -n 1) #usun najstarsze  kopie automatycznie generowanych list kanalow
                    counter=$((counter - 1)) 
                    #((counter--))
                done
            fi
        fi
        echo "_(Creating channel list backup)"
        WHAT2BACKUP='/etc/tuxbox/satellites.xml /etc/enigma2/userbouqu* /etc/enigma2/bouquet* /etc/enigma2/lamed* ' 
        find /etc/enigma2/ -name lista_* >/dev/null 2>&1
        [ $? == 0 ] &&  WHAT2BACKUP="$WHAT2BACKUP $(find /etc/enigma2/ -name lista_* ) "
        find /etc/enigma2/ -name altern*.tv >/dev/null 2>&1
        [ $? == 0 ] &&  WHAT2BACKUP="$WHAT2BACKUP $(find /etc/enigma2/ -name altern*.tv )" || debug "brak alternate w /etc/enigma2"
        [ -f /etc/tuxbox/terestrial.xml ] && WHAT2BACKUP="$WHAT2BACKUP /etc/tuxbox/terestrial.xml" 
        [ -f /etc/tuxbox/cables.xml ] && WHAT2BACKUP="$WHAT2BACKUP /etc/tuxbox/cables.xml" 
        [ -f /etc/tuxbox/atsc.xml ] && WHAT2BACKUP="$WHAT2BACKUP /etc/tuxbox/atsc.xml"
        plik_lokalny=$plik_lokalny$(date +"%Y-%m-%d_%H%M.%S").tar.gz
        tar zcvf $plik_lokalny $WHAT2BACKUP >/dev/null 2>&1
    else
        plik_lokalny="_(Channellist backup disabled in config file)" 
        echo "_(Skipping channel list backup)"
    fi
    debug backup_channel_list
}

check_beta_release ()
{
[ $(cat $PLUGIN_FOLDER/s4aUpdater.cfg  |grep -e beta |grep -e yes) ] && HTTP_ADDRESS="$HTTP_ADDRESS/beTa"    
}

wersja_wtyczki ()
{
local ver
ver=$(cat $PLUGIN_FOLDER/version.py|grep Version|cut -d '=' -f2)
ver="${ver//\'/}"
#ver=${ver:1:13} 
echo -e ''
echo "s4aUpdater _(Plugin version): $ver"
}

build_symlink ()
{
	[ ! -L "$PLUGIN_FOLDER/addons/$1" ] && ln -sf script.sh $PLUGIN_FOLDER/addons/$1.sh
}

ln_sf ()
{
build_symlink "backup_channel_list" 
build_symlink "backup_oscam_config" 
build_symlink "backup_picon" 
build_symlink "force_addons" 
build_symlink "force_beta_s4aupdater" 
build_symlink "force_change_language" 
build_symlink "force_change_oscam_edition"
build_symlink "force_change_oscam_port" 
build_symlink "force_download_srvid2" 
build_symlink "force_ftp_root_login_no_password" 
build_symlink "force_install_opkg"
build_symlink "force_install_opkg_j00zka"
build_symlink "force_install_opkg_acypaczom"
build_symlink "force_skip_SKT"
build_symlink "force_libusb_pcsc" 
build_symlink "force_freevpn"
build_symlink "force_cccam_2_oscam_importer"
build_symlink "download_SoftCam_key"
build_symlink "force_download_ExtraMenu"
build_symlink "force_overwrite_satellites_file" 
build_symlink "force_remove_oscam_http_password"
build_symlink "force_plugin_backup"
build_symlink "force_skip_channellist_backup" 
build_symlink "force_usb_backup"
build_symlink "force_plugin_restore" 
build_symlink "force_install_ciplushelper_for_poland" 
build_symlink "force_restore_previous_oscam" 
build_symlink "force_download_SoftCam_key"
build_symlink "force_factory_reset" 
build_symlink "info_openssl" 
build_symlink "info_show_public_ip" 
build_symlink "info_oscam_port" 
build_symlink "restore_channellist" 
build_symlink "restore_picon" 

}

function_oscam_edition ()
{
ADDITION=''
CyCeC='' 
local edition
edition=$(cat $PLUGIN_FOLDER/s4aUpdater.cfg |tr '[:upper:]' '[:lower:]' |grep -e oscam_edition|cut -d '=' -f2 )    
case $edition in
    *"samur"*) 
        OSCAM_EDITION='samur'
        OSCNAME="SAMUR"
        OSCAM_BINARIES="oscam_binaries_samur"
        oscam_version='oscam_version_samur'
        oscam_value='oscam_samur'
        EMU='-798' ;;
    *"mohamed"*) 
        OSCAM_EDITION='mohamed'
        OSCNAME="MOHAMED19OS"
        OSCAM_BINARIES="oscam_binaries_mohamed"
        oscam_version='oscam_version_mohamed'
        oscam_value='oscam_mohamed'
        EMU='-798' ;;
    *"levi45"*) 
        OSCAM_EDITION='levi45'
        OSCNAME="levi45"
        OSCAM_BINARIES="oscam_binaries_levi45"
        oscam_version='oscam_version_levi45'
        oscam_value='oscam_levi45'
        EMU='' ;;
     *"kitte"*) 
        OSCAM_EDITION='kitte888'
        OSCNAME='kitte888'
        OSCAM_BINARIES="oscam_binaries_kitte888"
        oscam_version='oscam_version_kitte888'
        oscam_value='oscam_kitte888'
        #EMU='-798' ;;
        EMU='' ;;
    # *"icam"*) 
    #    OSCAM_EDITION='jejon_icam'
    #    OSCAM_BINARIES='oscam_binaries'
    #    OSCNAME='jej@n'
    #    CyCeC='CyCeC+'
    #    oscam_version='oscam_version_jejon'
    #    oscam_value='oscam_icam'
    #    EMU='-icam' ;;
    *) 
        OSCAM_EDITION='jejon'
        OSCAM_BINARIES='oscam_binaries'
        OSCNAME='Jej@n'
        CyCeC='CyCeC+'
        oscam_version='oscam_version_jejon'
        oscam_value='oscam_cycec'
        EMU='' ;;
esac
}

check_if_ssl_installed ()
{
if [[ $Processor == arm ]] ||  [[ $Processor == mipsel ]] ||  [[ $Processor == aarch64 ]] ; then
    openssl help 1>/dev/null 2>&1
    if [ "$?" != "0" ] ; then
      $OPKGUPDATE 1>/dev/null 2>&1
      $OPKGINSTALL openssl 1>/dev/null 2>&1
      $OPKGINSTALL openssl-bin 1>/dev/null 2>&1   #openpli 8.3
    fi
fi
}

install_missing_opkgs ()
{
$OPKGUPDATE
$OPKGINSTALL curl  1>/dev/null 2>&1
$OPKGINSTALL openssl 1>/dev/null 2>&1
if [[ "$distro" == *"openpli"* ]]; then
    $OPKGINSTALL openssl-bin 1>/dev/null 2>&1
    $OPKGINSTALL wget 1>/dev/null 2>&1
fi
$OPKGINSTALL bash 1>/dev/null 2>&1

echo "_(Done correctly)"
}
