# Mon Jan 1 12:00:00 AM CET 2024
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
# Mon Jan 1 08:51:41 PM CET 2024
#!/bin/sh
#part of s4aUpdater
#by acypaczom  sat-4-all.com
PLUGIN_FOLDER='/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater'

	. $PLUGIN_FOLDER/functions.sh

PYTHON3_REQUIRED=$(cat $s4aupdater_version|grep 'support_py3only'|cut -d '=' -f2)
if [[ "$PYTHON3_REQUIRED" == "yes" ]]; then
    PYTHON_VERSION=$(python -c 'import sys; print(sys.version_info[0])')
    if (( "$PYTHON_VERSION" != "3" )); then
        echo "Python version not supported"
        exit 1
    fi
fi

ln_sf
identify_platform

if [ `echo $0| grep -c "$PLUGIN_FOLDER"` -gt 0 ] ; then
    cp -f $0 /tmp/plugin_update.sh 1>/dev/null 2>&1
    /tmp/plugin_update.sh 
    exit 0
fi
[ -f $PLUGIN_FOLDER/s4aUpdater.cfg ] || touch $PLUGIN_FOLDER/s4aUpdater.cfg 

which curl 1>/dev/null 2>&1
if [ "$?" != "0" ] ; then
    echo "_(CURL not found, trying to install one)"
	$OPKGUPDATE   1>/dev/null 2>&1 
	$OPKGINSTALL curl 1>/dev/null 2>&1
    if [ "$?" != "0" ] ; then
        identify_CPU
        prefer_fullwget_than_wget
    else
        is_curl=true
    fi
	debug "aktualizacja sprawdzam curl"
else 
	is_curl=true
fi

identify_CPU
#$is_curl || prefer_fullwget_than_wget
check_beta_release
function_download_file "$HTTP_ADDRESS/version" $s4aupdater_version
WERSJA_WTYCZKI_ZDALNA=$(cat $s4aupdater_version|grep plugin_version|cut -d '=' -f2)
WERSJA_WTYCZKI_LOKALNA=$(cat $PLUGIN_FOLDER/version.py|grep Version|cut -d '=' -f2)
WHATS_NEW=$(cat $s4aupdater_version|grep $whats_new|cut -d '=' -f2)

update_s4aUpdater_configfile beta
update_s4aUpdater_configfile logfile
update_s4aUpdater_configfile force_change_language
update_s4aUpdater_configfile force_ssl102
update_s4aUpdater_configfile force_usb_backup
update_s4aUpdater_configfile force_libusb 
update_s4aUpdater_configfile multi_replace_srvid2  
update_s4aUpdater_configfile skip_channellist_backup
update_s4aUpdater_configfile backup_copies 6
update_s4aUpdater_configfile oscam_edition jejon

chmod a+x $PLUGIN_FOLDER/*.sh
chmod a+x $PLUGIN_FOLDER/addons/*.sh

temp="${WERSJA_WTYCZKI_ZDALNA//\'/}"  #wycinamy '
nowy="${temp//./}"     #wycinamy .
temp="${WERSJA_WTYCZKI_LOKALNA//\'/}"
stary="${temp//./}"

if [[ $stary -ge $nowy ]]; then 
   echo "_(You have current version of plugin)"
   echo -e ' '
   echo  $WHATS_NEW
   wersja_wtyczki
   exit 0
fi

echo "_(Actualisation found)"
echo -e ""
echo  $WHATS_NEW
echo -e ""

function_download_file "$HTTP_ADDRESS/s4aUpdater.tar.gz" /tmp/s4aUpdater.tar.gz

echo "_(Actualisation has been downloaded ...)"
echo "_(Installation in progress, please wait)"
[ -d /tmp/tmp ] && rm -rf /tmp/tmp/* || mkdir /tmp/tmp
tar zxvf /tmp/s4aUpdater.tar.gz --directory=/tmp/tmp  --overwrite 1>/dev/null 2>&1
if [ $? -gt 0 ] ; then 
	echo "_(Downloaded archive is corrupted)"
   	rm -rf /tmp/tmp 1>/dev/null 2>&1
	exit 0
fi	
cp -rfp /tmp/tmp/*  /usr/lib/enigma2/python/Plugins/Extensions 1>/dev/null 2>&1
echo "_(Installed correctly)"
rm -f /tmp/s4aUpdater.tar.gz 1>/dev/null 2>&1
rm -rf /tmp/tmp 1>/dev/null 2>&1
language_select
function_generate_menu
function_oscam_edition
modify_menu
#   ##some  cleanup
#find $PLUGIN_FOLDER -name '*.tmp'  -exec rm -f -  {} \;

wersja_wtyczki
exit 0