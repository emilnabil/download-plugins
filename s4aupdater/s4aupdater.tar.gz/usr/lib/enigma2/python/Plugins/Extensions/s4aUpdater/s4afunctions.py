# -*- coding: utf-8 -*-
#!/usr/bin/env python

#tools functions for s4aupdater written by lareq/acypaczom
"""
This file is part of the s4aupdater plugin  (https://sat-4-all.com).
Copyright (c) 2023 acypaczom

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, version 3.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""

import subprocess
import os
import platform
import requests
import shutil

from Screens.MessageBox import MessageBox
try:
    # Python 3
    from urllib.parse import urlparse
except ImportError:
    # Python 2
    from urlparse import urlparse



pluginpath = '/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater'

def ClearMemory():
        with open("/proc/sys/vm/drop_caches", "w") as f: f.write("1\n")

def identify_platform():
    if os.path.isfile("/etc/opkg/opkg.conf"):
        OPKGUPDATE = 'opkg -V0 update'
        OPKGUPGRADE = 'opkg -V0 upgrade'
        OPKGINSTALL = 'opkg -V0 install'
        OPKGLIST = 'opkg list-installed'
    else:
        OPKGUPDATE = 'apt-get update'
        OPKGUPGRADE = 'apt-get upgrade'
        OPKGINSTALL = 'apt-get install'
        OPKGLIST = 'apt-get list-installed'

    return OPKGUPDATE, OPKGUPGRADE, OPKGINSTALL, OPKGLIST

def make_executable(path):
    mode = os.stat(path).st_mode
    mode |= (mode & 0o444) >> 2    # copy R bits to X
    os.chmod(path, mode)

def identify_CPU():
    processor = platform.machine().lower()  # x86_64
    make_backup = False
    result = ""

    if "armv7l" in processor or "armv71" in processor:
        processor = "arm"
    elif "mips" in processor or "sigma" in processor or "7405d0-smp" in processor or "7401c0" in processor:
        processor = "mipsel"
    elif "aarch64" in processor:
        processor = "aarch64"
    elif "sh4" in processor:
        processor = "sh4"
        make_backup = False
        # Uncomment and implement the file download and chmod operations if needed.
        # if not os.path.isfile(os.path.join(PLUGIN_FOLDER, 'busybox')):
        #     function_download_file(f"{HTTP_ADDRESS.rstrip('l')}/busybox/busybox-sh4", os.path.join(PLUGIN_FOLDER, 'busybox'))
        #     os.chmod(os.path.join(PLUGIN_FOLDER, 'busybox'), 0o755)
    elif "x86_64" in processor:
        processor = "X86_64"  # 4 tests only ;-)
    
    if processor == "unknown":
#        result = f"_(Unknown CPU) {processor}"
        result = "_(Unknown CPU) %s" % processor

    else:
        result = processor

    return result
#result = identify_CPU()


def return_distro():
    if os.path.exists("/etc/issue"):
        with open("/etc/issue", "r") as issue_file:
            distro = issue_file.read().lower()

        config_dir = ""
        usr_bin = ""

        if "openatv" in distro:
            distro = "openatv"
        elif "openpli" in distro or "openeight" in distro:
            distro = "openpli"
        elif "openspa" in distro:
            distro = "openspa"
        elif "vision" in distro:
            distro = "openvision"
        elif "openhdf" in distro:
            distro = "openhdf"
        elif "cobralib" in distro:
            distro = "cobralibero"
        elif "openbh" in distro:
            distro = "openbh"
            usr_bin = "/usr/softcams"
        elif "openvix" in distro:
            distro = "openvix"
            usr_bin = "/usr/softcams"
        elif "pkteam" in distro or "zukon" in distro:
            distro = "hyperion"
            config_dir = "/var/keys"
            usr_bin = "/var/emu"
        elif "egami" in distro:
            distro = "egami"
        elif "pure2" in distro:
            distro = "pure2"
        elif "graterlia" in distro:
            distro = "graterlia"
        elif "teamblue" in distro:
            distro = "teamblue"
        elif "vti" in distro or "vuplus" in distro:
            distro = "vti"
            if not os.path.exists("/usr/lib/libssl.so.1.0.2"):
                os.symlink("libssl.so.1.0.0", "/usr/lib/libssl.so.1.0.2")
            if not os.path.exists("/lib/libcrypto.so.1.0.2"):
                os.symlink("libcrypto.so.1.0.0", "/lib/libcrypto.so.1.0.2")
        else:
            distro = "unknown"
    else:
        if os.path.exists("/etc/openpli"):
            if platform.machine().lower() == "sh4":
                distro = "openpli"
                config_dir = "/var/keys"
                usr_bin = "/var/bin"
        else:
            distro = "unknown"

    return distro, config_dir, usr_bin
#distro, config_dir, usr_bin = return_distro()

def function_download_file(url, file_path):
    with open(os.path.join(pluginpath, 's4aUpdater.cfg'), 'r') as file:
        for line in file:
            if "beta" in line and "yes" in line:
                parsed_url = urlparse(url)
                scheme = parsed_url.scheme
                netloc = parsed_url.netloc
                path = parsed_url.path
                if "listy_kanalow" not in path:
                    word_list = [scheme,'://', netloc, '/beTa', path]
                    url = "".join(word_list)
                #print(f"adres pobierania {url}")

    rel = "/1.23.10"
    #h = url.split('pl')[1]
    #h = h.split('listy_kanalow')[1]

    #headers = {'User-Agent': f'4aUpdater2.0-{rel}'}
    headers = {'User-Agent': '4aUpdater2.0-' + rel}

    try:
        response = requests.get(url, headers=headers, stream=True)
        if response.status_code == 200:
            with open(file_path, 'wb') as file:
                for chunk in response.iter_content(chunk_size=1024):
                    if chunk:
                        file.write(chunk)
            print("File downloaded successfully.")
            self.session.open(MessageBox, "Download : {}".format(str(file_path)), MessageBox.TYPE_ERROR)
#            debug(f"curl {h} {file_path}")
        else:
            print("Download failed: _(Downloaded archive is corrupted)")
    except Exception as e:
#        print(f"Download failed: {str(e)}")
        print("Download failed: " + str(e))


#    if os.path.exists(file_path):
    # Get the last modification date of the local file
#        local_file_mtime = os.path.getmtime(file_path)

    # Send a HEAD request to get the last modification date of the server file
#        response = requests.head(url)

    # Check if the server file exists and the response has a Last-Modified header
#        if response.status_code == 200 and 'Last-Modified' in response.headers:
#            server_file_mtime = response.headers['Last-Modified']

        # Convert the server file's last modification date to a timestamp
#            server_file_mtime = requests.utils.parsedate_to_datetime(server_file_mtime).timestamp()

        # Compare the last modification dates
#            if server_file_mtime > local_file_mtime:
#            # The server file is newer, download it
#                response = requests.get(url)
#                with open(file_path, 'wb') as local_file:
#                    local_file.write(response.content)
#                print("File downloaded because it's newer.")
#            else:
#                print("Local file is up to date, no need to download.")
#        else:
#            print("Server file not found or Last-Modified header missing.")
#    else:
    # The local file doesn't exist, download it
#       with open(file_path, 'wb') as local_file:
#            local_file.write(response.content)
#        print("Local file not found, so it was downloaded.")


def build_symlink(subfolder):
#    symlink_path = os.path.join(pluginpath, "addons", f"{subfolder}.sh")
    symlink_path = os.path.join(pluginpath, "addons", "%s.sh" % subfolder)
    if not os.path.islink(symlink_path):
        os.symlink("script.sh", symlink_path)

def ln_sf():
    subfolders = [
        "backup_channel_list",
        "backup_oscam_config",
        "backup_picon",
        "force_addons",
        "force_beta_s4aupdater",
        "force_change_language",
        "force_change_oscam_edition",
        "force_change_oscam_port",
        "force_download_srvid2",
        "force_ftp_root_login_no_password",
        "force_install_opkg",
        "force_install_opkg_j00zka",
        "force_install_opkg_acypaczom",
        "force_skip_SKT",
        "force_libusb_pcsc",
        "force_freevpn",
        "force_cccam_2_oscam_importer",
        "download_SoftCam_key",
        "force_download_ExtraMenu",
        "force_overwrite_satellites_file",
        "force_remove_oscam_http_password",
        "force_plugin_backup",
        "force_skip_channellist_backup",
        "force_usb_backup",
        "force_plugin_restore",
        "force_install_ciplushelper_for_poland",
        "force_restore_previous_oscam",
        "force_download_SoftCam_key",
        "force_factory_reset",
        "info_openssl",
        "info_show_public_ip",
        "info_oscam_port",
        "restore_channellist",
        "restore_picon",
    ]
    for subfolder in subfolders:
        build_symlink(subfolder)

def update_s4aUpdater_configfile(parameter, value="no", path="no"):
    cfg_file = os.path.join(pluginpath, "s4aUpdater.cfg")

    if not any(line.startswith(parameter + "=") for line in open(cfg_file)):
        with open(cfg_file, "a") as f:
            #f.write(f"{parameter}={value}\n")
            f.write("%s=%s\n" % (parameter, value))
#        print("dodane " + parameter + "=" + value)



def ftp_root_login_no_password():
    # Remove the root password
    subprocess.call(['passwd', '-d', '-q', 'root'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # Modify the PAM configuration
    with open('/etc/pam.d/vsftpd', 'r') as pam_file:
        pam_lines = pam_file.readlines()

    with open('/etc/pam.d/vsftpd', 'w') as pam_file:
        for line in pam_lines:
            line = line.replace('/lib/security/pam_unix.so shadow', '/lib/security/pam_unix.so nullok shadow')
            pam_file.write(line)
#    print('Password has been removed')


def remove_oscam_http_password():
    oscam_version_file = None
    for files in os.walk('/tmp/'):
        for filename in files:
            if filename.startswith('oscam') and filename.endswith('.version'):
                oscam_version_file = os.path.join(root, filename)
                break
        if oscam_version_file:
            break
    
    if not oscam_version_file:
        print("OSCam version file not found in /tmp/")
        return

    # Extract the OSCAM_CONFIG value from the version file
    with open(oscam_version_file, 'r') as version_file:
        for line in version_file:
            if "ConfigDir" in line:
                OSCAM_CONFIG = line.split(':      ')[1].strip()
                break
        else:
            print("ConfigDir not found in OSCam version file")
            return
    oscam_conf_file = os.path.join(OSCAM_CONFIG, 'oscam.conf')
    try:
        with open(oscam_conf_file, 'r') as conf_file:
            conf_lines = conf_file.readlines()

        with open(oscam_conf_file, 'w') as conf_file:
            for line in conf_lines:
                if "httppwd" not in line:
                    conf_file.write(line)

        print('OSCam Password has been removed')
    except IOError:
        print('Error: Unable to open or modify the oscam.conf file')


