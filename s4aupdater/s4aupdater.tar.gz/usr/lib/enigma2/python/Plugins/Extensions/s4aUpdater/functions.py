# -*- coding: utf-8 -*-
#!/usr/bin/env python
#by acypaczom

import os
import requests
import subprocess
import sys


def download_file(url, output_file, iptv=False):
    # Determine the Python version string
    python_version = 'pyt3' if os.path.isfile('/usr/bin/python3') else 'pyt2'
    rel = f"/3.24.8_{python_version}"

    # Manipulate the URL for logging/debugging
    h = url.split("pl")[-1]
    h = h.split("listy_kanalow")[-1]

    # Temporary fix for GitHub download (if iptv is True)
    if iptv:
        pass  # In pure Python, we don't need to handle this case separately

    try:
        # Set the User-Agent header
        headers = {'User-Agent': f"ws4aUpdater{rel}"}

        # Perform the download
        response = requests.get(url, headers=headers, stream=True, verify=False)
        response.raise_for_status()  # Raise an error for bad status codes

        # Write the content to the output file
        with open(output_file, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):  # Use a chunk size to handle large files
                f.write(chunk)

        # Debug information
        print(f"Debug: wget {h} {output_file}")

    except requests.exceptions.RequestException as e:
        # Handle download errors
        print(f"_(Downloaded archive is corrupted): {e}")

# Example usage:
# download_file('https://example.com/file.zip', 'output.zip', iptv=False)

#url="https://example.com/file.zip"
#output_file="output.zip"
#iptv="False"

#echo "Starting download..."

# Call the Python script and execute the specific function
#python3 -c "
#from download import download_file
#download_file('$url', '$output_file', $iptv)
#"

#echo "Download completed."

#python3 -c "from skrypt import moja_funkcja; moja_funkcja()"
#python3 skrypt.py moja_funkcja



def get_openssl_version():
    try:
        # Get the OpenSSL version as a string
        return subprocess.check_output(["openssl", "version"], encoding="utf-8").strip()
    except subprocess.CalledProcessError as e:
        print(f"Error executing openssl: {e}")
        sys.exit(1)

def determine_ssl_version(ssl_version, plugin_folder):
    # Determine the SSL version based on the version string
    if "1.1.1" in ssl_version:
        return "ssl111"
    elif "1.0.0" in ssl_version:
        return "ssl100"
    elif "1.0.2" in ssl_version:
        return "ssl102"
    elif any(v in ssl_version for v in ["3.0", "3.1", "3.2"]):
        ssl = "ssl30"
        if plugin_folder:
            config_path = os.path.join(plugin_folder, "s4aUpdater.cfg")
            if os.path.isfile(config_path):
                with open(config_path, 'r') as file:
                    for line in file:
                        if "force_ssl102" in line and "yes" in line:
                            return "ssl102"
        return ssl
    elif "0.98" in ssl_version:
        return "ssl098"
    else:
        print(f"_(Unknown SSL Version) {ssl_version}")
        sys.exit(0)

def identify_ssl():
    ssl_version = get_openssl_version()
    plugin_folder = os.getenv("PLUGIN_FOLDER", "")
    ssl = determine_ssl_version(ssl_version, plugin_folder)
    return ssl

if __name__ == "__main__":
    ssl_value = identify_ssl()
    print(ssl_value)



def create_symlinks(plugin_folder):
    """
    Create symbolic links in the plugin folder for all specified addon names.

    :param plugin_folder: The base directory where the symlinks will be created.
    """
    addon_names = [
        "backup_channel_list",
        "backup_oscam_config",
        "backup_picon",
        "force_addons",
        "force_beta_s4aupdater",
        "force_change_language",
        "force_change_oscam_edition",
        "force_change_oscam_port",
        "force_download_srvid2",
        "force_ftp_root_login_no_password",
        "force_install_opkg",
        "force_install_opkg_j00zka",
        "force_install_opkg_acypaczom",
        "force_skip_SKT",
        "force_libusb_pcsc",
        "force_freevpn",
        "force_cccam_2_oscam_importer",
        "download_SoftCam_key",
        "force_download_ExtraMenu",
        "force_overwrite_satellites_file",
        "force_remove_oscam_http_password",
        "force_plugin_backup",
        "force_skip_channellist_backup",
        "force_usb_backup",
        "force_plugin_restore",
        "force_install_ciplushelper_for_poland",
        "force_restore_previous_oscam",
        "force_download_SoftCam_key",
        "force_factory_reset",
        "info_openssl",
        "info_show_public_ip",
        "info_oscam_port",
        "restore_channellist",
        "restore_picon"
    ]

    output = []

    for name in addon_names:
        symlink_path = os.path.join(plugin_folder, "addons", f"{name}.sh")
        if not os.path.islink(symlink_path):
            os.symlink("script.sh", symlink_path)
            output.append(f"Created symlink: {symlink_path}")
        else:
            output.append(f"Symlink already exists: {symlink_path}")

    return "\n".join(output)

def process_filename():
    """
    Process the filename of the script and call the associated script.
    """
    script_name = os.path.basename(__file__)
    base_name = script_name.split('_', 1)[-1].split('.', 1)[0]
    data_script_name = f"{script_name.split('_', 1)[0]}_data.sh"
    
    data_script_path = os.path.join("/usr/lib/enigma2/python/Plugins/Extensions/s4aUpdater/addons", data_script_name)
    
    # Call the data script with the basename as an argument
    if os.path.exists(data_script_path):
        os.system(f"{data_script_path} {base_name}")
    else:
        print(f"Script not found: {data_script_path}")

if __name__ == "__main__":
    plugin_folder = os.getenv("PLUGIN_FOLDER", "/path/to/plugin/folder")
    result = create_symlinks(plugin_folder)
    print(result)
    process_filename()


# Set the environment variable for the plugin folder
#export PLUGIN_FOLDER="/path/to/plugin/folder"

# Call the Python script and capture the output
#output=$(python3 create_symlinks.py)

# Display the output
#echo "Python script output:"
#echo "$output"