﻿# -*- coding: utf-8 -*-
####################################################
# Developed and maintained by magsat.
# This is an open-source plugin that may be modified for personal use.
# Redistribution of modified versions is not permitted.
# Only skin modifications may be shared.
# If you would like to donate, please visit www.mawaqit.net.
####################################################

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.config import config, ConfigSubsection, ConfigText, getConfigListEntry, ConfigSelection, ConfigYesNo, configfile
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Components.Sources.StaticText import StaticText
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap, MovingPixmap
from Tools.LoadPixmap import LoadPixmap
from Components.AVSwitch import AVSwitch
from Tools.Directories import resolveFilename, SCOPE_SKIN_IMAGE, SCOPE_PLUGINS, fileExists
from Components.ScrollLabel import ScrollLabel
from datetime import datetime, timedelta
from enigma import ePoint, eSize, eTimer, ePicLoad, getDesktop, addFont
from Components.Sources.List import List
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.Language import language
from Components.Input import Input
from skin import loadSkin
from threading import Thread
from .tools import movePrayerMarker, format_time_str, get_prayer_offsets_and_map, get_translated_date, MyTextInput, safe_label_text
from . import tools as state
from . import _
import os
import json
import time
import subprocess
import shutil
import unicodedata
import re
import calendar
import sys

global_prayer_timer = None

def autostart(reason, **kwargs):
    if reason == 0:
        session = kwargs.get("session")
        if session is not None:
            startGlobalPrayerTimer(session)
            from .tools import startPrayerOverlay
            startPrayerOverlay(session)

config.plugins.mawaqit = ConfigSubsection()
config.plugins.mawaqit.mosque_city = ConfigText(default="")
config.plugins.mawaqit.mosque_uuid = ConfigText(default="")
config.plugins.mawaqit.mosque_slug = ConfigText(default="")
config.plugins.mawaqit.storageLocation = ConfigSelection(default="/etc/enigma2/Mawaqit", choices=[("/etc/enigma2/Mawaqit", "/etc/enigma2/Mawaqit"), ("/media/hdd/Mawaqit", "/media/hdd/Mawaqit"), ("/media/usb/Mawaqit", "/media/usb/Mawaqit")])
config.plugins.mawaqit.downloadImages = ConfigYesNo(default=True)
config.plugins.mawaqit.warn_before = ConfigSelection(default="10", choices=[("off", _("Off")), ("10", _("10 Minutes")), ("20", "20 " + _("Minutes")), ("30", "30 " + _("Minutes"))])
config.plugins.mawaqit.showExactPopup = ConfigYesNo(default=True)
config.plugins.mawaqit.popupDuration = ConfigSelection(default="10s", choices=[("5s", _("5 Seconds")), ("10s", _("10 Seconds")), ("20s", "20 " + _("Seconds")), ("30s", "30 " + _("Seconds"))])
config.plugins.mawaqit.playSound = ConfigYesNo(default=True)
config.plugins.mawaqit.time_format = ConfigSelection(default="24h", choices=[("24h", "24 " + _("Hours")), ("12h", "12 " + _("Hours") + " (AM/PM)")])
config.plugins.mawaqit.imsakMode = ConfigSelection(default="only_offset", choices=[("off", _("Off")), ("only_offset", _("Only Deviation")), ("always", _("Always show"))])
config.plugins.mawaqit.hijriAdjust = ConfigSelection(default="0", choices=[("-3", "-3"), ("-2", "-2"), ("-1", "-1"), ("0", "0"), ("+1", "+1"), ("+2", "+2"), ("+3", "+3")])

try:
    import urllib2
except ImportError:
    import urllib.request as urllib2
try:
    from urllib import quote
except ImportError:
    from urllib.parse import quote

skin_base = "fhd" if getDesktop(0).size().width() > 1280 else "hd"
skins_root = "/usr/lib/enigma2/python/Plugins/Extensions/Mawaqit/skins/%s" % skin_base
if os.path.isdir(skins_root):
    available_skins = [d for d in os.listdir(skins_root)
        if os.path.isdir(os.path.join(skins_root, d)) and os.path.exists(os.path.join(skins_root, d, "main.xml"))] or ["MawVer"]
else:
    available_skins = ["MawVer"]
if not hasattr(config.plugins.mawaqit, 'skin'):
    config.plugins.mawaqit.skin = ConfigSelection(default="MawVer", choices=available_skins)

def is_valid_skin(path):
    try:
        if not os.path.exists(path):
            return False
        if os.path.getsize(path) == 0:
            return False
        with open(path, "r") as f:
            content = f.read().strip()
            if not content or "<screen" not in content:
                return False
        return True
    except:
        return False

def get_skin_path(screen_name):
    base = config.plugins.mawaqit.skin.value
    path = os.path.join(skins_root, base, "%s.xml" % screen_name)
    if not is_valid_skin(path):
        path = os.path.join(skins_root, "MawVer", "%s.xml" % screen_name)
    return path

def load_triggered_indices():
    try:
        with open("/tmp/PrayerTrig.json", "r") as f:
            data = json.load(f)
            return [data.get("last10", -1)], [data.get("lastNow", -1)]
    except:
        return [-1], [-1]

def getStorageFile(name):
    return os.path.join(config.plugins.mawaqit.storageLocation.value, name)

def loadUserData():
    UserDataFile = getStorageFile("userdata.json")
    if not os.path.exists(UserDataFile):
        return {"selected": {}, "history": []}
    try:
        import sys
        if sys.version_info[0] < 3:
            with open(UserDataFile, "r") as f:
                content = f.read()
                if not content.strip():
                    return {"selected": {}, "history": []}
                return json.loads(content.decode("utf-8") if isinstance(content, bytes) else content)
        else:
            with open(UserDataFile, "r", encoding="utf-8") as f:
                content = f.read()
                if not content.strip():
                    return {"selected": {}, "history": []}
                return json.loads(content)
    except Exception:
        return {"selected": {}, "history": []}

def saveUserData(data):
    path = getStorageFile("userdata.json")
    folder = os.path.dirname(path)
    try:
        if not os.path.exists(folder):
            os.makedirs(folder)
        import sys
        if sys.version_info[0] < 3:
            f = open(path, "w")
            content = json.dumps(data, indent=2, ensure_ascii=False)
            f.write(content.encode("utf-8"))
        else:
            f = open(path, "w", encoding="utf-8")
            json.dump(data, f, indent=2, ensure_ascii=False)
        f.close()
    except Exception:
        pass

def loadHistoryList():
    data = loadUserData()
    return data.get("history", [])

def storeSelectedMosque(label, uuid, localisation, slug, phone, email):
    data = loadUserData()
    data["selected"] = {"label": label, "uuid": uuid, "localisation": localisation, "slug": slug, "phone": phone, "email": email}
    history = data.get("history", [])
    history = [h for h in history if h.get("uuid") != uuid and h.get("label")]
    history.insert(0, {"label": label, "uuid": uuid, "localisation": localisation, "slug": slug, "phone": phone, "email": email})
    data["history"] = history[:50]
    saveUserData(data)

def startGlobalPrayerTimer(session):
    from .tools import showPrayerPopup
    global global_prayer_timer
    state.last_triggered_idx_warn[:], state.last_triggered_idx_now[:] = load_triggered_indices()
    def checkPrayer():
        try:
            now = datetime.now()
            path = getStorageFile("data.json")
            if not os.path.exists(path):
                return
            with open(path, "r") as f:
                data = json.load(f)
            calendar = data.get("calendar", [])
            iqama = data.get("iqama", [])
            label = _(data.get("label", "Unknown Mosque"))
            if not calendar:
                return
            month = now.month
            day = now.day
            if len(calendar) < month:
                return
            today_times = calendar[month - 1].get(str(day), [])
            iqama_times = iqama[month - 1].get(str(day), []) if len(iqama) >= month else ["-"] * 5
            if not today_times or len(today_times) < 6:
                return
            from .tools import time_until_next_prayer
            diff = time_until_next_prayer(today_times, return_seconds=True)
            idx = time_until_next_prayer(today_times, return_index=True)
            from .tools import handlePrayerTrigger
            handlePrayerTrigger(idx, diff, today_times, iqama_times, label)
        except Exception:
            pass
    global_prayer_timer = eTimer()
    global_prayer_timer.timeout.get().append(checkPrayer)
    global_prayer_timer.start(2000, False)

def is_leap_year(year):
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

def saveMosqueData(slug, localisation, phone, email):
    try:
        url = "https://mawaqit.net/fr/%s" % slug
        req = urllib2.Request(url)
        req.add_header("User-Agent", "Mozilla/5.0")
        import ssl
        context = ssl._create_unverified_context()
        response = urllib2.urlopen(req, timeout=10, context=context)
        html = response.read()
        if hasattr(html, "decode"):
            html = html.decode("utf-8")
        match = re.search(r'(?:var|let)\s+confData\s*=\s*(\{.*?\});', html, re.DOTALL)
        if not match:
            print("confData not found")
            return
        data = json.loads(match.group(1))
        mosque_info = {
            "uuid": data.get("uuid"),
            "label": data.get("label", ""),
            "localisation": localisation,
            "phone": phone,
            "email": email,
            "site": data.get("site", ""),
            "jumua": data.get("jumua", "-"),
            "calendar": data.get("calendar", []),
            "iqama": data.get("iqamaCalendar", []),
            "aidPrayerTime": data.get("aidPrayerTime", ""),
            "otherInfo": data.get("otherInfo", ""),
            "announcements": data.get("announcements", []),
            "womenSpace": data.get("womenSpace", False),
            "janazaPrayer": data.get("janazaPrayer", False),
            "aidPrayer": data.get("aidPrayer", False),
            "childrenCourses": data.get("childrenCourses", False),
            "adultCourses": data.get("adultCourses", False),
            "ramadanMeal": data.get("ramadanMeal", False),
            "handicapAccessibility": data.get("handicapAccessibility", False),
            "ablutions": data.get("ablutions", False),
            "parking": data.get("parking", False),
            "imsakNbMinBeforeFajr": data.get("imsakNbMinBeforeFajr", None),
            "association": data.get("association", ""),
            "jumuaAsDuhr": data.get("jumuaAsDuhr", False),
            "images": {
                "exterior": "exterior.jpg",
                "interior": "interior.jpg"}}
        StoragePath = config.plugins.mawaqit.storageLocation.value
        if not os.path.exists(StoragePath):
            os.makedirs(StoragePath)
        with open(os.path.join(StoragePath, "data.json"), "w") as f:
            txt = json.dumps(mosque_info, indent=2, separators=(',', ': '))
            txt = re.sub(r'\[\s+([^\[\]]*?)\s+\]',
                lambda m: '[' + re.sub(r'\s+', ' ', m.group(1)).strip() + ']', txt)
            f.write(txt)
        if config.plugins.mawaqit.downloadImages.value:
            downloadMosqueImage(data.get("exteriorPicture"), os.path.join(StoragePath, "interior.jpg"))
            downloadMosqueImage(data.get("interiorPicture"), os.path.join(StoragePath, "exterior.jpg"))
        else:
            try:
                for img in ["interior.jpg", "exterior.jpg"]:
                    path = os.path.join(StoragePath, img)
                    if os.path.exists(path):
                        os.remove(path)
            except Exception:
                pass
    except Exception:
        pass

def downloadMosqueImage(url, name):
    try:
        if not url or not name:
            return
        temp_dir = "/tmp/MawaqitConvert"
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)
        StoragePath = config.plugins.mawaqit.storageLocation.value
        final_path = os.path.join(StoragePath, name)
        tmp_dl = os.path.join(temp_dir, "temp_download.jpg")
        tmp_ff = os.path.join(temp_dir, "temp_converted.jpg")
        req = urllib2.Request(url)
        req.add_header("User-Agent", "Mozilla/5.0")
        import ssl
        context = ssl._create_unverified_context()
        img_data = urllib2.urlopen(req, context=context).read()
        if not img_data or len(img_data) < 1000:
            return
        with open(tmp_dl, "wb") as f:
            f.write(img_data)
        cmd = ["ffmpeg", "-y", "-i", tmp_dl, "-vf", "scale=iw:ih", "-pix_fmt", "rgb24", "-qscale:v", "5", tmp_ff]
        result = subprocess.call(cmd)
        if result != 0 or not os.path.exists(tmp_ff):
            return
        shutil.move(tmp_ff, final_path)
    except Exception:
        pass
    finally:
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)


class MosqueSearchScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.isHistoryView = True
        self.resultList = []
        self.mosque_list = []
        skin_path = get_skin_path("search")
        with open(skin_path, "r") as f:
            self.skin = f.read()
        self["searchInput"] = Input(text='')
        self.searchInputT9 = MyTextInput(nextFunc=self.updateMarker, lang="en_EN")
        for i in range(10):
            chars = "".join(self.searchInputT9.mapping[i])
            self["k%d" % i] = Label(chars)
        self.last_marked = -1
        self["delete"] = Label("< DEL >")
        self["cursor"] = Label("< CH >")
        self["info"] = Label("INFO")
        self.onLayoutFinish.append(self.updateMarker)
        self["key_red"] = StaticText(_("Back"))
        self["key_green"] = StaticText(_("OK"))
        self["key_yellow"] = StaticText(_("Keyboard"))
        self["key_blue_text"] = Label(_("Delete"))
        self["key_blue_visible"] = Pixmap()
        self["mosqueAddress"] = Label("")
        self["pageInfo"] = Label("")
        self["search"] = Label(_("Mosque Search"))
        self['land'] = StaticText('')
        self["mosqueLabel"] = Label("")
        try:
            with open(getStorageFile("data.json"), "r") as f:
                data = json.load(f)
            mosque_name = data.get("label", "")
        except Exception:
            mosque_name = ""
        self["mosqueLabel"].setText(safe_label_text(mosque_name))
        current_lang = language.getLanguage()
        self["land"].setText(safe_label_text(current_lang))
        self.switchLang(auto=True)
        self.searchInputT9.nextFunction = self.onInputChanged
        self.suggestions = MosqueSuggestionsInput(textinput=self.searchInputT9,
            update_callback=self.updateResults, append_callback=self.appendResults, parent=self)
        data = loadUserData()
        raw_history = data.get("history", [])
        self.searchHistory = [(str(entry.get("label", "")), str(entry.get("uuid", "")), entry.get("localisation", "-"), entry.get("slug", ""), entry.get("phone", ""), entry.get("email", "")) for entry in raw_history]
        self.resultList = self.searchHistory
        self["list"] = List(self.resultList)
        self["list"].onSelectionChanged.append(self.updateAddress)
        self["numActions"] = ActionMap(["MawaqitActions"], {
            str(i): (lambda i=i: self.searchInputT9.handleNumberKey(i)) for i in range(10)
        }, -2)
        self["searchActions"] = ActionMap(["MawaqitActions"], {
            "cancel": self.cancel,
            "ok": self.selectMosque,
            "red": self.cancel,
            "green": self.selectMosque,
            "yellow": self.virtualKeyboard,
            "info": self.switchLang,
            "showVirtualKeyboard": self.virtualKeyboard,
            "left": self.pageDown,
            "right": self.pageUp,
            "deleteBackward": self.searchInputT9.deleteBackward,
            "deleteForward": self.searchInputT9.deleteForward,
            "prevBouquet": self.searchInputT9.moveLeft,
            "nextBouquet": self.searchInputT9.moveRight,
            }, -2)
        self["blueActions"] = ActionMap(["ColorActions"], {
            "blue": self.deleteHistoryEntry
        }, -2)
        self.onLayoutFinish.append(self.updateAddress)
        self.onLayoutFinish.append(self.initMarkers)
        self.setDeleteVisible(len(self.resultList) > 0)

    def initMarkers(self):
        for i in range(10):
            self["k%d" % i].instance.setMarkedPos(-1)

    def switchLang(self, auto=False):
        langs = ['en_EN', 'ar_AE', 'de_DE', 'fr_FR', 'tr_TR', 'es_ES', 'pt_PT']
        if not hasattr(self, "_valid_langs"):
            tester = MyTextInput()
            base = []
            valid = []
            for lang in langs:
                tester.langMap(lang)
                mapping = tester.mapping[:]
                if mapping not in base:
                    valid.append(lang)
                    base.append(mapping)
            self._valid_langs = valid    
        if auto:
            current_lang = language.getLanguage()
            if current_lang in self._valid_langs:
                new_lang = current_lang
            else:
                new_lang = self._valid_langs[0]
        else:
            try:
                index = self._valid_langs.index(self.searchInputT9.lang)
            except ValueError:
                index = -1
            new_lang = self._valid_langs[(index + 1) % len(self._valid_langs)]    
        self.searchInputT9.lang = new_lang
        self.searchInputT9.langMap(new_lang)
        u_chars = "".join("".join(x) for x in self.searchInputT9.mapping)
        if hasattr(self.searchInputT9, "setUseableChars"):
            self.searchInputT9.setUseableChars(u_chars)
        for i in range(10):
            keyName = "k%d" % i
            if self.get(keyName, None) is not None:
                chars = "".join(self.searchInputT9.mapping[i])
                self[keyName].setText(safe_label_text(chars))
        self["land"].setText(safe_label_text(new_lang.split("_")[0].upper()))

    def updateMarker(self):
        textinput = self.searchInputT9
        key = textinput.lastKey
        pos = textinput.pos
        if hasattr(self, "last_marked") and 0 <= self.last_marked <= 9:
            self["k%d" % self.last_marked].instance.setMarkedPos(-1)
            self.last_marked = -1    
        if 0 <= key <= 9 and 0 <= pos < len(textinput.mapping[key]):
            chars_len = len(textinput.mapping[key])
            lang = textinput.lang.lower()
            if lang.startswith("ar") and key >= 2:
                marked_pos = chars_len - 1 - pos
            else:
                marked_pos = pos   
            self["k%d" % key].instance.setMarkedPos(marked_pos)
            self.last_marked = key

    def onInputChanged(self):
        self["searchInput"].setText(safe_label_text(self.searchInputT9.Text))
        try:
            self["searchInput"].currPos = self.searchInputT9.getGuiCursorPos()
            self["searchInput"].update()
        except Exception:
            pass
        self.updateMarker()
        self.suggestions.getSuggestionsFromText(self.searchInputT9.Text)

    def virtualKeyboard(self):
        self.session.openWithCallback(self.keyBoardCallback, VirtualKeyBoard, title=_("Mosque Search"), text=self["searchInput"].getText())

    def keyBoardCallback(self, result):
        if result is not None:
            self.searchInputT9.Text = result
            self.searchInputT9.currPos = len(result)
            self.onInputChanged()

    def cancel(self):
        self.close(False)

    def pageUp(self):
        try:
            self["list"].pageUp()
            self.updateAddress()
        except:
            pass

    def pageDown(self):
        try:
            self["list"].pageDown()
            self.updateAddress()
        except:
            pass

    def setDeleteVisible(self, visible):
        if visible:
            self["blueActions"].setEnabled(True)
            self["key_blue_visible"].show()
            self["key_blue_text"].show()
        else:
            self["blueActions"].setEnabled(False)
            self["key_blue_visible"].hide()
            self["key_blue_text"].hide()

    def updateResults(self, results):
        self.isHistoryView = False
        self.mosque_list = results
        self.resultList = [(safe_label_text(m.get("label", "")), m.get("uuid", ""), m.get("localisation", "-")) for m in results]
        self["list"].setList(self.resultList)
        if self.resultList:
            self["list"].index = 0
            self.updateAddress()
        self.setDeleteVisible(False)
            
    def appendResults(self, more_results):
        try:
            if not more_results:
                return    
            start_len = len(self.resultList)
            for m in more_results:
                label = safe_label_text(m.get("label", _("Unnamed")))
                addr = safe_label_text(m.get("localisation", "-"))
                self.resultList.append((label, addr))
                self.mosque_list.append(m)    
            cur = self["list"].index
            self["list"].setList(self.resultList)
            if 0 <= cur < len(self.resultList):
                self["list"].index = cur
            self.setDeleteVisible(False)
        except Exception:
            pass
     
    def updateAddress(self):
        try:
            index = self["list"].index
            entry = self["list"].getCurrent()
            if not entry:
                self["mosqueAddress"].setText("")
                return    
            label = safe_label_text(entry[0])
            uuid = entry[1] if len(entry) > 1 else ""
            addr = "-"
            for mosque in self.mosque_list:
                if safe_label_text(mosque.get("label", "")) == label:
                    addr = safe_label_text(mosque.get("localisation", "-"))
                    break    
            if addr == "-" and uuid:
                try:
                    data = loadUserData()
                    for h in data.get("history", []):
                        if h.get("uuid") == uuid:
                            addr = h.get("localisation", _("(from History)"))
                            break
                except Exception:
                    pass
                    addr = h.get("localisation") or _("(from History)")    
            if addr and addr != "-":
                self["mosqueAddress"].setText(_("Address:") + " " + safe_label_text(addr))
            else:
                self["mosqueAddress"].setText("")   
            per_page = 10
            page_number = (index // per_page) + 1
            self["pageInfo"].setText(_("Page %d") % page_number)
            if (hasattr(self, "suggestions")
                and getattr(self.suggestions, "next_page", None)
                and not getattr(self.suggestions, "running", False)):
                at_first_item = (index % per_page == 0 and index != 0)
                at_last_item = (index == len(self.resultList) - 1)
                if at_first_item or at_last_item:
                    self.suggestions.request_next_page()    
        except Exception:
            pass
            self["mosqueAddress"].setText("")

    def selectMosque(self):
        try:
            selected = self["list"].getCurrent()
            if not selected:
                return
            label = safe_label_text(selected[0])
            uuid = selected[1] if len(selected) > 1 else ""
            if self.searchInputT9.Text != label:
                self.searchInputT9.Text = label
                self["searchInput"].setText(safe_label_text(label))
                self.searchInputT9.currPos = len(label)
                self.onInputChanged()
            matched = next(
                (m for m in self.mosque_list
                 if safe_label_text(m.get("label", "")) == label),
                None
            )
            if not matched and uuid:
                history = loadUserData().get("history", [])
                history_match = next((h for h in history if h.get("uuid") == uuid), None)
                if history_match:
                    matched = history_match
            if matched:
                city = safe_label_text(
                    matched.get("label") or label or _("Unnamed")
                )
                uuid = matched.get("uuid", "")
                localisation = matched.get("localisation", "-")
                slug = matched.get("slug", "")
                phone = matched.get("phone", "")
                email = matched.get("email", "")
                if localisation in ("-", _("(Address from History)"), "", None):
                    history = loadHistoryList()
                    for h in history:
                        if h.get("uuid") == uuid:
                            localisation = h.get("localisation", _("Unknown"))
                            break
                self.saveSelectedMosque(city, uuid, localisation, slug, phone, email)
                return
            self.close(False)
        except Exception:
            self.close(False)

    def saveSelectedMosque(self, label, uuid, localisation, slug, phone, email):
        if not self.isOnline():
            self.session.open(
                MessageBox,
                _("No Internet Connection"),
                MessageBox.TYPE_ERROR,
                timeout=5
            )
            return
        storeSelectedMosque(label, uuid, localisation, slug, phone, email)
        config.plugins.mawaqit.mosque_city.value = label
        config.plugins.mawaqit.mosque_city.save()
        config.plugins.mawaqit.mosque_uuid.value = uuid
        config.plugins.mawaqit.mosque_uuid.save()
        config.plugins.mawaqit.mosque_slug.value = slug
        config.plugins.mawaqit.mosque_slug.save()
        saveMosqueData(slug, localisation, phone, email)
        try:
            from .tools import generate_hijri_calendar
            storage_path = config.plugins.mawaqit.storageLocation.value
            generate_hijri_calendar(storage_path)
            if os.path.exists("/tmp/PrayerTrig.json"):
                os.remove("/tmp/PrayerTrig.json")
            state.last_triggered_idx_now[0] = -1
            state.last_triggered_idx_warn[0] = -1
        except:
            pass
        self.close(True)

    def isOnline(self):
        try:
            import socket
            socket.setdefaulttimeout(2)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
            return True
        except:
            return False

    def deleteHistoryEntry(self):
        try:
            index = self["list"].index
            if index < 0 or index >= len(self.resultList):
                return    
            entry = self.resultList[index]
            label = safe_label_text(entry[0])
            uuid = entry[1]
            if not label or not uuid:
                return
    
            def confirm(result):
                if result:
                    try:
                        data = loadUserData()
                        history = data.get("history", [])
                        history = [h for h in history if h.get("uuid") != uuid]
                        data["history"] = history
                        saveUserData(data)
                        self.resultList = [(str(h.get("label", "")), str(h.get("uuid", ""))) for h in history]
                        self["list"].setList(self.resultList)
                        self.updateAddress()

                        self.setDeleteVisible(len(self.resultList) > 0)
                    except Exception:
                        pass    
            msg = _("Do you really want to delete \"%s\" from the History?") % label
            self.session.openWithCallback(confirm, MessageBox, msg, MessageBox.TYPE_YESNO)
        except Exception:
            pass


class MosqueSuggestionsInput(object):
    def __init__(self, textinput, update_callback, append_callback, parent=None):
        self.textinput = textinput
        self.update_callback = update_callback
        self.append_callback = append_callback
        self.parent = parent
        self.running = False
        self.last_sent = None
        self.next_page = None

    def getSuggestionsFromText(self, text):
        if not text.strip():
            self.update_callback([])
            self.next_page = None
            self.last_sent = None
            return
        if self.running:
            return
        if text == self.last_sent:
            return
        self.running = True
        Thread(target=self._fetchSuggestions, args=(text, 1)).start()

    def request_next_page(self):
        if getattr(self, "next_page", None) is None:
            return
        if getattr(self, "running", False):
            return
        page_to_load = self.next_page
        self.running = True
        Thread(target=self._fetchSuggestions, args=(self.last_sent, page_to_load)).start()

    def _fetchSuggestions(self, query, page=1):
        PY2 = sys.version_info[0] == 2
        q = query if query is not None else (self.textinput.Text or "")
        if PY2:
            if not isinstance(q, unicode):
                try:
                    q = unicode(q, "utf-8")
                except Exception:
                    q = unicode(q)
            safe_query = quote(q.encode("utf-8"))
        else:
            safe_query = quote(q)
        self.last_sent = q
        try:
            url = "https://mawaqit.net/api/2.0/mosque/search?word=%s&perPage=10&page=%d" % (safe_query, page)
            req = urllib2.Request(url)
            req.add_header("User-Agent", "Mozilla/5.0")
            response = urllib2.urlopen(req, timeout=5)
            try:
                raw = response.read()
                if hasattr(raw, "decode"):
                    raw = raw.decode("utf-8")
                data = json.loads(raw)
            finally:
                try:
                    response.close()
                except Exception:
                    pass
            results = data or []
            if q == self.last_sent:
                if page == 1 and self.update_callback:
                    self.update_callback(results)
                elif page > 1 and self.append_callback:
                    self.append_callback(results)
            self.next_page = page + 1 if data else None
            if page == 1 and data and self.append_callback and self.next_page == 2:
                Thread(target=self._fetchSuggestions, args=(q, 2)).start()
        except Exception:
            if page == 1 and self.update_callback:
                try:
                    self.update_callback([])
                except Exception:
                    pass
        finally:
            self.running = False


class PrayerSettingsScreen(Screen, ConfigListScreen):
    def __init__(self, session, main_screen=None):
        Screen.__init__(self, session)
        self.main_screen = main_screen
        skin_path = get_skin_path("setup")
        with open(skin_path, "r") as f:
            self.skin = f.read()
        self.session = session
        self.list = []
        self.onChangedEntry = []
        self["description"] = Label("")
        self["setup"] = Label(_("Prayer Time Settings"))
        ConfigListScreen.__init__(self, self.list, session=session)
        self["config"].onSelectionChanged.append(self.updateDescription)
        self["key_green"] = Label(_("Save"))
        self["key_red"] = Label(_("Cancel"))
        self["SettingsActions"] = ActionMap(["MawaqitActions"], {
            "ok": self.save,
            "green": self.save,
            "cancel": self.cancel,
            "red": self.cancel,
        }, -2)
        self._original_skin = config.plugins.mawaqit.skin.value
        self.createConfigList()
        self.updateDescription()

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Select Skin"), config.plugins.mawaqit.skin))
        self.list.append(getConfigListEntry(_("Storage Path"), config.plugins.mawaqit.storageLocation))
        self.list.append(getConfigListEntry(_("Download Mosque Images"), config.plugins.mawaqit.downloadImages))
        self.list.append(getConfigListEntry(_("Before Adhan Widget"), config.plugins.mawaqit.warn_before))
        self.list.append(getConfigListEntry(_("It's Time to Pray Widget"), config.plugins.mawaqit.showExactPopup))
        self.list.append(getConfigListEntry(_("Widget duration"), config.plugins.mawaqit.popupDuration))
        self.list.append(getConfigListEntry(_("Play Beep Sound for Adhan"), config.plugins.mawaqit.playSound))
        self.list.append(getConfigListEntry(_("Time Format"), config.plugins.mawaqit.time_format))
        self.list.append(getConfigListEntry(_("Imsak Mode"), config.plugins.mawaqit.imsakMode))
        self.list.append(getConfigListEntry(_("Hijri adjustment"), config.plugins.mawaqit.hijriAdjust))
        self["config"].list = self.list
        self["config"].setList(self.list)
        self.descriptions = {
            config.plugins.mawaqit.skin: _('Select the Skin Design for the Plugin "Restart Plugin Required"'),
            config.plugins.mawaqit.storageLocation: _("Data and Images Storage Path"),
            config.plugins.mawaqit.downloadImages: _("Download Pictures of the selected Mosque"),
            config.plugins.mawaqit.warn_before: _("Off or Show Widget 10, 20 or 30 Minutes before Prayer Time"),
            config.plugins.mawaqit.showExactPopup: _('Show Widget for "Time to Pray"'),
            config.plugins.mawaqit.popupDuration: _("How long the Widget is displayed"),
            config.plugins.mawaqit.playSound: _("Play Beep Sound at Prayer Time"),
            config.plugins.mawaqit.time_format: _('Time Display Format "12h or 24h"'),
            config.plugins.mawaqit.imsakMode: _("Off or Show only Imsak with Deviations or Show it with Mosques that calculate Imsak like Fajr"),
            config.plugins.mawaqit.hijriAdjust: _("Manually Adjust the Hijri Date by adding or subtracting Days")}

    def updateDescription(self):
        current = self["config"].getCurrent()
        if current:
            cfg = current[1]
            desc = self.descriptions.get(cfg, "")
            self["description"].setText(safe_label_text(desc))

    def isChanged(self):
        for entry in self["config"].list:
            if entry[1].isChanged():
                return True
        return False

    def save(self):
        old_skin = getattr(self, "_original_skin", config.plugins.mawaqit.skin.value)
        for entry in self["config"].list:
            entry[1].save()
        config.plugins.mawaqit.save()
        configfile.save()
        new_skin = config.plugins.mawaqit.skin.value
        if old_skin != new_skin:
            def _after_msgbox(_):
                try:
                    if hasattr(self, "main_screen") and self.main_screen:
                        self.main_screen.close()
                except Exception:
                    pass 
                self.close(True)
            self.session.openWithCallback(_after_msgbox, MessageBox, _("The Skin has been changed. The Plugin will be closed.\nPlease restart the Plugin."), MessageBox.TYPE_INFO, timeout=5)
        else:
            self.close(True)

    def cancel(self):
        if self.isChanged():
            self.session.openWithCallback(self._cancelConfirm, MessageBox, _("Do you want to discard the Changes?"), MessageBox.TYPE_YESNO)
        else:
            self.close(False)

    def _cancelConfirm(self, confirmed):
        if confirmed:
            for entry in self["config"].list:
                entry[1].cancel()
            self.close(False)


class MawaqitMainScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/Mawaqit/fonts/nmsbd.ttf", "nmsbold", 100, 1)
        skin_path = get_skin_path("main")
        with open(skin_path, "r") as f:
            self.skin = f.read()
        from .tools import ensure_hijri_calendar
        ensure_hijri_calendar()   
        self.loadPrayerData()
        self.last_marker_index = -1
        self.iqamaCountdownIdx = -1
        self["info"] = Label("")
        self["info"].hide()
        self["nextPrayer"] = Label("")
        self["shuruqLabelTitle"] = Label(_("Shuruq"))
        self["shuruqLabelTime"] = Label("")
        self["jumuaLabelTitle"] = Label(_("Jumu'a"))
        self["jumuaLabelTime"] = Label("")
        self["mosqueLabel"] = Label("")
        self["hijriLabel"] = Label("")
        self["date"] = Label("")
        self["imsakLabelTitle"] = Label(_("Imsak"))
        self["imsakLabelTitle"].hide()
        self["imsakLabelTime"] = Label("")
        for prayer in ["Fajr", "Duhr", "Asr", "Maghrib", "Isha"]:
            self["prayer_" + prayer] = Label("")
        for adhan in ["Fajr", "Duhr", "Asr", "Maghrib", "Isha"]:
            self["adhan_" + adhan] = Label("")
        for iqama in ["Fajr", "Duhr", "Asr", "Maghrib", "Isha"]:
            self["iqama_" + iqama] = Label("")
        self["key_red"] = Label(_("Exit"))
        self["key_green"] = Label(_("Settings"))
        self["key_yellow"] = Label(_("Search"))
        self["key_blue"] = Label(_("Calendar"))
        self["key_info"] = Label(_("Info"))
        self["prayerMarker"] = Pixmap()
        self["prayerMarker"].hide()
        self["IqamaCountdown"] = Label("")
        self["IqamaCountdown"].hide()
        self["IqamaMarker"] = Pixmap()
        self["IqamaMarker"].hide()
        self.blinkTimer = eTimer()
        self._blink_cb_added = False
        self.blinkState = True
        self.current_blink_index = None
        self.selected_times = []
        self.time_indices = []
        self["clockLabel"] = Label("")
        self.iqamaTimer = eTimer()
        self.iqamaCountdownTime = 0
        self.iqamaTimer.callback.append(self.updateIqamaCountdown)
        self.already_switched_day = False
        self.fetchMawaqit()
        self.timer = eTimer()
        self.timer.callback.append(self.updateClock)
        self.onLayoutFinish.append(self.updateClock)
        self.onLayoutFinish.append(self._onLayoutDone)
        self.timer.start(2000)
        state.mainScreen = self
        self.onClose.append(self.stopTimers)
        self["MainActions"] = ActionMap(["MawaqitActions"], {
            "cancel": self.close,
            "info": self.openMosqueInfo,
            "red": self.close,
            "green": self.openSettings,
            "yellow": self.openMosqueSearch,
            "blue": self.openCalendar,
        }, -2)

    def _onLayoutDone(self):
        self.restoreIqamaCountdownSafe()
        self.refreshNextPrayer()

    def stopTimers(self):
        try:
            if self.timer and self.timer.isActive():
                self.timer.stop()
        except Exception:
            pass

    def updateClock(self):
        now_str = datetime.now().strftime("%H:%M")
        self["clockLabel"].setText(safe_label_text(format_time_str(now_str)))
        self["date"].setText(safe_label_text(get_translated_date()))
        from .tools import getHijriDateFromCalendar
        hijri_adjust = int(config.plugins.mawaqit.hijriAdjust.value)
        hijri_date = getHijriDateFromCalendar(hijri_adjust)
        self["hijriLabel"].setText(safe_label_text(hijri_date))

    def restoreIqamaCountdownSafe(self, retry=0):
        try:
            if not self["IqamaCountdown"].instance:
                if retry < 5:
                    self.restoreTimer = eTimer()
                    self.restoreTimer.callback.append(lambda: self.restoreIqamaCountdownSafe(retry+1))
                    self.restoreTimer.start(300, True)
                    return
                else:
                    return
            from .tools import tryRestoreIqamaCountdown
            tryRestoreIqamaCountdown(self)
        except Exception:
            pass
    
    def loadPrayerData(self):
        now = datetime.now()
        month = now.month
        day = str(now.day)
        try:
            with open(getStorageFile("data.json")) as f:
                data = json.load(f)
                calendar = data.get("calendar", [])
                iqama = data.get("iqama", [])
                raw_today_times = calendar[month - 1].get(day, [])
                raw_iqama_times = iqama[month - 1].get(day, [])
                self.today_times = [format_time_str(t) for t in raw_today_times]
                self.iqama_times = [format_time_str(t) for t in raw_iqama_times]   
        except Exception:
            self.today_times = []
            self.iqama_times = []

    def startBlinking(self, idx=None):
        try:
            from .tools import get_prayer_indices    
            lang = language.getLanguage()[:2].lower()
            axis = getattr(self, "axis", "y")
            if idx is not None:
                base_indices = get_prayer_indices(self.today_times)
                base_map = {api_idx: pos for pos, api_idx in enumerate(base_indices)}   
                self.current_blink_index = base_map.get(idx, 0)    
                self.blinkState = True    
                if not getattr(self, "_blink_cb_added", False):
                    try:
                        self.blinkTimer.timeout.get().append(self.startBlinking)
                    except Exception:
                        self.blinkTimer.callback.append(self.startBlinking)
                    self._blink_cb_added = True    
                if self.blinkTimer.isActive():
                    self.blinkTimer.stop()
                self.startBlinking()
                return
            if not hasattr(self, "selected_times") or not self.selected_times:
                return  
            if self.current_blink_index is None:
                return
            widget_names = ["Fajr", "Duhr", "Asr", "Maghrib", "Isha"]
            if lang == "ar" and axis == "x":
                widget_names = list(reversed(widget_names)) 
            base_indices = get_prayer_indices(self.today_times)
            for i, name in enumerate(widget_names):
                key = "adhan_%s" % name
                if key not in self:
                    continue
                api_index_for_ui = base_indices[i]
                text = self.today_times[api_index_for_ui]
                if i == self.current_blink_index:
                    display = text if self.blinkState else "     "
                else:
                    display = text
                self[key].setText(safe_label_text(display))
            self.blinkState = not self.blinkState
            self.blinkTimer.start(500, True)
        except Exception:
            pass

    def stopBlinking(self):
        try:
            if self.blinkTimer and self.blinkTimer.isActive():
                self.blinkTimer.stop()
            self.blinkState = True
            self.current_blink_index = None    
            if hasattr(self, "selected_times") and self.selected_times:
                widget_names = ["Fajr", "Duhr", "Asr", "Maghrib", "Isha"]
                for i, name in enumerate(widget_names):
                    if "adhan_%s" % name in self and i < len(self.selected_times):
                        self["adhan_%s" % name].setText(safe_label_text(self.selected_times[i]))
        except Exception:
            pass

    def close(self):
        try:
            self.updateTimer.stop()
        except:
            pass
        Screen.close(self)

    def openSettings(self):
        self.session.openWithCallback(self.onSettingsClosed, PrayerSettingsScreen, self)

    def onSettingsClosed(self, result):
        if result:
            self.fetchMawaqit()

    def openMosqueSearch(self):
        self.session.openWithCallback(self.onMosqueSearchFinished, MosqueSearchScreen)

    def onMosqueSearchFinished(self, result):
        if result:
            if self.iqamaTimer.isActive():
                self.iqamaTimer.stop()
            self.last_marker_index = -1 
            self.iqamaCountdownIdx = -1
            self.iqamaCountdownTime = 0
            self.stopBlinking()
            self["IqamaCountdown"].setText("")
            self["IqamaCountdown"].hide()
            self["IqamaMarker"].hide()
            self.lastBlinkIdx = None
            self.fetchMawaqit()

    def fetchMawaqit(self, next_day=False):
        from .tools import get_prayer_indices
        if hasattr(self, "updateTimer"):
            self.updateTimer.stop()
            del self.updateTimer    
        self["nextPrayer"].setText("")
        self["prayerMarker"].hide()    
        today = datetime.today().date()
        if next_day:
            today += timedelta(days=1)    
        day = today.day
        month = today.month   
        calendar_path = getStorageFile("data.json")   
        if not os.path.exists(calendar_path):
            self["info"].setText(safe_label_text(
                _('No Prayer Times found.\nPlease load the Prayer Data via "Search Mosques".')))
            self["info"].show()
            self.today_times = []
            return    
        try:
            with open(calendar_path, "r") as f:
                data = json.load(f)  
            calendar = data.get("calendar", [])
            iqama = data.get("iqama", [])
            jumua = data.get("jumua", "-")
            mosque_name = data.get("label", "")
            imsak_offset = data.get("imsakNbMinBeforeFajr")   
            if not calendar or not isinstance(calendar, list) or len(calendar) < month:
                self["info"].setText(safe_label_text(_("The Calendar Data is invalid.")))
                self["info"].show()
                self.today_times = []
                return    
            month_data = calendar[month - 1]
            today_times = month_data.get(str(day), ["-"] * 6)    
            if not today_times or len(today_times) < 6:
                self["info"].setText(safe_label_text(_("No valid Times for Today.")))
                self["info"].show()
                self.today_times = []
                return   
            iqama_data = iqama[month - 1] if len(iqama) >= month else {}
            iqama_today = iqama_data.get(str(day), ["-"] * 5)
            self.today_times = today_times
            self.iqama_times = iqama_today
            skin_path = get_skin_path("main")
            try:
                offsets_list, prayer_index_map, offsets_dict, axis = \
                    get_prayer_offsets_and_map(skin_path, today_times)
                self.axis = axis or "y"
            except Exception:
                self.axis = "y"
            imsak_time = ""
            imsak_mode = config.plugins.mawaqit.imsakMode.value    
            if imsak_offset is not None:
                try:
                    fajr_dt = datetime.strptime(today_times[0], "%H:%M")
                    if imsak_mode == "always":
                        imsak_dt = fajr_dt - timedelta(
                            minutes=int(imsak_offset)) if int(imsak_offset) > 0 else fajr_dt
                    elif imsak_mode == "off":
                        imsak_dt = None
                    else:
                        imsak_dt = fajr_dt - timedelta(
                            minutes=int(imsak_offset)) if int(imsak_offset) > 0 else None
                    if imsak_dt:
                        self["imsakLabelTitle"].show()
                        imsak_time = format_time_str(imsak_dt.strftime("%H:%M"))
                    else:
                        self["imsakLabelTitle"].hide()
                except Exception:
                    self["imsakLabelTitle"].hide()
            else:
                self["imsakLabelTitle"].hide()    
            self["imsakLabelTime"].setText(
                safe_label_text(imsak_time) if imsak_time else "")
            shuruq = format_time_str(today_times[1])
            self["shuruqLabelTime"].setText(safe_label_text(shuruq))
            self["jumuaLabelTime"].setText(
                safe_label_text(format_time_str(jumua) if ":" in str(jumua) else "-"))
            self["mosqueLabel"].setText(safe_label_text(mosque_name))    
        except Exception:
            self["info"].setText(safe_label_text(
                _('No valid Data found.\nPlease Update Online via "Search Mosques".')))
            self["info"].show()
            self.today_times = []
            return
        self.renderPrayerWidgets()   
        self["prayerMarker"].show()
        self["info"].hide()
        if not next_day:
            from .tools import tryRestoreIqamaCountdown
            tryRestoreIqamaCountdown(self)
        self.refreshNextPrayer()
        self.updateTimer = eTimer()
        self.updateTimer.timeout.get().append(self.refreshNextPrayer)
        self.updateTimer.start(2000, False)
        self.loaded_day = "tomorrow" if next_day else "today"
        self.already_switched_day = False

    def renderPrayerWidgets(self):
        if not hasattr(self, "today_times") or not self.today_times:
            return    
        from .tools import get_prayer_indices    
        lang = language.getLanguage()[:2].lower()
        today_times = self.today_times
        iqama_today = getattr(self, "iqama_times", [])    
        if lang == "ar":
            prayer_labels = [_("Isha"), _("Maghrib"), _("Asr"), _("Duhr"), _("Fajr")]
            indices = get_prayer_indices(today_times)
            time_indices = list(reversed(indices))
        else:
            prayer_labels = [_("Fajr"), _("Duhr"), _("Asr"), _("Maghrib"), _("Isha")]
            time_indices = get_prayer_indices(today_times)    
        selected_times = [format_time_str(today_times[i]) for i in time_indices]
        self.selected_times = selected_times    
        formatted_iqama = [format_time_str(t) for t in iqama_today]
        if lang == "ar":
            formatted_iqama = formatted_iqama[::-1]    
        prayer_labels_safe = [safe_label_text(x) for x in prayer_labels]
        adhan_safe = [safe_label_text(x) for x in selected_times]
        iqama_safe = [safe_label_text(x) for x in formatted_iqama]    
        widget_names = ["Fajr", "Duhr", "Asr", "Maghrib", "Isha"]
        axis = getattr(self, "axis", "y")    
        if axis == "y" and lang == "ar":
            widget_iter = list(reversed(widget_names))
        else:
            widget_iter = widget_names    
        for i, widget_name in enumerate(widget_iter):
            if axis == "y":
                if lang == "ar":
                    if "iqama_%s" % widget_name in self:
                        self["iqama_%s" % widget_name].setText(prayer_labels_safe[i])
                    if "adhan_%s" % widget_name in self:
                        self["adhan_%s" % widget_name].setText(adhan_safe[i])
                    if "prayer_%s" % widget_name in self:
                        self["prayer_%s" % widget_name].setText(iqama_safe[i])
                else:
                    if "prayer_%s" % widget_name in self:
                        self["prayer_%s" % widget_name].setText(prayer_labels_safe[i])
                    if "adhan_%s" % widget_name in self:
                        self["adhan_%s" % widget_name].setText(adhan_safe[i])
                    if "iqama_%s" % widget_name in self:
                        self["iqama_%s" % widget_name].setText(iqama_safe[i])
            else:
                if "prayer_%s" % widget_name in self:
                    self["prayer_%s" % widget_name].setText(prayer_labels_safe[i])
                if "adhan_%s" % widget_name in self:
                    self["adhan_%s" % widget_name].setText(adhan_safe[i])
                if "iqama_%s" % widget_name in self:
                    self["iqama_%s" % widget_name].setText(iqama_safe[i])

    def refreshNextPrayer(self):
        from .tools import get_next_prayer_info, get_prayer_indices
        now = datetime.now()
        if not getattr(self, "today_times", None) or len(self.today_times) < 6:
            self["nextPrayer"].setText("")
            if self["prayerMarker"] and self["prayerMarker"].instance:
                self["prayerMarker"].hide()
            return   
        info = get_next_prayer_info(self.today_times, now)
        if not info:
            return
        diff = info["diff"]
        api_idx = info["index"]
        name = info["name"]
        h, m = divmod(diff, 3600)
        m //= 60
        label = "%s %s %02d:%02d" % (_(name), _("in"), h, m)
        self["nextPrayer"].setText(safe_label_text(label))
        try:
            skin_path = get_skin_path("main")
            offsets_list, prayer_index_map, offsets_dict, axis = get_prayer_offsets_and_map(skin_path, self.today_times)
            self.axis = axis or "y"
        except Exception:
            self.axis = "y"
            offsets_list = []
            prayer_index_map = {}    
        axis = getattr(self, "axis", "y")
        lang = language.getLanguage()[:2].lower()
        isha_index = 6 if len(self.today_times) == 7 else 5
        h_isha, m_isha = map(int, self.today_times[isha_index].split(":"))
        isha_time = now.replace(hour=h_isha, minute=m_isha, second=0, microsecond=0)    
        countdown = getattr(self, "iqamaCountdownTime", 0)
        iq_idx = getattr(self, "iqamaCountdownIdx", -1)
        now_d = now - timedelta(seconds=2)
        BLINK_WINDOW = 180   
        if not hasattr(self, "loaded_day"):
            return    
        isha_grace = isha_time + timedelta(seconds=BLINK_WINDOW)
        if isha_time < now_d <= isha_grace:
            if not getattr(self, "already_switched_day", False) and countdown <= 0 and self.loaded_day == "today":
                if getattr(self, "lastBlinkIdx", None) != isha_index:
                    self.startBlinking(isha_index)
                    self.lastBlinkIdx = isha_index
        elif now_d > isha_grace:
            if not (countdown > 0 and iq_idx == isha_index):
                if getattr(self, "lastBlinkIdx", None) == isha_index:
                    self.stopBlinking()
                    self.lastBlinkIdx = None
                if not getattr(self, "already_switched_day", False):
                    self.already_switched_day = True
                    self.fetchMawaqit(next_day=True)
                    return
        blink_stopped = False
        for idx, prayer_str in enumerate(self.today_times):
            if idx == isha_index:
                continue
            try:
                h_p, m_p = map(int, prayer_str.split(":"))
                prayer_time = now.replace(hour=h_p, minute=m_p, second=0, microsecond=0)    
                if countdown > 0:
                    continue    
                window_end = prayer_time + timedelta(seconds=BLINK_WINDOW)
                if prayer_time <= now_d <= window_end:
                    if not self.blinkTimer.isActive() or getattr(self, "lastBlinkIdx", None) != idx:
                        self.startBlinking(idx)
                        self.lastBlinkIdx = idx
                elif now_d > window_end:
                    if getattr(self, "lastBlinkIdx", None) == idx:
                        self.stopBlinking()
                        self.lastBlinkIdx = None
                        blink_stopped = True
            except Exception:
                continue
        if blink_stopped:
            self.renderPrayerWidgets()
        if api_idx in prayer_index_map:
            offset_idx = prayer_index_map[api_idx]
            if lang == "ar" and axis == "x":
                offset_idx = 4 - offset_idx
            base_offset = offsets_list[offset_idx]
            if self["prayerMarker"] and self["prayerMarker"].instance:
                if getattr(self, "last_marker_index", -1) != offset_idx:
                    movePrayerMarker(self, base_offset, axis=axis)
                    self["prayerMarker"].show()
                    self.last_marker_index = offset_idx

    def updateIqamaCountdown(self):
        if self.iqamaCountdownTime > 0:
            if getattr(self, "iqamaCountdownIdx", None) is not None:
                if not self.blinkTimer.isActive() or getattr(self, "lastBlinkIdx", None) != self.iqamaCountdownIdx:
                    self.startBlinking(self.iqamaCountdownIdx)
                    self.lastBlinkIdx = self.iqamaCountdownIdx
        else:
            self.stopBlinking()
        if self.iqamaCountdownTime > 0:
            self.iqamaCountdownTime -= 1
            minutes = self.iqamaCountdownTime // 60
            seconds = self.iqamaCountdownTime % 60
            label = "%s %s\n%02d:%02d" % (_("Iqama"), _("in"), minutes, seconds)
            self["IqamaCountdown"].setText(safe_label_text(label))
            self.iqamaTimer.start(1000, True)
        else:
            self["IqamaCountdown"].setText("")
            self["IqamaCountdown"].hide()
            self["IqamaMarker"].hide()
            self.refreshNextPrayer()
            self.renderPrayerWidgets()

    def openCalendar(self):
        data_file = getStorageFile("data.json")
        if not os.path.exists(data_file):
            self["info"].setText(safe_label_text(_("Calendar not found.")))
            self["info"].show()
            return
        try:
            with open(data_file, "r") as f:
                data = json.load(f)
            self.session.open(PrayerCalendarScreen, data)
        except Exception:
            self["info"].setText(safe_label_text(_("No valid Calendar Data found.")))
            self["info"].show()

    def openMosqueInfo(self):
        data_file = getStorageFile("data.json")
        if not os.path.exists(data_file):
            self["info"].setText(safe_label_text(_("Mosque Info not found.")))
            self["info"].show()
            return
        try:
            with open(data_file, "r") as f:
                data = json.load(f)
            self.session.open(MosqueInfoScreen, data)
        except Exception:
            self["info"].setText(safe_label_text(_("No valid Info Data found.")))
            self["info"].show()


class MosqueInfoScreen(Screen):
    def __init__(self, session, mosque_data):
        Screen.__init__(self, session)
        skin_path = get_skin_path("info")
        with open(skin_path, "r") as f:
            self.skin = f.read()
        self["mosqueImage1"] = Pixmap()
        self["mosqueImage2"] = Pixmap()
        self["announcements"] = ScrollLabel("")
        self["other"] = ScrollLabel("")
        self["info"] = Label(_("Mosque Information"))
        self["key_red"] = Label(_("Back"))
        self["key_green"] = Label(_("OK"))
        self["key_yellow"] = Label(_("Notes -"))
        self["key_blue"] = Label(_("Notes +"))
        self["feature_left"] = List([])
        self["feature_right"] = List([])
        self["imageHighlight"] = MovingPixmap()
        for key in ["name", "address", "phone", "email", "website", "announcements_header", "other_header", "association"]:
            self[key] = Label("")
        self.picload = ePicLoad()
        self.picload.PictureData.get().append(self.onImageReady)
        self._currentImagePath = None
        self._currentImageWidget = None
        self.imagePaths = [
            (getStorageFile("exterior.jpg"), "mosqueImage1"),
            (getStorageFile("interior.jpg"), "mosqueImage2")]
        self.imageIndex = 0
        self.onLayoutFinish.append(self.start)
        self["InfoActions"] = ActionMap(["MawaqitActions"], {
            "up": self.selectPreviousImage,
            "down": self.selectNextImage,
            "pageDown": self.annUp,
            "pageUp": self.annDown,
            "ok": self.openImageFullscreen,
            "cancel": self.close,
            "red": self.close,
            "green": self.openImageFullscreen,
            "yellow": self.otherUp,
            "blue": self.otherDown,
        }, -2)
        self.selectedImageIndex = 0
        self.onLayoutFinish.append(self.updateImageHighlight)
        self.buildInfoText(mosque_data)
        self.updateFeatureList(mosque_data)

    def start(self):
        self.startImageLoadingChain()
        self.updateImageHighlight()
    
    def startImageLoadingChain(self):
        if self.imageIndex < len(self.imagePaths):
            path, widget_name = self.imagePaths[self.imageIndex]
            if os.path.exists(path):
                self._currentImagePath = path
                self._currentImageWidget = widget_name
                width = self[widget_name].instance.size().width()
                height = self[widget_name].instance.size().height()
                sc = AVSwitch().getFramebufferScale()
                self.picload = ePicLoad()
                self.picload.PictureData.get().append(lambda info="": self.onImageReady(widget_name))
                self.picload.setPara((width, height, sc[0], sc[1], False, 1, "#00000000"))
                result = self.picload.startDecode(path)   
            else:
                self.imageIndex += 1
                self.startImageLoadingChain()

    def onImageReady(self, widget_name):
        ptr = self.picload.getData()
        if ptr:
            self[widget_name].instance.setPixmap(ptr)
            self[widget_name].instance.setScale(1)
            self[widget_name].show()
        self.imageIndex += 1
        self.startImageLoadingChain()

    def updateImageHighlight(self):
        from .tools import get_imagehighlight_step_from_skin
        skin_path = get_skin_path("info")
        step = get_imagehighlight_step_from_skin(skin_path)
        offset_y = self.selectedImageIndex * step
        movePrayerMarker(self, offset_y, marker_name="imageHighlight")

    def selectPreviousImage(self):
        self.selectedImageIndex = max(0, self.selectedImageIndex - 1)
        self.updateImageHighlight()

    def selectNextImage(self):
        self.selectedImageIndex = min(1, self.selectedImageIndex + 1)
        self.updateImageHighlight()

    def openImageFullscreen(self):
        images = [p for p, _ in self.imagePaths]
        if os.path.exists(images[self.selectedImageIndex]):
            self.session.open(MosqueImageFullscreen, (images, self.selectedImageIndex))

    def annUp(self):
        self["announcements"].pageUp()

    def annDown(self):
        self["announcements"].pageDown()

    def otherUp(self):
        self["other"].pageUp()

    def otherDown(self):
        self["other"].pageDown()

    def buildInfoText(self, mosque_data):
            try:
                self["name"].setText("%s %s" % ( _("Name:"), safe_label_text(mosque_data.get("label")) or _("None")))
                self["address"].setText("%s %s" % (_("Address:"), safe_label_text(mosque_data.get("localisation")) or _("None")))
                self["phone"].setText("%s %s" % ( _("Phone:"), safe_label_text(mosque_data.get("phone")) or _("None")))
                self["email"].setText("%s %s" % (_("E-Mail:"), safe_label_text(mosque_data.get("email")) or _("None")))
                self["website"].setText("%s %s" % ( _("Website:"), safe_label_text(mosque_data.get("site")) or _("None")))
                self["association"].setText("%s %s" % ( _("Association:"), safe_label_text(mosque_data.get("association")) or _("None")))
                announcements = mosque_data.get("announcements", [])
                header_text = _(u"Announcements:")
                if announcements:
                    parts = []
                    for ann in announcements:
                        title = safe_label_text(ann.get("title", "")).strip()
                        content = safe_label_text(ann.get("content", "")).strip()
                        if title:
                            parts.append(safe_label_text(title))
                        if content:
                            parts.append(safe_label_text(content))
                    content_text = "\n".join(parts)
                else:
                    content_text = ""
                    header_text = _(u"Announcements:") + " " + _("None")
                self["announcements_header"].setText(safe_label_text(header_text))
                self["announcements"].setText(safe_label_text(content_text))
                other_info = mosque_data.get("otherInfo")
                if other_info:
                    other_text = "\n%s" % safe_label_text(other_info)
                    titel_text = _(u"Notes:")
                else:
                    other_text = ""
                    titel_text = _(u"Notes:") + " " + _("None")   
                self["other"].setText(safe_label_text(other_text))
                self["other_header"].setText(safe_label_text(titel_text))
                self.image_url1 = getStorageFile("exterior.jpg")
                self.image_url2 = getStorageFile("interior.jpg") 
            except Exception as e:
                error_msg = _("Error displaying:\n%s" % str(e))
                self.image_url1 = None
                self.image_url2 = None

    def updateFeatureList(self, mosque_data):
        fhd_path = "/usr/lib/enigma2/python/Plugins/Extensions/Mawaqit/skins/fhd/img"
        hd_path = "/usr/lib/enigma2/python/Plugins/Extensions/Mawaqit/skins/hd/img"
        if os.path.exists(fhd_path) and getDesktop(0).size().width() > 1280:
            base_path = fhd_path
        else:
            base_path = hd_path
        yes_icon = LoadPixmap(os.path.join(base_path, "yes.png"))
        no_icon = LoadPixmap(os.path.join(base_path, "no.png"))
        aid_time = (mosque_data.get("aidPrayerTime") or "").strip()
        aid_text = str(aid_time)
        feature_entries = [
            (_("Ablution Room"), "ablution.png", mosque_data.get("ablutions")),
            (_("Women Space"), "women.png", mosque_data.get("womenSpace")),
            (_("Janaza Prayer"), "janaza.png", mosque_data.get("janazaPrayer")),
            (_("Eid Prayer"), "eid.png", mosque_data.get("aidPrayer")),
            (_("Children Courses"), "children.png", mosque_data.get("childrenCourses")),
            (_("Adult Courses"), "adult.png", mosque_data.get("adultCourses")),
            (_("Iftar Ramadan"), "iftar.png", mosque_data.get("ramadanMeal")),
            (_("Accessible Entrance"), "accessibility.png", mosque_data.get("handicapAccessibility")),
            (_("Parking"), "parking.png", mosque_data.get("parking")),
            (_("Jumu'a Time as Duhr"), "jumua.png", mosque_data.get("jumuaAsDuhr")),]
        mid_index = (len(feature_entries) + 1) // 2
        feature_left = feature_entries[:mid_index]
        feature_right = feature_entries[mid_index:]
        
        def build_feature_list(entries, with_aid=False):
            list_items = []
            for idx, (label, icon_file, value) in enumerate(entries):
                left_icon = LoadPixmap(os.path.join(base_path, icon_file))
                right_icon = yes_icon if value else no_icon
                if with_aid and idx == 3 and aid_text:
                    label = "%s   (%s)" % (label, aid_text)
                VTI = os.path.exists("/etc/vtiversion.info")
                BH = os.path.exists("/etc/bhversion")
                if language.getLanguage()[:2] == "ar" and VTI:
                    list_items.append((right_icon, label, left_icon))
                elif language.getLanguage()[:2] == "ar" and BH:
                    list_items.append((right_icon, label, left_icon))
                else:
                    list_items.append((left_icon, label, right_icon))
            return list_items
        self["feature_left"].setList(build_feature_list(feature_left, with_aid=True))
        self["feature_right"].setList(build_feature_list(feature_right, with_aid=False))


class MosqueImageFullscreen(Screen):
    def __init__(self, session, args):
        Screen.__init__(self, session)
        skin_path = get_skin_path("fullscreen")
        with open(skin_path, "r") as f:
            self.skin = f.read()
        self.image_paths, self.current_index = args
        self["fullscreenImage"] = Pixmap()
        self["imageName"] = Label("")
        self.picload = None
        self._currentImagePath = None
        self._currentImageWidget = None
        self.imageIndex = 0
        self.imagePaths = [(p, "fullscreenImage") for p in self.image_paths]
        self["ImageActions"] = ActionMap(["MawaqitActions"], {
            "cancel": self.close,
            "ok": self.close,
            "pageDown": self.showPreviousImage,
            "pageUp": self.showNextImage,
        }, -2)
        self.onLayoutFinish.append(self.startImageLoadingChain)

    def startImageLoadingChain(self):
        if not self.image_paths:
            return
        path = self.image_paths[self.current_index]
        if not os.path.exists(path):
            return
        IMAGE_NAME_MAP = {
            "interior.jpg": _("Interior View of the Mosque"),
            "exterior.jpg": _("Exterior View of the Mosque")}
        filename = os.path.basename(path)
        display_name = IMAGE_NAME_MAP.get(filename, filename)
        self["imageName"].setText(safe_label_text(display_name))
        self._currentImagePath = path
        self._currentImageWidget = "fullscreenImage"
        width = self["fullscreenImage"].instance.size().width()
        height = self["fullscreenImage"].instance.size().height()
        sc = AVSwitch().getFramebufferScale()
        self.picload = ePicLoad()
        self.picload.PictureData.get().append(lambda info="": self.onImageReady(self._currentImageWidget))
        self.picload.setPara((width, height, sc[0], sc[1], False, 1, "#00000000"))
        result = self.picload.startDecode(path)

    def onImageReady(self, widget_name):
        ptr = self.picload.getData()
        if ptr and widget_name:
            self[widget_name].instance.setPixmap(ptr)
            self[widget_name].instance.setScale(1)
            self[widget_name].show()

    def showNextImage(self):
        if self.image_paths:
            self.current_index = (self.current_index + 1) % len(self.image_paths)
            self.startImageLoadingChain()

    def showPreviousImage(self):
        if self.image_paths:
            self.current_index = (self.current_index - 1) % len(self.image_paths)
            self.startImageLoadingChain()


class PrayerCalendarScreen(Screen):
    def __init__(self, session, calendar_data):
        Screen.__init__(self, session)
        skin_path = get_skin_path("calendar")
        with open(skin_path, "r") as f:
            self.skin = f.read()
        self.marker_base_pos = None
        self.has_valid_calendar = False
        self["monthLabel"] = Label("")
        self["calendar"] = Label(_("Prayer Times Calendar"))
        self["holidayLabel"] = Label("")
        self["mosqueLabel"] = Label("")
        self["key_red"] = Label(_("Back"))
        self["calendarMarker"] = Pixmap()
        self["calendarMarker"].hide()
        for key in ["day", "hijri", "fajr", "duhr", "asr", "maghrib", "isha"]:
            self["calendar_" + key] = Label("")
        for key in ["day", "hijri", "fajr", "duhr", "asr", "maghrib", "isha"]:
            self["label_" + key] = Label("")
        self.current_month = datetime.today().month - 1
        self.calendar_data = []
        self.buildCalendarText()
        self.onLayoutFinish.append(self.setInitialMarker)
        self["CalendarActions"] = ActionMap(["MawaqitActions"], {
            "cancel": self.close,
            "red": self.close,
            "pageDown": self.prevMonth,
            "pageUp": self.nextMonth,
        }, -2)

    def setInitialMarker(self):
        try:
            if not hasattr(self, "marker_base_pos"):
                marker_widget = self["calendarMarker"]
                if marker_widget:
                    self.marker_base_pos = marker_widget.getPosition()
            self.positionCalendarMarker()
        except Exception:
            pass

    def prevMonth(self):
        if self.current_month > 0:
            self.current_month -= 1
            self.buildCalendarText()
            self.positionCalendarMarker()

    def nextMonth(self):
        if self.current_month < 11:
            self.current_month += 1
            self.buildCalendarText()
            self.positionCalendarMarker()

    def buildCalendarText(self):
        today = datetime.today().date()
        current_year = today.year
        leap = is_leap_year(current_year)
        month_names = [
            _("January"), _("February"), _("March"), _("April"), _("May"), _("June"),
            _("July"), _("August"), _("September"), _("October"), _("November"), _("December")
        ]
        month_name = month_names[self.current_month]
        hijri_months = [
            _("Muharram"), _("Safar"), _("Rabi' Al-Awwal"), _("Rabi' Al-Akhir"),
            _("Jumada Al-Oula"), _("Jumada Al-Akhira"), _("Rajab"), _("Sha'ban"),
            _("Ramadan"), _("Shawwal"), _("Dhu Al-Qi'dah"), _("Dhu Al-Hijjah")
        ]
        islamic_holidays = {
            (1, 0): (_("Islamic New Year"), "N"),
            (10, 0): (_("Ashura"), "A"),
            (12, 2): (_("The birth of the Prophet"), "P"),
            (1, 8): (_("Start of Ramadan"), "R"),
            (1, 9): (_("Eid Al-Fitr"), "F"),
            (10, 11): (_("Eid Al-Adha"), "D"),
        }
        calendar_path = getStorageFile("data.json")
        hijri_path = getStorageFile("hijridata.json")
        if not os.path.exists(calendar_path):
            for key in ["day", "hijri", "fajr", "duhr", "asr", "maghrib", "isha"]:
                self["calendar_" + key].setText("")
            self.has_valid_calendar = False
            return
        try:
            if not self.calendar_data:
                with open(calendar_path, "r") as f:
                    full_data = json.load(f)
                self.calendar_data = full_data.get("calendar", [])
                mosque_name = full_data.get("label", "")
                self["mosqueLabel"].setText(safe_label_text(mosque_name))
            if not isinstance(self.calendar_data, list) or len(self.calendar_data) <= self.current_month:
                raise Exception(_("Invalid calendar"))
            month_data = self.calendar_data[self.current_month]
            if not month_data:
                raise Exception(_("No data for month"))
            hijri_data = {}
            if os.path.exists(hijri_path):
                with open(hijri_path, "r") as f:
                    hijri_data = json.load(f).get("hijri_calendar", {})
            try:
                hijri_adjust = int(config.plugins.mawaqit.hijriAdjust.value)
            except Exception:
                hijri_adjust = 0
            day_col, hijri_col = [], []
            fajr_col, duhr_col, asr_col, maghrib_col, isha_col = [], [], [], [], []
            holiday_labels = []
            hijri_months_in_order = []
            hijri_year_by_month = {}
            for day in sorted(month_data.keys(), key=lambda x: int(x)):
                if not leap and self.current_month == 1 and int(day) == 29:
                    continue
                times = month_data[day]
                if len(times) >= 6:
                    day_col.append(day.zfill(2))
                    greg_date = "%s-%s-%d" % (day.zfill(2), str(self.current_month + 1).zfill(2), current_year)
                    greg_date_obj = datetime.strptime(greg_date, "%d-%m-%Y").date() + timedelta(days=hijri_adjust)
                    greg_date_adj = greg_date_obj.strftime("%d-%m-%Y")
                    hijri_day = ""
                    hijri_month_index = None
                    if greg_date_adj in hijri_data:
                        hijri_date = hijri_data[greg_date_adj]["hijri"]["date"]
                        d, m, y = hijri_date.split("-")
                        hijri_month_index = int(m) - 1
                        if hijri_month_index not in hijri_year_by_month:
                            hijri_months_in_order.append(hijri_month_index)
                            hijri_year_by_month[hijri_month_index] = y
                        hijri_day = d.zfill(2)
                        holiday_markers = {
                            "N": "| {0} |", "A": "|| {0} ||", "P": "|| {0} ||",
                            "R": "| {0} |", "F": "||| {0} |||", "D": "||| {0} |||",
                        }
                        key = (int(d), hijri_month_index)
                        if key in islamic_holidays:
                            holiday_name, marker = islamic_holidays[key]
                            fmt = holiday_markers.get(marker, "{0}")
                            hijri_day = fmt.format(hijri_day)
                            holiday_labels.append(fmt.format(holiday_name))
                    hijri_col.append(hijri_day)
                    if len(times) == 7:
                        fajr_col.append(format_time_str(times[0]))
                        duhr_col.append(format_time_str(times[3]))
                        asr_col.append(format_time_str(times[4]))
                        maghrib_col.append(format_time_str(times[5]))
                        isha_col.append(format_time_str(times[6]))
                    else:
                        fajr_col.append(format_time_str(times[0]))
                        duhr_col.append(format_time_str(times[2]))
                        asr_col.append(format_time_str(times[3]))
                        maghrib_col.append(format_time_str(times[4]))
                        isha_col.append(format_time_str(times[5]))
            lang = language.getLanguage()[:2]
            if lang == "ar":
                self["calendar_isha"].setText(safe_label_text("\n".join(day_col)))
                self["calendar_maghrib"].setText(safe_label_text("\n".join(hijri_col)))
                self["calendar_asr"].setText(safe_label_text("\n".join(fajr_col)))
                self["calendar_duhr"].setText(safe_label_text("\n".join(duhr_col)))
                self["calendar_fajr"].setText(safe_label_text("\n".join(asr_col)))
                self["calendar_hijri"].setText(safe_label_text("\n".join(maghrib_col)))
                self["calendar_day"].setText(safe_label_text("\n".join(isha_col)))
                self["label_isha"].setText(safe_label_text(_("Day")))
                self["label_maghrib"].setText(safe_label_text(_("Hijri")))
                self["label_asr"].setText(safe_label_text(_("Fajr")))
                self["label_duhr"].setText(safe_label_text(_("Duhr")))
                self["label_fajr"].setText(safe_label_text(_("Asr")))
                self["label_hijri"].setText(safe_label_text(_("Maghrib")))
                self["label_day"].setText(safe_label_text(_("Isha")))
            else:
                self["calendar_day"].setText(safe_label_text("\n".join(day_col)))
                self["calendar_hijri"].setText(safe_label_text("\n".join(hijri_col)))
                self["calendar_fajr"].setText(safe_label_text("\n".join(fajr_col)))
                self["calendar_duhr"].setText(safe_label_text("\n".join(duhr_col)))
                self["calendar_asr"].setText(safe_label_text("\n".join(asr_col)))
                self["calendar_maghrib"].setText(safe_label_text("\n".join(maghrib_col)))
                self["calendar_isha"].setText(safe_label_text("\n".join(isha_col)))
                self["label_day"].setText(safe_label_text(_("Day")))
                self["label_hijri"].setText(safe_label_text(_("Hijri")))
                self["label_fajr"].setText(safe_label_text(_("Fajr")))
                self["label_duhr"].setText(safe_label_text(_("Duhr")))
                self["label_asr"].setText(safe_label_text(_("Asr")))
                self["label_maghrib"].setText(safe_label_text(_("Maghrib")))
                self["label_isha"].setText(safe_label_text(_("Isha")))
            hijri_label = ""
            if hijri_months_in_order:
                years = set([hijri_year_by_month[m] for m in hijri_months_in_order])
                if len(years) == 1:
                    hijri_label = " |  " + " + ".join([hijri_months[m] for m in hijri_months_in_order]) + " " + list(years)[0]
                else:
                    parts = ["%s %s" % (hijri_months[m], hijri_year_by_month[m]) for m in hijri_months_in_order]
                    hijri_label = " |  " + " + ".join(parts)
            label_text = _("%(gregorian_month)s %(gregorian_year)d %(hijri_part)s") % {
                "gregorian_month": month_name,
                "gregorian_year": current_year,
                "hijri_part": hijri_label,
            }
            self["monthLabel"].setText(safe_label_text(label_text))
            if holiday_labels:
                self["holidayLabel"].setText(safe_label_text("     ".join(holiday_labels)))
            else:
                self["holidayLabel"].setText("")
            self.has_valid_calendar = True
        except Exception as e:
            for key in ["day", "hijri", "fajr", "duhr", "asr", "maghrib", "isha"]:
                self["calendar_" + key].setText("")
            self["monthLabel"].setText(safe_label_text(_("Error: %s") % e))
            self["holidayLabel"].setText("")
            self.has_valid_calendar = False

    def positionCalendarMarker(self):
        from .tools import get_calendar_step_from_skin
        try:
            if not getattr(self, "has_valid_calendar", False):
                self["calendarMarker"].hide()
                return
            today = datetime.today().date()
            if self.current_month + 1 == today.month:
                idx = today.day - 1
                skin_path = get_skin_path("calendar")
                calendar_step = get_calendar_step_from_skin(skin_path)
                offset_y = idx * calendar_step
                movePrayerMarker(self, offset_y, marker_name="calendarMarker")
            else:
                self["calendarMarker"].hide()
        except Exception:
            pass

def main(session, **kwargs):
    session.open(MawaqitMainScreen)

def Plugins(**kwargs):
    if getDesktop(0).size().width() > 1280:
        pluicon = 'mawaqitfhd.png'
    else:
        pluicon = 'mawaqithd.png'
    return [
        PluginDescriptor(
            name="MAWAQIT مواقيت",
            description=_("Prayer Times for Enigma2"),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon=pluicon),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=autostart)]