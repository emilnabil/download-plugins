﻿# -*- coding: utf-8 -*-
####################################################
# Developed and maintained by magsat.
# This is an open-source plugin that may be modified for personal use.
# Redistribution of modified versions is not permitted.
# Only skin modifications may be shared.
# If you would like to donate, please visit www.mawaqit.net.
####################################################
last_triggered_idx_warn = [-1]
last_triggered_idx_now = [-1]

from enigma import ePoint, addFont, eConsoleAppContainer, eTimer
from datetime import datetime, timedelta
from Components.config import config
from Components.Language import language
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.InfoBar import InfoBar
from Components.ActionMap import ActionMap
from Components.Converter.Converter import Converter
from Components.Renderer.Renderer import Renderer
from Components.Element import cached
from enigma import eWidget, eLabel, gFont
from enigma import eServiceReference
import os
import time
import json
import re
import sys
from . import _

overlay_instance = None

def hijri_from_gregorian(g_date):
    day = g_date.day
    month = g_date.month
    year = g_date.year
    if month < 3:
        year -= 1
        month += 12
    a = int(year / 100)
    b = 2 - a + int(a / 4)
    jd = int(365.25 * (year + 4716)) + int(30.6001 * (month + 1)) + day + b - 1524
    l = jd - 1948440 + 10632
    n = int((l - 1) / 10631)
    l = l - 10631 * n + 354
    j = (int((10985 - l) / 5316)) * (int((50 * l) / 17719)) + (int(l / 5670)) * (int((43 * l) / 15238))
    l = l - (int((30 - j) / 15)) * (int((17719 * j) / 50)) - (int(j / 16)) * (int((15238 * j) / 43)) + 29
    m = int((24 * l) / 709)
    d = l - int((709 * m) / 24)
    y = 30 * n + j - 30
    return (d, m, y)

def generate_hijri_calendar(storage_path):
    try:
        today = datetime.today()
        year = today.year
        start_date = datetime(year - 1, 12, 29)
        end_date = datetime(year + 1, 1, 3)
        hijri_calendar = {}
        current_date = start_date
        while current_date <= end_date:
            h_d, h_m, h_y = hijri_from_gregorian(current_date)
            g_str = current_date.strftime("%d-%m-%Y")
            h_str = "%02d-%02d-%04d" % (h_d, h_m, h_y)
            hijri_calendar[g_str] = {
                "gregorian": {"date": g_str},
                "hijri": {"date": h_str}
            }
            current_date += timedelta(days=1)
        data = {
            "last_update": today.strftime("%Y-%m-%d"),
            "hijri_calendar": hijri_calendar
        }
        out_path = os.path.join(storage_path, "hijridata.json")
        with open(out_path, "w") as f:
            f.write('{\n  "last_update": "%s",\n  "hijri_calendar": {\n' % today.strftime("%Y-%m-%d"))
            items = []
            for g_str in sorted(hijri_calendar.keys(), key=lambda d: datetime.strptime(d, "%d-%m-%Y")):
                h_str = hijri_calendar[g_str]["hijri"]["date"]
                line = '    "%s": {"gregorian":{"date":"%s"},"hijri":{"date":"%s"}}' % (g_str, g_str, h_str)
                items.append(line)
            f.write(",\n".join(items))
            f.write("\n  }\n}")
    except Exception:
        pass

def ensure_hijri_calendar():
    try:
        storage_path = config.plugins.mawaqit.storageLocation.value
        file_path = os.path.join(storage_path, "hijridata.json")
        regen = False
        if not os.path.exists(file_path):
            regen = True
        else:
            with open(file_path, "r") as f:
                data = json.load(f)
            last_update = data.get("last_update", "")
            if last_update.startswith(str(datetime.today().year)):
                pass
            else:
                regen = True
        if datetime.today().strftime("%d-%m") == "01-01":
            regen = True
        if regen:
            generate_hijri_calendar(storage_path)
    except Exception:
        pass

def getHijriDateFromCalendar(hijri_adjust=0):
    try:
        storage_path = config.plugins.mawaqit.storageLocation.value
        hijri_path = os.path.join(storage_path, "hijridata.json")
        if not os.path.exists(hijri_path):
            ensure_hijri_calendar()
        with open(hijri_path, "r") as f:
            data = json.load(f)
        hijri_calendar = data.get("hijri_calendar", {})
        target_date = datetime.today().date() + timedelta(days=hijri_adjust)
        target_str = target_date.strftime("%d-%m-%Y")
        if target_str not in hijri_calendar:
            return _("Bitte online aktualisieren")
        hijri_date = hijri_calendar[target_str]["hijri"]["date"]
        d, m, y = hijri_date.split("-")
        hijri_months = [
            _("Muharram"), _("Safar"), _("Rabi' Al-Awwal"), _("Rabi' Al-Akhir"),
            _("Jumada Al-Oula"), _("Jumada Al-Akhira"), _("Rajab"), _("Sha'ban"),
            _("Ramadan"), _("Shawwal"), _("Dhu Al-Qi'dah"), _("Dhu Al-Hijjah")
        ]
        month_name = hijri_months[int(m) - 1]
        return "%02d %s %s" % (int(d), month_name, y)
    except Exception as e:
        return _("Hijri-Fehler")

def get_translated_date(now=None):
    if now is None:
        now = datetime.now()
    weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    weekday = _(weekdays[now.weekday()])
    month = _(months[now.month - 1])
    date_format = "%(weekday)s %(day)02d %(month)s %(year)d"
    date_str = date_format % {"weekday": weekday, "day": now.day, "month": month, "year": now.year,}
    return safe_label_text(date_str)

def format_time_str(t):
    try:
        if not t:
            return t
        if re.search(r'\b(am|pm)\b', t.lower()):
            return t
        dt = datetime.strptime(t, "%H:%M")
        if config.plugins.mawaqit.time_format.value == "12h":
            hour = dt.strftime("%I")
            minute = dt.strftime("%M")
            suffix = "AM" if dt.hour < 12 else "PM"
            return "%s:%s %s" % (hour, minute, suffix)
        else:
            return dt.strftime("%H:%M")
    except Exception:
        return t

def get_prayer_step_from_skin(skin_path):
    try:
        with open(skin_path, 'r') as f:
            content = f.read()
        step_match = re.search(r'<prayerOffsets\s+step="(\d+)"', content)
        axis_match = re.search(r'axis="([xy])"', content)
        step = int(step_match.group(1)) if step_match else 73
        axis = axis_match.group(1) if axis_match else "y"
        return step, axis
    except Exception:
        return 73, "y"

def get_prayer_indices(times):
    return [0, 3, 4, 5, 6] if len(times) == 7 else [0, 2, 3, 4, 5]

def get_prayer_offsets_and_map(skin_path, today_times):
    step = 73
    axis = "y"
    try:
        with open(skin_path, "r") as f:
            content = f.read()
        m = re.search(r'<prayerOffsets\s+step="(\d+)"', content)
        if m:
            step = int(m.group(1))
        m2 = re.search(r'<prayerOffsets[^>]*axis="(x|y)"', content, re.IGNORECASE)
        if m2:
            axis = m2.group(1).lower()
    except Exception:
        pass
    base_indices = get_prayer_indices(today_times)
    prayer_index_map = {idx: pos for pos, idx in enumerate(base_indices)}
    offsets_list = [step * i for i in range(5)]
    offsets_dict = {idx: step * pos for pos, idx in enumerate(base_indices)}
    return offsets_list, prayer_index_map, offsets_dict, axis

def get_calendar_step_from_skin(skin_path):
    try:
        with open(skin_path, 'r') as f:
            content = f.read()
        match = re.search(r'<calendarOffsets\s+step="(\d+)"', content)
        if match:
            return int(match.group(1))
    except Exception:
        pass
    return 28

def movePrayerMarker(screen, offset, marker_name="prayerMarker", axis="y", rtl=False):
    try:
        marker = screen[marker_name]
        if not marker.instance:
            return
        base_attr = "marker_base_pos_" + marker_name
        if not hasattr(screen, base_attr):
            base_pos = marker.getPosition()
            setattr(screen, base_attr, base_pos)
        else:
            base_pos = getattr(screen, base_attr)
        x_base, y_base = base_pos
        if axis == "x":
            if rtl:
                new_x = x_base - offset
            else:
                new_x = x_base + offset
            new_y = y_base
        else:
            new_x = x_base
            new_y = y_base + offset
        marker.move(new_x, new_y)
        marker.show()
    except Exception:
        pass

def get_imagehighlight_step_from_skin(skin_path):
    try:
        with open(skin_path, 'r') as f:
            content = f.read()
        match = re.search(r'<imageHighlightOffsets\s+step="(\d+)"', content)
        if match:
            return int(match.group(1))
    except Exception:
        pass
    return 435

def get_next_prayer_info(times, now=None):
    if now is None:
        now = datetime.now()
    indices = get_prayer_indices(times)
    names = ["Fajr", "Duhr", "Asr", "Maghrib", "Isha"]
    result = []
    for i, idx in enumerate(indices):
        try:
            h, m = map(int, times[idx].split(":"))
            pt = now.replace(hour=h, minute=m, second=0, microsecond=0)
            diff = (pt - now).total_seconds()
            if diff < 0:
                diff += 86400
            result.append((diff, idx, names[i], times[idx]))
        except Exception:
            continue
    if not result:
        return None
    diff, idx, name, tstr = min(result, key=lambda x: x[0])
    return {"index": idx, "name": name, "diff": int(diff), "time_str": tstr}

def save_triggered_indices(idx10, idxNow):
    try:
        with open("/tmp/PrayerTrig.json", "w") as f:
            json.dump({"last10": idx10, "lastNow": idxNow}, f)
    except:
        pass

def handlePrayerTrigger(idx, diff, today_times, iqama_times, label="Unbekannte Moschee"):
    from .tools import showPrayerPopup
    from . import tools as state
    names = [_("Fajr"), _("Duhr"), _("Asr"), _("Maghrib"), _("Isha")]
    name = names[idx]
    iqama = iqama_times[idx] if idx < len(iqama_times) else "-"
    warn_val = config.plugins.mawaqit.warn_before.value
    warn_minutes = 0 if warn_val == "off" else int(warn_val)
    if warn_minutes > 0:
        target = warn_minutes * 60
        lower = target - 1
        upper = target + 1
        if lower < diff <= upper and idx != state.last_triggered_idx_warn[0]:
            state.last_triggered_idx_warn[0] = idx
            save_triggered_indices(state.last_triggered_idx_warn[0], state.last_triggered_idx_now[0])
            warn = config.plugins.mawaqit.warn_before.value
            lang = language.getLanguage()[:2]
            if lang == "ar" and warn == "10":
                showPrayerPopup(_("%s Prayer in %d 10MinAr\nIqama: %s") % (name, warn_minutes, iqama), play_sound=False)
            else:
                showPrayerPopup(_("%s Prayer in %d Minutes\nIqama: %s") % (name, warn_minutes, iqama), play_sound=False)
    if -1 < diff <= +1 and config.plugins.mawaqit.showExactPopup.value and idx != state.last_triggered_idx_now[0]:
        state.last_triggered_idx_now[0] = idx
        save_triggered_indices(state.last_triggered_idx_warn[0], state.last_triggered_idx_now[0])
        showPrayerPopup(_("Now the Call to %s Prayer\nIqama: %s") % (name, iqama), play_sound=True)
        prayer_indices = get_prayer_indices(today_times)
        real_idx = prayer_indices[idx]
        prayer_str = today_times[real_idx]
        now = datetime.now()
        try:
            h, m = map(int, prayer_str.split(":"))
            prayer_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
            if (prayer_time - now).total_seconds() < -300:
                prayer_time += timedelta(days=1)
        except Exception:
            return
        try:
            if iqama.startswith("+"):
                offset = int(iqama[1:])
                target_time = prayer_time + timedelta(minutes=offset)
                countdown = offset * 60
            else:
                try:
                    h, m = map(int, iqama.split(":"))
                    target_time = prayer_time.replace(hour=h, minute=m, second=0, microsecond=0)
                    if target_time < prayer_time:
                        target_time += timedelta(days=1)
                    countdown = int((target_time - prayer_time).total_seconds())
                except Exception:
                    return
        except Exception:
            return
        try:
            screen = getattr(state, "mainScreen", None)
            if screen:
                startIqamaCountdown(screen=screen, times=today_times, iqamas=iqama_times,
                    countdownLabel=screen["IqamaCountdown"], countdownMarker=screen["IqamaMarker"],
                    timer=screen.iqamaTimer, idx=idx, override_seconds=countdown)
        except Exception:
            pass

def startIqamaCountdown(screen, times, iqamas, countdownLabel=None, countdownMarker=None, timer=None, idx=None, override_seconds=None, restored=False, restored_target_time=None, skin_path=None):
    from .plugin import get_skin_path
    if skin_path is None:
        skin_path = get_skin_path("main")
    offsets_list, prayer_index_map, offsets_dict, axis = get_prayer_offsets_and_map(skin_path, screen.today_times)
    if idx is None:
        return
    base_indices = get_prayer_indices(times)
    lang = language.getLanguage()[:2].lower()
    prayer_indices = base_indices
    ui_idx_map = {api_idx: pos for pos, api_idx in enumerate(base_indices)}
    if lang == "ar" and axis == "x":
        ui_idx_map = {api_idx: 4 - pos for api_idx, pos in ui_idx_map.items()}
    if idx < 0 or idx >= len(prayer_indices):
        return
    real_idx = prayer_indices[idx]
    prayer_str = times[real_idx]
    iqama_str = iqamas[idx]
    now = datetime.now()
    try:
        h, m = map(int, prayer_str.split(":"))
        prayer_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
        if (prayer_time - now).total_seconds() < -300:
            prayer_time += timedelta(days=1)
    except:
        return
    if override_seconds is not None:
        countdown = override_seconds
        target_time = restored_target_time if restored and restored_target_time else now + timedelta(seconds=override_seconds)
    else:
        if iqama_str.startswith("+"):
            offset_minutes = int(iqama_str[1:])
            target_time = prayer_time + timedelta(minutes=offset_minutes)
        else:
            try:
                h, m = map(int, iqama_str.split(":"))
                target_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
                if target_time < now:
                    target_time += timedelta(days=1)
            except:
                return
        countdown = int((target_time - now).total_seconds())
    if countdown <= 0:
        return
    if countdownLabel and countdownMarker:
        try:
            screen.iqamaCountdownTime = countdown
            screen.iqamaCountdownIdx = real_idx
            ui_idx = ui_idx_map[real_idx]
            offset = offsets_list[ui_idx]
            if not hasattr(screen, "iqama_base_label"):
                screen.iqama_base_label = countdownLabel.getPosition()
            if not hasattr(screen, "iqama_base_marker"):
                screen.iqama_base_marker = countdownMarker.getPosition()
            x_base_l, y_base_l = screen.iqama_base_label
            x_base_m, y_base_m = screen.iqama_base_marker
            if axis == "x":
                countdownLabel.move(x_base_l + offset, y_base_l)
                countdownMarker.move(x_base_m + offset, y_base_m)
            else:
                countdownLabel.move(x_base_l, y_base_l + offset)
                countdownMarker.move(x_base_m, y_base_m + offset)
            countdownLabel.show()
            countdownMarker.show()
        except Exception:
            pass
    if timer:
        screen.updateIqamaCountdown()
        timer.start(1000, True)

def tryRestoreIqamaCountdown(screen):
    if getattr(screen, "iqamaCountdownFinished", False):
        return
    try:
        now = datetime.now() - timedelta(seconds=2)
        today_times = getattr(screen, "today_times", [])
        iqama_times = getattr(screen, "iqama_times", [])
        if not today_times or not iqama_times or len(today_times) < 6 or len(iqama_times) < 5:
            return
        countdown_active = getattr(screen, "iqamaCountdownTime", 0) > 0
        idx_map = get_prayer_indices(today_times)
        for idx, prayer_idx in enumerate(idx_map):
            prayer_str = today_times[prayer_idx]
            iqama_str = iqama_times[idx]
            try:
                h, m = map(int, prayer_str.split(":"))
                prayer_time = now.replace(hour=h, minute=m, second=0, microsecond=0)
            except:
                continue
            if (now - prayer_time).total_seconds() > 3600:
                prayer_time += timedelta(days=1)
            try:
                if iqama_str.startswith("+"):
                    offset = int(iqama_str[1:])
                    target_time = prayer_time + timedelta(minutes=offset)
                else:
                    h, m = map(int, iqama_str.split(":"))
                    target_time = prayer_time.replace(hour=h, minute=m)
                    if target_time < now:
                        target_time += timedelta(days=1)
                    if target_time <= now:
                        continue
            except:
                continue
            remaining = int((target_time - now).total_seconds())
            elapsed   = int((now - prayer_time).total_seconds())
            if 0 <= elapsed <= 3600 and 0 < remaining <= 3600:
                screen.iqamaCountdownTime = remaining
                screen.iqamaCountdownIdx = prayer_idx
                startIqamaCountdown(screen, today_times, iqama_times, countdownLabel=screen["IqamaCountdown"],
                    countdownMarker=screen["IqamaMarker"], timer=screen.iqamaTimer, idx=idx, override_seconds=remaining)
                screen._keep_today_times_until = prayer_time.date()
                return
    except Exception:
        pass

def time_until_next_prayer(times, return_seconds=False, return_index=False):
    now = datetime.now() - timedelta(seconds=2)
    prayer_names = ["Fajr", "Duhr", "Asr", "Maghrib", "Isha"]
    indices = get_prayer_indices(times)
    valid = []
    for i, idx in enumerate(indices):
        try:
            h, m = map(int, times[idx].split(":"))
            pt = now.replace(hour=h, minute=m, second=0, microsecond=0)
            diff = (pt - now).total_seconds()
            if diff < 0:
                diff += 86400
            valid.append((diff, i))
        except Exception:
            continue
    if not valid:
        return None
    diff, index = min(valid)
    if return_index:
        return index
    elif return_seconds:
        return int(diff)
    else:
        return "%s in %02d:%02d" % (prayer_names[index], diff // 3600, (diff % 3600) // 60)


def startPrayerOverlay(session):
    global overlay_instance
    if overlay_instance is None:
        overlay_instance = PrayerNotificationOverlay(session)

class PrayerOverlayScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        addFont("/usr/lib/enigma2/python/Plugins/Extensions/Mawaqit/fonts/nmsbd.ttf", "nmsbold", 100, 1)
        from .plugin import get_skin_path
        skin_path = get_skin_path("widget")
        with open(skin_path, "r") as f:
            self.skin = f.read()
        self["label"] = Label("")
        self["mosque"] = Label("")


class PrayerNotificationOverlay:
    def __init__(self, session):
        self.session = session
        self.dialog = None
        self.msg = ""
        self.play_sound = False
        self.close_timer = None
        self.timer = eTimer()
        try:
            self.timer.callback.append(self._initOverlay)
        except:
            self.timer.timeout.append(self._initOverlay)
        self.timer.start(1000, True)

    def _initOverlay(self):
        if not self.dialog:
            self.dialog = self.session.instantiateDialog(PrayerOverlayScreen)
            self.dialog.hide()
            self.dialog.onShow.append(self._onShow)
            self.dialog.onHide.append(self._onHide)

    def _onShow(self):
        duration = getPopupDuration()
        if duration == 0:
            return
        if self.msg:
            self.dialog["label"].setText(safe_label_text(self.msg))
            self.dialog["mosque"].setText(safe_label_text(self.mosque))
            self.dialog.show()
            if self.play_sound and isSoundEnabled():
                self._playSound()
            self.close_timer = eTimer()
            try:
                self.close_timer.callback.append(self.dialog.hide)
            except:
                self.close_timer.timeout.append(self.dialog.hide)
            self.close_timer.start(duration)

    def _onHide(self):
        if self.dialog and self.dialog.shown:
            self.dialog.hide()

    def showMessage(self, msg, play_sound=False):
        if self.dialog:
            self.dialog.close()
        self.dialog = self.session.instantiateDialog(PrayerOverlayScreen)
        self.msg = msg
        self.mosque = getMosqueName()
        self.play_sound = play_sound
        self._onShow()

    def _playSound(self):
        SOUND_FILE = "/usr/lib/enigma2/python/Plugins/Extensions/Mawaqit/beep.wav"
        if not os.path.exists(SOUND_FILE):
            return
        alsa_available = os.path.exists("/dev/snd/controlC0") or os.path.exists("/dev/snd/pcmC0D0p")
        if alsa_available:
            try:
                self.audio = eConsoleAppContainer()
                cmd = 'gst-launch-1.0 -q filesrc location="%s" ! wavparse ! audioconvert ! audioresample ! alsasink device=plughw:0,0' % SOUND_FILE
                self.audio.execute(cmd)
                return
            except Exception:
                pass
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if not ref:
                return
            title = _("Time to Pray")
            snd_ref_str = "4097:0:0:0:0:0:0:0:0:0:%s:%s" % (SOUND_FILE, title) 
            snd_ref = eServiceReference(snd_ref_str)    
            self.session.nav.playService(snd_ref)
            self._restore_timer = eTimer()
            def restore_tv():
                try:
                    self.session.nav.playService(ref)
                except Exception:
                    pass
            try:
                self._restore_timer.callback.append(restore_tv)
            except:
                self._restore_timer.timeout.append(restore_tv)    
            self._restore_timer.start(3000, True)
        except Exception:
            pass

def getPopupDuration():
    value = config.plugins.mawaqit.popupDuration.value
    return {"5s": 5000, "10s": 10000, "20s": 20000, "30s": 30000}.get(value, 10000)

def isSoundEnabled():
    return config.plugins.mawaqit.playSound.value

def safe_label_text(s):
    PY2 = sys.version_info[0] < 3
    try:
        if s is None:
            return ""
        if PY2:
            if isinstance(s, unicode):
                s = s.encode("utf-8")
            else:
                s = str(s)
        else:
            if isinstance(s, bytes):
                s = s.decode("utf-8")
            else:
                s = str(s)
        return s.replace("\r", "")
    except Exception:
        return ""

def showPrayerPopup(text, play_sound=False):
    if overlay_instance:
        overlay_instance.showMessage(text, play_sound)

def getMosqueName():
    try:
        storage_path = config.plugins.mawaqit.storageLocation.value
        path = os.path.join(storage_path, "data.json")
        if os.path.exists(path):
            with open(path, "r") as f:
                data = json.load(f)
                return data.get("label", _("Unbekannte Moschee"))
    except Exception:
        pass
    return _("Unbekannte Moschee")


class MyTextInput:
    def __init__(self, nextFunc=None, key_timeout=1000, lang="en_EN"):
        self.nextFunction = nextFunc
        self.key_timeout = key_timeout
        self.timer = eTimer()
        self.timer.callback.append(self.timeout)
        self.lang = lang
        self.mapping = []
        self.langMap(lang)
        self.lastKey = -1
        self.pos = -1
        self.Text = ""
        self.currPos = 0
        self.offset = 0
        self.overwrite = False

    def langMap(self, lang):
        self.lang = lang
        base_map = [
            u'0 , & = * \' + " \\ $ ( ) ~ < > [ ] { } @ ? !', u'1 \xa0 # . % _ : / | ; - ^ §',]

        lang_map = {
            "de_DE": [u'2 a b c A B C ä Ä', u'3 d e f D E F', u'4 g h i G H I', u'5 j k l J K L',
                u'6 m n o M N O ö Ö', u'7 p q r s P Q R S ß', u'8 t u v T U V ü Ü', u'9 w x y z W X Y Z',],
            "en_EN": [u'2 a b c A B C', u'3 d e f D E F', u'4 g h i G H I', u'5 j k l J K L', 
                u'6 m n o M N O', u'7 p q r s P Q R S', u'8 t u v T U V', u'9 w x y z W X Y Z',],
            "ar_AE": [u'ب  ت  ة  ث  2', u'ا  ء  أ  ؤ  ى  3', u'ص  ش  س  ط  4', u' ذ  ر  ز  ض 5',
                u'ج  ح  خ  د  6', u' ن  ه  و  ي  ئ 7', u' ق  ك  ل  م 8', u'ظ  ع  غ  ف  9',],
            "es_ES": [u'2abcčáàABCČÁÀ', u'3deféèěDEFÉÈĚ', u'4ghi í ì GHI Í Ì', u'5jkl ĺ JKLĹ',
                u'6mnoñŋńóòMNOÑŃŇÓÒ', u'7pqrsŕPQRSŔ', u'8tuvúùTUVÚÙ', u'9wxyzWXYZ',],
            "fr_FR": [u'2 abc ABC àâá çćč', u'3 def DEF èêé', u'4 ghi GHI ì î í', u'5 jkl JKL ń',
                u'6 mno MNO òôó', u'7 pqrs PQRS ś', u'8 tuv TUV ùûú', u'9 wxyz WXYZ',],
            "tr_TR": [u'2 a b c A B C ç Ç', u'3 d e f D E F', u'4 g h i G H I ğ Ğ ı İ', u'5 j k l J K L',
                u'6 m n o M N O ö Ö', u'7 p q r s P Q R S ş Ş', u'8 t u v T U V ü Ü', u'9 w x y z W X Y Z',],
            "pt_PT": [u'2 abc ABC áàâãç ÁÀÂÃÇ', u'3 def DEF éê ÉÊ', u'4 ghi GHI í Í', u'5 jkl JKL', 
                u'6 mno MNO óôõ ÓÔÕ', u'7 pqrs PQRS', u'8 tuv TUV úÚ', u'9 wxyz WXYZ',]}
        self.mapping = base_map + lang_map[lang]

    def getKey(self, num):
        if self.lastKey != num:
            if self.lastKey != -1:
                self.finalizeChar()
            self.lastKey = num
            self.pos = -1
        if self.timer:
            self.timer.start(self.key_timeout, True)
        while True:
            self.pos += 1
            if self.pos >= len(self.mapping[num]):
                self.pos = 0
            char = self.mapping[num][self.pos]
            if char != " ":
                break
        return char

    def insertChar(self, ch, owr=False, ins=False):
        pos = self.currPos
        if ins:
            self.Text = self.Text[:pos] + ch + self.Text[pos:]
        elif owr or self.overwrite:
            if pos < len(self.Text):
                self.Text = self.Text[:pos] + ch + self.Text[pos+1:]
            else:
                self.Text += ch
        else:
            if pos < len(self.Text):
                self.Text = self.Text[:pos] + ch + self.Text[pos+1:]
            else:
                self.Text += ch
        if not self.lastKey or owr == False:
            self.currPos += 1

    def handleNumberKey(self, num):
        owr = (self.lastKey == num)
        char = self.getKey(num)
        if char is None:
            return
        if owr:
            if self.currPos < len(self.Text):
                self.Text = self.Text[:self.currPos] + char + self.Text[self.currPos+1:]
            else:
                self.Text = self.Text + char
        else:
            self.Text = self.Text[:self.currPos] + char + self.Text[self.currPos:]
        if self.nextFunction:
            self.nextFunction()

    def finalizeChar(self):
        self.lastKey = -1
        self.pos = -1
        if self.currPos < len(self.Text):
            self.currPos += 1
        if self.nextFunction:
            self.nextFunction()

    def timeout(self):
        if self.lastKey != -1:
            self.finalizeChar()

    def moveLeft(self):
        if self.currPos > 0:
            self.currPos -= 1
            if self.nextFunction:
                self.nextFunction()

    def moveRight(self):
        if self.currPos < len(self.Text):
            self.currPos += 1
            if self.nextFunction:
                self.nextFunction()

    def deleteBackward(self):
        if self.currPos > 0:
            self.Text = self.Text[:self.currPos-1] + self.Text[self.currPos:]
            self.currPos -= 1
            if self.nextFunction:
                self.nextFunction()

    def deleteForward(self):
        if self.currPos < len(self.Text):
            self.Text = self.Text[:self.currPos] + self.Text[self.currPos+1:]
            if self.nextFunction:
                self.nextFunction()

    def getGuiCursorPos(self):
        if self.lang.startswith("ar") or self.lang.startswith("he"):
            return len(self.Text) - self.currPos
        else:
            return self.currPos