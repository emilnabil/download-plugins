# -*- coding: utf-8 -*-
import os
import gettext
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

PLUGIN_NAME = "Mawaqit"
PLUGIN_LOCALE_PATH = "Extensions/Mawaqit/locale"

def localeInit():
    lang = language.getLanguage()[:2]
    IS_DREAMOS = os.path.exists("/var/lib/dpkg/status")

    if IS_DREAMOS:
        os.environ["LANGUAGE"] = lang
        os.environ["LC_ALL"] = lang

    gettext.bindtextdomain(PLUGIN_NAME, resolveFilename(SCOPE_PLUGINS, PLUGIN_LOCALE_PATH))
    gettext.textdomain(PLUGIN_NAME)

def _(txt):
    translated = gettext.dgettext(PLUGIN_NAME, txt)
    if translated == txt:
        translated = gettext.gettext(txt)
    return translated

localeInit()
language.addCallback(localeInit)