# -*- coding: utf-8 -*-
global PICON_CACHE
from Components.Renderer.Picon import getPiconName
from Tools.LoadPixmap import LoadPixmap
from enigma import iServiceInformation, eServiceCenter
import os
import time
import hashlib
from PIL import Image

PICON_CACHE = {}

def getBestCachePath():
    """تحديد أفضل مسار لتخزين البيكونات. تفضل HDD إذا كان موجوداً، وإلا تستخدم tmp."""
    hdd_paths = ['/media/hdd/', '/media/usb/', '/media/mmc/', '/media/cf/']
    for path in hdd_paths:
        if os.path.exists(path) and os.path.ismount(path):
            try:
                stat = os.statvfs(path)
                free_space = stat.f_frsize * stat.f_bavail / 1048576  # MB
                if free_space > 100:
                    cache_dir = os.path.join(path, 'picons_cache/')
                    os.makedirs(cache_dir, exist_ok=True)
                    return cache_dir
            except:
                pass
    tmp_dir = '/tmp/picons_cache/'
    os.makedirs(tmp_dir, exist_ok=True)
    return tmp_dir

def cleanPiconCache(days=30):
    """تنظيف ملفات البيكون القديمة من HDD.
       days: عدد الأيام للاحتفاظ بالملفات (افتراضي 30 يوم)"""
    cache_path = getBestCachePath()
    if not os.path.exists(cache_path):
        return
    current_time = time.time()
    deleted_count = 0
    try:
        for filename in os.listdir(cache_path):
            file_path = os.path.join(cache_path, filename)
            if not os.path.isfile(file_path):
                continue
            file_age_days = (current_time - os.path.getmtime(file_path)) / 86400
            if file_age_days > days:
                os.remove(file_path)
                deleted_count += 1
        if deleted_count > 0:
            print(f'[Picon] Cleaned {deleted_count} old picon files')
    except Exception as e:
        print(f'[Picon] Error cleaning cache: {e}')

def getPicon(service, size=(40, 40)):
    """الحصول على صورة القناة (Picon) وتحجيمها.
       تستخدم ذاكرة تخزين مؤقتة وملفات محفوظة في HDD لتسريع الأداء.
       service: مرجع الخدمة، size: حجم الصورة المطلوب
       المخرج: الصورة المحجمة أو None في حالة الفشل"""
    sref = service.toString()
    if sref in PICON_CACHE:
        return PICON_CACHE[sref]

    png = getPiconName(sref)
    if not png or not os.path.exists(png):
        PICON_CACHE[sref] = None
        return None

    # Use or create a persistent cache directory
    if not hasattr(getPicon, 'cache_path'):
        getPicon.cache_path = getBestCachePath()
        # Clean old files once per session
        try:
            cleanPiconCache(30)
        except:
            pass

    # Compute hash of the original picon path to use as filename
    file_hash = hashlib.md5(png.encode()).hexdigest()
    cached_filename = f'picon_{file_hash}.png'
    cached_path = os.path.join(getPicon.cache_path, cached_filename)

    # Check if already resized and cached on disk
    if os.path.exists(cached_path):
        pixmap = LoadPixmap(cached_path)
        if pixmap:
            PICON_CACHE[sref] = pixmap
            return pixmap

    # Load original, resize, save to disk, and load pixmap
    try:
        img = Image.open(png)
        img = img.resize(size, Image.LANCZOS)
        img.save(cached_path, 'PNG')
        pixmap = LoadPixmap(cached_path)
        PICON_CACHE[sref] = pixmap
        return pixmap
    except Exception as e:
        print(f'[Picon] Error loading picon: {e}')
        PICON_CACHE[sref] = None
        return None

def getSatelliteName(orbpos):
    """تحويل رقم القمر الصناعي إلى اسم مقروء (مثال: 192 -> 19.2E)."""
    if orbpos > 1800:
        return '%.1fW' % ((3600 - orbpos) / 10.0)
    else:
        return '%.1fE' % (orbpos / 10.0)

def getChannelType(service):
    """تحديد نوع القناة: TV, Radio, أو IPTV."""
    sref = service.toString()
    if '%3a//' in sref or 'http' in sref:
        return 'IPTV'
    # service.getData(0) returns the type (0 = TV, 2 = Radio)
    service_type = service.getData(0) if hasattr(service, 'getData') else None
    if service_type == 2:
        return 'Radio'
    return 'TV'

def getChannelQuality(info, service):
    """تحديد جودة القناة: HD, SD, أو غير معروف."""
    width = info.getInfo(service, iServiceInformation.sVideoWidth)
    height = info.getInfo(service, iServiceInformation.sVideoHeight)
    if width >= 1280 or height >= 720:
        return 'HD'
    if width > 0:
        return 'SD'
    # Fallback: check name for 'hd'
    name = info.getName(service).lower()
    if 'hd' in name:
        return 'HD'
    if getChannelType(service) == 'TV':
        return 'SD'
    return '-'
