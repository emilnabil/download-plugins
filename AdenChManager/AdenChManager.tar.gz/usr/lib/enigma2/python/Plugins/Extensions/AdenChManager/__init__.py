# -*- coding: utf-8 -*-
from Plugins.Extensions.AdenChManager.plugin import main, Plugins