# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.ChoiceBox import ChoiceBox
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Tools.LoadPixmap import LoadPixmap
from enigma import eServiceCenter, eServiceReference, eListboxPythonMultiContent, gFont, eDVBDB, iServiceInformation, eTimer
from twisted.internet import reactor
import os
import time
from functools import partial
from Plugins.Extensions.AdenChManager.utils import getPicon, getSatelliteName, getChannelType, getChannelQuality

class ConfirmationDialog(Screen):
    """شاشة تأكيد مخصصة بحجم صغير في وسط الشاشة - تظهر فوق الشاشة السابقة"""
    skin = '\n    <screen position=\"center,center\" size=\"600,250\" title=\"Confirmation\" flags=\"wfNoBorder\">\n        <widget name=\"message1\" position=\"20,30\" size=\"560,40\" font=\"Regular;24\" halign=\"center\" valign=\"center\" foregroundColor=\"#ffffff\"/>\n        <widget name=\"message2\" position=\"20,70\" size=\"560,50\" font=\"Regular;28\" halign=\"center\" valign=\"center\" foregroundColor=\"#ffff00\"/>\n        <widget name=\"message3\" position=\"20,120\" size=\"560,40\" font=\"Regular;24\" halign=\"center\" valign=\"center\" foregroundColor=\"#ffffff\"/>\n\n        <widget name=\"key_red\" position=\"70,180\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Cancel\"/>\n        <widget name=\"key_green\" position=\"390,180\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"Confirm\"/>\n    </screen>\n    '
    def __init__(self, session, message_type, item_name):
        Screen.__init__(self, session)
        self.session = session
        self.item_name = item_name
        self.message_type = message_type
        if message_type == 'bouquet':
            self['message1'] = Label('Are you sure you want to delete this bouquet?')
            self['message3'] = Label('This action cannot be undone!')
        else:
            self['message1'] = Label('Are you sure you want to remove this channel?')
            self['message3'] = Label('This action cannot be undone!')
        self['message2'] = Label(f'\"{item_name}\"')
        self['key_red'] = Label('Cancel')
        self['key_green'] = Label('Confirm')
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'red': self.cancel, 'green': self.confirm, 'cancel': self.cancel}, -1)
        self.setTitle('Confirmation')
        self.onExecBegin.append(self.bringToFront)

    def bringToFront(self):
        try:
            self.instance.raise_()
        except:
            pass

    def cancel(self):
        self.close(False)

    def confirm(self):
        self.close(True)

class MenuListScreen(Screen):
    """شاشة قائمة خيارات بنفس أسلوب namefinder.py"""
    skin = '\n    <screen position=\"center,center\" size=\"500,500\" title=\"Options\">\n        <widget name=\"list\" position=\"10,10\" size=\"480,440\" itemHeight=\"38\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n    </screen>\n    '
    def __init__(self, session, menu, parent):
        Screen.__init__(self, session)
        self.parent = parent
        self.closed = False
        formatted_menu = []
        for item in menu:
            formatted_menu.append(item)
            if item[1] == 'separator':
                formatted_menu.append(('--------------------', 'separator'))
        self['list'] = MenuList(formatted_menu)
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.ok, 'cancel': self.cancel}, -1)

    def ok(self):
        if self.closed:
            return
        current = self['list'].getCurrent()
        if current and current[1] != 'separator':
            action = current[1]
            try:
                if hasattr(self.parent, 'handleMenuAction'):
                    self.parent.handleMenuAction(action)
            except Exception as e:
                print('[MenuListScreen] Error:', e)
        self.closed = True
        self.close()

    def cancel(self):
        self.closed = True
        self.close()

class SmallConfirmScreen(Screen):
    """شاشة تأكيد صغيرة في منتصف الشاشة مع اختيار Yes / No في سطر واحد والاختيار الافتراضي = No"""
    skin = '\n    <screen position=\"center,center\" size=\"700,230\" title=\"Confirm\" flags=\"wfNoBorder\">\n        <widget name=\"message\" position=\"20,20\" size=\"660,130\" font=\"Regular;28\" halign=\"center\" valign=\"center\"/>\n        <widget name=\"choices\" position=\"20,165\" size=\"660,35\" font=\"Regular;30\" halign=\"center\" valign=\"center\"/>\n    </screen>\n    '
    def __init__(self, session, message):
        Screen.__init__(self, session)
        self.session = session
        self.selection = False
        self['message'] = Label(message)
        self['choices'] = Label('')
        self.updateChoices()
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions'], {'ok': self.okPressed, 'cancel': self.noPressed, 'left': self.leftPressed, 'right': self.rightPressed, 'up': self.leftPressed, 'down': self.rightPressed}, -1)

    def updateChoices(self):
        if self.selection:
            self['choices'].setText('No      [Yes]')
        else:
            self['choices'].setText('[No]      Yes')

    def okPressed(self):
        self.close(self.selection)

    def noPressed(self):
        self.close(False)

    def yesPressed(self):
        self.close(True)

    def leftPressed(self):
        self.selection = False
        self.updateChoices()

    def rightPressed(self):
        self.selection = True
        self.updateChoices()

def openSmallConfirm(session, callback, message):
    session.openWithCallback(callback, SmallConfirmScreen, message)

class SatelliteSelectionScreen(Screen):
    """شاشة اختيار الأقمار الصناعية بشكل متعدد"""
    skin = '\n    <screen position=\"center,center\" size=\"560,520\" title=\"Select Satellites\">\n        <widget name=\"title_label\" position=\"10,10\" size=\"540,30\" font=\"Regular;26\" halign=\"center\" foregroundColor=\"#00aaff\"/>\n        <widget name=\"help_label\" position=\"10,45\" size=\"540,28\" font=\"Regular;20\" halign=\"center\" foregroundColor=\"#cccccc\"/>\n        <widget name=\"list\" position=\"10,85\" size=\"540,370\" itemHeight=\"36\" font=\"Regular;24\" scrollbarMode=\"showOnDemand\"/>\n\n        <widget name=\"key_red\" position=\"10,475\" size=\"120,35\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Cancel\"/>\n        <widget name=\"key_green\" position=\"150,475\" size=\"120,35\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"All\"/>\n        <widget name=\"key_yellow\" position=\"290,475\" size=\"120,35\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#ffff00\" text=\"Toggle\"/>\n        <widget name=\"key_blue\" position=\"430,475\" size=\"120,35\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#00aaff\" text=\"None\"/>\n    </screen>\n    '
    def __init__(self, session, satellites, selected_satellites=None):
        Screen.__init__(self, session)
        self.session = session
        self.satellites = list(satellites or [])
        self.selected_satellites = set(selected_satellites or [])
        self['title_label'] = Label('Select Satellites')
        self['help_label'] = Label('OK=Toggle  |  GREEN=Select All  |  YELLOW=Apply  |  BLUE=Clear All')
        self['list'] = MenuList([])
        self['key_red'] = Label('Cancel')
        self['key_green'] = Label('All')
        self['key_yellow'] = Label('Apply')
        self['key_blue'] = Label('None')
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.toggleCurrent, 'cancel': self.cancel, 'red': self.cancel, 'green': self.selectAll, 'yellow': self.apply, 'blue': self.clearAll}, -1)
        self.refreshList()

    def refreshList(self):
        items = []
        for sat in self.satellites:
            prefix = '[x]' if sat in self.selected_satellites else '[ ]'
            items.append((f'{prefix} {sat}', sat))
        self['list'].setList(items)

    def toggleCurrent(self):
        current = self['list'].getCurrent()
        if not current:
            return
        sat = current[1]
        if sat in self.selected_satellites:
            self.selected_satellites.remove(sat)
        else:
            self.selected_satellites.add(sat)
        self.refreshList()

    def selectAll(self):
        self.selected_satellites = set(self.satellites)
        self.refreshList()

    def clearAll(self):
        self.selected_satellites.clear()
        self.refreshList()

    def cancel(self):
        self.close(None)

    def apply(self):
        self.close(sorted(self.selected_satellites, key=lambda x: x.lower()))

    def okPressed(self):
        self.toggleCurrent()

    def keySave(self):
        self.apply()

    def greenPressed(self):
        self.selectAll()

    def yellowPressed(self):
        self.toggleCurrent()

    def bluePressed(self):
        self.clearAll()

    def closeScreen(self):
        self.apply()

class BouquetFilterScreen(Screen):
    """شاشة فلترة متقدمة لمحتويات الباقة"""
    skin = '\n    <screen position=\"center,center\" size=\"620,500\" title=\"Select Filter\">\n        <widget name=\"title_label\" position=\"10,10\" size=\"600,30\" font=\"Regular;26\" halign=\"center\" foregroundColor=\"#00aaff\"/>\n        <widget name=\"satellite_label\" position=\"10,50\" size=\"600,28\" font=\"Regular;22\" halign=\"left\" foregroundColor=\"#ffff99\"/>\n        <widget name=\"help_label\" position=\"10,80\" size=\"600,28\" font=\"Regular;20\" halign=\"left\" foregroundColor=\"#cccccc\"/>\n        <widget name=\"list\" position=\"10,120\" size=\"600,300\" itemHeight=\"38\" font=\"Regular;24\" scrollbarMode=\"showOnDemand\"/>\n\n        <widget name=\"key_red\" position=\"10,450\" size=\"130,35\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Cancel\"/>\n        <widget name=\"key_green\" position=\"160,450\" size=\"130,35\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"Apply\"/>\n        <widget name=\"key_yellow\" position=\"310,450\" size=\"130,35\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#ffff00\" text=\"Satellite\"/>\n        <widget name=\"key_blue\" position=\"460,450\" size=\"130,35\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#00aaff\" text=\"Clear Sat\"/>\n    </screen>\n    '
    FILTER_ITEMS = [('tv', 'TV'), ('radio', 'Radio'), ('iptv', 'IPTV'), ('hd', 'HD'), ('sd', 'SD'), ('scr', 'SCR'), ('fta', 'FTA')]

    def __init__(self, session, filter_state, selected_satellites, satellites):
        Screen.__init__(self, session)
        self.session = session
        self.filter_state = dict(filter_state or {})
        self.selected_satellites = set(selected_satellites or [])
        self.satellites = list(satellites or [])
        self['title_label'] = Label('Select Filter')
        self['satellite_label'] = Label('')
        self['help_label'] = Label('OK=Toggle  |  YELLOW=Satellite  |  BLUE=Clear Satellite')
        self['list'] = MenuList([])
        self['key_red'] = Label('Cancel')
        self['key_green'] = Label('Apply')
        self['key_yellow'] = Label('Satellite')
        self['key_blue'] = Label('Clear Sat')
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.toggleCurrent, 'cancel': self.cancel, 'red': self.cancel, 'green': self.apply, 'yellow': self.openSatelliteMenu, 'blue': self.clearSatellite}, -1)
        self.refreshList()

    def isOptionDisabled(self, key):
        if key in ['hd', 'sd'] and not self.filter_state.get('tv'):
            return True
        return False

    def getOptionText(self, key, title):
        value = self.filter_state.get(key, False)
        disabled = self.isOptionDisabled(key)
        if disabled:
            prefix = '[-]'
            if key in ['hd', 'sd']:
                return f'{prefix} {title} (TV only)'
            else:
                return f'{prefix} {title}'
        else:
            prefix = '[x]' if value else '[ ]'
            return f'{prefix} {title}'

    def refreshList(self):
        items = []
        for key, title in self.FILTER_ITEMS:
            items.append((self.getOptionText(key, title), key))
        self['list'].setList(items)
        self.updateSatelliteLabel()

    def updateSatelliteLabel(self):
        if not self.selected_satellites:
            sat_text = 'All'
        else:
            if len(self.selected_satellites) == 1:
                sat_text = list(self.selected_satellites)[0]
            else:
                sat_text = '%d selected' % len(self.selected_satellites)
        self['satellite_label'].setText(f'Satellite: {sat_text}')

    def toggleCurrent(self):
        current = self['list'].getCurrent()
        if not current:
            return
        key = current[1]
        if self.isOptionDisabled(key):
            return
        new_value = not self.filter_state.get(key, False)
        self.filter_state[key] = new_value
        if key == 'tv' and not new_value:
            self.filter_state['hd'] = False
            self.filter_state['sd'] = False
        if key == 'hd' and new_value:
            self.filter_state['sd'] = False
        elif key == 'sd' and new_value:
            self.filter_state['hd'] = False
        if key == 'scr' and new_value:
            self.filter_state['fta'] = False
        elif key == 'fta' and new_value:
            self.filter_state['scr'] = False
        self.refreshList()

    def openSatelliteMenu(self):
        if not self.satellites:
            showMessage(self.session, 'No satellites found.', MessageBox.TYPE_INFO)
        else:
            self.session.openWithCallback(self.satelliteSelected, SatelliteSelectionScreen, self.satellites, sorted(self.selected_satellites, key=lambda x: x.lower()))

    def satelliteSelected(self, selected_list):
        if selected_list is not None:
            self.selected_satellites = set(selected_list)
            self.updateSatelliteLabel()

    def clearSatellite(self):
        self.selected_satellites.clear()
        self.updateSatelliteLabel()

    def apply(self):
        self.close({'filter_state': dict(self.filter_state), 'satellites': sorted(self.selected_satellites, key=lambda x: x.lower())})

    def cancel(self):
        self.close(None)

def getFolderIcon():
    """الحصول على أيقونة المجلد من المسار: icons/folder.png داخل مجلد البلاجين"""
    current_dir = os.path.dirname(__file__)
    folder_icon_path = os.path.join(current_dir, 'icons', 'folder.png')
    if os.path.exists(folder_icon_path):
        print(f'[BouquetsManager] Loading folder icon from: {folder_icon_path}')
        return LoadPixmap(folder_icon_path)
    else:
        print(f'[BouquetsManager] Folder icon not found at: {folder_icon_path}')
        old_path = os.path.join(current_dir, 'folder.png')
        if os.path.exists(old_path):
            print(f'[BouquetsManager] Found icon in old location: {old_path}')
            return LoadPixmap(old_path)
        else:
            return None

class SmallMessageBox(MessageBox):
    skin = '\n    <screen position=\"center,center\" size=\"760,220\" title=\"Message\">\n        <widget name=\"text\" position=\"20,20\" size=\"720,120\" font=\"Regular;28\" halign=\"center\" valign=\"center\" />\n        <widget source=\"list\" render=\"Listbox\" position=\"160,155\" size=\"440,40\" scrollbarMode=\"showNever\">\n            <convert type=\"StringList\" />\n        </widget>\n    </screen>\n    '

def showMessage(session, text, type=MessageBox.TYPE_INFO):
    """عرض الرسائل في نافذة صغيرة بمنتصف الشاشة"""
    reactor.callLater(0.1, lambda: session.open(SmallMessageBox, text, type))

class ChannelInfoScreen(Screen):
    """شاشة عرض معلومات مفصلة عن القناة المحددة"""
    skin = '\n    <screen position=\"center,center\" size=\"600,400\" title=\"Channel Information\">\n        <widget name=\"info\" position=\"10,10\" size=\"580,360\" font=\"Regular;24\" />\n    </screen>\n    '
    def __init__(self, session, service):
        Screen.__init__(self, session)
        info = eServiceCenter.getInstance().info(service)
        name = info.getName(service)
        sref = service.toString()
        info_text = 'Channel Name: %s\n\n' % name
        info_text += 'Service Reference: %s\n\n' % sref
        tp = info.getInfoObject(service, iServiceInformation.sTransponderData)
        if tp:
            if 'frequency' in tp:
                info_text += 'Frequency: %s MHz\n' % str(int(tp['frequency'] / 1000))
            if 'symbol_rate' in tp:
                info_text += 'Symbol Rate: %s\n' % str(tp['symbol_rate'])
            if 'polarization' in tp:
                pol = {0: 'Horizontal', 1: 'Vertical', 2: 'Circular Left', 3: 'Circular Right'}
                info_text += 'Polarization: %s\n' % pol.get(tp['polarization'], 'Unknown')
            if 'orbital_position' in tp:
                info_text += 'Satellite: %s\n' % getSatelliteName(tp['orbital_position'])
        self['info'] = Label(info_text)
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.close, 'cancel': self.close}, -1)

class BouquetSelectionScreen(Screen):
    """شاشة اختيار باقة الهدف لنسخ قناة أو قنوات إليها"""
    skin = '\n    <screen position=\"center,center\" size=\"500,380\" title=\"Select Bouquet\">\n        <widget name=\"list\" position=\"10,10\" size=\"480,340\" itemHeight=\"38\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n    </screen>\n    '
    def __init__(self, session, bouquets, parent, multiple=False):
        Screen.__init__(self, session)
        self.parent = parent
        self.multiple = multiple
        self.bouquets = bouquets
        self.closed = False
        self['list'] = MenuList(bouquets)
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.ok, 'cancel': self.cancel}, -1)

    def ok(self):
        if self.closed:
            return
        current = self['list'].getCurrent()
        if current and self.parent:
            try:
                if self.multiple:
                    if hasattr(self.parent, 'copyMultipleToBouquetSelected'):
                        self.parent.copyMultipleToBouquetSelected(current)
                else:
                    if hasattr(self.parent, 'copyToBouquetSelected'):
                        self.parent.copyToBouquetSelected(current)
            except Exception as e:
                print('[BouquetSelectionScreen] Error:', e)
        self.closed = True
        self.close()

    def cancel(self):
        self.closed = True
        self.close()

class BouquetsManager(Screen):
    """الشاشة الرئيسية لإدارة الباقات - تعرض قائمة بجميع الباقات المتاحة"""
    skin = '\n    <screen position=\"center,center\" size=\"900,600\" title=\"Bouquets Manager\">\n        <widget name=\"title_label\" position=\"10,10\" size=\"780,30\" font=\"Regular;26\" halign=\"center\" foregroundColor=\"#00aaff\"/>\n\n        <widget name=\"list\" position=\"10,80\" size=\"880,465\" itemHeight=\"42\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n\n        <widget name=\"key_red\" position=\"10,560\" size=\"130,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Back\"/>\n        <widget name=\"key_green\" position=\"120,560\" size=\"130,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"Add New\"/>\n        <widget name=\"key_yellow\" position=\"260,560\" size=\"160,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffff00\" text=\"Move Bouquet\"/>\n        <widget name=\"key_blue\" position=\"420,560\" size=\"130,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00aaff\" text=\"Rename\"/>\n        <widget name=\"key_menu\" position=\"560,560\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffffff\" text=\"Menu\"/>\n\n        <widget name=\"info_label\" position=\"10,40\" size=\"780,30\" font=\"Regular;24\" halign=\"left\" foregroundColor=\"#cccccc\"/>\n    </screen>\n    '
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.bouquets = []
        self.selected_bouquet = None
        self.serviceHandler = eServiceCenter.getInstance()
        self.move_mode_active = False
        self.selected_bouquet_index = -1
        self._confirmTimer = eTimer()
        self._confirmTimer.callback.append(self._doOpenConfirm)
        self._confirmCallback = None
        self._confirmMessage = None
        self.folder_icon = getFolderIcon()
        print('[BouquetsManager] Using text fallback for folder icon')
        self.loadBouquets()
        self['title_label'] = Label('Bouquets Manager - Select a bouquet')
        self['list'] = MenuList([], False, eListboxPythonMultiContent)
        self['list'].l.setFont(0, gFont('Regular', 26))
        self['list'].l.setItemHeight(42)
        self['key_red'] = Label('Back')
        self['key_green'] = Label('Add New')
        self['key_yellow'] = Label('Move Bouquet')
        self['key_blue'] = Label('Rename')
        self['key_menu'] = Label('Menu')
        self['info_label'] = Label(f'Total: {len(self.bouquets)} bouquets')
        self['list'].onSelectionChanged.append(self.selectionChanged)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'MenuActions', 'DirectionActions'], {'ok': self.openBouquet, 'cancel': self.close, 'red': self.close, 'green': self.addNewBouquet, 'yellow': self.toggleMoveMode, 'blue': self.renameBouquet, 'menu': self.openBouquetMenu, 'up': self.moveUp, 'down': self.moveDown, 'left': self.moveLeft, 'right': self.moveRight}, -1)
        self.updateList()

    def selectionChanged(self):
        current_index = self['list'].getSelectedIndex()
        if current_index is not None and 0 <= current_index < len(self.bouquets):
            self.selected_bouquet = (self.bouquets[current_index]['name'], self.bouquets[current_index]['ref'], self.bouquets[current_index]['type'], self.bouquets[current_index]['path'])
            print(f'[BouquetsManager] Selected: {self.selected_bouquet[0]}')

    def loadBouquets(self):
        self.bouquets = []
        print('[BouquetsManager] ===== LOADING BOUQUETS =====')
        tv_bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        tv_list = self.serviceHandler.list(tv_bouquet_root)
        if tv_list:
            tv_index = 0
            while True:
                bouquet = tv_list.getNext()
                if not bouquet.valid():
                    break
                info = self.serviceHandler.info(bouquet)
                name = info.getName(bouquet)
                print(f'[BouquetsManager] Loading TV bouquet {tv_index}: \'{name}\'')
                if name.startswith('(TV) '):
                    name = name[5:]
                elif name.startswith('TV '):
                    name = name[3:]
                if not name or name.strip() == '':
                    path = self.getBouquetPath(bouquet)
                    if path and os.path.exists(path):
                        try:
                            with open(path, 'r') as f:
                                first_line = f.readline().strip()
                                if first_line.startswith('#NAME '):
                                    name = first_line[6:].strip()
                                    print(f'[BouquetsManager] Read name from file: \'{name}\'')
                        except:
                            pass
                if not name or name.strip() == '':
                    name = 'Unnamed'
                ref_str = bouquet.toString()
                print(f'[BouquetsManager] TV bouquet {tv_index} reference: {ref_str[:50]}...')
                self.bouquets.append({'name': name, 'ref': bouquet, 'type': 'tv', 'path': self.getBouquetPath(bouquet)})
                tv_index += 1

        radio_bouquet_root = eServiceReference('1:7:2:0:0:0:0:0:0:0:(type == 2) FROM BOUQUET "bouquets.radio" ORDER BY bouquet')
        radio_list = self.serviceHandler.list(radio_bouquet_root)
        if radio_list:
            radio_index = 0
            while True:
                bouquet = radio_list.getNext()
                if not bouquet.valid():
                    break
                info = self.serviceHandler.info(bouquet)
                name = info.getName(bouquet)
                print(f'[BouquetsManager] Loading Radio bouquet {radio_index}: \'{name}\'')
                if name.startswith('(Radio) '):
                    name = name[8:]
                elif name.startswith('Radio '):
                    name = name[6:]
                if not name or name.strip() == '':
                    path = self.getBouquetPath(bouquet)
                    if path and os.path.exists(path):
                        try:
                            with open(path, 'r') as f:
                                first_line = f.readline().strip()
                                if first_line.startswith('#NAME '):
                                    name = first_line[6:].strip()
                                    print(f'[BouquetsManager] Read name from file: \'{name}\'')
                        except:
                            pass
                if not name or name.strip() == '':
                    name = 'Unnamed'
                ref_str = bouquet.toString()
                print(f'[BouquetsManager] Radio bouquet {radio_index} reference: {ref_str[:50]}...')
                self.bouquets.append({'name': name, 'ref': bouquet, 'type': 'radio', 'path': self.getBouquetPath(bouquet)})
                radio_index += 1

        print(f'[BouquetsManager] Total bouquets loaded: {len(self.bouquets)}')
        print('[BouquetsManager] ===== LOADING COMPLETE =====')

    def getBouquetPath(self, bouquet_ref):
        try:
            ref_str = bouquet_ref.toString()
            parts = ref_str.split('"')
            if len(parts) > 1:
                path = parts[1]
                if path.startswith('/'):
                    return path
                else:
                    return '/etc/enigma2/' + path
        except:
            pass
        return ''

    def updateList(self):
        listdata = []
        for idx, bouquet in enumerate(self.bouquets):
            if self.move_mode_active and idx == self.selected_bouquet_index:
                display_name = f'>>> {bouquet["name"]} <<<'
            else:
                display_name = bouquet['name']
            entry = []
            if self.folder_icon:
                entry.append(MultiContentEntryPixmapAlphaBlend(pos=(10, 5), size=(40, 40), png=self.folder_icon))
            else:
                entry.append(MultiContentEntryText(pos=(10, 5), size=(40, 40), font=0, text='[+]'))
            entry.append(MultiContentEntryText(pos=(60, 5), size=(750, 40), font=0, text=display_name))
            entry.append(MultiContentEntryText(pos=(780, 5), size=(200, 40), font=0, text=bouquet['type'].upper()))
            listdata.append(entry)
        self['list'].setList(listdata)
        if self.move_mode_active:
            self['info_label'].setText('Move Mode: Select bouquet with OK, then use UP/DOWN to move. Press YELLOW again to save.')
        else:
            self['info_label'].setText(f'Total: {len(self.bouquets)} bouquets')

    def getCurrentBouquet(self):
        current_index = self['list'].getSelectedIndex()
        if current_index is not None and 0 <= current_index < len(self.bouquets):
            bouquet = self.bouquets[current_index]
            return (bouquet['name'], bouquet['ref'], bouquet['type'], bouquet['path'])
        current = self['list'].getCurrent()
        if current and len(current) > 0 and isinstance(current[0], tuple):
            return current[0]
        return None

    def openBouquet(self):
        if self.move_mode_active:
            self.toggleBouquetSelection()
            return
        bouquet_data = self.getCurrentBouquet()
        if bouquet_data:
            name, ref, btype, path = bouquet_data
            self.session.open(BouquetContentsScreen, ref, name, btype)

    def toggleMoveMode(self):
        if not self.move_mode_active:
            self.move_mode_active = True
            self.selected_bouquet_index = -1
            self['key_yellow'].setText('Save Move')
            self['info_label'].setText('Move Mode: Press OK on bouquet to select, then UP/DOWN to move')
            print('[BouquetsManager] Move mode activated')
        else:
            print('[BouquetsManager] Saving bouquet order...')
            self.saveBouquetOrder()
        self.updateList()

    def toggleBouquetSelection(self):
        if not self.move_mode_active:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0 or current_index >= len(self.bouquets):
            return
        if self.selected_bouquet_index == -1:
            self.selected_bouquet_index = current_index
            self['info_label'].setText(f'Selected: {self.bouquets[current_index]["name"]}. Use UP/DOWN to move')
            print(f'[BouquetsManager] Selected bouquet: {self.bouquets[current_index]["name"]} at index {current_index}')
        else:
            if self.selected_bouquet_index == current_index:
                self.selected_bouquet_index = -1
                self['info_label'].setText('Move Mode: Press OK on bouquet to select')
                print('[BouquetsManager] Selection cancelled')
            else:
                self.selected_bouquet_index = current_index
                self['info_label'].setText(f'Selected: {self.bouquets[current_index]["name"]}. Use UP/DOWN to move')
                print(f'[BouquetsManager] Switched selection to: {self.bouquets[current_index]["name"]}')
        self.updateList()

    def moveBouquet(self, direction):
        if not self.move_mode_active or self.selected_bouquet_index == -1:
            return
        new_index = self.selected_bouquet_index
        if direction == 'up' and new_index > 0:
            new_index -= 1
        elif direction == 'down' and new_index < len(self.bouquets) - 1:
            new_index += 1
        else:
            return
        print(f'[BouquetsManager] Moving bouquet from index {self.selected_bouquet_index} to {new_index}')
        print(f'[BouquetsManager] Moving: {self.bouquets[self.selected_bouquet_index]["name"]}')
        self.bouquets[self.selected_bouquet_index], self.bouquets[new_index] = self.bouquets[new_index], self.bouquets[self.selected_bouquet_index]
        self.selected_bouquet_index = new_index
        self['list'].moveToIndex(new_index)
        self.updateList()

    def saveBouquetOrder(self):
        try:
            print('[BouquetsManager] ===== START SAVING BOUQUET ORDER =====')
            tv_bouquets_file = '/etc/enigma2/bouquets.tv'
            radio_bouquets_file = '/etc/enigma2/bouquets.radio'
            tv_bouquets = [b for b in self.bouquets if b['type'] == 'tv']
            radio_bouquets = [b for b in self.bouquets if b['type'] == 'radio']
            print(f'[BouquetsManager] TV bouquets: {len(tv_bouquets)}')
            print(f'[BouquetsManager] Radio bouquets: {len(radio_bouquets)}')
            if tv_bouquets:
                with open(tv_bouquets_file, 'w') as f:
                    for bouquet in tv_bouquets:
                        ref_str = bouquet['ref'].toString()
                        f.write(f'#SERVICE {ref_str}\n')
                print('[BouquetsManager] Saved TV bouquets')
            if radio_bouquets:
                with open(radio_bouquets_file, 'w') as f:
                    for bouquet in radio_bouquets:
                        ref_str = bouquet['ref'].toString()
                        f.write(f'#SERVICE {ref_str}\n')
                print('[BouquetsManager] Saved Radio bouquets')
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.saveServicelist()
            self.move_mode_active = False
            self.selected_bouquet_index = -1
            self['key_yellow'].setText('Move Bouquet')
            self.updateList()
            print('[BouquetsManager] Save completed')
            reactor.callLater(1, self.reloadBouquetsInBackground)
        except Exception as e:
            print(f'[BouquetsManager] ERROR: {e}')
            import traceback
            traceback.print_exc()

    def reloadBouquetsInBackground(self):
        try:
            print('[BouquetsManager] Reloading bouquets in background...')
            self.loadBouquets()
            self.updateList()
            print('[BouquetsManager] Background reload completed')
        except Exception as e:
            print(f'[BouquetsManager] Background reload error: {e}')

    def moveUp(self):
        if self.move_mode_active and self.selected_bouquet_index != -1:
            self.moveBouquet('up')
        else:
            if not self.bouquets:
                return
            current_index = self['list'].getSelectedIndex()
            if current_index is None or current_index < 0:
                return
            if current_index == 0:
                self['list'].moveToIndex(len(self.bouquets) - 1)
            else:
                self['list'].up()

    def moveDown(self):
        if self.move_mode_active and self.selected_bouquet_index != -1:
            self.moveBouquet('down')
        else:
            if not self.bouquets:
                return
            current_index = self['list'].getSelectedIndex()
            if current_index is None or current_index < 0:
                return
            if current_index == len(self.bouquets) - 1:
                self['list'].moveToIndex(0)
            else:
                self['list'].down()

    def moveLeft(self):
        if self.move_mode_active:
            return
        if not self.bouquets:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        items_per_page = 10
        new_index = max(0, current_index - items_per_page)
        self['list'].moveToIndex(new_index)

    def moveRight(self):
        if self.move_mode_active:
            return
        if not self.bouquets:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        items_per_page = 10
        new_index = min(len(self.bouquets) - 1, current_index + items_per_page)
        self['list'].moveToIndex(new_index)

    def addNewBouquet(self):
        if self.move_mode_active:
            return

        def nameCallback(name):
            if not name or not name.strip():
                return
            print(f'[BouquetsManager] Adding new bouquet with name: \'{name}\'')
            self.session.openWithCallback(partial(self.typeCallback, name), ChoiceBox, title='Select bouquet type', list=[('TV Bouquet', 'tv'), ('Radio Bouquet', 'radio')])

        self.session.openWithCallback(nameCallback, VirtualKeyBoard, title='Enter bouquet name')

    def typeCallback(self, name, choice):
        if not choice or not choice[1]:
            return
        btype = choice[1]
        print(f'[BouquetsManager] Creating bouquet: \'{name}\' type: {btype}')
        self.createNewBouquet(name, btype)

    def createNewBouquet(self, name, btype):
        try:
            safe_name = name.replace(' ', '_')
            if btype == 'tv':
                bouquet_ref = eServiceReference(f'1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.{safe_name}.tv" ORDER BY bouquet')
                bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
            else:
                bouquet_ref = eServiceReference(f'1:7:2:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.{safe_name}.radio" ORDER BY bouquet')
                bouquet_root = eServiceReference('1:7:2:0:0:0:0:0:0:0:(type == 2) FROM BOUQUET "bouquets.radio" ORDER BY bouquet')
            bouquet_list = self.serviceHandler.list(bouquet_root)
            if not bouquet_list:
                showMessage(self.session, 'Could not access bouquets list', MessageBox.TYPE_ERROR)
                return
            mutable = bouquet_list.startEdit()
            if not mutable:
                showMessage(self.session, 'Could not edit bouquets list', MessageBox.TYPE_ERROR)
                return
            mutable.addService(bouquet_ref)
            mutable.flushChanges()
            bouquet_filename = f'/etc/enigma2/userbouquet.{safe_name}.{btype}'
            with open(bouquet_filename, 'w') as f:
                f.write(f'#NAME {name}\n')
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.saveServicelist()
            time.sleep(0.5)
            self.loadBouquets()
            self.updateList()
        except Exception as e:
            print(f'[BouquetsManager] Error creating bouquet: {e}')
            showMessage(self.session, f'Error creating bouquet:\n{str(e)}', MessageBox.TYPE_ERROR)

    def renameBouquet(self):
        if self.move_mode_active:
            return
        bouquet_data = self.getCurrentBouquet()
        if not bouquet_data:
            return
        self.selected_bouquet = bouquet_data
        name = bouquet_data[0]

        def nameCallback(new_name):
            if not new_name or not new_name.strip():
                return
            new_name = new_name.strip()
            self.renameBouquetCallback(new_name)

        self.session.openWithCallback(nameCallback, VirtualKeyBoard, title=f'Rename bouquet: {name}', text=name)

    def renameBouquetCallback(self, new_name):
        if not self.selected_bouquet:
            return
        old_name, ref, btype, path = self.selected_bouquet
        try:
            print(f'[BouquetsManager] Renaming \'{old_name}\' to \'{new_name}\'')
            if btype == 'tv':
                bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
            else:
                bouquet_root = eServiceReference('1:7:2:0:0:0:0:0:0:0:(type == 2) FROM BOUQUET "bouquets.radio" ORDER BY bouquet')
            bouquet_list = self.serviceHandler.list(bouquet_root)
            if bouquet_list:
                mutable = bouquet_list.startEdit()
                if mutable:
                    mutable.removeService(ref)
                    mutable.flushChanges()
                    print('[BouquetsManager] Removed old reference')
            safe_new_name = new_name.replace(' ', '_')
            safe_old_name = old_name.replace(' ', '_')
            if btype == 'tv':
                new_ref = eServiceReference(f'1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.{safe_new_name}.tv" ORDER BY bouquet')
            else:
                new_ref = eServiceReference(f'1:7:2:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.{safe_new_name}.radio" ORDER BY bouquet')
            bouquet_list = self.serviceHandler.list(bouquet_root)
            if bouquet_list:
                mutable = bouquet_list.startEdit()
                if mutable:
                    mutable.addService(new_ref)
                    mutable.flushChanges()
                    print('[BouquetsManager] Added new reference')
            old_path = f'/etc/enigma2/userbouquet.{safe_old_name}.{btype}'
            new_path = f'/etc/enigma2/userbouquet.{safe_new_name}.{btype}'
            print(f'[BouquetsManager] Old path: {old_path}')
            print(f'[BouquetsManager] New path: {new_path}')
            if os.path.exists(old_path):
                with open(old_path, 'r') as f:
                    lines = f.readlines()
                if lines and lines[0].startswith('#NAME'):
                    lines[0] = f'#NAME {new_name}\n'
                else:
                    lines.insert(0, f'#NAME {new_name}\n')
                with open(new_path, 'w') as f:
                    f.writelines(lines)
                os.remove(old_path)
            else:
                with open(new_path, 'w') as f:
                    f.write(f'#NAME {new_name}\n')
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.saveServicelist()
            time.sleep(0.5)
            self.loadBouquets()
            self.updateList()
            for b in self.bouquets:
                if b['ref'].toString() == new_ref.toString():
                    self.selected_bouquet = (b['name'], b['ref'], b['type'], b['path'])
                    break
        except Exception as e:
            print(f'[BouquetsManager] Error renaming bouquet: {e}')
            showMessage(self.session, f'Error renaming bouquet:\n{str(e)}', MessageBox.TYPE_ERROR)

    def openConfirmSafe(self, message, callback):
        self._confirmMessage = message
        self._confirmCallback = callback
        try:
            self._confirmTimer.stop()
        except:
            pass
        self._confirmTimer.start(50, True)

    def _doOpenConfirm(self):
        try:
            self._confirmTimer.stop()
        except:
            pass
        callback = self._confirmCallback
        message = self._confirmMessage
        self._confirmCallback = None
        self._confirmMessage = None
        if callback and message is not None:
            self.session.openWithCallback(callback, SmallConfirmScreen, message)

    def confirmDeleteBouquet(self):
        if self.move_mode_active:
            return
        if not self.selected_bouquet:
            return
        name = self.selected_bouquet[0]
        msg = 'Delete this bouquet?\n\nBouquet: %s' % name
        self.openConfirmSafe(msg, self.deleteBouquetCallback)

    def deleteBouquetCallback(self, answer):
        if not answer or not self.selected_bouquet:
            return
        name, ref, btype, path = self.selected_bouquet
        try:
            if btype == 'tv':
                bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
            else:
                bouquet_root = eServiceReference('1:7:2:0:0:0:0:0:0:0:(type == 2) FROM BOUQUET "bouquets.radio" ORDER BY bouquet')
            bouquet_list = self.serviceHandler.list(bouquet_root)
            if bouquet_list:
                mutable = bouquet_list.startEdit()
                if mutable:
                    mutable.removeService(ref)
                    mutable.flushChanges()
            safe_name = name.replace(' ', '_')
            file_path = f'/etc/enigma2/userbouquet.{safe_name}.{btype}'
            if os.path.exists(file_path):
                os.remove(file_path)
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.saveServicelist()
            time.sleep(0.5)
            self.loadBouquets()
            self.updateList()
        except Exception as e:
            print(f'[BouquetsManager] Error deleting bouquet: {e}')
            showMessage(self.session, f'Error deleting bouquet:\n{str(e)}', MessageBox.TYPE_ERROR)

    def showBouquetInfo(self):
        if self.move_mode_active:
            return
        if not self.selected_bouquet:
            return
        name, ref, btype, path = self.selected_bouquet
        try:
            channel_count = 0
            marker_count = 0
            services = self.serviceHandler.list(ref)
            if services:
                while True:
                    s = services.getNext()
                    if not s.valid():
                        break
                    if s.flags & eServiceReference.isMarker:
                        marker_count += 1
                    else:
                        channel_count += 1
            info = 'Bouquet Information\n\n'
            info += f'Name: {name}\n'
            info += f'Type: {btype.upper()}\n'
            info += f'Channels: {channel_count}\n'
            info += f'Markers: {marker_count}\n'
            info += f'Path: {path}\n\n'
            info += f'Reference:\n{ref.toString()}'
            showMessage(self.session, info)
        except Exception as e:
            print(f'[BouquetsManager] Error showing info: {e}')
            showMessage(self.session, f'Error: {str(e)}', MessageBox.TYPE_ERROR)

    def sortBouquetChannels(self):
        if self.move_mode_active:
            return
        if not self.selected_bouquet:
            return
        name, ref, btype, path = self.selected_bouquet
        options = [('Sort A-Z (by name)', 'name_asc'), ('Sort Z-A (by name)', 'name_desc'), ('Sort by service reference', 'ref'), ('Sort by satellite position', 'sat'), ('--------------------', 'separator'), ('Keep current order', 'cancel')]
        self.session.openWithCallback(partial(self.sortCallback, ref), ChoiceBox, title=f'Sort channels in: {name}', list=options)

    def sortCallback(self, bouquet_ref, choice):
        if not choice or not choice[1] or choice[1] == 'cancel':
            return
        sort_mode = choice[1]
        serviceHandler = eServiceCenter.getInstance()
        services = serviceHandler.list(bouquet_ref)
        if not services:
            return
        channels = []
        while True:
            service = services.getNext()
            if not service.valid():
                break
            if not (service.flags & eServiceReference.isMarker):
                info = serviceHandler.info(service)
                name = info.getName(service)
                channels.append((name, service))
        if sort_mode == 'name_asc':
            channels.sort(key=lambda x: x[0].lower())
        elif sort_mode == 'name_desc':
            channels.sort(key=lambda x: x[0].lower(), reverse=True)
        elif sort_mode == 'ref':
            channels.sort(key=lambda x: x[1].toString())
        elif sort_mode == 'sat':
            def get_sat_pos(service):
                info = serviceHandler.info(service)
                tp = info.getInfoObject(service, iServiceInformation.sTransponderData)
                if tp and 'orbital_position' in tp:
                    return tp['orbital_position']
                return 0
            channels.sort(key=lambda x: get_sat_pos(x[1]))
        services = serviceHandler.list(bouquet_ref)
        if services:
            mutable = services.startEdit()
            if mutable:
                mutable.flushChanges()
                for name, service in channels:
                    mutable.addService(service)
                mutable.flushChanges()
        showMessage(self.session, 'Channels sorted successfully')

    def manualMoveMode(self):
        if self.move_mode_active:
            return
        if not self.selected_bouquet:
            return
        name, ref, btype, path = self.selected_bouquet
        self.session.open(BouquetMoveModeAdvanced, ref, name)

    def exportBouquet(self):
        if self.move_mode_active:
            return
        if not self.selected_bouquet:
            return
        name, ref, btype, path = self.selected_bouquet
        try:
            safe_name = name.replace(' ', '_')
            export_path = f'/tmp/{safe_name}_export.txt'
            services = self.serviceHandler.list(ref)
            with open(export_path, 'w') as f:
                f.write(f'# Bouquet: {name}\n')
                while True:
                    service = services.getNext()
                    if not service.valid():
                        break
                    if not (service.flags & eServiceReference.isMarker):
                        info = self.serviceHandler.info(service)
                        channel_name = info.getName(service)
                        sref = service.toString()
                        f.write(f'{channel_name}|{sref}\n')
            showMessage(self.session, f'Bouquet exported to:\n{export_path}')
        except Exception as e:
            print(f'[BouquetsManager] Error exporting bouquet: {e}')
            showMessage(self.session, f'Error exporting bouquet:\n{str(e)}', MessageBox.TYPE_ERROR)

    def importBouquet(self):
        if self.move_mode_active:
            return
        if not self.selected_bouquet:
            return
        name, ref, btype, path = self.selected_bouquet

        def pathCallback(filepath):
            if not filepath or not filepath.strip():
                return
            self.importFromFile(ref, filepath.strip())

        self.session.openWithCallback(pathCallback, VirtualKeyBoard, title='Enter path to import file', text='/tmp/')

    def importFromFile(self, bouquet_ref, filepath):
        if not os.path.exists(filepath):
            showMessage(self.session, 'File not found', MessageBox.TYPE_ERROR)
            return
        services = self.serviceHandler.list(bouquet_ref)
        if not services:
            return
        mutable = services.startEdit()
        if not mutable:
            showMessage(self.session, 'Could not edit bouquet', MessageBox.TYPE_ERROR)
            return
        success_count = 0
        fail_count = 0
        try:
            with open(filepath, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split('|')
                    if len(parts) >= 2:
                        service_ref = eServiceReference(parts[1])
                        mutable.addService(service_ref)
                        success_count += 1
                    else:
                        fail_count += 1
            mutable.flushChanges()
            showMessage(self.session, f'Import completed:\nSuccess: {success_count}\nFailed: {fail_count}')
        except Exception as e:
            print(f'[BouquetsManager] Error importing: {e}')
            showMessage(self.session, f'Error importing:\n{str(e)}', MessageBox.TYPE_ERROR)

    def openBouquetMenu(self):
        """فتح قائمة الخيارات للباقة المحددة"""
        if self.move_mode_active:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is not None and 0 <= current_index < len(self.bouquets):
            self.selected_bouquet = (self.bouquets[current_index]['name'], self.bouquets[current_index]['ref'], self.bouquets[current_index]['type'], self.bouquets[current_index]['path'])
        else:
            bouquet_data = self.getCurrentBouquet()
            if not bouquet_data:
                return
            self.selected_bouquet = bouquet_data
        if not self.selected_bouquet:
            return
        name = self.selected_bouquet[0]
        print(f'[BouquetsManager] Opening menu for bouquet: {name}')
        menu = [(f'Open bouquet: {name}', 'open'), ('Rename bouquet', 'rename'), ('Delete bouquet', 'delete'), ('Bouquet information', 'info'), ('--------------------', 'separator'), ('Sort bouquet channels', 'sort'), ('Move channels manually', 'move'), ('--------------------', 'separator'), ('Export bouquet', 'export'), ('Import channels', 'import')]
        self.session.open(MenuListScreen, menu, self)

    def handleMenuAction(self, action):
        """تنفيذ أوامر منيو الباقة الرئيسية"""
        print(f'[BouquetsManager] handleMenuAction: {action}')
        if not action:
            return
        if not self.selected_bouquet:
            self.selected_bouquet = self.getCurrentBouquet()
            if not self.selected_bouquet:
                return
        if action == 'open':
            self.openBouquet()
        elif action == 'rename':
            self.renameBouquet()
        elif action == 'delete':
            self.confirmDeleteBouquet()
        elif action == 'info':
            self.showBouquetInfo()
        elif action == 'sort':
            self.sortBouquetChannels()
        elif action == 'move':
            self.manualMoveMode()
        elif action == 'export':
            self.exportBouquet()
        elif action == 'import':
            self.importBouquet()

class BouquetContentsScreen(Screen):
    """شاشة عرض محتويات الباقة (القنوات) مع دعم Multi-Select"""
    SORT_MODES = [('original', 'Original Order'), ('name_asc', 'Name A-Z'), ('name_desc', 'Name Z-A'), ('ref', 'Service Reference'), ('sat_pos', 'Satellite Position'), ('sat_name', 'Satellite Name'), ('freq', 'Frequency'), ('quality', 'Quality'), ('encryption', 'Encryption')]
    skin = '\n    <screen position=\"center,center\" size=\"950,620\" title=\"Bouquet Contents\">\n        <widget name=\"title_label\" position=\"10,10\" size=\"930,30\" font=\"Regular;26\" halign=\"center\" foregroundColor=\"#00aaff\"/>\n\n        <widget name=\"info_label\" position=\"10,45\" size=\"930,30\" font=\"Regular;22\" halign=\"left\" foregroundColor=\"#cccccc\"/>\n        <widget name=\"help_label\" position=\"10,75\" size=\"930,30\" font=\"Regular;22\" halign=\"left\" foregroundColor=\"#ffff99\"/>\n\n        <widget name=\"list\" position=\"10,110\" size=\"930,450\" itemHeight=\"50\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n\n        <widget name=\"key_red\" position=\"10,575\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Back\"/>\n        <widget name=\"key_green\" position=\"140,575\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"Sort\"/>\n        <widget name=\"key_yellow\" position=\"270,575\" size=\"130,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffff00\" text=\"Delete\"/>\n        <widget name=\"key_blue\" position=\"410,575\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00aaff\" text=\"Move\"/>\n        <widget name=\"key_menu\" position=\"560,575\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffffff\" text=\"Menu\"/>\n    </screen>\n    '
    def __init__(self, session, bouquet_ref, bouquet_name, bouquet_type):
        Screen.__init__(self, session)
        self.session = session
        self.bouquet_ref = bouquet_ref
        self.bouquet_name = bouquet_name
        self.bouquet_type = bouquet_type
        self.channels = []
        self.all_channels = []
        self.filter_state = {'tv': False, 'radio': False, 'iptv': False, 'hd': False, 'sd': False, 'scr': False, 'fta': False}
        self.filter_satellites = []
        self.pending_service = None
        self.pending_services = []
        self.pending_service_names = []
        self.original_service = session.nav.getCurrentlyPlayingServiceReference()
        self.previewed_service = None
        self.previewed_name = ''
        self.channel_confirmed = False
        self.items_per_page = 12
        self.sort_mode = 'original'
        self.multi_select_mode = False
        self.selected_indices = set()
        self.selected_services_refs = set()
        self.select_all_state = False
        self._confirmTimer = eTimer()
        self._confirmTimer.callback.append(self._doOpenConfirm)
        self._confirmCallback = None
        self._confirmMessage = None
        self.loadChannels()
        icon_path = os.path.join(os.path.dirname(__file__), 'icons', 'icon_crypt.png')
        self.lock_icon = LoadPixmap(icon_path) if os.path.exists(icon_path) else None
        self['title_label'] = Label(f'Bouquet: {bouquet_name}')
        self['list'] = MenuList([], False, eListboxPythonMultiContent)
        self['list'].l.setFont(0, gFont('Regular', 26))
        self['key_red'] = Label('Back')
        self['key_green'] = Label('Sort')
        self['key_yellow'] = Label('Remove')
        self['key_blue'] = Label('Move')
        self['key_menu'] = Label('Menu')
        self['info_label'] = Label('')
        self['help_label'] = Label('')
        self['list'].onSelectionChanged.append(self.onSelectionChanged)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'MenuActions', 'DirectionActions'], {'ok': self.okPressed, 'cancel': self.exitPlugin, 'red': self.exitPlugin, 'green': self.greenPressed, 'yellow': self.yellowPressed, 'blue': self.bluePressed, 'menu': self.openAdvancedMenu, 'up': self.moveUp, 'down': self.moveDown, 'left': self.moveLeft, 'right': self.moveRight}, -1)
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()

    def loadChannels(self):
        self.all_channels = []
        serviceHandler = eServiceCenter.getInstance()
        services = serviceHandler.list(self.bouquet_ref)
        if services:
            while True:
                service = services.getNext()
                if not service.valid():
                    break
                if not (service.flags & eServiceReference.isMarker):
                    info = serviceHandler.info(service)
                    name = info.getName(service)
                    tp = info.getInfoObject(service, iServiceInformation.sTransponderData)
                    sat = ''
                    orb = 0
                    freq = ''
                    if tp and 'orbital_position' in tp:
                        orb = tp['orbital_position']
                        sat = getSatelliteName(orb)
                    if tp and 'frequency' in tp:
                        try:
                            freq = str(int(tp['frequency'] / 1000)) + ' MHz'
                        except:
                            freq = ''
                    ctype = getChannelType(service)
                    quality = getChannelQuality(info, service)
                    try:
                        is_locked = bool(info.isCrypted())
                    except:
                        is_locked = False
                    self.all_channels.append((name, service, sat, orb, freq, ctype, quality, is_locked))
        self.channels = list(self.all_channels)

    def getSortModeText(self):
        for key, text in self.SORT_MODES:
            if key == self.sort_mode:
                return text
        return 'Unknown'

    def updateSelectedIndicesFromRefs(self):
        self.selected_indices.clear()
        for idx, channel_data in enumerate(self.channels):
            if channel_data[1].toString() in self.selected_services_refs:
                self.selected_indices.add(idx)

    def updateList(self):
        listdata = []
        self.updateSelectedIndicesFromRefs()
        for idx, (name, service, sat, orb, freq, ctype, quality, is_locked) in enumerate(self.channels):
            picon = getPicon(service)
            display_name = name
            if self.multi_select_mode:
                prefix = '[x] ' if idx in self.selected_indices else '[ ] '
                display_name = prefix + name
            entry = [MultiContentEntryPixmapAlphaBlend(pos=(10, 5), size=(40, 40), png=picon), MultiContentEntryText(pos=(70, 10), size=(280, 40), font=0, text=display_name)]
            if is_locked and self.lock_icon is not None:
                entry.append(MultiContentEntryPixmapAlphaBlend(pos=(360, 8), size=(55, 35), png=self.lock_icon))
            entry.extend([MultiContentEntryText(pos=(460, 10), size=(70, 40), font=0, text=ctype), MultiContentEntryText(pos=(550, 10), size=(70, 40), font=0, text=quality), MultiContentEntryText(pos=(630, 10), size=(120, 40), font=0, text=sat), MultiContentEntryText(pos=(750, 10), size=(180, 40), font=0, text=freq)])
            listdata.append(entry)
        self['list'].setList(listdata)

    def getActiveFilterText(self):
        parts = []
        type_parts = []
        if self.filter_state.get('tv'):
            type_parts.append('TV')
        if self.filter_state.get('radio'):
            type_parts.append('Radio')
        if self.filter_state.get('iptv'):
            type_parts.append('IPTV')
        if type_parts:
            parts.append('/'.join(type_parts))
        if self.filter_state.get('hd'):
            parts.append('HD')
        if self.filter_state.get('sd'):
            parts.append('SD')
        if self.filter_state.get('scr'):
            parts.append('SCR')
        if self.filter_state.get('fta'):
            parts.append('FTA')
        if self.filter_satellites:
            if len(self.filter_satellites) == 1:
                parts.append(f'SAT={self.filter_satellites[0]}')
            else:
                parts.append(f'SAT={len(self.filter_satellites)} selected')
        return ', '.join(parts) if parts else 'None'

    def updateInfoLabel(self):
        sort_text = self.getSortModeText()
        filter_text = self.getActiveFilterText()
        if self.multi_select_mode:
            self['info_label'].setText(f'Channels: {len(self.channels)}  |  Selected: {len(self.selected_services_refs)}  |  Sort: {sort_text}  |  Filter: {filter_text}')
        else:
            self['info_label'].setText(f'Channels: {len(self.channels)}  |  Sort: {sort_text}  |  Filter: {filter_text}')

    def updateHelpLabel(self):
        """تحديث سطر التعليمات أسفل سطر المعلومات"""
        if self.multi_select_mode:
            if self.selected_services_refs:
                self['help_label'].setText('Multi-Select: YELLOW=Select/Deselect  |  GREEN=Select All  |  MENU=Copy/Remove selected')
            else:
                self['help_label'].setText('Multi-Select: Use YELLOW to select channels, GREEN to select all, MENU for actions')
        else:
            current = self['list'].getCurrent()
            if current and len(current) >= 1:
                name = current[0][0]
                service = current[0][1]
                if self.previewed_service is not None and service.toString() == self.previewed_service.toString():
                    self['help_label'].setText('Preview active: Press OK again to zap, or EXIT to return to original channel')
                else:
                    self['help_label'].setText('Navigation: Press OK to preview channel, GREEN to change sort mode, MENU for more options')
            else:
                self['help_label'].setText('Navigation: Press OK to preview channel, GREEN to change sort mode, MENU for more options')

    def moveUp(self):
        if not self.channels:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if current_index == 0:
            self['list'].moveToIndex(len(self.channels) - 1)
        else:
            self['list'].up()

    def moveDown(self):
        if not self.channels:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if current_index == len(self.channels) - 1:
            self['list'].moveToIndex(0)
        else:
            self['list'].down()

    def moveLeft(self):
        if not self.channels:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        new_index = max(0, current_index - self.items_per_page)
        self['list'].moveToIndex(new_index)

    def moveRight(self):
        if not self.channels:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        new_index = min(len(self.channels) - 1, current_index + self.items_per_page)
        self['list'].moveToIndex(new_index)

    def okPressed(self):
        if self.multi_select_mode:
            self.previewChannel()
        else:
            self.playChannel()

    def greenPressed(self):
        if self.multi_select_mode:
            if self.select_all_state:
                self.deselectAll()
            else:
                self.selectAll()
        else:
            self.cycleSortMode()

    def yellowPressed(self):
        if self.multi_select_mode:
            self.toggleCurrentSelection()
            current_index = self['list'].getSelectedIndex()
            if current_index is not None and current_index >= 0 and self.channels:
                next_index = min(len(self.channels) - 1, current_index + 1)
                self['list'].moveToIndex(next_index)
                self.onSelectionChanged()
        else:
            self.removeChannel()

    def bluePressed(self):
        if self.multi_select_mode:
            self.showMultipleInfo()
        else:
            self.openMoveMode()

    def playChannel(self):
        current = self['list'].getCurrent()
        if not current or len(current) == 1:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked = current[0]
        if not service or service.flags & eServiceReference.isMarker:
            return
        if self.previewed_service is not None and service.toString() == self.previewed_service.toString():
            try:
                from Screens.InfoBar import InfoBar
                infobar = InfoBar.instance
            except:
                infobar = None
            if infobar and hasattr(infobar, 'servicelist') and infobar.servicelist:
                sl = infobar.servicelist
                bouquet_ref = self.bouquet_ref
                try:
                    if hasattr(sl, 'servicePath') and sl.servicePath is not None:
                        del sl.servicePath[:]
                        if getattr(sl, 'bouquet_root', None):
                            sl.servicePath.append(sl.bouquet_root)
                        if bouquet_ref is not None:
                            sl.servicePath.append(bouquet_ref)
                except Exception as e:
                    print('[BouquetContents] servicePath error:', e)
                try:
                    if hasattr(sl, 'setRoot'):
                        if bouquet_ref is not None:
                            sl.setRoot(bouquet_ref)
                except Exception as e:
                    print('[BouquetContents] setRoot error:', e)
                if hasattr(sl, 'setCurrentSelection'):
                    sl.setCurrentSelection(service)
                if hasattr(sl, 'setCurrent'):
                    sl.setCurrent(service)
                try:
                    sl.addToHistory(service)
                except Exception as e:
                    print('[BouquetContents] addToHistory error:', e)
            self.previewed_service = None
            self.previewed_name = ''
            self.close()
        else:
            self.session.nav.playService(service)
            self.previewed_service = service
            self.previewed_name = name
            self.updateInfoLabel()
            self.updateHelpLabel()

    def previewChannel(self):
        current = self['list'].getCurrent()
        if not current or len(current) == 1:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked = current[0]
        if not service or service.flags & eServiceReference.isMarker:
            return
        self.session.nav.playService(service)
        self.previewed_service = service
        self.previewed_name = name
        self.updateInfoLabel()
        self.updateHelpLabel()

    def exitPlugin(self):
        if self.multi_select_mode:
            self.exitMultiSelectMode()
        else:
            print('[BouquetContents] Exit, returning to original channel')
            if self.original_service:
                self.session.nav.playService(self.original_service)
            self.previewed_service = None
            self.previewed_name = ''
            self.close()

    def onSelectionChanged(self):
        self.updateInfoLabel()
        self.updateHelpLabel()

    def applyCurrentSort(self, save=False):
        """تطبيق الفرز الحالي على self.channels"""
        sort_mode = self.sort_mode
        if sort_mode == 'original':
            pass
        elif sort_mode == 'name_asc':
            self.channels.sort(key=lambda x: x[0].lower())
        elif sort_mode == 'name_desc':
            self.channels.sort(key=lambda x: x[0].lower(), reverse=True)
        elif sort_mode == 'ref':
            self.channels.sort(key=lambda x: x[1].toString())
        elif sort_mode == 'sat_pos':
            def get_sat_pos(channel):
                try:
                    return channel[3] if channel[3] is not None else 9999
                except:
                    return 9999
            self.channels.sort(key=get_sat_pos)
        elif sort_mode == 'sat_name':
            def get_sat_name(channel):
                try:
                    sat = channel[2]
                    return sat.lower() if sat else 'zzz'
                except:
                    return 'zzz'
            self.channels.sort(key=get_sat_name)
        elif sort_mode == 'freq':
            def get_freq(channel):
                freq = channel[4]
                if freq and 'MHz' in freq:
                    try:
                        return int(freq.replace('MHz', '').strip())
                    except:
                        return 999999
                return 999999
            self.channels.sort(key=get_freq)
        elif sort_mode == 'quality':
            def get_quality_order(channel):
                try:
                    quality = channel[6]
                    order = {'UHD': 0, '4K': 0, 'FHD': 1, 'HD': 2, 'SD': 3, '-': 4}
                    return order.get(quality, 9)
                except:
                    return 9
            self.channels.sort(key=get_quality_order)
        elif sort_mode == 'encryption':
            def get_encryption_order(channel):
                try:
                    is_locked = channel[7]
                    return 0 if is_locked else 1
                except:
                    return 9
            self.channels.sort(key=get_encryption_order)
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()
        if save:
            if sort_mode != 'original':
                if not self.hasActiveFilter():
                    self.saveCurrentOrder()
                else:
                    print('[BouquetContents] Filter active, skipping saveCurrentOrder()')

    def cycleSortMode(self):
        """التنقل بين أنواع الفرز بالزر الأخضر"""
        modes = [x[0] for x in self.SORT_MODES]
        try:
            current_index = modes.index(self.sort_mode)
        except:
            current_index = 0
        current_index = (current_index + 1) % len(modes)
        self.sort_mode = modes[current_index]
        print(f'[BouquetContents] Cycle sort mode -> {self.sort_mode}')
        self.rebuildChannelView()

    def sortChannels(self):
        menu = [('Original Order', 'original'), ('Sort A-Z (by name)', 'name_asc'), ('Sort Z-A (by name)', 'name_desc'), ('Sort by service reference', 'ref'), ('Sort by satellite position', 'sat_pos'), ('Sort by satellite name', 'sat_name'), ('Sort by frequency', 'freq'), ('Sort by quality', 'quality'), ('Sort by encryption', 'encryption')]
        self.session.openWithCallback(self.sortCallback, ChoiceBox, title='Sort channels', list=menu)

    def sortCallback(self, choice):
        if not choice or not choice[1]:
            return
        selected_sort = choice[1]
        print(f'[BouquetContents] Sorting channels by: {selected_sort}')
        self.sort_mode = selected_sort
        self.rebuildChannelView()

    def saveCurrentOrder(self):
        try:
            print('[BouquetContents] Saving current order...')
            ref_str = self.bouquet_ref.toString()
            import re
            match = re.search('"([^"]+)"', ref_str)
            if not match:
                print('[BouquetContents] Could not extract filename')
                return
            bouquet_filename = match.group(1)
            if bouquet_filename.startswith('/'):
                full_path = bouquet_filename
            else:
                full_path = f'/etc/enigma2/{bouquet_filename}'
            lines = [f'#NAME {self.bouquet_name}\n']
            for channel in self.channels:
                name, service, sat, orb, freq, ctype, quality, is_locked = channel
                service_ref = service.toString()
                lines.append(f'#SERVICE {service_ref}\n')
            with open(full_path, 'w') as f:
                f.writelines(lines)
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.saveServicelist()
            print('[BouquetContents] Order saved successfully')
        except Exception as e:
            print(f'[BouquetContents] Error saving order: {e}')

    def activateMultiSelectMode(self):
        self.multi_select_mode = True
        self.selected_indices.clear()
        self.selected_services_refs.clear()
        self.select_all_state = False
        self['key_green'].setText('Select All')
        self['key_yellow'].setText('Select')
        self['key_blue'].setText('Info')
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()

    def exitMultiSelectMode(self):
        self.multi_select_mode = False
        self.selected_indices.clear()
        self.selected_services_refs.clear()
        self.select_all_state = False
        self['key_green'].setText('Sort')
        self['key_yellow'].setText('Remove')
        self['key_blue'].setText('Move')
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()

    def selectAll(self):
        self.selected_indices = set(range(len(self.channels)))
        self.selected_services_refs.clear()
        for idx in self.selected_indices:
            if 0 <= idx < len(self.channels):
                name, service, sat, orb, freq, ctype, quality, is_locked = self.channels[idx]
                self.selected_services_refs.add(service.toString())
        self.select_all_state = True
        self['key_green'].setText('Deselect All')
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()

    def deselectAll(self):
        self.selected_indices.clear()
        self.selected_services_refs.clear()
        self.select_all_state = False
        self['key_green'].setText('Select All')
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()

    def toggleCurrentSelection(self):
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if current_index in self.selected_indices:
            self.selected_indices.remove(current_index)
            name, service, sat, orb, freq, ctype, quality, is_locked = self.channels[current_index]
            self.selected_services_refs.discard(service.toString())
        else:
            self.selected_indices.add(current_index)
            name, service, sat, orb, freq, ctype, quality, is_locked = self.channels[current_index]
            self.selected_services_refs.add(service.toString())
        if len(self.selected_indices) == len(self.channels):
            self.select_all_state = True
            self['key_green'].setText('Deselect All')
        else:
            self.select_all_state = False
            self['key_green'].setText('Select All')
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()

    def getSelectedServices(self):
        selected_services = []
        selected_names = []
        for idx, channel_data in enumerate(self.channels):
            name, service, sat, orb, freq, ctype, quality, is_locked = channel_data
            if service.toString() in self.selected_services_refs:
                selected_services.append(service)
                selected_names.append(name)
        return selected_services, selected_names

    def showMultipleInfo(self):
        selected_services, selected_names = self.getSelectedServices()
        if not selected_services:
            showMessage(self.session, 'No channels selected.', MessageBox.TYPE_INFO)
            return
        tv_count = 0
        radio_count = 0
        iptv_count = 0
        hd_count = 0
        sd_count = 0
        for idx in self.selected_indices:
            if 0 <= idx < len(self.channels):
                name, service, sat, orb, freq, ctype, quality, is_locked = self.channels[idx]
                if ctype == 'TV':
                    tv_count += 1
                elif ctype == 'Radio':
                    radio_count += 1
                elif ctype == 'IPTV':
                    iptv_count += 1
                if quality == 'HD':
                    hd_count += 1
                elif quality == 'SD':
                    sd_count += 1
        info = 'Selected Channels Summary:\n\n'
        info += f'Total: {len(selected_services)} channels\n'
        info += f'TV: {tv_count} | Radio: {radio_count} | IPTV: {iptv_count}\n'
        info += f'HD: {hd_count} | SD: {sd_count}'
        showMessage(self.session, info, MessageBox.TYPE_INFO)

    def openConfirmSafe(self, message, callback):
        self._confirmMessage = message
        self._confirmCallback = callback
        try:
            self._confirmTimer.stop()
        except:
            pass
        self._confirmTimer.start(50, True)

    def _doOpenConfirm(self):
        try:
            self._confirmTimer.stop()
        except:
            pass
        callback = self._confirmCallback
        message = self._confirmMessage
        self._confirmCallback = None
        self._confirmMessage = None
        if callback and message is not None:
            self.session.openWithCallback(callback, SmallConfirmScreen, message)

    def confirmRemoveMultiple(self):
        selected_services, selected_names = self.getSelectedServices()
        if not selected_services:
            showMessage(self.session, 'No channels selected.', MessageBox.TYPE_INFO)
            return
        count = len(selected_services)
        msg = f'Delete selected channels?\n\nBouquet: {self.bouquet_name}\nCount: {count}'
        self.openConfirmSafe(msg, self.confirmRemoveMultipleCallback)

    def confirmRemoveMultipleCallback(self, answer):
        if answer:
            self.removeMultipleChannels()

    def removeMultipleChannels(self):
        selected_services, selected_names = self.getSelectedServices()
        if not selected_services:
            return
        serviceHandler = eServiceCenter.getInstance()
        services = serviceHandler.list(self.bouquet_ref)
        if not services:
            return
        mutable = services.startEdit()
        if not mutable:
            return
        try:
            for service in selected_services:
                mutable.removeService(service)
            mutable.flushChanges()
            self.selected_indices.clear()
            self.selected_services_refs.clear()
            self.select_all_state = False
            self.loadChannels()
            self.updateList()
            self.updateInfoLabel()
            self.updateHelpLabel()
            self.exitMultiSelectMode()
        except Exception as e:
            print(f'[BouquetContents] Error removing multiple channels: {e}')
            showMessage(self.session, f'Error removing channels:\n{str(e)}', MessageBox.TYPE_ERROR)

    def removeChannel(self):
        current = self['list'].getCurrent()
        if not current or len(current) == 1:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked = current[0]
        msg = f'Delete this channel?\n\nBouquet: {self.bouquet_name}\nChannel: {name}'
        self.openConfirmSafe(msg, lambda answer: self._removeChannelCallback(answer, service))

    def _removeChannelCallback(self, answer, service):
        if answer:
            self.removeChannelFromBouquet(service)

    def removeChannelFromBouquet(self, service):
        if not service:
            return
        serviceHandler = eServiceCenter.getInstance()
        services = serviceHandler.list(self.bouquet_ref)
        if not services:
            return
        mutable = services.startEdit()
        if not mutable:
            return
        try:
            mutable.removeService(service)
        except:
            mutable.removeService(eServiceReference(service.toString()))
        mutable.flushChanges()
        try:
            sref = service.toString()
            if sref in self.selected_services_refs:
                self.selected_services_refs.remove(sref)
        except:
            pass
        self.loadChannels()
        self.rebuildChannelView()

    def getAvailableTargetBouquets(self):
        """جلب الباقات المتاحة كوجهة للنسخ، مع استبعاد الباقة الحالية"""
        bouquets = []
        serviceHandler = eServiceCenter.getInstance()
        if self.bouquet_type == 'tv':
            bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        else:
            bouquet_root = eServiceReference('1:7:2:0:0:0:0:0:0:0:(type == 2) FROM BOUQUET "bouquets.radio" ORDER BY bouquet')
        bouquet_list = serviceHandler.list(bouquet_root)
        current_ref_str = self.bouquet_ref.toString()
        if bouquet_list:
            while True:
                bouquet = bouquet_list.getNext()
                if not bouquet.valid():
                    break
                if bouquet.toString() == current_ref_str:
                    continue
                info = serviceHandler.info(bouquet)
                name = info.getName(bouquet)
                bouquets.append((name, bouquet))
        return bouquets

    def copyToBouquet(self):
        """نسخ القناة الحالية إلى باقة أخرى"""
        current = self['list'].getCurrent()
        if not current or len(current) == 1:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked = current[0]
        if not service or service.flags & eServiceReference.isMarker:
            return
        self.pending_service = service
        bouquets = self.getAvailableTargetBouquets()
        if not bouquets:
            showMessage(self.session, 'No target bouquets found', MessageBox.TYPE_INFO)
        else:
            self.session.open(BouquetSelectionScreen, bouquets, self, False)

    def copyToBouquetSelected(self, bouquet):
        """تنفيذ نسخ القناة الحالية إلى الباقة المختارة"""
        service = self.pending_service
        if not service or not bouquet:
            return
        try:
            serviceHandler = eServiceCenter.getInstance()
            bouquet_ref = bouquet[1]
            bouquet_list = serviceHandler.list(bouquet_ref)
            if not bouquet_list:
                showMessage(self.session, 'Could not access target bouquet', MessageBox.TYPE_ERROR)
                return
            mutable = bouquet_list.startEdit()
            if not mutable:
                showMessage(self.session, 'Could not edit target bouquet', MessageBox.TYPE_ERROR)
                return
            mutable.addService(service)
            mutable.flushChanges()
        except Exception as e:
            print(f'[BouquetContents] Error copying channel: {e}')
            showMessage(self.session, f'Error copying channel:\n{str(e)}', MessageBox.TYPE_ERROR)

    def copyMultipleToBouquet(self):
        """نسخ القنوات المحددة إلى باقة أخرى"""
        selected_services, selected_names = self.getSelectedServices()
        if not selected_services:
            showMessage(self.session, 'No channels selected.', MessageBox.TYPE_INFO)
            return
        self.pending_services = list(selected_services)
        self.pending_service_names = list(selected_names)
        bouquets = self.getAvailableTargetBouquets()
        if not bouquets:
            showMessage(self.session, 'No target bouquets found', MessageBox.TYPE_INFO)
        else:
            self.session.open(BouquetSelectionScreen, bouquets, self, True)

    def copyMultipleToBouquetSelected(self, bouquet):
        """تنفيذ نسخ القنوات المحددة إلى الباقة المختارة"""
        if not bouquet or not self.pending_services:
            return
        success_count = 0
        fail_count = 0
        try:
            serviceHandler = eServiceCenter.getInstance()
            bouquet_ref = bouquet[1]
            bouquet_list = serviceHandler.list(bouquet_ref)
            if not bouquet_list:
                showMessage(self.session, 'Could not access target bouquet', MessageBox.TYPE_ERROR)
                return
            mutable = bouquet_list.startEdit()
            if not mutable:
                showMessage(self.session, 'Could not edit target bouquet', MessageBox.TYPE_ERROR)
                return
            for service in self.pending_services:
                try:
                    mutable.addService(service)
                    success_count += 1
                except:
                    fail_count += 1
            mutable.flushChanges()
            self.pending_services = []
            self.pending_service_names = []
            msg = f'Copied {success_count} channels to bouquet: {bouquet[0]}'
            if fail_count > 0:
                msg += f'\nFailed: {fail_count}'
            showMessage(self.session, msg, MessageBox.TYPE_INFO)
        except Exception as e:
            print(f'[BouquetContents] Error copying multiple channels: {e}')
            self.pending_services = []
            self.pending_service_names = []
            showMessage(self.session, f'Error copying channels:\n{str(e)}', MessageBox.TYPE_ERROR)

    def hasActiveFilter(self):
        if self.filter_satellites:
            return True
        return any(self.filter_state.values())

    def getUniqueSatelliteValues(self):
        values = set()
        for name, service, sat, orb, freq, ctype, quality, is_locked in self.all_channels:
            if sat:
                values.add(sat)
        return sorted(values, key=lambda x: x.lower())

    def selectFilter(self):
        self.session.openWithCallback(self.filterScreenCallback, BouquetFilterScreen, dict(self.filter_state), list(self.filter_satellites), self.getUniqueSatelliteValues())

    def filterScreenCallback(self, result):
        if not result:
            return
        self.filter_state = dict(result.get('filter_state') or {})
        for key in ['tv', 'radio', 'iptv', 'hd', 'sd', 'scr', 'fta']:
            if key not in self.filter_state:
                self.filter_state[key] = False
        if not self.filter_state.get('tv'):
            self.filter_state['hd'] = False
            self.filter_state['sd'] = False
        if self.filter_state.get('hd'):
            self.filter_state['sd'] = False
        elif self.filter_state.get('sd'):
            self.filter_state['hd'] = False
        if self.filter_state.get('scr'):
            self.filter_state['fta'] = False
        elif self.filter_state.get('fta'):
            self.filter_state['scr'] = False
        self.filter_satellites = list(result.get('satellites') or [])
        self.rebuildChannelView()

    def clearFilter(self):
        self.filter_state = {'tv': False, 'radio': False, 'iptv': False, 'hd': False, 'sd': False, 'scr': False, 'fta': False}
        self.filter_satellites = []
        self.rebuildChannelView()

    def matchesTypeFilter(self, channel):
        selected_types = []
        if self.filter_state.get('tv'):
            selected_types.append('TV')
        if self.filter_state.get('radio'):
            selected_types.append('Radio')
        if self.filter_state.get('iptv'):
            selected_types.append('IPTV')
        if not selected_types:
            return True
        return channel[5] in selected_types

    def matchesQualityFilter(self, channel):
        ctype = channel[5]
        quality = channel[6]
        if not self.filter_state.get('tv'):
            return True
        hd_selected = self.filter_state.get('hd')
        sd_selected = self.filter_state.get('sd')
        if not hd_selected and not sd_selected:
            return True
        if ctype != 'TV':
            return True
        hd_values = ('HD', 'FHD', 'UHD', '4K')
        if hd_selected and quality in hd_values:
            return True
        if sd_selected and quality == 'SD':
            return True
        return False

    def matchesEncryptionFilter(self, channel):
        is_locked = bool(channel[7])
        if self.filter_state.get('scr'):
            return is_locked
        elif self.filter_state.get('fta'):
            return not is_locked
        return True

    def matchesSatelliteFilter(self, channel):
        if not self.filter_satellites:
            return True
        return channel[2] in self.filter_satellites

    def rebuildChannelView(self):
        self.channels = []
        for ch in self.all_channels:
            if self.matchesTypeFilter(ch) and self.matchesQualityFilter(ch) and self.matchesEncryptionFilter(ch) and self.matchesSatelliteFilter(ch):
                self.channels.append(ch)
        if self.sort_mode != 'original':
            self.applyCurrentSort(save=False)
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()
        if self.multi_select_mode:
            self.updateSelectedIndicesFromRefs()

    def openMoveMode(self):
        self.session.openWithCallback(self.onMoveModeClosed, BouquetMoveModeAdvanced, self.bouquet_ref, self.bouquet_name)

    def onMoveModeClosed(self, *args):
        print('[BouquetContents] Returning from move mode, reloading channels...')
        self.loadChannels()
        self.updateList()
        self.updateInfoLabel()
        self.updateHelpLabel()

    def openAdvancedMenu(self):
        current = self['list'].getCurrent()
        if not current or len(current) == 1:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked = current[0]
        self.pending_service = service
        if self.multi_select_mode:
            menu = []
            if self.selected_services_refs:
                menu.append(('Copy selected channels to bouquet', 'copy_multiple'))
                menu.append(('Remove selected channels', 'remove_multiple'))
                menu.append(('Show selected info', 'info_multiple'))
                menu.append(('--------------------', 'separator'))
            menu.append(('Exit Multi-Select Mode', 'exit_multi'))
        else:
            menu = [('Copy selected channel to bouquet', 'copy'), ('Remove selected channel', 'remove'), ('Channel information', 'channel_info'), ('Preview selected channel', 'preview'), ('--------------------', 'separator'), ('Activate Multi-Select Mode', 'activate_multi'), ('Select filter', 'filter_select'), ('Clear filter', 'filter_clear'), ('--------------------', 'separator'), ('Sort bouquet channels', 'sort'), ('Move channels manually', 'move'), ('--------------------', 'separator'), ('Export bouquet', 'export'), ('Import channels', 'import'), ('Bouquet information', 'bouquet_info')]
        self.session.open(MenuListScreen, menu, self)

    def handleMenuAction(self, action):
        print(f'[BouquetContents] handleMenuAction: {action}')
        if not action:
            return
        if action == 'copy':
            self.copyToBouquet()
        elif action == 'remove':
            self.removeChannel()
        elif action == 'channel_info':
            self.showChannelInfo()
        elif action == 'preview':
            current = self['list'].getCurrent()
            if current and len(current) >= 1:
                name, service, sat, orb, freq, ctype, quality, is_locked = current[0]
                if service and not (service.flags & eServiceReference.isMarker):
                    self.session.nav.playService(service)
                    self.previewed_service = service
                    self.previewed_name = name
                    self.updateInfoLabel()
                    self.updateHelpLabel()
        elif action == 'activate_multi':
            self.activateMultiSelectMode()
        elif action == 'filter_select':
            self.selectFilter()
        elif action == 'filter_clear':
            self.clearFilter()
        elif action == 'copy_multiple':
            self.copyMultipleToBouquet()
        elif action == 'remove_multiple':
            self.confirmRemoveMultiple()
        elif action == 'info_multiple':
            self.showMultipleInfo()
        elif action == 'exit_multi':
            self.exitMultiSelectMode()
        elif action == 'sort':
            self.sortChannels()
        elif action == 'move':
            self.openMoveMode()
        elif action == 'export':
            self.exportBouquet()
        elif action == 'import':
            self.importChannels()
        elif action == 'bouquet_info':
            self.showBouquetInfo()

    def showChannelInfo(self):
        current = self['list'].getCurrent()
        if not current or len(current) == 1:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked = current[0]
        if not service or service.flags & eServiceReference.isMarker:
            return
        self.session.open(ChannelInfoScreen, service)

    def exportBouquet(self):
        try:
            safe_name = self.bouquet_name.replace(' ', '_')
            export_path = f'/tmp/{safe_name}_export.txt'
            with open(export_path, 'w') as f:
                f.write(f'# Bouquet: {self.bouquet_name}\n')
                f.write(f'# Type: {self.bouquet_type}\n')
                f.write(f'# Exported: {time.strftime("%Y-%m-%d %H:%M:%S")}\n\n')
                for name, service, sat, orb, freq, ctype, quality, is_locked in self.channels:
                    sref = service.toString()
                    f.write(f'{name}|{sref}\n')
            showMessage(self.session, f'Exported to:\n{export_path}')
        except Exception as e:
            print(f'[BouquetContents] Error exporting: {e}')
            showMessage(self.session, f'Error: {str(e)}', MessageBox.TYPE_ERROR)

    def importChannels(self):
        def pathCallback(filepath):
            if not filepath or not filepath.strip():
                return
            self.importFromFile(filepath.strip())

        self.session.openWithCallback(pathCallback, VirtualKeyBoard, title='Enter path to import file', text='/tmp/')

    def importFromFile(self, filepath):
        if not os.path.exists(filepath):
            showMessage(self.session, 'File not found', MessageBox.TYPE_ERROR)
            return
        success_count = 0
        fail_count = 0
        new_channels = []
        try:
            with open(filepath, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parts = line.split('|')
                    if len(parts) >= 2:
                        service_ref = eServiceReference(parts[1])
                        if service_ref.valid():
                            new_channels.append(service_ref)
                            success_count += 1
                        else:
                            fail_count += 1
                    else:
                        fail_count += 1
            if success_count > 0:
                serviceHandler = eServiceCenter.getInstance()
                services = serviceHandler.list(self.bouquet_ref)
                if services:
                    mutable = services.startEdit()
                    if mutable:
                        for service_ref in new_channels:
                            mutable.addService(service_ref)
                        mutable.flushChanges()
                        db = eDVBDB.getInstance()
                        db.reloadBouquets()
                        db.saveServicelist()
                        self.loadChannels()
                        self.updateList()
                        self.updateInfoLabel()
                        self.updateHelpLabel()
            showMessage(self.session, f'Import completed:\nSuccess: {success_count}\nFailed: {fail_count}')
        except Exception as e:
            print(f'[BouquetContents] Error importing: {e}')
            showMessage(self.session, f'Error: {str(e)}', MessageBox.TYPE_ERROR)

    def showBouquetInfo(self):
        info = 'Bouquet Information:\n\n'
        info += f'Name: {self.bouquet_name}\n'
        info += f'Type: {self.bouquet_type.upper()}\n'
        info += f'Channels: {len(self.channels)}\n'
        info += f'Sort: {self.getSortModeText()}\n'
        info += f'Reference: {self.bouquet_ref.toString()}'
        showMessage(self.session, info)

class BouquetMoveModeAdvanced(Screen):
    """وضع النقل اليدوي للقنوات داخل البوكيه مع نفس مقاسات وبيانات شاشة محتويات الباقة"""
    skin = '\n    <screen position=\"center,center\" size=\"950,620\" title=\"Move Channels\">\n        <widget name=\"title_label\" position=\"10,10\" size=\"930,30\" font=\"Regular;26\" halign=\"center\" foregroundColor=\"#00aaff\"/>\n        <widget name=\"info_label\" position=\"10,45\" size=\"930,30\" font=\"Regular;22\" halign=\"left\" foregroundColor=\"#cccccc\"/>\n        <widget name=\"help_label\" position=\"10,75\" size=\"930,30\" font=\"Regular;22\" halign=\"left\" foregroundColor=\"#ffff99\"/>\n        <widget name=\"list\" position=\"10,110\" size=\"930,440\" itemHeight=\"50\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n\n        <widget name=\"key_red\" position=\"10,575\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Back\"/>\n        <widget name=\"key_green\" position=\"140,575\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"Preview\"/>\n        <widget name=\"key_yellow\" position=\"270,575\" size=\"130,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffff00\" text=\"Reset\"/>\n        <widget name=\"key_blue\" position=\"410,575\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00aaff\" text=\"Save\"/>\n    </screen>\n    '
    def __init__(self, session, bouquet_ref, bouquet_name):
        Screen.__init__(self, session)
        self.session = session
        self.bouquet_ref = bouquet_ref
        self.bouquet_name = bouquet_name
        self.channels = []
        self.original_order = []
        self.selected_index = -1
        self.items_per_page = 12
        self.original_service = session.nav.getCurrentlyPlayingServiceReference()
        self.previewed_service = None
        icon_path = os.path.join(os.path.dirname(__file__), 'icons', 'icon_crypt.png')
        self.lock_icon = LoadPixmap(icon_path) if os.path.exists(icon_path) else None
        self.loadChannels()
        self['title_label'] = Label(f'Move Channels In: {bouquet_name}')
        self['info_label'] = Label('')
        self['help_label'] = Label('')
        self['list'] = MenuList([], False, eListboxPythonMultiContent)
        self['list'].l.setFont(0, gFont('Regular', 26))
        self['list'].l.setItemHeight(50)
        self['list'].onSelectionChanged.append(self.onSelectionChanged)
        self['key_red'] = Label('Back')
        self['key_green'] = Label('Preview')
        self['key_yellow'] = Label('Reset')
        self['key_blue'] = Label('Save')
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions', 'ColorActions'], {'ok': self.okPressed, 'cancel': self.exit, 'red': self.exit, 'green': self.greenPressed, 'yellow': self.yellowPressed, 'blue': self.bluePressed, 'up': self.upPressed, 'down': self.downPressed, 'left': self.leftPressed, 'right': self.rightPressed}, -2)
        self.updateList()

    def loadChannels(self):
        self.channels = []
        self.original_order = []
        serviceHandler = eServiceCenter.getInstance()
        services = serviceHandler.list(self.bouquet_ref)
        if services:
            while True:
                service = services.getNext()
                if not service.valid():
                    break
                if not (service.flags & eServiceReference.isMarker):
                    info = serviceHandler.info(service)
                    if not info:
                        continue
                    name = info.getName(service)
                    tp = info.getInfoObject(service, iServiceInformation.sTransponderData)
                    sat = ''
                    orb = 0
                    freq = ''
                    if tp and 'orbital_position' in tp:
                        orb = tp['orbital_position']
                        sat = getSatelliteName(orb)
                    if tp and 'frequency' in tp:
                        try:
                            freq = str(int(tp['frequency'] / 1000)) + ' MHz'
                        except:
                            freq = ''
                    ctype = getChannelType(service)
                    quality = getChannelQuality(info, service)
                    try:
                        is_locked = bool(info.isCrypted())
                    except:
                        is_locked = False
                    item = (name, service, sat, orb, freq, ctype, quality, is_locked)
                    self.channels.append(item)
                    self.original_order.append(item)

    def updateList(self):
        listdata = []
        for idx, (name, service, sat, orb, freq, ctype, quality, is_locked) in enumerate(self.channels):
            picon = getPicon(service)
            display_name = f'>>> {name} <<<' if idx == self.selected_index else name
            entry = [MultiContentEntryPixmapAlphaBlend(pos=(10, 5), size=(40, 40), png=picon), MultiContentEntryText(pos=(70, 10), size=(240, 40), font=0, text=display_name)]
            if is_locked and self.lock_icon is not None:
                entry.append(MultiContentEntryPixmapAlphaBlend(pos=(320, 8), size=(55, 35), png=self.lock_icon))
            entry.extend([MultiContentEntryText(pos=(430, 10), size=(70, 40), font=0, text=ctype), MultiContentEntryText(pos=(510, 10), size=(70, 40), font=0, text=quality), MultiContentEntryText(pos=(590, 10), size=(120, 40), font=0, text=sat), MultiContentEntryText(pos=(720, 10), size=(180, 40), font=0, text=freq)])
            listdata.append(entry)
        self['list'].setList(listdata)
        self.updateInfoLabel()
        self.updateHelpLabel()

    def updateInfoLabel(self):
        current_index = self['list'].getSelectedIndex()
        cursor = current_index + 1 if current_index is not None and current_index >= 0 else 0
        moving_name = self.channels[self.selected_index][0] if self.selected_index != -1 and self.selected_index < len(self.channels) else 'None'
        self['info_label'].setText(f'Channels: {len(self.channels)}  |  Cursor: {cursor}  |  Moving: {moving_name}')

    def updateHelpLabel(self):
        if self.selected_index != -1:
            self['help_label'].setText('Move mode: use UP/DOWN to reposition the selected channel, BLUE=Save')
        else:
            self['help_label'].setText('Press OK to select a channel for moving, GREEN=Preview, YELLOW=Reset')

    def onSelectionChanged(self):
        self.updateInfoLabel()
        self.updateHelpLabel()

    def okPressed(self):
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if self.selected_index == current_index:
            self.selected_index = -1
        else:
            self.selected_index = current_index
        self.updateList()

    def greenPressed(self):
        current = self['list'].getCurrent()
        if not current:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked = current[0]
        self.session.nav.playService(service)
        self.previewed_service = service
        self['help_label'].setText(f'Previewing: {name}')

    def yellowPressed(self):
        self.channels = list(self.original_order)
        self.selected_index = -1
        self.updateList()

    def bluePressed(self):
        self.saveChanges()

    def upPressed(self):
        if self.selected_index != -1:
            if self.selected_index > 0:
                new_index = self.selected_index - 1
                self.channels[self.selected_index], self.channels[new_index] = self.channels[new_index], self.channels[self.selected_index]
                self.selected_index = new_index
                self['list'].moveToIndex(new_index)
                self.updateList()
            return
        else:
            self.navigateUp()

    def downPressed(self):
        if self.selected_index != -1:
            if self.selected_index < len(self.channels) - 1:
                new_index = self.selected_index + 1
                self.channels[self.selected_index], self.channels[new_index] = self.channels[new_index], self.channels[self.selected_index]
                self.selected_index = new_index
                self['list'].moveToIndex(new_index)
                self.updateList()
            return
        else:
            self.navigateDown()

    def leftPressed(self):
        if self.selected_index != -1:
            return
        if not self.channels:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        new_index = max(0, current_index - self.items_per_page)
        self['list'].moveToIndex(new_index)
        self.onSelectionChanged()

    def rightPressed(self):
        if self.selected_index != -1:
            return
        if not self.channels:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        new_index = min(len(self.channels) - 1, current_index + self.items_per_page)
        self['list'].moveToIndex(new_index)
        self.onSelectionChanged()

    def navigateUp(self):
        if not self.channels:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if current_index == 0:
            self['list'].moveToIndex(len(self.channels) - 1)
        else:
            self['list'].up()
        self.onSelectionChanged()

    def navigateDown(self):
        if not self.channels:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if current_index == len(self.channels) - 1:
            self['list'].moveToIndex(0)
        else:
            self['list'].down()
        self.onSelectionChanged()

    def saveChanges(self):
        serviceHandler = eServiceCenter.getInstance()
        services = serviceHandler.list(self.bouquet_ref)
        if not services:
            return
        mutable = services.startEdit()
        if not mutable:
            print('[MoveMode] startEdit failed')
            return
        try:
            current_services = []
            srvlist = serviceHandler.list(self.bouquet_ref)
            if srvlist:
                while True:
                    s = srvlist.getNext()
                    if not s.valid():
                        break
                    if not (s.flags & eServiceReference.isMarker):
                        current_services.append(s)
            for s in current_services:
                try:
                    mutable.removeService(s)
                except Exception as e:
                    print('[MoveMode] remove error:', e)
            mutable.flushChanges()
            for item in self.channels:
                try:
                    mutable.addService(item[1])
                except Exception as e:
                    print('[MoveMode] add error:', e)
            mutable.flushChanges()
            db = eDVBDB.getInstance()
            db.reloadBouquets()
            db.saveServicelist()
            print('[MoveMode] Save OK')
            self.selected_index = -1
            self.original_order = list(self.channels)
            self.close(True)
        except Exception as e:
            print('[MoveMode] Save error:', e)
            showMessage(self.session, f'Error saving changes:\n{str(e)}')

    def exit(self):
        if self.original_service:
            self.session.nav.playService(self.original_service)
        self.close(False)

def openBouquetsManager(session, **kwargs):
    """فتح شاشة إدارة الباقات"""
    session.open(BouquetsManager)