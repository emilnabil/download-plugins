# -*- coding: utf-8 -*-
import os
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Tools.LoadPixmap import LoadPixmap
from enigma import eServiceCenter, eServiceReference, eListboxPythonMultiContent, gFont, iServiceInformation
from Plugins.Extensions.AdenChManager.utils import getPicon, getSatelliteName, getChannelType, getChannelQuality
from Plugins.Extensions.AdenChManager.bouquets import BouquetSelectionScreen, showMessage

LOCK_ICON = '🔒'
CHECK_ICON = '[x]'
UNCHECK_ICON = '[ ]'


def getLockIcon():
    paths = [
        '/usr/share/enigma2/skin_default/icons/lock.png',
        '/usr/share/enigma2/Aden-Pli-HD/icons/lock.png',
        '/usr/share/enigma2/Aden-Pli9-FHD-Poster/icons/lock.png'
    ]
    for path in paths:
        try:
            if os.path.exists(path):
                pix = LoadPixmap(path)
                if pix:
                    return pix
        except Exception:
            pass
    return None


def getFolderIcon():
    paths = [
        '/usr/share/enigma2/skin_default/icons/folder.png',
        '/usr/share/enigma2/Aden-Pli-HD/icons/folder.png',
        '/usr/share/enigma2/Aden-Pli9-FHD-Poster/icons/folder.png'
    ]
    for path in paths:
        try:
            pix = LoadPixmap(path)
            if pix:
                return pix
        except Exception:
            pass
    return None


class SatelliteChannelsMenuScreen(Screen):
    """
    شاشة منيو مستقلة خاصة بقنوات الأقمار
    """
    skin = """
    <screen position="center,center" size="620,420" title="Satellite Channels Menu">
        <widget name="title_label" position="10,10" size="600,30" font="Regular;26" halign="center" foregroundColor="#00aaff"/>
        <widget name="help_label" position="10,45" size="600,28" font="Regular;20" halign="center" foregroundColor="#cccccc"/>
        <widget name="list" position="10,85" size="600,280" itemHeight="40" font="Regular;24" scrollbarMode="showOnDemand"/>
        <widget name="key_red" position="10,380" size="120,30" font="Regular;22" halign="center" foregroundColor="#ff0000" text="Close"/>
    </screen>
    """

    def __init__(self, session, parent_screen):
        Screen.__init__(self, session)
        self.session = session
        self.parent_screen = parent_screen
        self['title_label'] = Label('Satellite Channels Menu')
        self['help_label'] = Label('OK=Run  |  RED=Close')
        self['list'] = MenuList([])
        self['key_red'] = Label('Close')
        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions', 'DirectionActions'],
            {
                'ok': self.runAction,
                'cancel': self.close,
                'red': self.close,
                'up': self.moveUpCircular,
                'down': self.moveDownCircular,
                'left': self.pageUpCircular,
                'right': self.pageDownCircular
            }, -1
        )
        self.refreshMenu()

    def refreshMenu(self):
        all_visible_selected = self.parent_screen.areAllVisibleSelected()
        menu = [
            ('Copy selected/current channels to bouquet', 'copy'),
            ('Deselect all visible channels' if all_visible_selected else 'Select all visible channels', 'toggle_all'),
            ('Select / deselect current channel', 'toggle_current'),
            ('Filter by name', 'filter_name'),
            ('Filter by encryption', 'filter_encryption'),
            ('Filter by channel type', 'filter_channel_type'),
            ('Filter by quality', 'filter_quality'),
            ('Filter by frequency', 'filter_frequency')
        ]
        if hasattr(self.parent_screen, 'supportsSatelliteFilter') and self.parent_screen.supportsSatelliteFilter():
            menu.append(('Filter by satellite', 'filter_satellite'))
        menu.extend([
            ('Reset all filters', 'reset_filters'),
            ('Clear all selected channels', 'clear_selection')
        ])
        self['list'].setList(menu)

    def getVisibleRowsCount(self):
        list_instance = self['list']
        listbox_instance = getattr(list_instance, 'instance', None)
        if listbox_instance is not None:
            size = listbox_instance.size()
            if size is not None:
                height = size.height()
                item_height = self['list'].l.getItemSize().height()
                if height > 0 and item_height > 0:
                    return max(1, int(height / item_height))
        return 7

    def moveSelectionCircular(self, step):
        items = self['list'].list if hasattr(self['list'], 'list') else []
        total = len(items)
        if total <= 0:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            current_index = 0
        try:
            new_index = (current_index + step) % total
            self['list'].moveToIndex(new_index)
        except Exception as e:
            print('[SatelliteChannelsMenu] circular move error: %s' % e)

    def moveUpCircular(self):
        self.moveSelectionCircular(-1)

    def moveDownCircular(self):
        self.moveSelectionCircular(1)

    def pageUpCircular(self):
        total = len(self['list'].list) if hasattr(self['list'], 'list') else 0
        if total <= 0:
            return
        page_size = self.getVisibleRowsCount()
        if total <= page_size:
            self['list'].moveToIndex(0)
        else:
            self.moveSelectionCircular(-page_size)

    def pageDownCircular(self):
        total = len(self['list'].list) if hasattr(self['list'], 'list') else 0
        if total <= 0:
            return
        page_size = self.getVisibleRowsCount()
        if total <= page_size:
            self['list'].moveToIndex(total - 1)
        else:
            self.moveSelectionCircular(page_size)

    def runAction(self):
        current = self['list'].getCurrent()
        if not current:
            return
        action = current[1]
        if action == 'copy':
            self.close('copy')
        elif action == 'toggle_all':
            self.parent_screen.toggleSelectAllVisible()
            self.refreshMenu()
        elif action == 'toggle_current':
            self.close('toggle_current')
        elif action == 'filter_name':
            self.close('filter_name')
        elif action == 'filter_encryption':
            self.close('filter_encryption')
        elif action == 'filter_channel_type':
            self.close('filter_channel_type')
        elif action == 'filter_quality':
            self.close('filter_quality')
        elif action == 'filter_frequency':
            self.close('filter_frequency')
        elif action == 'filter_satellite':
            self.close('filter_satellite')
        elif action == 'reset_filters':
            self.close('reset_filters')
        elif action == 'clear_selection':
            self.close('clear_selection')


class SatellitesBrowserScreen(Screen):
    skin = """
    <screen position="center,center" size="900,600" title="Satellites Browser">
        <widget name="title_label" position="10,10" size="880,30" font="Regular;26" halign="center" foregroundColor="#00aaff"/>
        <widget name="info_label" position="10,45" size="880,30" font="Regular;22" halign="left" foregroundColor="#cccccc"/>
        <widget name="list" position="10,80" size="880,460" itemHeight="42" font="Regular;26" scrollbarMode="showOnDemand"/>

        <widget name="key_red" position="10,560" size="120,35" font="Regular;22" halign="center" foregroundColor="#ff0000" text="Back"/>
        <widget name="key_green" position="770,560" size="120,35" font="Regular;22" halign="center" foregroundColor="#00ff00" text="Open"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.serviceHandler = eServiceCenter.getInstance()
        self.satellites = []
        self.folder_icon = getFolderIcon()
        self['title_label'] = Label('Satellites Browser')
        self['info_label'] = Label('Loading satellites...')
        self['list'] = MenuList([], False, eListboxPythonMultiContent)
        self['key_red'] = Label('Sort')
        self['key_green'] = Label('Open')
        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions', 'DirectionActions'],
            {
                'ok': self.openSatellite,
                'cancel': self.close,
                'red': self.close,
                'green': self.openSatellite,
                'up': self.moveUpCircular,
                'down': self.moveDownCircular,
                'left': self.pageUpCircular,
                'right': self.pageDownCircular
            }, -1
        )
        self.loadSatellites()
        self.updateList()

    def getVisibleRowsCount(self):
        list_instance = self['list']
        listbox_instance = getattr(list_instance, 'instance', None)
        if listbox_instance is not None:
            size = listbox_instance.size()
            if size is not None:
                height = size.height()
                item_height = self['list'].l.getItemSize().height()
                if height > 0 and item_height > 0:
                    return max(1, int(height / item_height))
        return 10

    def moveSelectionCircular(self, step):
        items = self['list'].list if hasattr(self['list'], 'list') else []
        total = len(items)
        if total <= 0:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            current_index = 0
        try:
            new_index = (current_index + step) % total
            self['list'].moveToIndex(new_index)
        except Exception as e:
            print('[SatellitesBrowserScreen] circular move error: %s' % e)

    def moveUpCircular(self):
        self.moveSelectionCircular(-1)

    def moveDownCircular(self):
        self.moveSelectionCircular(1)

    def pageUpCircular(self):
        total = len(self['list'].list) if hasattr(self['list'], 'list') else 0
        if total <= 0:
            return
        page_size = self.getVisibleRowsCount()
        if total <= page_size:
            self['list'].moveToIndex(0)
        else:
            self.moveSelectionCircular(-page_size)

    def pageDownCircular(self):
        total = len(self['list'].list) if hasattr(self['list'], 'list') else 0
        if total <= 0:
            return
        page_size = self.getVisibleRowsCount()
        if total <= page_size:
            self['list'].moveToIndex(total - 1)
        else:
            self.moveSelectionCircular(page_size)

    def loadSatellites(self):
        self.satellites = []
        satellites_map = {}
        seen = set()
        total_services = 0
        try:
            bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
            bouquet_list = self.serviceHandler.list(bouquet_root)
            if not bouquet_list:
                self['info_label'].setText('No TV bouquets found')
                return
            while True:
                bouquet = bouquet_list.getNext()
                if not bouquet.valid():
                    break
                services = self.serviceHandler.list(bouquet)
                if not services:
                    continue
                while True:
                    service = services.getNext()
                    if not service.valid():
                        break
                    if service.flags & eServiceReference.isMarker:
                        continue
                    sref = service.toString()
                    if sref in seen:
                        continue
                    info = self.serviceHandler.info(service)
                    if not info:
                        continue
                    tp = info.getInfoObject(service, iServiceInformation.sTransponderData)
                    if not tp or 'orbital_position' not in tp:
                        continue
                    name_text = info.getName(service) or ''
                    if name_text.strip():
                        seen.add(sref)
                        total_services += 1
                        orb = tp['orbital_position']
                        name = getSatelliteName(orb)
                        if orb not in satellites_map:
                            satellites_map[orb] = {'name': name, 'orbital_position': orb, 'count': 0}
                        satellites_map[orb]['count'] += 1
            self.satellites = sorted(satellites_map.values(), key=lambda x: x['orbital_position'])
            self.satellites.append({'name': 'All Satellites', 'orbital_position': None, 'count': total_services})
            self['info_label'].setText('Total satellites: %d' % len(satellites_map))
        except Exception as e:
            print('[SatellitesBrowser] load satellite error: %s' % e)

    def updateList(self):
        items = []
        for sat in self.satellites:
            row = [(sat['name'], sat['orbital_position'], sat['count'])]
            if self.folder_icon:
                row.append(MultiContentEntryPixmapAlphaBlend(pos=(10, 5), size=(32, 32), png=self.folder_icon))
            else:
                row.append(MultiContentEntryText(pos=(10, 5), size=(40, 32), font=0, text='[+]'))
            row.append(MultiContentEntryText(pos=(55, 5), size=(450, 32), font=0, text=sat['name']))
            row.append(MultiContentEntryText(pos=(650, 5), size=(200, 32), font=0, text='%d channels' % sat['count']))
            items.append(row)
        self['list'].setList(items)

    def openSatellite(self):
        current = self['list'].getCurrent()
        if not current or not current[0]:
            return
        sat_name, orbital_position, count = current[0]
        if orbital_position is None:
            self.session.open(AllSatellitesChannelsScreen, sat_name, orbital_position)
        else:
            self.session.open(SatelliteChannelsScreen, sat_name, orbital_position)


class SatelliteChannelsScreen(Screen):
    skin = """
    <screen position="center,center" size="940,660" title="Satellite Channels">
        <widget name="title_label" position="10,10" size="920,40" font="Regular;28" halign="center" foregroundColor="#00aaff"/>
        <widget name="info_label" position="10,45" size="920,36" font="Regular;26" halign="left" foregroundColor="#cccccc"/>
        <widget name="filter_label" position="10,70" size="920,36" font="Regular;26" halign="left" foregroundColor="#ffff00"/>
        <widget name="list" position="10,105" size="920,490" itemHeight="44" font="Regular;28" scrollbarMode="showOnDemand"/>

        <widget name="key_red" position="10,620" size="120,30" font="Regular;24" halign="center" foregroundColor="#ff0000" text="Sort"/>
        <widget name="key_green" position="150,620" size="140,30" font="Regular;24" halign="center" foregroundColor="#00ff00" text="Select All"/>
        <widget name="key_yellow" position="310,620" size="130,30" font="Regular;24" halign="center" foregroundColor="#ffff00" text="Select"/>
        <widget name="key_blue" position="460,620" size="130,30" font="Regular;24" halign="center" foregroundColor="#00aaff" text="Copy"/>
        <widget name="key_menu" position="610,620" size="140,30" font="Regular;24" halign="center" foregroundColor="#ffffff" text="Menu"/>
        <widget name="key_ok" position="760,620" size="180,30" font="Regular;24" halign="center" foregroundColor="#cccccc" text="OK = Play"/>
    </screen>
    """

    def __init__(self, session, sat_name, orbital_position):
        Screen.__init__(self, session)
        self.session = session
        self.serviceHandler = eServiceCenter.getInstance()
        self.sat_name = sat_name
        self.orbital_position = orbital_position
        self.original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        self.preview_service_ref = None
        self.close_after_zap = False
        self.lock_icon = getLockIcon()
        self.all_channels = []
        self.filtered_channels = []
        self.selected_refs = set()
        self.pending_service = None
        self.pending_services = []
        self.filter_name = ''
        self.filter_encryption = 'all'
        self.filter_channel_type = 'all'
        self.filter_quality = 'all'
        self.filter_frequencies = set()
        self.sort_mode = 'name'

        self['title_label'] = Label('Satellite: %s' % sat_name)
        self['info_label'] = Label('Loading channels...')
        self['filter_label'] = Label('')
        self['list'] = MenuList([], False, eListboxPythonMultiContent)
        self['list'].l.setFont(0, gFont('Regular', 24))

        self['key_red'] = Label('Sort')
        self['key_green'] = Label('Select All')
        self['key_yellow'] = Label('Select')
        self['key_blue'] = Label('Copy')
        self['key_menu'] = Label('Menu')
        self['key_ok'] = Label('OK = Play')

        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions', 'MenuActions', 'DirectionActions'],
            {
                'ok': self.playSelectedChannel,
                'cancel': self.exitScreen,
                'red': self.openSortMenu,
                'green': self.toggleSelectAllVisible,
                'yellow': self.toggleSelectionAndMove,
                'blue': self.copySelectedToBouquet,
                'menu': self.openMenuScreen,
                'up': self.moveUpCircular,
                'down': self.moveDownCircular,
                'left': self.pageUpCircular,
                'right': self.pageDownCircular
            }, -1
        )
        self.loadChannels()
        self.applyFilters()

    def exitScreen(self):
        if not self.close_after_zap and self.original_service:
            try:
                self.session.nav.playService(self.original_service)
            except Exception:
                pass
        self.close()

    def isEncryptedChannel(self, info, service, tp=None):
        try:
            return bool(info.isCrypted())
        except Exception:
            return False

    def loadChannels(self):
        self.all_channels = []
        seen = set()
        try:
            bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
            bouquet_list = self.serviceHandler.list(bouquet_root)
            if not bouquet_list:
                self['info_label'].setText('No TV bouquets found')
                return
            while True:
                bouquet = bouquet_list.getNext()
                if not bouquet.valid():
                    break
                services = self.serviceHandler.list(bouquet)
                if not services:
                    continue
                while True:
                    service = services.getNext()
                    if not service.valid():
                        break
                    if service.flags & eServiceReference.isMarker:
                        continue
                    sref = service.toString()
                    if sref in seen:
                        continue
                    info = self.serviceHandler.info(service)
                    if not info:
                        continue
                    tp = info.getInfoObject(service, iServiceInformation.sTransponderData)
                    if not tp or 'orbital_position' not in tp:
                        continue
                    orb = tp['orbital_position']
                    if self.orbital_position is not None and orb != self.orbital_position:
                        continue
                    name = info.getName(service) or '-'
                    if name.strip():
                        seen.add(sref)
                        freq = ''
                        freq_raw = 0
                        if 'frequency' in tp:
                            try:
                                freq_raw = int(tp['frequency'])
                                freq = '%d MHz' % int(freq_raw / 1000)
                            except Exception:
                                freq = ''
                                freq_raw = 0
                        ctype = getChannelType(service)
                        quality = getChannelQuality(info, service)
                        locked = self.isEncryptedChannel(info, service, tp)
                        self.all_channels.append({
                            'name': name,
                            'service': service,
                            'freq': freq,
                            'freq_raw': freq_raw,
                            'ctype': ctype,
                            'quality': quality,
                            'locked': locked,
                            'orbital_position': orb,
                            'satellite': getSatelliteName(orb),
                            'bouquet_ref': bouquet
                        })
            self.all_channels.sort(key=lambda x: x['name'].lower())
        except Exception as e:
            print('[SatelliteChannels] load channel error: %s' % e)

    def buildFilterSummary(self):
        parts = []
        if self.filter_name:
            parts.append('Name=%s' % self.filter_name)
        if self.filter_encryption != 'all':
            parts.append('Enc=%s' % self.filter_encryption)
        if self.filter_channel_type != 'all':
            parts.append('Type=%s' % self.filter_channel_type)
        if self.filter_quality != 'all':
            parts.append('Quality=%s' % self.filter_quality)
        if self.filter_frequencies:
            parts.append('Freq=%d selected' % len(self.filter_frequencies))
        if not parts:
            return 'Filters: none'
        return 'Filters: ' + ' | '.join(parts)

    def applyFilters(self):
        result = []
        name_filter = self.filter_name.lower().strip()
        for item in self.all_channels:
            if name_filter and name_filter not in (item['name'] or '').lower():
                continue
            if self.filter_encryption == 'encrypted' and not item['locked']:
                continue
            if self.filter_encryption == 'free' and item['locked']:
                continue
            if self.filter_channel_type != 'all' and item['ctype'] != self.filter_channel_type:
                continue
            if self.filter_quality != 'all' and item['quality'] != self.filter_quality:
                continue
            if self.filter_frequencies and item['freq_raw'] not in self.filter_frequencies:
                continue
            result.append(item)
        self.filtered_channels = self.sortChannels(result)
        self.updateList()

    def supportsSatelliteFilter(self):
        return False

    def areAllVisibleSelected(self):
        if not self.filtered_channels:
            return False
        for item in self.filtered_channels:
            if item['service'].toString() not in self.selected_refs:
                return False
        return True

    def updateGreenKeyLabel(self):
        if self.areAllVisibleSelected():
            self['key_green'].setText('Deselect All')
        else:
            self['key_green'].setText('Select All')

    def sortChannels(self, items):
        try:
            if self.sort_mode == 'name':
                return sorted(items, key=lambda x: (x.get('name') or '').lower())
            elif self.sort_mode == 'ctype':
                return sorted(items, key=lambda x: (x.get('ctype') or '', (x.get('name') or '').lower()))
            elif self.sort_mode == 'quality':
                quality_order = {'UHD': 0, '4K': 0, 'FHD': 1, 'HD': 2, 'SD': 3, '-': 4, '': 4}
                return sorted(items, key=lambda x: (quality_order.get(x.get('quality'), 9), (x.get('name') or '').lower()))
            elif self.sort_mode == 'locked':
                return sorted(items, key=lambda x: (0 if x.get('locked') else 1, (x.get('name') or '').lower()))
            elif self.sort_mode == 'freq':
                return sorted(items, key=lambda x: (x.get('freq_raw', 0), (x.get('name') or '').lower()))
            else:
                return items
        except Exception as e:
            print('[SatelliteChannels] sort error: %s' % e)
            return items

    def openSortMenu(self):
        items = [
            ('Alphabetical', 'name'),
            ('By channel type', 'ctype'),
            ('By quality', 'quality'),
            ('By encryption', 'locked'),
            ('By frequency', 'freq')
        ]
        self.session.openWithCallback(self.sortMenuCallback, MenuChoiceScreen, 'Sort channels', items)

    def sortMenuCallback(self, choice):
        if not choice:
            return
        self.sort_mode = choice[1]
        self.applyFilters()

    def updateList(self):
        listdata = []
        for item in self.filtered_channels:
            name = item['name']
            service = item['service']
            freq = item['freq']
            ctype = item['ctype']
            quality = item['quality']
            locked = item['locked']
            sref = service.toString()
            selected_text = CHECK_ICON if sref in self.selected_refs else UNCHECK_ICON
            picon = getPicon(service)

            entry = [(name, service, freq, ctype, quality, locked)]
            entry.append(MultiContentEntryText(pos=(10, 8), size=(55, 35), font=0, text=selected_text))
            if picon:
                entry.append(MultiContentEntryPixmapAlphaBlend(pos=(60, 5), size=(40, 40), png=picon))
            else:
                entry.append(MultiContentEntryText(pos=(60, 8), size=(40, 35), font=0, text=' '))
            entry.append(MultiContentEntryText(pos=(120, 8), size=(300, 35), font=0, text=name))
            entry.append(MultiContentEntryText(pos=(565, 8), size=(80, 35), font=0, text=ctype))
            entry.append(MultiContentEntryText(pos=(660, 8), size=(80, 35), font=0, text=quality))
            entry.append(MultiContentEntryText(pos=(760, 8), size=(150, 35), font=0, text=freq))

            if locked:
                if self.lock_icon:
                    entry.append(MultiContentEntryPixmapAlphaBlend(pos=(440, 7), size=(70, 35), png=self.lock_icon))
                else:
                    entry.append(MultiContentEntryText(pos=(440, 7), size=(70, 35), font=0, text=LOCK_ICON))

            listdata.append(entry)

        self['list'].setList(listdata)
        self['info_label'].setText('Channels: %d / %d    Selected: %d' % (
            len(self.filtered_channels), len(self.all_channels), len(self.selected_refs)))
        self['filter_label'].setText(self.buildFilterSummary())
        self.updateGreenKeyLabel()

    def moveToNextRow(self):
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        total = len(self.filtered_channels)
        if total <= 0:
            return
        if current_index < total - 1:
            self['list'].moveToIndex(current_index + 1)

    def getVisibleRowsCount(self):
        list_instance = self['list']
        listbox_instance = getattr(list_instance, 'instance', None)
        if listbox_instance is not None:
            size = listbox_instance.size()
            if size is not None:
                height = size.height()
                item_height = self['list'].l.getItemSize().height()
                if height > 0 and item_height > 0:
                    return max(1, int(height / item_height))
        return 10

    def moveSelectionCircular(self, step):
        total = len(self.filtered_channels)
        if total <= 0:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            current_index = 0
        try:
            new_index = (current_index + step) % total
            self['list'].moveToIndex(new_index)
        except Exception as e:
            print('[SatelliteChannels] circular move error: %s' % e)

    def moveUpCircular(self):
        self.moveSelectionCircular(-1)

    def moveDownCircular(self):
        self.moveSelectionCircular(1)

    def pageUpCircular(self):
        total = len(self.filtered_channels)
        if total <= 0:
            return
        page_size = self.getVisibleRowsCount()
        if total <= page_size:
            self['list'].moveToIndex(0)
        else:
            self.moveSelectionCircular(-page_size)

    def pageDownCircular(self):
        total = len(self.filtered_channels)
        if total <= 0:
            return
        page_size = self.getVisibleRowsCount()
        if total <= page_size:
            self['list'].moveToIndex(total - 1)
        else:
            self.moveSelectionCircular(page_size)

    def getCurrentItem(self):
        current = self['list'].getCurrent()
        if not current:
            return None
        data = current[0]
        if len(data) != 6:
            return None
        name, service, freq, ctype, quality, locked = data
        # find the full channel object to get bouquet_ref
        bouquet_ref = None
        for channel in self.filtered_channels:
            if channel['service'].toString() == service.toString():
                bouquet_ref = channel.get('bouquet_ref')
                break
        return {
            'name': name,
            'service': service,
            'freq': freq,
            'ctype': ctype,
            'quality': quality,
            'locked': locked,
            'bouquet_ref': bouquet_ref
        }

    def playSelectedChannel(self):
        item = self.getCurrentItem()
        if not item:
            return
        service = item['service']
        current_ref = service.toString()

        if self.preview_service_ref == current_ref:
            self.close_after_zap = True
            try:
                from Screens.InfoBar import InfoBar
                infobar = InfoBar.instance
            except Exception:
                infobar = None
        else:
            self.session.nav.playService(service)
            self.preview_service_ref = current_ref
            try:
                from Screens.InfoBar import InfoBar
                infobar = InfoBar.instance
            except Exception:
                infobar = None

            if infobar and hasattr(infobar, 'servicelist') and infobar.servicelist:
                sl = infobar.servicelist
                bouquet_ref = item.get('bouquet_ref')
                try:
                    if hasattr(sl, 'servicePath') and sl.servicePath is not None:
                        del sl.servicePath[:]
                        if getattr(sl, 'bouquet_root', None):
                            sl.servicePath.append(sl.bouquet_root)
                        if bouquet_ref is not None:
                            sl.servicePath.append(bouquet_ref)
                except Exception as e:
                    print('[SatelliteChannels] servicePath set error: %s' % e)
                try:
                    if bouquet_ref is not None and hasattr(sl, 'setRoot'):
                        sl.setRoot(bouquet_ref)
                except Exception as e:
                    print('[SatelliteChannels] setRoot error: %s' % e)
                try:
                    if hasattr(sl, 'setCurrentSelection'):
                        sl.setCurrentSelection(service)
                    if hasattr(sl, 'setCurrent'):
                        sl.setCurrent(service)
                    if hasattr(sl, 'addToHistory'):
                        sl.addToHistory(service)
                except Exception as e:
                    print('[SatelliteChannels] history integration error: %s' % e)

    def toggleSelection(self):
        item = self.getCurrentItem()
        if not item:
            return False
        sref = item['service'].toString()
        if sref in self.selected_refs:
            self.selected_refs.remove(sref)
            changed_to_selected = False
        else:
            self.selected_refs.add(sref)
            changed_to_selected = True
        self.updateList()
        return changed_to_selected

    def toggleSelectionAndMove(self):
        self.toggleSelection()
        self.moveToNextRow()

    def selectAllVisible(self):
        for item in self.filtered_channels:
            self.selected_refs.add(item['service'].toString())
        self.updateList()

    def deselectAllVisible(self):
        for item in self.filtered_channels:
            sref = item['service'].toString()
            if sref in self.selected_refs:
                self.selected_refs.remove(sref)
        self.updateList()

    def toggleSelectAllVisible(self):
        if self.areAllVisibleSelected():
            self.deselectAllVisible()
        else:
            self.selectAllVisible()

    def clearSelection(self):
        self.selected_refs = set()
        self.updateList()

    def getSelectedServices(self):
        selected = []
        names = []
        for item in self.all_channels:
            sref = item['service'].toString()
            if sref in self.selected_refs:
                selected.append(item['service'])
                names.append(item['name'])
        return selected, names

    def getAvailableTargetBouquets(self):
        bouquets = []
        bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        bouquet_list = self.serviceHandler.list(bouquet_root)
        if not bouquet_list:
            return bouquets
        while True:
            bouquet = bouquet_list.getNext()
            if not bouquet.valid():
                break
            try:
                info = self.serviceHandler.info(bouquet)
                name = info.getName(bouquet)
                bouquets.append((name, bouquet))
            except Exception:
                pass
        return bouquets

    def copySelectedToBouquet(self):
        selected_services, selected_names = self.getSelectedServices()
        bouquets = self.getAvailableTargetBouquets()
        if not bouquets:
            showMessage(self.session, 'No target bouquets found', MessageBox.TYPE_INFO)
            return
        if selected_services:
            self.pending_services = list(selected_services)
            self.session.open(BouquetSelectionScreen, bouquets, self, True)
        else:
            item = self.getCurrentItem()
            if not item:
                return
            self.pending_service = item['service']
            self.session.open(BouquetSelectionScreen, bouquets, self, False)

    def copyToBouquetSelected(self, bouquet):
        service = self.pending_service
        if not service or not bouquet:
            return
        try:
            bouquet_ref = bouquet[1]
            bouquet_list = self.serviceHandler.list(bouquet_ref)
            if not bouquet_list:
                showMessage(self.session, 'Could not access target bouquet', MessageBox.TYPE_ERROR)
                return
            mutable = bouquet_list.startEdit()
            if not mutable:
                showMessage(self.session, 'Could not edit target bouquet', MessageBox.TYPE_ERROR)
                return
            mutable.addService(service)
            mutable.flushChanges()
            showMessage(self.session, 'Channel copied to bouquet:\n%s' % bouquet[0], MessageBox.TYPE_INFO)
        except Exception as e:
            print('[SatelliteChannels] copy single error: %s' % e)
            showMessage(self.session, 'Error copying channel:\n%s' % str(e), MessageBox.TYPE_ERROR)

    def copyMultipleToBouquetSelected(self, bouquet):
        if not bouquet or not self.pending_services:
            return
        success_count = 0
        fail_count = 0
        try:
            bouquet_ref = bouquet[1]
            bouquet_list = self.serviceHandler.list(bouquet_ref)
            if not bouquet_list:
                showMessage(self.session, 'Could not access target bouquet', MessageBox.TYPE_ERROR)
                return
            mutable = bouquet_list.startEdit()
            if not mutable:
                showMessage(self.session, 'Could not edit target bouquet', MessageBox.TYPE_ERROR)
                return
            for service in self.pending_services:
                try:
                    mutable.addService(service)
                    success_count += 1
                except Exception:
                    fail_count += 1
            mutable.flushChanges()
            msg = 'Copied %d channels to bouquet: %s' % (success_count, bouquet[0])
            if fail_count > 0:
                msg += '\nFailed: %d' % fail_count
            showMessage(self.session, msg, MessageBox.TYPE_INFO)
        except Exception as e:
            print('[SatelliteChannels] copy multiple error: %s' % e)
            showMessage(self.session, 'Error copying channels:\n%s' % str(e), MessageBox.TYPE_ERROR)
        self.pending_services = []

    def openMenuScreen(self):
        self.session.openWithCallback(self.onMenuClosed, SatelliteChannelsMenuScreen, self)

    def onMenuClosed(self, action=None):
        if not action:
            return
        if action == 'copy':
            self.copySelectedToBouquet()
        elif action == 'toggle_current':
            self.toggleSelectionAndMove()
        elif action == 'filter_name':
            self.openNameFilter()
        elif action == 'filter_encryption':
            self.openEncryptionFilter()
        elif action == 'filter_channel_type':
            self.openChannelTypeFilter()
        elif action == 'filter_quality':
            self.openQualityFilter()
        elif action == 'filter_frequency':
            self.openFrequencyFilter()
        elif action == 'filter_satellite' and self.supportsSatelliteFilter():
            self.openSatelliteFilter()
        elif action == 'reset_filters':
            self.resetFilters()
        elif action == 'clear_selection':
            self.clearSelection()

    def openNameFilter(self):
        self.session.openWithCallback(self.nameFilterCallback, VirtualKeyBoard, title='Enter channel name filter', text=self.filter_name)

    def openEncryptionFilter(self):
        items = [('All channels', 'all'), ('Encrypted only', 'encrypted'), ('Free only', 'free')]
        self.session.openWithCallback(self.encryptionFilterCallback, MenuChoiceScreen, 'Encryption filter', items)

    def openChannelTypeFilter(self):
        items = [('All channels', 'all'), ('TV only', 'TV'), ('Radio only', 'Radio')]
        self.session.openWithCallback(self.channelTypeFilterCallback, MenuChoiceScreen, 'Channel type filter', items)

    def openQualityFilter(self):
        items = [('All qualities', 'all'), ('HD only', 'HD'), ('SD only', 'SD'), ('Unknown / other', '-')]
        self.session.openWithCallback(self.qualityFilterCallback, MenuChoiceScreen, 'Quality filter', items)

    def getAvailableFrequencies(self):
        frequencies = []
        seen = set()
        for item in self.all_channels:
            freq_raw = item.get('freq_raw', 0)
            freq_text = item.get('freq', '')
            if not freq_raw or freq_raw in seen:
                continue
            seen.add(freq_raw)
            frequencies.append((freq_text or str(freq_raw), freq_raw))
        frequencies.sort(key=lambda x: x[1])
        return frequencies

    def openFrequencyFilter(self):
        self.session.openWithCallback(self.frequencyFilterCallback, FrequencyMultiSelectScreen, self.getAvailableFrequencies(), self.filter_frequencies)

    def nameFilterCallback(self, value):
        if value is None:
            return
        self.filter_name = value.strip()
        self.applyFilters()

    def encryptionFilterCallback(self, choice):
        if not choice:
            return
        self.filter_encryption = choice[1]
        self.applyFilters()

    def channelTypeFilterCallback(self, choice):
        if not choice:
            return
        self.filter_channel_type = choice[1]
        self.applyFilters()

    def qualityFilterCallback(self, choice):
        if not choice:
            return
        self.filter_quality = choice[1]
        self.applyFilters()

    def frequencyFilterCallback(self, values):
        if values is None:
            return
        self.filter_frequencies = set(values)
        self.applyFilters()

    def resetFilters(self):
        self.filter_name = ''
        self.filter_encryption = 'all'
        self.filter_channel_type = 'all'
        self.filter_quality = 'all'
        self.filter_frequencies = set()
        self.sort_mode = 'name'
        self.applyFilters()


class AllSatellitesChannelsScreen(SatelliteChannelsScreen):
    skin = """
    <screen position="center,center" size="1110,660" title="All Satellites Channels">
        <widget name="title_label" position="10,10" size="1000,40" font="Regular;28" halign="center" foregroundColor="#00aaff"/>
        <widget name="info_label" position="10,45" size="1000,36" font="Regular;26" halign="left" foregroundColor="#cccccc"/>
        <widget name="filter_label" position="10,70" size="1000,36" font="Regular;26" halign="left" foregroundColor="#ffff00"/>
        <widget name="list" position="10,105" size="1090,490" itemHeight="44" font="Regular;28" scrollbarMode="showOnDemand"/>

        <widget name="key_red" position="10,620" size="120,30" font="Regular;24" halign="center" foregroundColor="#ff0000" text="Sort"/>
        <widget name="key_green" position="150,620" size="140,30" font="Regular;24" halign="center" foregroundColor="#00ff00" text="Select All"/>
        <widget name="key_yellow" position="310,620" size="130,30" font="Regular;24" halign="center" foregroundColor="#ffff00" text="Select"/>
        <widget name="key_blue" position="460,620" size="130,30" font="Regular;24" halign="center" foregroundColor="#00aaff" text="Copy"/>
        <widget name="key_menu" position="610,620" size="140,30" font="Regular;24" halign="center" foregroundColor="#ffffff" text="Menu"/>
        <widget name="key_ok" position="900,620" size="220,30" font="Regular;24" halign="center" foregroundColor="#cccccc" text="OK = Play"/>
    </screen>
    """

    def __init__(self, session, sat_name, orbital_position):
        self.filter_satellites = set()
        self.last_preview_ref = None
        SatelliteChannelsScreen.__init__(self, session, sat_name, orbital_position)
        self['title_label'].setText('Folder: %s' % sat_name)

    def supportsSatelliteFilter(self):
        return True

    def buildFilterSummary(self):
        parts = []
        if self.filter_name:
            parts.append('Name=%s' % self.filter_name)
        if self.filter_encryption != 'all':
            parts.append('Enc=%s' % self.filter_encryption)
        if self.filter_channel_type != 'all':
            parts.append('Type=%s' % self.filter_channel_type)
        if self.filter_quality != 'all':
            parts.append('Quality=%s' % self.filter_quality)
        if self.filter_frequencies:
            parts.append('Freq=%d selected' % len(self.filter_frequencies))
        if self.filter_satellites:
            parts.append('Sat=%d selected' % len(self.filter_satellites))
        if not parts:
            return 'Filters: none'
        return 'Filters: ' + ' | '.join(parts)

    def applyFilters(self):
        result = []
        name_filter = self.filter_name.lower().strip()
        for item in self.all_channels:
            if name_filter and name_filter not in (item['name'] or '').lower():
                continue
            if self.filter_encryption == 'encrypted' and not item['locked']:
                continue
            if self.filter_encryption == 'free' and item['locked']:
                continue
            if self.filter_channel_type != 'all' and item['ctype'] != self.filter_channel_type:
                continue
            if self.filter_quality != 'all' and item['quality'] != self.filter_quality:
                continue
            if self.filter_frequencies and item['freq_raw'] not in self.filter_frequencies:
                continue
            if self.filter_satellites and item.get('orbital_position') not in self.filter_satellites:
                continue
            result.append(item)
        self.filtered_channels = self.sortChannels(result)
        self.updateList()

    def sortChannels(self, items):
        if self.sort_mode == 'satellite':
            return sorted(items, key=lambda x: ((x.get('satellite') or '').lower(), (x.get('name') or '').lower()))
        else:
            return super(AllSatellitesChannelsScreen, self).sortChannels(items)

    def openSortMenu(self):
        items = [
            ('Alphabetical', 'name'),
            ('By satellite', 'satellite'),
            ('By channel type', 'ctype'),
            ('By quality', 'quality'),
            ('By encryption', 'locked'),
            ('By frequency', 'freq')
        ]
        self.session.openWithCallback(self.sortMenuCallback, MenuChoiceScreen, 'Sort channels', items)

    def getAvailableSatellites(self):
        satellites = []
        seen = set()
        for item in self.all_channels:
            orb = item.get('orbital_position')
            name = item.get('satellite') or '-'
            if orb in seen:
                continue
            seen.add(orb)
            satellites.append((name, orb))
        satellites.sort(key=lambda x: (x[0] or '').lower())
        return satellites

    def openSatelliteFilter(self):
        self.session.openWithCallback(self.satelliteFilterCallback, SatelliteMultiSelectScreen, self.getAvailableSatellites(), self.filter_satellites)

    def satelliteFilterCallback(self, values):
        if values is None:
            return
        self.filter_satellites = set(values)
        self.applyFilters()

    def resetFilters(self):
        self.filter_name = ''
        self.filter_encryption = 'all'
        self.filter_channel_type = 'all'
        self.filter_quality = 'all'
        self.filter_frequencies = set()
        self.filter_satellites = set()
        self.sort_mode = 'name'
        self.applyFilters()

    def updateList(self):
        listdata = []
        for item in self.filtered_channels:
            name = item['name']
            service = item['service']
            freq = item['freq']
            ctype = item['ctype']
            quality = item['quality']
            locked = item['locked']
            satellite = item.get('satellite') or '-'
            sref = service.toString()
            selected_text = CHECK_ICON if sref in self.selected_refs else UNCHECK_ICON
            picon = getPicon(service)

            entry = [(name, service, freq, ctype, quality, locked, satellite)]
            entry.append(MultiContentEntryText(pos=(10, 8), size=(55, 35), font=0, text=selected_text))
            if picon:
                entry.append(MultiContentEntryPixmapAlphaBlend(pos=(60, 5), size=(40, 40), png=picon))
            else:
                entry.append(MultiContentEntryText(pos=(60, 8), size=(40, 35), font=0, text=' '))
            entry.append(MultiContentEntryText(pos=(120, 8), size=(350, 35), font=0, text=name))

            if locked:
                if self.lock_icon:
                    entry.append(MultiContentEntryPixmapAlphaBlend(pos=(520, 7), size=(70, 35), png=self.lock_icon))
                else:
                    entry.append(MultiContentEntryText(pos=(520, 7), size=(70, 35), font=0, text=LOCK_ICON))

            entry.append(MultiContentEntryText(pos=(620, 8), size=(70, 35), font=0, text=ctype))
            entry.append(MultiContentEntryText(pos=(720, 8), size=(70, 35), font=0, text=quality))
            entry.append(MultiContentEntryText(pos=(820, 8), size=(120, 35), font=0, text=satellite))
            entry.append(MultiContentEntryText(pos=(940, 8), size=(120, 35), font=0, text=freq))
            listdata.append(entry)

        self['list'].setList(listdata)
        self['info_label'].setText('Channels: %d / %d    Selected: %d' % (
            len(self.filtered_channels), len(self.all_channels), len(self.selected_refs)))
        self['filter_label'].setText(self.buildFilterSummary())
        self.updateGreenKeyLabel()

    def playSelectedChannel(self):
        item = self.getCurrentItem()
        if not item:
            return
        service = item['service']
        sref = service.toString()

        if self.last_preview_ref == sref:
            self.close_after_zap = True
            try:
                from Screens.InfoBar import InfoBar
                infobar = InfoBar.instance
            except Exception:
                infobar = None
        else:
            self.session.nav.playService(service)
            self.last_preview_ref = sref
            try:
                from Screens.InfoBar import InfoBar
                infobar = InfoBar.instance
            except Exception:
                infobar = None

            if infobar and hasattr(infobar, 'servicelist') and infobar.servicelist:
                sl = infobar.servicelist
                bouquet_ref = item.get('bouquet_ref')
                try:
                    if hasattr(sl, 'servicePath') and sl.servicePath is not None:
                        del sl.servicePath[:]
                        if getattr(sl, 'bouquet_root', None):
                            sl.servicePath.append(sl.bouquet_root)
                        if bouquet_ref is not None:
                            sl.servicePath.append(bouquet_ref)
                except Exception as e:
                    print('[AllSatellitesChannels] servicePath set error: %s' % e)
                try:
                    if bouquet_ref is not None and hasattr(sl, 'setRoot'):
                        sl.setRoot(bouquet_ref)
                except Exception as e:
                    print('[AllSatellitesChannels] setRoot error: %s' % e)
                try:
                    if hasattr(sl, 'setCurrentSelection'):
                        sl.setCurrentSelection(service)
                    if hasattr(sl, 'setCurrent'):
                        sl.setCurrent(service)
                    if hasattr(sl, 'addToHistory'):
                        sl.addToHistory(service)
                except Exception as e:
                    print('[AllSatellitesChannels] history integration error: %s' % e)

    def moveUpCircular(self):
        self.last_preview_ref = None
        super(AllSatellitesChannelsScreen, self).moveUpCircular()

    def moveDownCircular(self):
        self.last_preview_ref = None
        super(AllSatellitesChannelsScreen, self).moveDownCircular()

    def pageUpCircular(self):
        self.last_preview_ref = None
        super(AllSatellitesChannelsScreen, self).pageUpCircular()

    def pageDownCircular(self):
        self.last_preview_ref = None
        super(AllSatellitesChannelsScreen, self).pageDownCircular()

    def getCurrentItem(self):
        current = self['list'].getCurrent()
        if not current:
            return None
        data = current[0]
        if len(data) == 7:
            name, service, freq, ctype, quality, locked, satellite = data
        elif len(data) == 6:
            name, service, freq, ctype, quality, locked = data
            satellite = None
        else:
            return None
        bouquet_ref = None
        for channel in self.filtered_channels:
            if channel['service'].toString() == service.toString():
                bouquet_ref = channel.get('bouquet_ref')
                break
        return {
            'name': name,
            'service': service,
            'freq': freq,
            'ctype': ctype,
            'quality': quality,
            'locked': locked,
            'satellite': satellite,
            'bouquet_ref': bouquet_ref
        }


class SatelliteMultiSelectScreen(Screen):
    skin = """
    <screen position="center,center" size="560,420" title="Satellite Filter">
        <widget name="title_label" position="10,10" size="540,30" font="Regular;26" halign="center" foregroundColor="#00aaff"/>
        <widget name="list" position="10,50" size="540,300" itemHeight="38" font="Regular;24" scrollbarMode="showOnDemand"/>
        <widget name="key_red" position="10,380" size="120,25" font="Regular;22" halign="center" foregroundColor="#ff0000" text="Cancel"/>
        <widget name="key_green" position="150,380" size="120,25" font="Regular;22" halign="center" foregroundColor="#00ff00" text="Apply"/>
        <widget name="key_yellow" position="290,380" size="120,25" font="Regular;22" halign="center" foregroundColor="#ffff00" text="Mark"/>
        <widget name="key_blue" position="430,380" size="120,25" font="Regular;22" halign="center" foregroundColor="#00aaff" text="Clear"/>
    </screen>
    """

    def __init__(self, session, satellites, selected_values=None):
        Screen.__init__(self, session)
        self.satellites = satellites or []
        self.selected_values = set(selected_values or [])
        self['title_label'] = Label('Filter by satellite')
        self['list'] = MenuList([])
        self['key_red'] = Label('Cancel')
        self['key_green'] = Label('Apply')
        self['key_yellow'] = Label('Mark')
        self['key_blue'] = Label('Clear')
        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions'],
            {
                'ok': self.toggleCurrent,
                'yellow': self.toggleCurrent,
                'green': self.applySelection,
                'blue': self.clearSelection,
                'cancel': self.cancel,
                'red': self.cancel
            }, -1
        )
        self.updateList()

    def updateList(self):
        rows = []
        for label, value in self.satellites:
            prefix = CHECK_ICON if value in self.selected_values else UNCHECK_ICON
            rows.append(('%s %s' % (prefix, label), value))
        self['list'].setList(rows)

    def toggleCurrent(self):
        current = self['list'].getCurrent()
        if not current:
            return
        value = current[1]
        if value in self.selected_values:
            self.selected_values.remove(value)
        else:
            self.selected_values.add(value)
        index = self['list'].getSelectedIndex()
        self.updateList()
        if index is not None and index >= 0:
            try:
                self['list'].moveToIndex(index)
            except Exception:
                pass

    def clearSelection(self):
        self.selected_values = set()
        self.updateList()

    def applySelection(self):
        self.close(list(self.selected_values))

    def cancel(self):
        self.close(None)


class FrequencyMultiSelectScreen(Screen):
    """
    شاشة صغيرة لاختيار تردد واحد أو عدة ترددات
    """
    skin = """
    <screen position="center,center" size="560,420" title="Frequency Filter">
        <widget name="title_label" position="10,10" size="540,30" font="Regular;26" halign="center" foregroundColor="#00aaff"/>
        <widget name="list" position="10,50" size="540,300" itemHeight="38" font="Regular;24" scrollbarMode="showOnDemand"/>
        <widget name="key_red" position="10,380" size="120,25" font="Regular;22" halign="center" foregroundColor="#ff0000" text="Cancel"/>
        <widget name="key_green" position="150,380" size="120,25" font="Regular;22" halign="center" foregroundColor="#00ff00" text="Apply"/>
        <widget name="key_yellow" position="290,380" size="120,25" font="Regular;22" halign="center" foregroundColor="#ffff00" text="Mark"/>
        <widget name="key_blue" position="430,380" size="120,25" font="Regular;22" halign="center" foregroundColor="#00aaff" text="Clear"/>
    </screen>
    """

    def __init__(self, session, frequencies, selected_values=None):
        Screen.__init__(self, session)
        self.frequencies = frequencies or []
        self.selected_values = set(selected_values or [])
        self['title_label'] = Label('Filter by frequency')
        self['list'] = MenuList([])
        self['key_red'] = Label('Cancel')
        self['key_green'] = Label('Apply')
        self['key_yellow'] = Label('Mark')
        self['key_blue'] = Label('Clear')
        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions'],
            {
                'ok': self.toggleCurrent,
                'yellow': self.toggleCurrent,
                'green': self.applySelection,
                'blue': self.clearSelection,
                'cancel': self.cancel,
                'red': self.cancel
            }, -1
        )
        self.updateList()

    def updateList(self):
        rows = []
        for label, value in self.frequencies:
            prefix = CHECK_ICON if value in self.selected_values else UNCHECK_ICON
            rows.append(('%s %s' % (prefix, label), value))
        self['list'].setList(rows)

    def toggleCurrent(self):
        current = self['list'].getCurrent()
        if not current:
            return
        value = current[1]
        if value in self.selected_values:
            self.selected_values.remove(value)
        else:
            self.selected_values.add(value)
        index = self['list'].getSelectedIndex()
        self.updateList()
        if index is not None and index >= 0:
            try:
                self['list'].moveToIndex(index)
            except Exception:
                pass

    def clearSelection(self):
        self.selected_values = set()
        self.updateList()

    def applySelection(self):
        self.close(list(self.selected_values))

    def cancel(self):
        self.close(None)


class MenuChoiceScreen(Screen):
    """
    شاشة اختيار مستقلة بسيطة للفلاتر
    """
    skin = """
    <screen position="center,center" size="520,360" title="Select Option">
        <widget name="title_label" position="10,10" size="500,30" font="Regular;26" halign="center" foregroundColor="#00aaff"/>
        <widget name="list" position="10,55" size="500,255" itemHeight="40" font="Regular;24" scrollbarMode="showOnDemand"/>
        <widget name="key_red" position="10,325" size="120,25" font="Regular;22" halign="center" foregroundColor="#ff0000" text="Cancel"/>
        <widget name="key_green" position="390,325" size="120,25" font="Regular;22" halign="center" foregroundColor="#00ff00" text="Select"/>
    </screen>
    """

    def __init__(self, session, title, items):
        Screen.__init__(self, session)
        self['title_label'] = Label(title)
        self['list'] = MenuList(items)
        self['key_red'] = Label('Cancel')
        self['key_green'] = Label('Select')
        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions', 'DirectionActions'],
            {
                'ok': self.ok,
                'green': self.ok,
                'cancel': self.cancel,
                'red': self.cancel,
                'up': self.moveUpCircular,
                'down': self.moveDownCircular,
                'left': self.pageUpCircular,
                'right': self.pageDownCircular
            }, -1
        )

    def getVisibleRowsCount(self):
        list_instance = self['list']
        listbox_instance = getattr(list_instance, 'instance', None)
        if listbox_instance is not None:
            size = listbox_instance.size()
            if size is not None:
                height = size.height()
                item_height = self['list'].l.getItemSize().height()
                if height > 0 and item_height > 0:
                    return max(1, int(height / item_height))
        return 6

    def moveSelectionCircular(self, step):
        items = self['list'].list if hasattr(self['list'], 'list') else []
        total = len(items)
        if total <= 0:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            current_index = 0
        try:
            new_index = (current_index + step) % total
            self['list'].moveToIndex(new_index)
        except Exception as e:
            print('[MenuChoiceScreen] circular move error: %s' % e)

    def moveUpCircular(self):
        self.moveSelectionCircular(-1)

    def moveDownCircular(self):
        self.moveSelectionCircular(1)

    def pageUpCircular(self):
        self.moveSelectionCircular(-self.getVisibleRowsCount())

    def pageDownCircular(self):
        self.moveSelectionCircular(self.getVisibleRowsCount())

    def ok(self):
        self.close(self['list'].getCurrent())

    def cancel(self):
        self.close(None)


def openSatellitesBrowser(session, **kwargs):
    session.open(SatellitesBrowserScreen)