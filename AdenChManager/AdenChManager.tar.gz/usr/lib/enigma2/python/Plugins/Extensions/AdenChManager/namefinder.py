# -*- coding: utf-8 -*-
global SEARCH_HISTORY
global SEARCH_MODE
global CHANNEL_CACHE
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.MessageBox import MessageBox
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Renderer.Picon import getPiconName
from Tools.LoadPixmap import LoadPixmap
from Components.ProgressBar import ProgressBar
from enigma import eServiceCenter, eServiceReference, iServiceInformation, eListboxPythonMultiContent, gFont, eDVBDB, gRGB
import os
import json
import time
import hashlib
from PIL import Image
from functools import partial
from twisted.internet import reactor, threads
from Plugins.Extensions.AdenChManager.utils import getPicon, getSatelliteName, getChannelType, getChannelQuality

CHANNEL_CACHE = None
PICON_CACHE = {}
SEARCH_HISTORY = []
HISTORY_FILE = '/etc/enigma2/channel_finder_history.json'
SEARCH_MODE = 'contains'
CONFIG_FILE = '/etc/enigma2/channel_finder_config.json'

def loadSearchMode():
    """تحميل وضع البحث من ملف الإعدادات. الوضع الافتراضي هو "contains" (يحتوي على)."""
    global SEARCH_MODE
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                SEARCH_MODE = config.get('search_mode', 'contains')
                print(f'[ChannelFinder] Loaded search mode: {SEARCH_MODE}')
        else:
            SEARCH_MODE = 'contains'
    except Exception as e:
        print(f'[ChannelFinder] Error loading config: {e}')
        SEARCH_MODE = 'contains'

def saveSearchMode():
    """حفظ وضع البحث الحالي في ملف الإعدادات."""
    try:
        config = {}
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
        config['search_mode'] = SEARCH_MODE
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        print(f'[ChannelFinder] Saved search mode: {SEARCH_MODE}')
    except Exception as e:
        print(f'[ChannelFinder] Error saving config: {e}')

def loadHistory():
    """تحميل سجل البحث من الملف المحفوظ على الجهاز."""
    global SEARCH_HISTORY
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r') as f:
                SEARCH_HISTORY = json.load(f)
                if len(SEARCH_HISTORY) > 50:
                    SEARCH_HISTORY = SEARCH_HISTORY[-50:]
                print(f'[ChannelFinder] Loaded history: {SEARCH_HISTORY}')
        else:
            print('[ChannelFinder] History file not found, starting with empty history')
            SEARCH_HISTORY = []
    except Exception as e:
        print(f'[ChannelFinder] Error loading history: {e}')
        SEARCH_HISTORY = []

def saveHistory():
    """حفظ سجل البحث الحالي في الملف المخصص على الجهاز."""
    global SEARCH_HISTORY
    try:
        history_dir = os.path.dirname(HISTORY_FILE)
        if not os.path.exists(history_dir):
            os.makedirs(history_dir)
            print(f'[ChannelFinder] Created directory: {history_dir}')
        if len(SEARCH_HISTORY) > 50:
            SEARCH_HISTORY = SEARCH_HISTORY[-50:]
        with open(HISTORY_FILE, 'w') as f:
            json.dump(SEARCH_HISTORY, f, indent=2)
        if os.path.exists(HISTORY_FILE):
            file_size = os.path.getsize(HISTORY_FILE)
            print(f'[ChannelFinder] History saved successfully to {HISTORY_FILE}')
            print(f'[ChannelFinder] File size: {file_size} bytes')
            print(f'[ChannelFinder] History content: {SEARCH_HISTORY}')
        else:
            print('[ChannelFinder] Warning: File was not created!')
    except Exception as e:
        print(f'[ChannelFinder] Error saving history: {e}')
        try:
            backup_file = '/tmp/channel_finder_history_backup.json'
            with open(backup_file, 'w') as f:
                json.dump(SEARCH_HISTORY, f, indent=2)
            print(f'[ChannelFinder] Saved backup history to: {backup_file}')
        except:
            pass

def addToHistory(text):
    """إضافة كلمة إلى سجل البحث بشكل آمن."""
    if not text or not text.strip():
        return False
    try:
        text = text.strip().lower()
        if text not in SEARCH_HISTORY:
            SEARCH_HISTORY.append(text)
            print(f'[ChannelFinder] Added \'{text}\' to history')
            saveHistory()
            return True
        else:
            print(f'[ChannelFinder] \'{text}\' already in history')
            return False
    except Exception as e:
        print(f'[ChannelFinder] Error adding to history: {e}')
        return False

class MenuListScreen(Screen):
    """شاشة عرض قائمة الخيارات (إضافة، حذف، معلومات، تفعيل Multi، إعدادات البحث)."""
    skin = '\n    <screen position=\"center,center\" size=\"500,500\" title=\"Options\">\n        <widget name=\"list\" position=\"10,10\" size=\"480,440\" itemHeight=\"38\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n    </screen>\n    '
    def __init__(self, session, menu, parent):
        """تهيئة شاشة القائمة."""
        Screen.__init__(self, session)
        self.parent = parent
        formatted_menu = []
        for item in menu:
            if item[1] == 'separator':
                formatted_menu.append(('--------------------', 'separator'))
            else:
                formatted_menu.append(item)
        self['list'] = MenuList(formatted_menu)
        self.closed = False
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.ok, 'cancel': self.cancel}, -1)

    def ok(self):
        """تنفيذ الإجراء المحدد عند الضغط على OK."""
        if self.closed:
            return
        current = self['list'].getCurrent()
        if not current:
            return
        if current[1] == 'separator':
            return
        action = current[1]
        try:
            if action == 'add':
                if hasattr(self.parent, 'addToBouquet'):
                    self.parent.addToBouquet()
            elif action == 'delete':
                if hasattr(self.parent, 'confirmDelete'):
                    self.parent.confirmDelete()
            elif action == 'info':
                if hasattr(self.parent, 'channelInfo'):
                    self.parent.channelInfo()
            elif action == 'search_settings':
                if hasattr(self.parent, 'openSearchSettings'):
                    self.parent.openSearchSettings()
            elif action == 'activate_multi':
                if hasattr(self.parent, 'activateMultiSelectMode'):
                    self.parent.activateMultiSelectMode()
                self.closed = True
                self.close()
            elif action == 'add_multiple':
                if hasattr(self.parent, 'addMultipleToBouquet'):
                    self.parent.addMultipleToBouquet()
            elif action == 'delete_multiple':
                if hasattr(self.parent, 'confirmMultipleDelete'):
                    self.parent.confirmMultipleDelete()
            elif action == 'info_multiple':
                if hasattr(self.parent, 'showMultipleInfo'):
                    self.parent.showMultipleInfo()
            elif action == 'exit_multi':
                if hasattr(self.parent, 'exitMultiSelectMode'):
                    self.parent.exitMultiSelectMode()
                self.closed = True
                self.close()
        except Exception as e:
            print('[MenuListScreen] Error:', e)

    def cancel(self):
        """معالجة الضغط على زر الإلغاء"""
        self.closed = True
        self.close()

class BouquetSelectionScreen(Screen):
    """شاشة عرض قائمة البوكيهات المتاحة لإضافة القناة إليها."""
    skin = '\n    <screen position=\"center,center\" size=\"500,380\" title=\"Select Bouquet\">\n        <widget name=\"list\" position=\"10,10\" size=\"480,400\"  itemHeight=\"38\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n    </screen>\n    '
    def __init__(self, session, bouquets, parent, multiple=False):
        """تهيئة شاشة اختيار البوكيه."""
        Screen.__init__(self, session)
        self.parent = parent
        self.multiple = multiple
        self.bouquets = bouquets
        self['list'] = MenuList(bouquets)
        self.closed = False
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.ok, 'cancel': self.cancel}, -1)

    def ok(self):
        """اختيار بوكيه وإضافة القناة/القنوات إليه."""
        if self.closed:
            return
        current = self['list'].getCurrent()
        if current and self.parent:
            try:
                if self.multiple:
                    if hasattr(self.parent, 'addMultipleToBouquetSelected'):
                        self.parent.addMultipleToBouquetSelected(current)
                else:
                    if hasattr(self.parent, 'addToBouquetSelected'):
                        self.parent.addToBouquetSelected(current)
            except Exception as e:
                print('[BouquetSelection] Error:', e)
        self.closed = True
        self.close()

    def cancel(self):
        """معالجة الضغط على زر الإلغاء."""
        if self.closed:
            return
        try:
            if self.parent and hasattr(self.parent, 'pending_services') and self.multiple:
                self.parent.pending_services = []
                self.parent.pending_service_names = []
        except:
            pass
        finally:
            self.closed = True
            self.close()

class SearchHistoryScreen(Screen):
    """شاشة عرض كلمات البحث السابقة للاختيار منها أو حذفها."""
    skin = '\n    <screen position=\"center,center\" size=\"600,450\" title=\"Search History\">\n\n        <widget name=\"list\" position=\"10,10\" size=\"580,330\"  itemHeight=\"38\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n\n        <widget name=\"key_red\" position=\"10,380\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\"/>\n        <widget name=\"key_green\" position=\"160,380\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\"/>\n        <widget name=\"key_yellow\" position=\"310,380\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffff00\"/>\n        <widget name=\"key_blue\" position=\"460,380\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00aaff\"/>\n    </screen>\n    '
    def __init__(self, session):
        """تهيئة شاشة سجل البحث."""
        Screen.__init__(self, session)
        self['list'] = MenuList(SEARCH_HISTORY)
        self['key_red'] = Label('Delete')
        self['key_green'] = Label('New Search')
        self['key_yellow'] = Label('Sort A-Z')
        self['key_blue'] = Label('Original')
        self.original_history = list(SEARCH_HISTORY)
        self.closed = False
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.selectHistory, 'cancel': self.exitHistory, 'red': self.deleteWord, 'green': self.newSearch, 'yellow': self.sortHistory, 'blue': self.restoreHistory}, -1)

    def exitHistory(self):
        """الخروج من شاشة التاريخ بدون اختيار كلمة."""
        self.closed = True
        self.close(None)

    def deleteWord(self):
        """حذف الكلمة المحددة من سجل البحث."""
        current = self['list'].getCurrent()
        if not current:
            return
        if current in SEARCH_HISTORY:
            SEARCH_HISTORY.remove(current)
        saveHistory()
        self['list'].setList(SEARCH_HISTORY)

    def sortHistory(self):
        """ترتيب سجل البحث أبجدياً (A-Z)."""
        sorted_list = sorted(SEARCH_HISTORY, key=lambda x: x.lower())
        self['list'].setList(sorted_list)

    def restoreHistory(self):
        """إعادة السجل إلى الترتيب الأصلي (حسب تاريخ الإضافة)."""
        self['list'].setList(self.original_history)

    def selectHistory(self):
        """اختيار كلمة من السجل لاستخدامها في البحث."""
        if self.closed:
            return
        current = self['list'].getCurrent()
        if not current:
            return
        text = str(current)
        self.closed = True
        self.close(text)

    def newSearch(self):
        """فتح لوحة المفاتيح لكتابة كلمة بحث جديدة."""
        def new_search_callback(text):
            if text:
                self.closed = True
                self.close(text)
            else:
                self.closed = True
                self.close(None)
        self.session.openWithCallback(new_search_callback, VirtualKeyBoard, title='Search Channel')

class SearchSettingsScreen(Screen):
    """شاشة إعدادات البحث لتحديد طريقة البحث (يبدأ بـ / يحتوي على)"""
    skin = '\n    <screen position=\"center,center\" size=\"550,350\" title=\"Search Settings\">\n        <widget name=\"list\" position=\"10,10\" size=\"530,200\" itemHeight=\"42\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n        \n        <widget name=\"key_red\" position=\"10,260\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Cancel\"/>\n        <widget name=\"key_green\" position=\"290,260\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"Save\"/>\n        <widget name=\"info_label\" position=\"10,310\" size=\"530,40\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#cccccc\"/>\n    </screen>\n    '
    def __init__(self, session, current_mode):
        """تهيئة شاشة إعدادات البحث."""
        Screen.__init__(self, session)
        self.current_mode = current_mode
        self.selected_mode = current_mode
        self.closed = False
        self.search_options = [('contains', 'Contains (anywhere in name)'), ('startswith', 'Starts with (beginning of name)')]
        menu_list = []
        for mode, description in self.search_options:
            prefix = '[x] ' if mode == self.current_mode else '[ ] '
            menu_list.append((prefix + description, mode))
        self['list'] = MenuList(menu_list)
        self['key_red'] = Label('Cancel')
        self['key_green'] = Label('Save')
        self['info_label'] = Label('Select search mode and press OK or Save')
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.toggleSelection, 'cancel': self.cancel, 'red': self.cancel, 'green': self.applySettings}, -1)

    def toggleSelection(self):
        """تبديل الاختيار عند الضغط على OK."""
        if self.closed:
            return
        current = self['list'].getCurrent()
        if not current:
            return
        self.selected_mode = current[1]
        menu_list = []
        for mode, description in self.search_options:
            prefix = '[x] ' if mode == self.selected_mode else '[ ] '
            menu_list.append((prefix + description, mode))
        self['list'].setList(menu_list)
        mode_text = 'Starts With' if self.selected_mode == 'startswith' else 'Contains'
        self['info_label'].setText(f'Selected: {mode_text}')

    def applySettings(self):
        """تطبيق الإعدادات المحددة وحفظها."""
        if self.closed:
            return
        self.closed = True
        self.close(self.selected_mode)

    def cancel(self):
        """إلغاء التغييرات والعودة بدون حفظ."""
        if self.closed:
            return
        self.closed = True
        self.close(None)

class ChannelInfoScreen(Screen):
    """شاشة عرض معلومات مفصلة عن القناة المحددة."""
    skin = '\n    <screen position=\"center,center\" size=\"600,400\" title=\"Channel Information\">\n        <widget name=\"info\" position=\"10,10\" size=\"580,360\"  font=\"Regular;24\" />\n    </screen>\n    '
    def __init__(self, session, service):
        """تهيئة شاشة معلومات القناة."""
        Screen.__init__(self, session)
        info = eServiceCenter.getInstance().info(service)
        name = info.getName(service)
        sref = service.toString()
        info_text = 'Channel Name: %s\n\n' % name
        info_text += 'Service Reference: %s\n\n' % sref
        tp = info.getInfoObject(service, iServiceInformation.sTransponderData)
        if tp:
            if 'frequency' in tp:
                info_text += 'Frequency: %s MHz\n' % str(int(tp['frequency'] / 1000))
            if 'symbol_rate' in tp:
                info_text += 'Symbol Rate: %s\n' % str(tp['symbol_rate'])
            if 'polarization' in tp:
                pol = {0: 'Horizontal', 1: 'Vertical', 2: 'Circular Left', 3: 'Circular Right'}
                info_text += 'Polarization: %s\n' % pol.get(tp['polarization'], 'Unknown')
            if 'orbital_position' in tp:
                info_text += 'Satellite: %s\n' % getSatelliteName(tp['orbital_position'])
        self['info'] = Label(info_text)
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.close, 'cancel': self.close}, -1)

class FilterMenuScreen(Screen):
    """شاشة عرض خيارات الفلتر لاختيار أنواع القنوات المعروضة."""
    skin = '\n    <screen position=\"center,center\" size=\"600,500\" title=\"Filter Channels\">\n        <widget name=\"status_label\" position=\"10,10\" size=\"580,30\" font=\"Regular;22\" halign=\"center\" foregroundColor=\"#00aaff\"/>\n        \n        <widget name=\"list\" position=\"10,50\" size=\"580,380\"  itemHeight=\"42\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n        \n        <widget name=\"key_red\" position=\"10,460\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Clear All\"/>\n        <widget name=\"key_green\" position=\"160,460\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"Select All\"/>\n        <widget name=\"key_yellow\" position=\"290,460\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffff00\" text=\"Satellites\"/>\n        <widget name=\"key_blue\" position=\"460,460\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00aaff\" text=\"Apply\"/>\n        \n       </screen>\n    '
    FILTER_OPTIONS = [('all', 'All Channels', True), ('tv', 'TV Channels', True), ('radio', 'Radio Channels', True), ('iptv', 'IPTV Channels', True), ('hd', 'HD Channels Only', False), ('sd', 'SD Channels Only', False), ('scr', 'Encrypted Channels Only', False), ('fta', 'Free Channels Only', False)]

    def __init__(self, session, current_filter_keys, available_satellites=None):
        """تهيئة شاشة اختيار الفلتر."""
        Screen.__init__(self, session)
        self.available_satellites = available_satellites or []
        self.showing_satellites = False
        is_first_time = not current_filter_keys or current_filter_keys == ['all', 'tv', 'radio', 'iptv']
        self.filter_items = []
        for key, name, default in self.FILTER_OPTIONS:
            if is_first_time:
                selected = (key == 'all')
            else:
                selected = key in current_filter_keys
            self.filter_items.append({'key': key, 'name': name, 'selected': selected, 'type': 'main', 'enabled': True})
        self.satellite_items = []
        for sat_name in self.available_satellites:
            sat_key = 'sat_' + sat_name
            if is_first_time:
                selected = False
            else:
                selected = sat_key in current_filter_keys
            self.satellite_items.append({'key': sat_key, 'name': 'Sat: ' + sat_name, 'selected': selected, 'type': 'satellite', 'sat_name': sat_name, 'enabled': True})
        self['list'] = MenuList([])
        self['status_label'] = Label('Main Filters')
        self.closed = False
        self['key_red'] = Label('Clear All')
        self['key_green'] = Label('Select All')
        self['key_yellow'] = Label('Satellites')
        self['key_blue'] = Label('Apply')
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.toggleCurrent, 'cancel': self.cancel, 'red': self.clearAll, 'green': self.selectAll, 'yellow': self.toggleSatelliteView, 'blue': self.applyFilter}, -1)
        self.updateHDEnabledState()
        self.updateListWithColors()

    def updateListWithColors(self):
        """بناء القائمة مع مراعاة حالة التفعيل للخيارات."""
        menu_list = []
        if self.showing_satellites:
            for item in self.satellite_items:
                prefix = '[x] ' if item['selected'] else '[ ] '
                text = prefix + item['name']
                menu_list.append((text, item))
        else:
            for item in self.filter_items:
                prefix = '[x] ' if item['selected'] else '[ ] '
                text = prefix + item['name']
                menu_list.append((text, item))
        self['list'].setList(menu_list)

    def updateHDEnabledState(self):
        """تحديث حالة تمكين خيارات HD و SD بناءً على تحديد TV."""
        tv_selected = False
        for item in self.filter_items:
            if item['key'] == 'tv':
                tv_selected = item['selected']
                break
        for item in self.filter_items:
            if item['key'] == 'hd' or item['key'] == 'sd':
                if tv_selected:
                    item['enabled'] = True
                else:
                    item['enabled'] = False
                    item['selected'] = False

    def toggleSatelliteView(self):
        """التبديل بين عرض الفلاتر الأساسية وعرض الأقمار."""
        if self.closed:
            return
        self.showing_satellites = not self.showing_satellites
        if self.showing_satellites:
            self['status_label'].setText('Satellite Filters')
            self['key_yellow'].setText('Main Filters')
        else:
            self['status_label'].setText('Main Filters')
            self['key_yellow'].setText('Satellites')
        self.updateListWithColors()

    def toggleCurrent(self):
        """تبديل حالة الاختيار للعنصر الحالي."""
        if self.closed:
            return
        current = self['list'].getCurrent()
        if not current:
            return
        if isinstance(current, tuple) and len(current) >= 2:
            item = current[1]
        else:
            return
        if not item.get('enabled', True):
            return
        if self.showing_satellites:
            item['selected'] = not item['selected']
            self.updateListWithColors()
            return
        # Main filters
        old_selected = item['selected']
        if item['key'] == 'all':
            if not old_selected:
                for fi in self.filter_items:
                    fi['selected'] = False
                item['selected'] = True
            else:
                item['selected'] = False
        elif item['key'] == 'tv':
            item['selected'] = not old_selected
            if item['selected']:
                for fi in self.filter_items:
                    if fi['key'] == 'all':
                        fi['selected'] = False
            else:
                for fi in self.filter_items:
                    if fi['key'] in ('hd', 'sd'):
                        fi['selected'] = False
            self.updateHDEnabledState()
        elif item['key'] == 'hd':
            item['selected'] = not old_selected
            if item['selected']:
                for fi in self.filter_items:
                    if fi['key'] == 'all':
                        fi['selected'] = False
                for fi in self.filter_items:
                    if fi['key'] == 'tv':
                        fi['selected'] = True
                for fi in self.filter_items:
                    if fi['key'] == 'sd':
                        fi['selected'] = False
            self.updateHDEnabledState()
        elif item['key'] == 'sd':
            item['selected'] = not old_selected
            if item['selected']:
                for fi in self.filter_items:
                    if fi['key'] == 'all':
                        fi['selected'] = False
                for fi in self.filter_items:
                    if fi['key'] == 'tv':
                        fi['selected'] = True
                for fi in self.filter_items:
                    if fi['key'] == 'hd':
                        fi['selected'] = False
            self.updateHDEnabledState()
        elif item['key'] == 'scr':
            item['selected'] = not old_selected
            if item['selected']:
                for fi in self.filter_items:
                    if fi['key'] == 'all':
                        fi['selected'] = False
                    elif fi['key'] == 'fta':
                        fi['selected'] = False
        elif item['key'] == 'fta':
            item['selected'] = not old_selected
            if item['selected']:
                for fi in self.filter_items:
                    if fi['key'] == 'all':
                        fi['selected'] = False
                    elif fi['key'] == 'scr':
                        fi['selected'] = False
        else:
            item['selected'] = not old_selected
            if item['selected']:
                for fi in self.filter_items:
                    if fi['key'] == 'all':
                        fi['selected'] = False
        self.updateListWithColors()

    def clearAll(self):
        """إلغاء اختيار جميع العناصر في القائمة الحالية."""
        if self.showing_satellites:
            for item in self.satellite_items:
                if item.get('enabled', True):
                    item['selected'] = False
        else:
            for item in self.filter_items:
                if item.get('enabled', True):
                    item['selected'] = False
            self.updateHDEnabledState()
        self.updateListWithColors()

    def selectAll(self):
        """اختيار جميع العناصر المفعّلة في القائمة الحالية ما عدا All Channels."""
        if self.showing_satellites:
            for item in self.satellite_items:
                if item.get('enabled', True):
                    item['selected'] = True
        else:
            for item in self.filter_items:
                if item['key'] != 'all' and item.get('enabled', True):
                    item['selected'] = True
                elif item['key'] == 'all':
                    item['selected'] = False
            # Ensure HD and SD are not both selected
            hd_selected = any(i['key'] == 'hd' and i['selected'] for i in self.filter_items)
            sd_selected = any(i['key'] == 'sd' and i['selected'] for i in self.filter_items)
            if hd_selected and sd_selected:
                for i in self.filter_items:
                    if i['key'] == 'sd':
                        i['selected'] = False
                        break
            scr_selected = any(i['key'] == 'scr' and i['selected'] for i in self.filter_items)
            fta_selected = any(i['key'] == 'fta' and i['selected'] for i in self.filter_items)
            if scr_selected and fta_selected:
                for i in self.filter_items:
                    if i['key'] == 'fta':
                        i['selected'] = False
                        break
            self.updateHDEnabledState()
        self.updateListWithColors()

    def applyFilter(self):
        """تطبيق الفلتر المحدد وإغلاق الشاشة."""
        if self.closed:
            return
        selected_keys = []
        for item in self.filter_items:
            if item['selected'] and item.get('enabled', True):
                selected_keys.append(item['key'])
        for item in self.satellite_items:
            if item['selected'] and item.get('enabled', True):
                selected_keys.append(item['key'])
        if not selected_keys:
            selected_keys = ['all']
        self.closed = True
        self.close(selected_keys)

    def cancel(self):
        """معالجة الضغط على زر الإلغاء."""
        if self.closed:
            return
        self.closed = True
        self.close(None)

class DeleteProgressScreen(Screen):
    """شاشة عرض تقدم عملية الحذف مع شريط تقدم دقيق."""
    skin = '\n    <screen position=\"center,center\" size=\"500,200\" title=\"Deleting Channels\">\n\n        <widget name=\"status\" position=\"20,20\" size=\"460,40\" font=\"Regular;26\" halign=\"center\"/>\n\n        <widget name=\"progress\" position=\"20,80\" size=\"460,30\"/>\n\n        <widget name=\"percent\" position=\"20,130\" size=\"460,40\" font=\"Regular;24\" halign=\"center\"/>\n\n    </screen>\n    '
    def __init__(self, session, total):
        Screen.__init__(self, session)
        self.total = total
        self.current = 0
        self.last_percent = 0
        self['status'] = Label('Deleting channels...')
        self['progress'] = ProgressBar()
        self['percent'] = Label('0%')
        self['progress'].setRange((0, total))
        self['progress'].setValue(0)

    def updateProgress(self, value):
        """تحديث شريط التقدم - يدعم القيم المطلقة (0 إلى total) أو النسب المئوية (0 إلى 100)"""
        if value <= self.total:
            self['progress'].setValue(value)
            percent = int(value * 100 / self.total)
            self['percent'].setText(f'{percent}%')
        elif value <= 100:
            progress_value = int(value * self.total / 100)
            self.current = progress_value
            self['progress'].setValue(progress_value)
            self['percent'].setText(f'{value}%')

class ChannelResults(Screen):
    """الشاشة الرئيسية لعرض نتائج البحث."""
    SORT_MODES = [('original', 'Original Order'), ('name_asc', 'Name A-Z'), ('name_desc', 'Name Z-A'), ('ref', 'Service Reference'), ('sat_pos', 'Satellite Position'), ('sat_name', 'Satellite Name'), ('freq', 'Frequency'), ('quality', 'Quality'), ('encryption', 'Encryption')]
    skin = '\n<screen position=\"center,center\" size=\"1030,650\" title=\"Channel Search Results\">\n\n    <widget name=\"result_count\" position=\"10,5\" size=\"930,30\" font=\"Regular;22\" halign=\"left\"/>\n\n    <widget name=\"list\" position=\"10,45\" size=\"1010,550\"  itemHeight=\"42\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n\n    <widget name=\"key_red\" position=\"10,605\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\"/>\n    <widget name=\"key_green\" position=\"160,605\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\"/>\n    <widget name=\"key_yellow\" position=\"310,605\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffff00\"/>\n    <widget name=\"key_blue\" position=\"460,605\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00aaff\"/>\n    <widget name=\"key_menu\" position=\"610,605\" size=\"140,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ffffff\"/>\n\n</screen>\n'
    def __init__(self, session, services):
        """تهيئة شاشة نتائج البحث."""
        Screen.__init__(self, session)
        self.all_services = services
        self.services = services
        self.filter_keys = ['all', 'tv', 'radio', 'iptv']
        self.sort_mode = 0
        self.services.sort(key=lambda x: x[0].lower())
        self.multi_select_mode = False
        self.selected_indices = set()
        self.selected_services_refs = set()
        self.select_all_state = False
        self.original_service = session.nav.getCurrentlyPlayingServiceReference()
        self.previewed_service = None
        self.channel_confirmed = False
        self.close_after_zap = False
        self.pending_service = None
        self.pending_services = []
        self.pending_service_names = []
        self.closed = False
        icon_path = os.path.join(os.path.dirname(__file__), 'icons', 'icon_crypt.png')
        self.lock_icon = LoadPixmap(icon_path) if os.path.exists(icon_path) else None
        self.items_per_page = 12
        self['result_count'] = Label('')
        self.updateResultText()
        self['key_red'] = Label('Sort')
        self['key_green'] = Label('New Search')
        self['key_yellow'] = Label('History')
        self['key_blue'] = Label('Filter')
        self['key_menu'] = Label('Menu')
        self['list'] = MenuList([], False, eListboxPythonMultiContent)
        self['list'].l.setFont(0, gFont('Regular', 26))
        self['list'].l.setItemHeight(50)
        self.updateList()
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'MenuActions', 'DirectionActions'], {'ok': self.okPressed, 'cancel': self.exitPlugin, 'red': self.cycleSort, 'green': self.greenPressed, 'yellow': self.yellowPressed, 'blue': self.openFilter, 'menu': self.openMenu, 'up': self.moveUp, 'down': self.moveDown, 'left': self.moveLeft, 'right': self.moveRight}, -1)

    def __del__(self):
        """دالة التدمير - تنظيف الذاكرة"""
        try:
            self.pending_services = []
            self.pending_service_names = []
            self.pending_service = None
            self.selected_indices.clear()
            self.selected_services_refs.clear()
        except:
            pass

    def moveUp(self):
        """التحرك لأعلى مع خاصية Loop"""
        if self.closed:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if current_index == 0:
            self['list'].moveToIndex(len(self.services) - 1)
        else:
            self['list'].up()

    def moveDown(self):
        """التحرك لأسفل مع خاصية Loop"""
        if self.closed:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if current_index == len(self.services) - 1:
            self['list'].moveToIndex(0)
        else:
            self['list'].down()

    def moveLeft(self):
        """الانتقال إلى الصفحة السابقة (Page Up)"""
        if self.closed:
            return
        if not self.services:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        new_index = max(0, current_index - self.items_per_page)
        self['list'].moveToIndex(new_index)

    def moveRight(self):
        """الانتقال إلى الصفحة التالية (Page Down)"""
        if self.closed:
            return
        if not self.services:
            return
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        new_index = min(len(self.services) - 1, current_index + self.items_per_page)
        self['list'].moveToIndex(new_index)

    def greenPressed(self):
        """معالجة الضغط على الزر الأخضر"""
        if self.closed:
            return
        if self.multi_select_mode:
            if self.select_all_state:
                self.deselectAll()
            else:
                self.selectAll()
        else:
            self.newSearch()

    def yellowPressed(self):
        """معالجة الضغط على الزر الأصفر"""
        if self.closed:
            return
        if self.multi_select_mode:
            self.toggleCurrentSelection()
        else:
            self.openHistory()

    def okPressed(self):
        """معالجة الضغط على OK"""
        if self.closed:
            return
        if self.multi_select_mode:
            self.previewChannel()
        else:
            self.handleNormalModeOk()

    def handleNormalModeOk(self):
        """معالجة OK في الوضع العادي"""
        current = self['list'].getCurrent()
        if not current:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = current[0]
        if not service or service.flags & eServiceReference.isMarker:
            return
        if self.previewed_service and self.previewed_service.toString() != service.toString():
            self.session.nav.playService(service)
            self.previewed_service = service
            return
        # Confirm zap
        try:
            from Screens.InfoBar import InfoBar
            infobar = InfoBar.instance
        except Exception:
            infobar = None
        if infobar and hasattr(infobar, 'servicelist') and infobar.servicelist:
            sl = infobar.servicelist
            try:
                if hasattr(sl, 'servicePath') and sl.servicePath is not None:
                    del sl.servicePath[:]
                    if getattr(sl, 'bouquet_root', None):
                        sl.servicePath.append(sl.bouquet_root)
                    if bouquet_ref is not None:
                        sl.servicePath.append(bouquet_ref)
            except Exception as e:
                print('[ChannelResults] servicePath set error: %s' % e)
            try:
                if bouquet_ref is not None and hasattr(sl, 'setRoot'):
                    sl.setRoot(bouquet_ref)
            except Exception as e:
                print('[ChannelResults] setRoot error: %s' % e)
            try:
                if hasattr(sl, 'setCurrentSelection'):
                    sl.setCurrentSelection(service)
                if hasattr(sl, 'setCurrent'):
                    sl.setCurrent(service)
                try:
                    sl.addToHistory(service)
                except Exception as e:
                    print('[ChannelResults] addToHistory error: %s' % e)
            except Exception as e:
                print('[ChannelResults] setCurrentSelection error: %s' % e)
        self.close_after_zap = True
        self.channel_confirmed = True
        self.closed = True
        self.close(True)

    def openSearchSettings(self):
        """فتح شاشة إعدادات البحث لتغيير طريقة البحث."""
        if self.closed:
            return
        self.session.openWithCallback(self.searchSettingsCallback, SearchSettingsScreen, SEARCH_MODE)

    def searchSettingsCallback(self, selected_mode=None):
        """معالجة نتيجة إعدادات البحث."""
        global SEARCH_MODE
        if selected_mode is None:
            return
        if selected_mode != SEARCH_MODE:
            SEARCH_MODE = selected_mode
            saveSearchMode()
            mode_text = 'Starts With' if selected_mode == 'startswith' else 'Contains'
            self.session.open(MessageBox, f'Search mode changed to: {mode_text}', MessageBox.TYPE_INFO)

    def activateMultiSelectMode(self):
        """تفعيل وضع التحديد المتعدد"""
        self.multi_select_mode = True
        self.selected_indices.clear()
        self.selected_services_refs.clear()
        self.select_all_state = False
        self['key_yellow'].setText('Select')
        self['key_green'].setText('Select All')
        self.updateList()
        self.updateResultText()

    def exitMultiSelectMode(self):
        """الخروج من وضع التحديد المتعدد"""
        try:
            self.multi_select_mode = False
            self.selected_indices.clear()
            self.selected_services_refs.clear()
            self.pending_services = []
            self.pending_service_names = []
            self.pending_service = None
            self.select_all_state = False
            self['key_yellow'].setText('History')
            self['key_green'].setText('New Search')
            self.updateList()
            self.updateResultText()
        except Exception as e:
            print('[ChannelResults] Error in exitMultiSelectMode:', e)

    def selectAll(self):
        """تحديد جميع القنوات في القائمة"""
        if not self.services:
            return
        self.selected_indices = set(range(len(self.services)))
        self.selected_services_refs.clear()
        for idx in self.selected_indices:
            if 0 <= idx < len(self.services):
                name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = self.services[idx]
                self.selected_services_refs.add(service.toString())
        self['key_green'].setText('Deselect All')
        self.select_all_state = True
        self.updateList()
        self.updateResultText()

    def deselectAll(self):
        """إلغاء تحديد جميع القنوات"""
        self.selected_indices.clear()
        self.selected_services_refs.clear()
        self['key_green'].setText('Select All')
        self.select_all_state = False
        self.updateList()
        self.updateResultText()

    def toggleCurrentSelection(self):
        """تبديل حالة التحديد للقناة الحالية"""
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return
        if current_index in self.selected_indices:
            self.selected_indices.remove(current_index)
            name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = self.services[current_index]
            self.selected_services_refs.discard(service.toString())
        else:
            self.selected_indices.add(current_index)
            name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = self.services[current_index]
            self.selected_services_refs.add(service.toString())
        if len(self.selected_indices) == len(self.services):
            self.select_all_state = True
            self['key_green'].setText('Deselect All')
        else:
            self.select_all_state = False
            self['key_green'].setText('Select All')
        self.updateList()
        self.updateResultText()

    def getSelectedServices(self):
        """الحصول على قائمة الخدمات للقنوات المحددة"""
        selected_services = []
        selected_names = []
        for idx, channel_data in enumerate(self.services):
            name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = channel_data
            if service.toString() in self.selected_services_refs:
                selected_services.append(service)
                selected_names.append(name)
        return selected_services, selected_names

    def updateSelectedIndicesFromRefs(self):
        """تحديث selected_indices بناءً على selected_services_refs"""
        self.selected_indices.clear()
        for idx, channel_data in enumerate(self.services):
            name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = channel_data
            if service.toString() in self.selected_services_refs:
                self.selected_indices.add(idx)

    def getAvailableSatellites(self):
        """استخراج قائمة الأقمار المتاحة من القنوات"""
        satellites = set()
        for name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref in self.all_services:
            if sat and sat not in ('', '-'):
                satellites.add(sat)
        return sorted(list(satellites))

    def cycleSort(self):
        """التنقل بين أوضاع الفرز المختلفة"""
        if self.closed:
            return
        self.sort_mode = (self.sort_mode + 1) % len(self.SORT_MODES)
        sort_key = self.SORT_MODES[self.sort_mode][0]
        selected_refs_before_sort = set(self.selected_services_refs)
        if sort_key == 'original':
            self.services.sort(key=lambda x: x[0].lower())
        elif sort_key == 'name_asc':
            self.services.sort(key=lambda x: x[0].lower())
        elif sort_key == 'name_desc':
            self.services.sort(key=lambda x: x[0].lower(), reverse=True)
        elif sort_key == 'ref':
            self.services.sort(key=lambda x: x[1].toString())
        elif sort_key == 'sat_pos':
            self.services.sort(key=lambda x: x[3] if x[3] is not None else 9999)
        elif sort_key == 'sat_name':
            self.services.sort(key=lambda x: x[2].lower() if x[2] else 'zzz')
        elif sort_key == 'freq':
            def extract_freq(freq_str):
                if freq_str and 'MHz' in freq_str:
                    try:
                        return int(freq_str.replace('MHz', '').strip())
                    except:
                        return 999999
                return 999999
            self.services.sort(key=lambda x: extract_freq(x[4]))
        elif sort_key == 'quality':
            order = {'UHD': 0, '4K': 0, 'FHD': 1, 'HD': 2, 'SD': 3, '-': 4}
            self.services.sort(key=lambda x: order.get(x[6], 9))
        elif sort_key == 'encryption':
            self.services.sort(key=lambda x: 0 if x[7] else 1)
        self.selected_services_refs = selected_refs_before_sort
        self.updateSelectedIndicesFromRefs()
        if len(self.selected_indices) == len(self.services) and len(self.services) > 0:
            self.select_all_state = True
            self['key_green'].setText('Deselect All')
        else:
            self.select_all_state = False
            self['key_green'].setText('Select All' if self.multi_select_mode else 'New Search')
        self.updateList()
        self.updateResultText()

    def openFilter(self):
        """فتح شاشة اختيار الفلتر"""
        if self.closed:
            return
        available_satellites = self.getAvailableSatellites()
        self.session.openWithCallback(self.filterSelected, FilterMenuScreen, self.filter_keys, available_satellites)

    def filterSelected(self, selected_keys=None):
        """معالجة الفلاتر المحددة"""
        if self.closed:
            return
        if selected_keys is None:
            return
        if not selected_keys:
            return
        self.filter_keys = selected_keys
        self.applyFilter()

    def applyFilter(self):
        """تطبيق الفلاتر المحددة على القنوات"""
        filtered = []
        selected_refs_before_filter = set(self.selected_services_refs)
        satellite_filters = [k for k in self.filter_keys if k.startswith('sat_')]
        has_satellite_filter = len(satellite_filters) > 0
        has_all_filter = 'all' in self.filter_keys
        has_tv = 'tv' in self.filter_keys
        has_hd = 'hd' in self.filter_keys
        has_sd = 'sd' in self.filter_keys
        has_radio = 'radio' in self.filter_keys
        has_iptv = 'iptv' in self.filter_keys
        has_scr = 'scr' in self.filter_keys
        has_fta = 'fta' in self.filter_keys
        filtered_channels = []
        new_selected_refs = set()
        for channel in self.all_services:
            name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = channel
            # Satellite filter
            if has_satellite_filter:
                satellite_match = False
                for sat_key in satellite_filters:
                    sat_name = sat_key[4:]
                    if sat == sat_name:
                        satellite_match = True
                        break
                if not satellite_match:
                    continue
            # All filter
            if has_all_filter:
                encrypted_match = True
                if has_scr and not is_locked:
                    encrypted_match = False
                elif has_fta and is_locked:
                    encrypted_match = False
                if encrypted_match:
                    filtered_channels.append(channel)
                    if service.toString() in selected_refs_before_filter:
                        new_selected_refs.add(service.toString())
                continue
            # Type filters
            channel_matches = False
            if has_tv and ctype == 'TV':
                quality_match = True
                hd_values = ('HD', 'FHD', 'UHD', '4K')
                if has_hd and not has_sd:
                    if quality not in hd_values:
                        quality_match = False
                elif has_sd and not has_hd:
                    if quality != 'SD':
                        quality_match = False
                elif has_hd and has_sd:
                    if quality not in hd_values and quality != 'SD':
                        quality_match = False
                if quality_match:
                    channel_matches = True
            if has_radio and ctype == 'Radio' and not channel_matches:
                channel_matches = True
            if has_iptv and ctype == 'IPTV' and not channel_matches:
                channel_matches = True
            if not has_tv and not has_radio and not has_iptv:
                channel_matches = True
            if not channel_matches:
                continue
            # Encryption filter
            encrypted_match = True
            if has_scr and not is_locked:
                encrypted_match = False
            elif has_fta and is_locked:
                encrypted_match = False
            if encrypted_match:
                filtered_channels.append(channel)
                if service.toString() in selected_refs_before_filter:
                    new_selected_refs.add(service.toString())
        filtered_channels.sort(key=lambda x: x[0].lower())
        self.services = filtered_channels
        self.selected_services_refs = new_selected_refs
        self.updateSelectedIndicesFromRefs()
        if len(self.selected_indices) == len(self.services) and len(self.services) > 0:
            self.select_all_state = True
        else:
            self.select_all_state = False
        if self.multi_select_mode:
            self['key_green'].setText('Deselect All' if self.select_all_state else 'Select All')
            self['key_yellow'].setText('Select')
        else:
            self['key_green'].setText('New Search')
            self['key_yellow'].setText('History')
        self.sort_mode = 0
        self.updateList()
        self.updateResultText()

    def updateResultText(self):
        """تحديث نص عداد النتائج"""
        mode = self.SORT_MODES[self.sort_mode][1]
        filter_parts = []
        if 'all' in self.filter_keys:
            filter_parts.append('All')
        else:
            filter_names = {'tv': 'TV', 'radio': 'Radio', 'iptv': 'IPTV', 'hd': 'HD', 'sd': 'SD', 'scr': 'SCR', 'fta': 'FTA'}
            for k in self.filter_keys:
                if k in filter_names:
                    filter_parts.append(filter_names[k])
            satellites = [k[4:] for k in self.filter_keys if k.startswith('sat_')]
            if satellites:
                sat_text = 'Sat:' + ','.join(satellites[:3])
                if len(satellites) > 3:
                    sat_text += '...'
                filter_parts.append(sat_text)
        filter_text = ' | '.join(filter_parts) if filter_parts else 'None'
        search_mode_text = 'Starts With' if SEARCH_MODE == 'startswith' else 'Contains'
        if self.multi_select_mode:
            selected_count = len(self.selected_services_refs)
            select_state = 'All' if self.select_all_state else 'Partial'
            self['result_count'].setText('Found %d channels  |  Selected: %d (%s)  |  Filter: %s  |  Sort: %s  |  Search: %s' % (len(self.services), selected_count, select_state, filter_text, mode, search_mode_text))
        else:
            self['result_count'].setText('Found %d channels  |  Filter: %s  |  Sort: %s  |  Search: %s' % (len(self.services), filter_text, mode, search_mode_text))

    def updateList(self):
        """بناء وعرض قائمة القنوات"""
        listdata = []
        self.updateSelectedIndicesFromRefs()
        for idx, (name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref) in enumerate(self.services):
            picon = getPicon(service)
            display_name = name
            if self.multi_select_mode:
                prefix = '[x] ' if idx in self.selected_indices else '[ ] '
                display_name = prefix + name
            entry = [MultiContentEntryPixmapAlphaBlend(pos=(10, 0), size=(40, 40), png=picon), MultiContentEntryText(pos=(80, 5), size=(300, 40), font=0, text=display_name), MultiContentEntryText(pos=(570, 5), size=(70, 40), font=0, text=quality), MultiContentEntryText(pos=(750, 5), size=(120, 40), font=0, text=sat), MultiContentEntryText(pos=(840, 5), size=(130, 40), font=0, text=freq)]
            if is_locked and self.lock_icon:
                entry.append(MultiContentEntryPixmapAlphaBlend(pos=(460, 7), size=(70, 40), png=self.lock_icon))
            listdata.append(entry)
        self['list'].setList(listdata)

    def previewChannel(self):
        """معاينة القناة في الخلفية"""
        current = self['list'].getCurrent()
        if not current:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = current[0]
        if not service or service.flags & eServiceReference.isMarker:
            return
        self.session.nav.playService(service)
        self.previewed_service = service

    def newSearch(self):
        """فتح لوحة المفاتيح لبدء بحث جديد"""
        if self.closed:
            return
        def new_search_callback(text):
            if text and text.strip():
                self.closed = True
                self.close(text.strip())
        self.session.openWithCallback(new_search_callback, VirtualKeyBoard, title='Search Channel')

    def openHistory(self):
        """فتح شاشة سجل البحث"""
        if self.closed:
            return
        if not self.channel_confirmed and not self.close_after_zap and self.original_service:
            self.session.nav.playService(self.original_service)
        self.session.openWithCallback(self.historyClosed, SearchHistoryScreen)

    def historyClosed(self, result=None):
        """دالة الاستدعاء بعد إغلاق شاشة التاريخ"""
        if not result or self.closed:
            return
        self.closed = True
        self.close(result)

    def exitPlugin(self):
        """الخروج من البلجن"""
        if self.closed:
            return
        if not self.channel_confirmed and not self.close_after_zap and self.original_service:
            self.session.nav.playService(self.original_service)
        self.closed = True
        self.close(False)

    def openMenu(self):
        """فتح قائمة الخيارات"""
        if self.closed:
            return
        if self.multi_select_mode:
            self.openMultiSelectMenu()
        else:
            self.openSingleChannelMenu()

    def openSingleChannelMenu(self):
        """فتح قائمة الخيارات العادية"""
        current = self['list'].getCurrent()
        if not current:
            return
        name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = current[0]
        self.pending_service = service
        menu = [('Add channel to bouquet', 'add'), ('Delete channel permanently', 'delete'), ('Channel information', 'info'), ('--------------------', 'separator'), ('Search Settings', 'search_settings'), ('--------------------', 'separator'), ('Activate Multi-Select Mode', 'activate_multi')]
        self.session.open(MenuListScreen, menu, self)

    def openMultiSelectMenu(self):
        """فتح قائمة خيارات التحديد المتعدد"""
        menu = []
        if self.selected_services_refs:
            menu.append(('Add selected to bouquet', 'add_multiple'))
            menu.append(('Delete selected permanently', 'delete_multiple'))
            menu.append(('Show selected info', 'info_multiple'))
            menu.append(('--------------------', 'separator'))
        menu.append(('Exit Multi-Select Mode', 'exit_multi'))
        self.session.open(MenuListScreen, menu, self)

    def addToBouquet(self):
        """بدء عملية إضافة القناة إلى بوكيه"""
        service = self.pending_service
        if not service:
            return
        serviceHandler = eServiceCenter.getInstance()
        bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        bouquet_list = serviceHandler.list(bouquet_root)
        bouquets = []
        if bouquet_list:
            while True:
                bouquet = bouquet_list.getNext()
                if not bouquet.valid():
                    break
                info = serviceHandler.info(bouquet)
                name = info.getName(bouquet)
                bouquets.append((name, bouquet))
        if bouquets:
            self.session.open(BouquetSelectionScreen, bouquets, self, False)
        else:
            self.session.open(MessageBox, 'No bouquets found', MessageBox.TYPE_INFO)

    def addToBouquetSelected(self, bouquet):
        """إضافة القناة إلى البوكيه المحدد"""
        service = self.pending_service
        if not service:
            return
        serviceHandler = eServiceCenter.getInstance()
        bouquet_ref = bouquet[1]
        bouquet_list = serviceHandler.list(bouquet_ref)
        if not bouquet_list:
            return
        mutable = bouquet_list.startEdit()
        if not mutable:
            return
        try:
            mutable.addService(service)
            mutable.flushChanges()
            self.session.open(MessageBox, f'Channel added to bouquet: {bouquet[0]}', MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, f'Error adding channel: {str(e)}', MessageBox.TYPE_ERROR)

    def addMultipleToBouquet(self):
        """إضافة القنوات المحددة إلى بوكيه"""
        selected_services, selected_names = self.getSelectedServices()
        if not selected_services:
            self.session.open(MessageBox, 'No channels selected.', MessageBox.TYPE_INFO)
            return
        self.pending_services = list(selected_services)
        self.pending_service_names = list(selected_names)
        serviceHandler = eServiceCenter.getInstance()
        bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        bouquet_list = serviceHandler.list(bouquet_root)
        bouquets = []
        if bouquet_list:
            while True:
                bouquet = bouquet_list.getNext()
                if not bouquet.valid():
                    break
                info = serviceHandler.info(bouquet)
                name = info.getName(bouquet)
                bouquets.append((name, bouquet))
        if bouquets:
            self.session.open(BouquetSelectionScreen, bouquets, self, True)
        else:
            self.pending_services = []
            self.pending_service_names = []
            self.session.open(MessageBox, 'No bouquets found', MessageBox.TYPE_INFO)

    def addMultipleToBouquetSelected(self, bouquet):
        """إضافة القنوات المحددة إلى البوكيه المختار"""
        if not bouquet or not self.pending_services:
            return
        success_count = 0
        fail_count = 0
        error_messages = []
        serviceHandler = eServiceCenter.getInstance()
        bouquet_ref = bouquet[1]
        bouquet_list = serviceHandler.list(bouquet_ref)
        if not bouquet_list:
            return
        mutable = bouquet_list.startEdit()
        if not mutable:
            self.session.open(MessageBox, 'Could not edit bouquet', MessageBox.TYPE_ERROR)
            return
        try:
            services_to_add = list(self.pending_services)
            bouquet_name = bouquet[0]
            for service in services_to_add:
                try:
                    mutable.addService(service)
                    success_count += 1
                except Exception as e:
                    fail_count += 1
                    error_messages.append(str(e))
            mutable.flushChanges()
            self.pending_services = []
            self.pending_service_names = []
            if success_count > 0:
                message = f'{success_count} channels added to bouquet: {bouquet_name}'
                if fail_count > 0:
                    message += f'\n{fail_count} channels failed.'
                    if error_messages:
                        message += f'\nErrors: {", ".join(error_messages[:3])}'
            else:
                message = 'No channels were added'
                if error_messages:
                    message += f'\nErrors: {", ".join(error_messages[:3])}'
            def show_success_message():
                if self and not self.closed:
                    self.session.openWithCallback(self.afterAddMessageClosed, MessageBox, message, MessageBox.TYPE_INFO)
            reactor.callLater(0.1, show_success_message)
        except Exception as e:
            self.pending_services = []
            self.pending_service_names = []
            def show_error_message():
                if self and not self.closed:
                    self.session.open(MessageBox, f'Error adding channels:\n{str(e)}', MessageBox.TYPE_ERROR)
            reactor.callLater(0.1, show_error_message)

    def afterAddMessageClosed(self, *args):
        """دالة يتم استدعاؤها بعد إغلاق رسالة النجاح/الخطأ"""
        if not self or self.closed:
            return
        try:
            if hasattr(self, 'multi_select_mode') and self.multi_select_mode:
                self.exitMultiSelectMode()
            self.updateList()
            self.updateResultText()
        except Exception as e:
            print('[ChannelResults] Error in afterAddMessageClosed:', e)

    def confirmDelete(self):
        """طلب تأكيد حذف القناة"""
        service = self.pending_service
        if not service:
            return
        self.session.openWithCallback(self.confirmDeleteCallback, MessageBox, 'Are you sure you want to delete this channel permanently?\n\nThis action cannot be undone!', MessageBox.TYPE_YESNO)

    def confirmDeleteCallback(self, answer):
        if answer:
            self.deleteChannelCompletely()

    def deleteChannelCompletely(self):
        """حذف القناة بشكل دائم"""
        global CHANNEL_CACHE
        service = self.pending_service
        if not service:
            return
        try:
            serviceHandler = eServiceCenter.getInstance()
            bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
            bouquet_list = serviceHandler.list(bouquet_root)
            if bouquet_list:
                while True:
                    bouquet = bouquet_list.getNext()
                    if not bouquet.valid():
                        break
                    services = serviceHandler.list(bouquet)
                    if not services:
                        continue
                    mutable = services.startEdit()
                    if not mutable:
                        continue
                    mutable.removeService(service)
                    mutable.flushChanges()
            db = eDVBDB.getInstance()
            db.removeService(service)
            db.saveServicelist()
            CHANNEL_CACHE = None
            service_ref = service.toString()
            self.services = [s for s in self.services if s[1].toString() != service_ref]
            self.all_services = [s for s in self.all_services if s[1].toString() != service_ref]
            if service_ref in self.selected_services_refs:
                self.selected_services_refs.discard(service_ref)
            self.updateSelectedIndicesFromRefs()
            self.updateList()
            self.updateResultText()
        except Exception as e:
            print(f'[ChannelResults] Error deleting channel: {e}')

    def confirmMultipleDelete(self):
        """طلب تأكيد حذف القنوات المحددة"""
        selected_services, selected_names = self.getSelectedServices()
        if not selected_services:
            self.session.open(MessageBox, 'No channels selected.', MessageBox.TYPE_INFO)
            return
        self.pending_services = selected_services
        self.pending_service_names = selected_names
        self.service_refs_to_delete = [s.toString() for s in selected_services]
        message = '⚠️ IMPORTANT WARNING ⚠️\n\n'
        message += f'Are you sure you want to delete {len(selected_services)} channels permanently?\n\n'
        message += 'This action cannot be undone!\n'
        message += 'All traces of these channels will be removed from the system.'
        self.session.openWithCallback(self.confirmMultipleDeleteCallback, MessageBox, message, MessageBox.TYPE_YESNO)

    def confirmMultipleDeleteCallback(self, answer):
        if answer:
            self.deleteMultipleChannelsSuperFast()

    def deleteMultipleChannelsSuperFast(self):
        """أسرع طريقة لحذف القنوات بشكل جماعي"""
        if not self.pending_services:
            return
        count = len(self.pending_services)
        self.wait_dialog = self.session.open(MessageBox, f'Deleting {count} channels...\n\nPlease wait, this may take a moment.', MessageBox.TYPE_INFO, timeout=5)
        threads.deferToThread(self._background_delete_all)

    def _background_delete_all(self):
        """تنفيذ الحذف في الخلفية"""
        global CHANNEL_CACHE
        try:
            db = eDVBDB.getInstance()
            serviceHandler = eServiceCenter.getInstance()
            bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
            bouquet_list_container = serviceHandler.list(bouquet_root)
            all_mutable_lists = []
            if bouquet_list_container:
                while True:
                    bouquet = bouquet_list_container.getNext()
                    if not bouquet.valid():
                        break
                    try:
                        services_in_bouquet = serviceHandler.list(bouquet)
                        if services_in_bouquet:
                            mutable = services_in_bouquet.startEdit()
                            if mutable:
                                all_mutable_lists.append(mutable)
                    except:
                        continue
            for service in self.pending_services:
                for mutable_list in all_mutable_lists:
                    try:
                        mutable_list.removeService(service)
                    except:
                        pass
            for mutable_list in all_mutable_lists:
                try:
                    mutable_list.flushChanges()
                except:
                    pass
            for service in self.pending_services:
                try:
                    db.removeService(service)
                except:
                    pass
            db.saveServicelist()
            CHANNEL_CACHE = None
            reactor.callFromThread(self._background_delete_complete)
        except Exception as e:
            print(f'[ChannelResults] Background delete error: {e}')
            reactor.callFromThread(self._background_delete_error, str(e))

    def _background_delete_complete(self):
        """اكتمال الحذف - تحديث الواجهة"""
        try:
            self.wait_dialog.close()
        except:
            pass
        try:
            service_refs_to_remove = set(self.service_refs_to_delete)
            self.services = [s for s in self.services if s[1].toString() not in service_refs_to_remove]
            self.all_services = [s for s in self.all_services if s[1].toString() not in service_refs_to_remove]
            self.selected_services_refs = set()
            self.selected_indices.clear()
            self.pending_services = []
            self.pending_service_names = []
            self.updateList()
            self.updateResultText()
            self.session.open(MessageBox, f'✅ Successfully deleted {len(self.service_refs_to_delete)} channels!', MessageBox.TYPE_INFO)
            self.exitMultiSelectMode()
        except Exception as e:
            print(f'[ChannelResults] Error in delete complete: {e}')

    def _background_delete_error(self, error_msg):
        """حدث خطأ أثناء الحذف"""
        try:
            self.wait_dialog.close()
        except:
            pass
        self.session.open(MessageBox, f'❌ Error during deletion:\n{error_msg}', MessageBox.TYPE_ERROR)

    def showMultipleInfo(self):
        """عرض معلومات مختصرة عن القنوات المحددة"""
        selected_services, selected_names = self.getSelectedServices()
        if not selected_services:
            self.session.open(MessageBox, 'No channels selected.', MessageBox.TYPE_INFO)
            return
        tv_count = 0
        radio_count = 0
        iptv_count = 0
        hd_count = 0
        sd_count = 0
        encrypted_count = 0
        free_count = 0
        for idx in self.selected_indices:
            if 0 <= idx < len(self.services):
                name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = self.services[idx]
                if ctype == 'TV':
                    tv_count += 1
                elif ctype == 'Radio':
                    radio_count += 1
                elif ctype == 'IPTV':
                    iptv_count += 1
                if quality in ['HD', 'FHD', 'UHD', '4K']:
                    hd_count += 1
                elif quality == 'SD':
                    sd_count += 1
                if is_locked:
                    encrypted_count += 1
                else:
                    free_count += 1
        info = 'Selected Channels Summary:\n'
        info += f'Total: {len(selected_services)} channels\n'
        info += f'TV: {tv_count} | Radio: {radio_count} | IPTV: {iptv_count}\n'
        info += f'HD: {hd_count} | SD: {sd_count}\n'
        info += f'Encrypted: {encrypted_count} | FTA: {free_count}'
        self.session.open(MessageBox, info, MessageBox.TYPE_INFO)

    def channelInfo(self):
        """عرض معلومات مفصلة عن القناة المحددة."""
        if self.pending_service:
            service = self.pending_service
        else:
            current = self['list'].getCurrent()
            if not current:
                return
            name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref = current[0]
            self.pending_service = service
        if not self.pending_service:
            return
        self.session.open(ChannelInfoScreen, self.pending_service)

def loadChannels():
    """تحميل جميع القنوات من قاعدة البيانات (مع استخدام الذاكرة المؤقتة). المخرج: قائمة بجميع القنوات في النظام"""
    global CHANNEL_CACHE
    if CHANNEL_CACHE is not None:
        return CHANNEL_CACHE
    serviceHandler = eServiceCenter.getInstance()
    bouquet_root = eServiceReference('1:7:1:0:0:0:0:0:0:0:(type == 1) FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
    bouquet_list = serviceHandler.list(bouquet_root)
    channels = []
    seen = set()
    if bouquet_list:
        while True:
            bouquet = bouquet_list.getNext()
            if not bouquet.valid():
                break
            services = serviceHandler.list(bouquet)
            if not services:
                continue
            while True:
                service = services.getNext()
                if not service.valid():
                    break
                ref = service.toString()
                if ref in seen:
                    continue
                seen.add(ref)
                info = serviceHandler.info(service)
                if not info:
                    continue
                name = info.getName(service)
                tp = info.getInfoObject(service, iServiceInformation.sTransponderData)
                sat = ''
                orb = 0
                freq = ''
                if tp and 'orbital_position' in tp:
                    orb = tp['orbital_position']
                    sat = getSatelliteName(orb)
                if tp and 'frequency' in tp:
                    try:
                        freq = str(int(tp['frequency'] / 1000)) + ' MHz'
                    except:
                        freq = ''
                ctype = getChannelType(service)
                quality = getChannelQuality(info, service)
                try:
                    is_locked = bool(info.isCrypted())
                except Exception:
                    is_locked = False
                channels.append((name, service, sat, orb, freq, ctype, quality, is_locked, bouquet))
    CHANNEL_CACHE = channels
    print(f'[ChannelFinder] Loaded {len(channels)} channels')
    return channels

def searchChannels(session, text):
    """الدالة الرئيسية للبحث عن القنوات."""
    if not text:
        return
    text = text.strip().lower()
    if not text:
        return
    addToHistory(text)
    channels = loadChannels()
    result = []
    for name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref in channels:
        name_lower = name.lower()
        if SEARCH_MODE == 'startswith':
            if name_lower.startswith(text):
                result.append((name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref))
        else:  # contains
            if text in name_lower:
                result.append((name, service, sat, orb, freq, ctype, quality, is_locked, bouquet_ref))
    if result:
        result.sort(key=lambda x: x[0].lower())
        def channel_results_callback(confirmed_or_text):
            if confirmed_or_text is True:
                print('[ChannelFinder] Channel confirmed. Exiting.')
            elif not confirmed_or_text:
                print('[ChannelFinder] Search cancelled.')
            else:
                print(f'[ChannelFinder] New search requested for: {confirmed_or_text}')
                searchChannels(session, confirmed_or_text)
        session.openWithCallback(channel_results_callback, ChannelResults, result)
    else:
        mode_text = 'starts with' if SEARCH_MODE == 'startswith' else 'contains'
        session.open(MessageBox, f'No channels found that {mode_text} \'{text}\'', MessageBox.TYPE_INFO)

def start_channel_finder(session, **kwargs):
    """نقطة الدخول الرئيسية للبحث عن القنوات."""
    loadHistory()
    def history_callback(text):
        if text:
            text = text.strip().lower()
            if text:
                print(f'[ChannelFinder] Searching for: \'{text}\'')
                searchChannels(session, text)
        else:
            print('[ChannelFinder] No search text provided')
    if not SEARCH_HISTORY:
        print('[ChannelFinder] History is empty, opening keyboard')
        session.openWithCallback(history_callback, VirtualKeyBoard, title='Search Channel')
    else:
        print(f'[ChannelFinder] Showing history with {len(SEARCH_HISTORY)} items')
        session.openWithCallback(history_callback, SearchHistoryScreen)