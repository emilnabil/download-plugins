# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Label import Label
from Plugins.Extensions.AdenChManager.namefinder import start_channel_finder
from Plugins.Extensions.AdenChManager.bouquets import openBouquetsManager
from Plugins.Extensions.AdenChManager.satellites import openSatellitesBrowser

class MainMenuScreen(Screen):
    skin = '\n    <screen position=\"center,center\" size=\"600,430\" title=\"Aden-Channel Manager  V 1.0\">\n    \n\n        <widget name=\"list\" position=\"10,10\" size=\"550,200\" itemHeight=\"50\" font=\"Regular;26\" scrollbarMode=\"showOnDemand\"/>\n\n        <widget name=\"key_red\" position=\"10,350\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#ff0000\" text=\"Exit\"/>\n        <widget name=\"key_green\" position=\"470,350\" size=\"120,40\" font=\"Regular;24\" halign=\"center\" foregroundColor=\"#00ff00\" text=\"Select\"/>\n\n        <widget name=\"info_label\" position=\"10,400\" size=\"580,25\" font=\"Regular;20\" halign=\"center\" foregroundColor=\"#cccccc\"/>\n    </screen>\n    '
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self['title_label'] = Label('Aden-Channel Manager  V 1.0')
        self.menu_items = [('🔍 Channel Finder - Search for channels', 'channel_finder'), ('📁 Bouquets Manager - Manage your bouquets', 'bouquets_manager'), ('🛰 Satellites Browser - Browse satellites', 'satellites_browser')]
        self['list'] = MenuList(self.menu_items)
        self['key_red'] = Label('Exit')
        self['key_green'] = Label('Select')
        self['info_label'] = Label('Use UP/DOWN to navigate, OK or GREEN to select')
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'DirectionActions'], {'ok': self.selectOption, 'cancel': self.close, 'red': self.close, 'green': self.selectOption, 'up': self.moveUp, 'down': self.moveDown}, -1)
    
    def moveUp(self):
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return None
        else:
            if current_index == 0:
                self['list'].moveToIndex(len(self.menu_items) - 1)
            else:
                self['list'].up()
    
    def moveDown(self):
        current_index = self['list'].getSelectedIndex()
        if current_index is None or current_index < 0:
            return None
        else:
            if current_index == len(self.menu_items) - 1:
                self['list'].moveToIndex(0)
            else:
                self['list'].down()
    
    def selectOption(self):
        current = self['list'].getCurrent()
        if not current:
            return None
        else:
            option = current[1]
            if option == 'channel_finder':
                self.runChannelFinder()
            else:
                if option == 'bouquets_manager':
                    self.runBouquetsManager()
                else:
                    if option == 'satellites_browser':
                        self.runSatellitesBrowser()
    
    def runChannelFinder(self):
        try:
            print('[MainMenu] Starting Channel Finder...')
            start_channel_finder(self.session)
        except Exception as e:
            print('[MainMenu] Error opening Channel Finder: %s' % e)
            self.session.open(MessageBox, 'Error opening Channel Finder:\n%s' % str(e), MessageBox.TYPE_ERROR)
    
    def runBouquetsManager(self):
        try:
            print('[MainMenu] Starting Bouquets Manager...')
            openBouquetsManager(self.session)
        except Exception as e:
            print('[MainMenu] Error opening Bouquets Manager: %s' % e)
            self.session.open(MessageBox, 'Error opening Bouquets Manager:\n%s' % str(e), MessageBox.TYPE_ERROR)
    
    def runSatellitesBrowser(self):
        try:
            print('[MainMenu] Starting Satellites Browser...')
            openSatellitesBrowser(self.session)
        except Exception as e:
            print('[MainMenu] Error opening Satellites Browser: %s' % e)
            self.session.open(MessageBox, 'Error opening Satellites Browser:\n%s' % str(e), MessageBox.TYPE_ERROR)

def main(session, **kwargs):
    print('[Aden-Channel Manager] Starting main menu...')
    session.open(MainMenuScreen)

def Plugins(**kwargs):
    return PluginDescriptor(
        name='Aden-Channel Manager  V 1.0',
        description='Search channels, manage bouquets and browse satellites',
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main,
        icon='plugin.png'
    )