#!/usr/bin/python
# -*- coding: utf-8 -*-
###################################
# # __author__ = "Lululla"      # #
# # __copyright__ = "AGP Team"  # #
# # __modified_by__ = "MNASR"   # #
###################################
from __future__ import absolute_import, print_function

# Standard library
from os import remove
from os.path import exists, getsize
from re import compile, sub, IGNORECASE
from threading import Thread
from json import loads as json_loads
from random import choice
from time import sleep
import threading
import urllib3
import logging

# Third-party libraries
from PIL import Image
from requests import get, codes, Session
from requests.adapters import HTTPAdapter, Retry
from requests.exceptions import HTTPError
from twisted.internet.reactor import callInThread
from functools import lru_cache

# Enigma2 specific
from enigma import getDesktop
from Components.config import config

# Local imports
from .MetrixHD_lib import quoteEventName, split_title_and_year
from .MetrixHD_Utils import logger

# ========================
# DISABLE URLLIB3 DEBUG LOGS
# ========================
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
logging.getLogger("urllib3").setLevel(logging.WARNING)
logging.getLogger("requests").setLevel(logging.WARNING)

global srch

try:
    lng = config.osd.language.value
    lng = lng[:-3]
except BaseException:
    lng = 'en'
    pass


def getRandomUserAgent():
    useragents = [
        'Mozilla/5.0 (compatible; Konqueror/4.5; FreeBSD) KHTML/4.5.4 (like Gecko)',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:29.0) Gecko/20120101 Firefox/29.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0',
        'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20120101 Firefox/35.0',
        'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
        'Mozilla/5.0 (X11; Linux x86_64; rv:28.0) Gecko/20100101 Firefox/28.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.13+ (KHTML, like Gecko) Version/5.1.7 Safari/534.57.2',
        'Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8; U; de) Presto/2.9.168 Version/11.52',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0'
    ]
    return choice(useragents)


AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0",
    "Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36 Edge/87.0.664.75",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363"
]
headers = {"User-Agent": choice(AGENTS)}

isz = "1280,720"
screenwidth = getDesktop(0).size()
if screenwidth.width() <= 1280:
    isz = isz.replace(isz, "1280,720")
elif screenwidth.width() <= 1920:
    isz = isz.replace(isz, "1280,720")
else:
    isz = isz.replace(isz, "1280,720")


class MetrixHDbDownloadThread(Thread):
    """
    Main Backdrop renderer class for Enigma2
    Handles Backdrop display and refresh logic
    """

    def __init__(self, *args, **kwargs):
        Thread.__init__(self)
        self._stop_event = threading.Event()
        self.search_year = ""
        self.checkMovie = [
            "film", "movie", "фильм", "кино", "ταινία",
            "película", "cinéma", "cine", "cinema", "filma"
        ]
        self.checkTV = [
            "serial", "series", "serie", "serien", "série", "séries",
            "serious", "folge", "episodio", "episode", "épisode",
            "l'épisode", "ep.", "animation", "staffel", "soap", "doku",
            "tv", "talk", "show", "news", "factual", "entertainment",
            "telenovela", "dokumentation", "dokutainment", "documentary",
            "informercial", "information", "sitcom", "reality", "program",
            "magazine", "mittagsmagazin", "т/с", "м/с", "сезон", "с-н",
            "эпизод", "сериал", "серия", "actualité", "discussion",
            "interview", "débat", "émission", "divertissement", "jeu",
            "magasine", "information", "météo", "journal", "sport",
            "culture", "infos", "feuilleton", "téléréalité", "société",
            "clips", "concert", "santé", "éducation", "variété"
        ]

        self.search_tmdb = lru_cache(maxsize=100)(self.search_tmdb)

    def _normalize_match_title(self, value):
        value = str(value or "").lower().strip()
        value = value.replace("&", " and ")
        value = sub(r"[^a-z0-9\u0600-\u06FF]+", " ", value)
        value = sub(r"\s+", " ", value).strip()
        return value

    def _select_best_tmdb_result(self, results, shortdesc="", fulldesc="", year=None):
        target = self._normalize_match_title(self.title_safe)
        srch, _fd = self.checkType(shortdesc, fulldesc)

        candidates = []

        for each in results:
            title = each.get('name', each.get('title', ''))
            original_title = each.get(
                'original_name', each.get('original_title', ''))
            media_type = str(each.get('media_type', '')).lower()

            if not media_type:
                if srch == "tv":
                    media_type = "serie"
                elif srch == "movie":
                    media_type = "movie"

            if media_type == "tv":
                media_type = "serie"

            backdrop_path = each.get('backdrop_path')
            if media_type not in ['movie', 'serie'] or not backdrop_path:
                continue

            title_n = self._normalize_match_title(title)
            orig_n = self._normalize_match_title(original_title)
            result_year = each.get(
                'release_date', each.get('first_air_date', ''))[:4]

            score = 0

            if title_n == target:
                score += 500
            if orig_n == target:
                score += 500

            if target and target in title_n:
                score += 120
            if target and target in orig_n:
                score += 120
            if title_n and title_n in target:
                score += 80
            if orig_n and orig_n in target:
                score += 80

            if srch == 'movie' and media_type == 'movie':
                score += 200
            elif srch in ('tv', 'serie') and media_type == 'serie':
                score += 200
            elif srch == 'multi':
                if media_type == 'movie':
                    score += 30
                elif media_type == 'serie':
                    score += 10

            if year:
                if result_year:
                    if str(year) == str(result_year):
                        score += 600
                    else:
                        score -= 500
                else:
                    score -= 150

            try:
                score += min(float(each.get('popularity', 0)), 10)
            except Exception:
                pass

            candidates.append((each, score, result_year))

        if not candidates:
            return None, -1

        if year:
            exact_year = [(each, score) for each, score, result_year in candidates if str(
                result_year) == str(year)]
            if exact_year:
                exact_year.sort(key=lambda x: x[1], reverse=True)
                return exact_year[0][0], exact_year[0][1]

        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0], candidates[0][1]

    def search_tmdb(self, dwn_backdrop, title, shortdesc, fulldesc, year=None, channel=None, api_key=None):
        """Download backdrop from TMDB with full verification pipeline (thread-safe)"""
        def _strip_year_for_search(t):
            t = str(t).strip()
            t = sub(r"\s*[\(\[]\s*(?:19|20)\d{2}\s*[\)\]]\s*", " ", t)
            t = sub(r"(?<!^)\s+(?:19|20)\d{2}\s*$", "", t)
            return sub(r"\s+", " ", t).strip()

        if not api_key:
            return False, "No API key"

        try:
            if not dwn_backdrop or not title:
                return False, "Invalid input parameters"

            clean_input_title = title.replace(
                "+", " ").replace('–', '').strip()
            logger.info("[tmdb] year flow | step='clean_input_title' | value='{}'".format(
                str(clean_input_title or "")))

            forced_year = ""
            split_title = clean_input_title
            try:
                split_title, forced_year = split_title_and_year(
                    clean_input_title)
            except Exception as e:
                forced_year = ""
                split_title = clean_input_title

            local_title_safe = _strip_year_for_search(split_title)

            if not local_title_safe:
                return False, "Invalid title after cleaning"

            srch, fd = self.checkType(shortdesc, fulldesc)

            desc_year = ""
            if not year:
                desc_year = self._extract_year(fd)
                year = desc_year

            if forced_year and not year:
                year = forced_year

            local_search_year = year or ""

            old_title_safe = getattr(self, "title_safe", None)
            old_search_year = getattr(self, "search_year", None)
            self.title_safe = local_title_safe
            self.search_year = local_search_year

            request_url = f"https://api.themoviedb.org/3/search/{srch}?api_key={api_key}&language={lng}&query={quoteEventName(local_title_safe)}"
            if year and srch in ("movie", "multi"):
                request_url += f"&year={year}"

            try:
                logger.info("[tmdb] search link | url={}".format(request_url))
            except Exception:
                pass

            retries = Retry(total=3, backoff_factor=1,
                            status_forcelist=[500, 502, 503, 504])
            adapter = HTTPAdapter(max_retries=retries)
            http = Session()
            http.mount("http://", adapter)
            http.mount("https://", adapter)

            response = http.get(request_url, headers=headers,
                                timeout=(10, 20), verify=False)
            response.raise_for_status()

            if response.status_code == codes.ok:
                data = response.json()
                if data and data.get('results'):
                    rank_year = local_search_year

                    if srch == "tv":
                        rank_year = ""

                    return self.downloadData2(
                        data,
                        dwn_backdrop,
                        shortdesc,
                        fulldesc,
                        title_safe=local_title_safe,
                        search_year=rank_year
                    )
                logger.warning("No results found on TMDB")
                return False, "No results"

            logger.warning("No results found on TMDB")
            return False, "No results"

        except HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                return False, "No results found on TMDb"
            else:
                logger.error("TMDb HTTP error: " + str(e))
                return False, "HTTP error during TMDb search"

        except Exception as e:
            logger.error("TMDb search error: " + str(e))
            return False, "Unexpected error during TMDb search"

        finally:
            try:
                self.title_safe = old_title_safe
                self.search_year = old_search_year
            except Exception:
                pass

    def downloadData2(self, data, dwn_backdrop, shortdesc="", fulldesc="", title_safe="", search_year=""):
        if not data.get('results'):
            logger.warning("No results found on TMDB")
            return False, "No results"

        if isinstance(data, bytes):
            data = data.decode("utf-8", errors="ignore")
        data_json = data if isinstance(data, dict) else json_loads(data)

        old_title_safe = getattr(self, "title_safe", None)
        old_search_year = getattr(self, "search_year", None)
        self.title_safe = title_safe or ""
        self.search_year = search_year or ""

        try:
            results = data_json.get('results', [])
            best, best_score = self._select_best_tmdb_result(
                results,
                shortdesc,
                fulldesc,
                (search_year or self._extract_year(fulldesc or shortdesc or ""))
            )

            if not best:
                logger.warning("No valid TMDB result after ranking")
                return False, "No valid result"

            title = best.get('name', best.get('title', ''))
            backdrop_path = best.get('backdrop_path')
            backdrop = f"http://image.tmdb.org/t/p/w780{backdrop_path}"
            if not backdrop.strip():
                backdrop = f"http://image.tmdb.org/t/p/original{backdrop_path}"

            if backdrop.strip():
                callInThread(self.saveBackdrop, backdrop, dwn_backdrop)
                if exists(dwn_backdrop):
                    return True, f"[SUCCESS] backdrop match: {title}"

            return False, "[SKIP] No valid Result"

        finally:
            self.title_safe = old_title_safe
            self.search_year = old_search_year

    def saveBackdrop(self, url, filepath):
        """Robust backdrop download with file locking"""
        if not url:
            logger.debug("Empty URL provided")
            return False

        lock = threading.Lock()

        with lock:
            if exists(filepath):
                try:
                    with open(filepath, "rb") as f:
                        if f.read(2) == b"\xFF\xD8" and getsize(filepath) > 1024:
                            return True
                    logger.warning("Removing corrupted file")
                    remove(filepath)
                except Exception as e:
                    logger.error(f"File check failed: {e}")
                    if exists(filepath):
                        remove(filepath)

            max_retries = 3

            for attempt in range(max_retries):
                try:
                    headers = {
                        "User-Agent": choice(AGENTS),
                        "Accept": "image/jpeg",
                        "Accept-Encoding": "gzip"
                    }

                    response = get(url, headers=headers,
                                   stream=True, timeout=(15, 30))
                    response.raise_for_status()

                    if "image/jpeg" not in response.headers.get("Content-Type", "").lower():
                        raise ValueError(
                            f"Invalid content type: {response.headers.get('Content-Type')}")

                    with open(filepath, "wb") as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)

                    with open(filepath, "rb") as f:
                        if f.read(2) != b"\xFF\xD8" or getsize(filepath) < 1024:
                            remove(filepath)
                            raise ValueError("Invalid JPEG file")

                    logger.debug(f"Successfully saved: {url}")
                    return True

                except Exception as e:
                    logger.debug(f"Attempt {attempt + 1} failed: {str(e)}")
                    if exists(filepath):
                        try:
                            remove(filepath)
                        except BaseException:
                            pass
                    sleep(2 * (attempt + 1))
                    continue

            return False

    def resizeBackdrop(self, dwn_backdrop):
        try:
            img = Image.open(dwn_backdrop)
            width, height = img.size
            ratio = float(width) // float(height)
            new_height = int(isz.split(",")[1])
            new_width = int(ratio * new_height)
            try:
                rimg = img.resize((new_width, new_height), Image.LANCZOS)
            except BaseException:
                rimg = img.resize((new_width, new_height), Image.ANTIALIAS)
            img.close()
            rimg.save(dwn_backdrop)
            rimg.close()
        except Exception as e:
            print("ERROR:{}".format(e))

    def verifyBackdrop(self, dwn_backdrop):
        try:
            img = Image.open(dwn_backdrop)
            img.verify()
            if img.format == "JPEG":
                pass
            else:
                try:
                    remove(dwn_backdrop)
                except BaseException:
                    pass
                return False
        except Exception as e:
            print(e)
            try:
                remove(dwn_backdrop)
            except BaseException:
                pass
            return False
        return True

    def _extract_year(self, description):
        """Helper to extract year from description"""
        try:
            year_matches = findall(r"19\d{2}|20\d{2}", description)
            return year_matches[0] if year_matches else ""
        except Exception:
            return ""

    def checkType(self, shortdesc, fulldesc):
        if shortdesc and shortdesc != '':
            fd = shortdesc.splitlines()[0]
        elif fulldesc and fulldesc != '':
            fd = fulldesc.splitlines()[0]
        else:
            fd = ''

        text = "{} {}".format(shortdesc or "", fulldesc or "").lower()

        tv_patterns = [
            r'\bseason\s*\d+\b', r'\bs\d+\s*e\d+\b', r'\bepisode\s*\d+\b', r'\bepisodio\s*\d+\b', r'\bstagione\s*\d+\b',
            r'\bep\.?\s*\d+\b', r'\bج\s*\d+\b', r'\bح\s*\d+\b', r'\bجزء\s*\d+\b', r'\bحلقة\s*\d+\b', r'\bالموسم\s*\d+\b',
            r'\bالحلقة\s*\d+\b', r'\bodc\.?\s*\d+\b', r'\bodcinek\s*\d+\b',
        ]

        movie_patterns = [
            r'\bfilm\b', r'\bmovie\b', r'\bpel[íi]cula\b', r'\bcinema\b', r'\bcin[eé]ma\b', r'\bфильм\b', r'\bkino\b', r'\bfilma\b',
        ]

        global srch
        srch = "multi"

        for pattern in tv_patterns:
            if compile(pattern, IGNORECASE).search(text):
                srch = "tv"
                return srch, fd

        for pattern in movie_patterns:
            if compile(pattern, IGNORECASE).search(text):
                srch = "movie"
                return srch, fd

        return srch, fd
