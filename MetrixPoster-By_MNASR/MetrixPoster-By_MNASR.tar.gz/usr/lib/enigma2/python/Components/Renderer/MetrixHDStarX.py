#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
"""
MetrixHD Star renderer - cache only mode
Reads rating from cached JSON in IMOVIE_FOLDER and renders one-widget stars.
Supports ChannelSelection, infobar now/next, and EPG-style screens.
"""
import os
from json import load as json_load
from os import remove, makedirs
from os.path import exists, getsize, join
from threading import Lock
from re import sub

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

from Components.config import config, ConfigSubsection, ConfigOnOff, ConfigYesNo, ConfigText
from Components.Renderer.Renderer import Renderer
from Components.VariableValue import VariableValue
from enigma import eEPGCache, eSlider, eWidget, ePoint, eSize, loadPNG
from enigma import eTimer
from Components.Sources.Event import Event
from Components.Sources.EventInfo import EventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
import NavigationInstance
from ServiceReference import ServiceReference

from .MetrixHD_Utils import IMOVIE_FOLDER, logger
from .MetrixHD_lib import build_search_title, clean_search_title, smart_capitalize_title, should_skip_title

# ==========================================
# PLUGIN CONFIGURATION FOR THIS RENDERER
# ==========================================
if not hasattr(config.plugins, "MetrixHDSP"):
    config.plugins.MetrixHDSP = ConfigSubsection()

if not hasattr(config.plugins.MetrixHDSP, "rating_source"):
    config.plugins.MetrixHDSP.rating_source = ConfigOnOff(default=True)
if not hasattr(config.plugins.MetrixHDSP, "tmdb_api"):
    config.plugins.MetrixHDSP.tmdb_api = ConfigText(
        default="3c3efcf47c3577558812bb9d64019d65", visible_width=50, fixed_size=False)
if not hasattr(config.plugins.MetrixHDSP, "load_tmdb_api"):
    config.plugins.MetrixHDSP.load_tmdb_api = ConfigYesNo(default=False)

cfg = config.plugins.MetrixHDSP

class ApiKeyManager:
    def __init__(self):
        self.plugin_api_file = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixPoster/tmdb_api"

    def get_tmdb_key(self):
        if cfg.load_tmdb_api.value and exists(self.plugin_api_file):
            try:
                with open(self.plugin_api_file, "r") as f:
                    key = f.read().strip()
                    if key:
                        return key
            except Exception:
                pass
        return cfg.tmdb_api.value

api_key_manager = ApiKeyManager()
# ==========================================

if not IMOVIE_FOLDER.endswith("/"):
    IMOVIE_FOLDER += "/"

# Reliable path resolution matching MetrixHDParentalX
cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
STAR_PATH = '/usr/share/enigma2/{}/xtra/'.format(cur_skin)
if not exists(STAR_PATH):
    STAR_PATH = '/usr/share/enigma2/MetrixHD/xtra/'

epgcache = eEPGCache.getInstance()
epgcache.load()


class MetrixHDStarX(VariableValue, Renderer):
    GUI_WIDGET = eWidget
    sources = ["Service", "ServiceEvent"]

    def __init__(self):
        Renderer.__init__(self)
        VariableValue.__init__(self)

        self.lock = Lock()
        self.__start = 0
        self.__end = 100
        self.epgcache = eEPGCache.getInstance()

        self.star = None
        self.pxmp = None
        self.szX = 200
        self.szY = 20

        self.storage_path = IMOVIE_FOLDER
        self.pending_info_file = ""
        self.pending_title = ""
        self.retry_count = 0
        self.max_retries = 6
        self.retry_interval_ms = 5000

        self.nxts = 0
        self.canal = [None] * 6
        self.oldCanal = None
        self.last_channel = None

        self.adsl = True

        self._json_timer = eTimer()
        self._json_timer.callback.append(self._retry_json_read)

        logger.info("MetrixHDStarX Renderer initialized")

    def get_search_title(self, title, shortdesc="", fulldesc=""):
        try:
            result = build_search_title(
                title or "", shortdesc or "", fulldesc or "")
            return smart_capitalize_title(result)
        except Exception:
            return smart_capitalize_title(clean_search_title(title or ""))

    def _get_skin_star_background(self):
        return join(STAR_PATH, "star_back.png")

    def _get_skin_filled_pixmap(self):
        if self.pxmp:
            if str(self.pxmp).startswith("/"):
                return self.pxmp
            return join('/usr/share/enigma2/{}/'.format(cur_skin), str(self.pxmp).lstrip("/"))
        return join(STAR_PATH, "star.png")

    def _hide_star(self):
        try:
            if self.star:
                self.star.hide()
            if self.instance:
                self.instance.hide()
        except Exception:
            pass

    def _reset_star(self):
        try:
            if self.star:
                self.star.setRange(0, 100)
                self.star.setValue(0)
                self.star.hide()
            if self.instance:
                self.instance.hide()
        except Exception:
            pass

    def applySkin(self, desktop, screen):
        attribs = []
        for attrib, value in self.skinAttributes:
            if attrib == 'size':
                self.szX = int(value.split(',')[0])
                self.szY = int(value.split(',')[1])
                attribs.append((attrib, value))
            elif attrib == 'pixmap':
                self.pxmp = value
            elif attrib == 'nexts':
                try:
                    self.nxts = int(value)
                except Exception:
                    self.nxts = 0
            elif attrib == 'path':
                self.storage_path = str(value)
                try:
                    if not exists(self.storage_path):
                        os.makedirs(self.storage_path)
                except Exception as e:
                    logger.error("Failed to create star path {}: {}".format(
                        self.storage_path, str(e)))
            else:
                attribs.append((attrib, value))

        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, screen)

    def GUIcreate(self, parent):
        self.instance = eWidget(parent)
        self.star = eSlider(self.instance)
        
        # Force transparency on both the wrapper and the slider
        self.instance.setTransparent(1)
        self.star.setTransparent(1)
        
        # Force alpha blending so PNG transparency is respected
        if hasattr(self.instance, "setAlphatest"):
            self.instance.setAlphatest(2) # 2 = blend
        if hasattr(self.star, "setAlphatest"):
            self.star.setAlphatest(2)

    def _strip_control(self, value):
        try:
            return sub(r"[\u0000-\u001F\u007F-\u009F]", "", str(value or ""))
        except Exception:
            return str(value or "")

    def _strip_service_name(self, service):
        try:
            return ServiceReference(service).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
        except Exception:
            return ""

    def _resolve_event_from_source(self):
        source = self.source
        source_type = type(source)
        service = None

        if self.nxts == 0 and getattr(source, "event", None) is not None:
            event = source.event
            self.canal = [None] * 6
            self.canal[1] = event.getBeginTime()
            self.canal[2] = self._strip_control(event.getEventName())
            self.canal[3] = event.getExtendedDescription()
            self.canal[4] = event.getShortDescription()
            self.canal[5] = self.canal[2]
            return True

        if source_type is ServiceEvent:
            service = source.getCurrentService()
        elif source_type is CurrentService:
            service = source.getCurrentServiceRef()
        elif source_type is EventInfo or source_type is Event:
            service = NavigationInstance.instance.getCurrentlyPlayingServiceReference()

        if service is None:
            return False

        service_str = service.toString()

        if self.nxts == 1:
            events = self.epgcache.lookupEvent(
                ['IBDCTESX', (service_str, 1, -1, -1)])
            idx = 0
        elif self.nxts > 1:
            events = self.epgcache.lookupEvent(
                ['IBDCTESX', (service_str, -1, -1, 1440)])
            idx = self.nxts
        else:
            events = self.epgcache.lookupEvent(
                ['IBDCTESX', (service_str, 0, -1, -1)])
            idx = 0

        if not events or len(events) <= idx:
            return False

        evt = events[idx]
        self.canal = [None] * 6
        self.canal[0] = self._strip_service_name(service)
        self.canal[1] = evt[1]
        self.canal[2] = self._strip_control(evt[4])
        self.canal[3] = evt[5]
        self.canal[4] = evt[6]
        self.canal[5] = self.canal[2]
        return True

    def changed(self, what):
        if what[0] == self.CHANGED_CLEAR:
            if self._json_timer.isActive():
                self._json_timer.stop()
            self.oldCanal = None
            self.pending_info_file = ""
            self.pending_title = ""
            self._reset_star()
            return

        try:
            is_enabled = config.plugins.MetrixHDSP.rating_source.value
        except Exception:
            is_enabled = True

        if not is_enabled:
            if self._json_timer.isActive():
                self._json_timer.stop()
            self.oldCanal = None
            self.pending_info_file = ""
            self.pending_title = ""
            self._reset_star()
            return

        self.infos()

    def infos(self):
        try:
            if not self._resolve_event_from_source() or not self.canal[5]:
                self.oldCanal = None
                self._hide_star()
                return

            curCanal = "%s-%s-%s" % (self.nxts, self.canal[1], self.canal[2])
            if curCanal == self.oldCanal:
                return

            self.oldCanal = curCanal
            self.last_channel = self.canal[2]
            self._reset_star()
            self.pending_title = self.get_search_title(
                self.canal[5], self.canal[4], self.canal[3])

            skip_title, skip_word = should_skip_title(self.pending_title)
            if skip_title:
                logger.info("MetrixHDStarX skipping title: original='{}' | final_search_title='{}' | matched_exclusion='{}'".format(
                    self.canal[2], self.pending_title, skip_word
                ))
                self._hide_star()
                return

            base = self.storage_path if str(self.storage_path).endswith(
                "/") else str(self.storage_path) + "/"
            self.pending_info_file = "{}{}.json".format(
                base, self.pending_title)
            self.retry_count = 0

            self._start_json_retry()

        except Exception as e:
            logger.error("MetrixHDStarX infos error: {}".format(
                str(e)), exc_info=True)
            self.oldCanal = None

    def _start_json_retry(self):
        if self._json_timer.isActive():
            self._json_timer.stop()
        self._json_timer.start(100, True)

    def _retry_json_read(self):
        try:
            if not self.instance or not self.star:
                logger.info("MetrixHDStarX retry aborted: widget not ready")
                return

            current_title = self.canal[2] if self.canal and len(
                self.canal) > 2 else self.last_channel
            if not current_title:
                logger.info("MetrixHDStarX retry waiting: no current title yet")
                self.retry_count += 1
                if self.retry_count < self.max_retries:
                    self._json_timer.start(self.retry_interval_ms, True)
                else:
                    self._hide_star()
                return

            info_file = self.pending_info_file
            if not info_file:
                logger.info("MetrixHDStarX retry aborted: no pending file")
                self._hide_star()
                return

            if exists(info_file):
                try:
                    if getsize(info_file) > 0:
                        with open(info_file, "r") as f:
                            data = json_load(f)
                        logger.info(
                            "MetrixHDStarX loaded cached json | file='{}'".format(info_file))
                        self.process_data(data)
                        return
                    else:
                        logger.info(
                            "MetrixHDStarX JSON file is empty (0 bytes): {}".format(info_file))
                except Exception as e:
                    logger.warning(
                        "MetrixHDStarX invalid json, removing: {} | error={}".format(info_file, str(e)))
                    try:
                        remove(info_file)
                    except Exception:
                        pass

            self._hide_star()
            self.retry_count += 1
            if self.retry_count < self.max_retries:
                logger.info("MetrixHDStarX waiting for json | try='{}/{}' | file='{}'".format(
                    self.retry_count, self.max_retries, info_file
                ))
                self._json_timer.start(self.retry_interval_ms, True)
            else:
                logger.info(
                    "MetrixHDStarX json not found after retries | file='{}'".format(info_file))
                self._hide_star()

        except Exception as e:
            logger.error("MetrixHDStarX _retry_json_read error: {}".format(
                str(e)), exc_info=True)
            self._hide_star()

    def process_data(self, data):
        try:
            self._delayed_ui_update(data)
        except Exception as e:
            logger.error("MetrixHDStarX process_data error: {}".format(
                str(e)), exc_info=True)

    def _delayed_ui_update(self, data):
        try:
            if not self.instance or not self.star:
                return

            current_title = self.canal[2] if self.canal and len(
                self.canal) > 2 else self.last_channel
            if not current_title or current_title != self.last_channel:
                return

            rating = data.get('vote_average', 0)

            try:
                rtng = min(int(float(rating) * 10), 100) if rating else 0
            except Exception:
                rtng = 0

            if rtng <= 0:
                logger.info("MetrixHDStarX no usable rating | title='{}' | file='{}'".format(
                    self.pending_title, self.pending_info_file
                ))
                self._hide_star()
                return

            if rtng > 100:
                rtng = 100

            filled_pix = self._get_skin_filled_pixmap()
            background_pix = self._get_skin_star_background()

            with self.lock:
                self.star.move(ePoint(0, 0))
                self.star.resize(eSize(self.szX, self.szY))

                if hasattr(self.star, "setAlphatest"):
                    try:
                        self.star.setAlphatest(2)
                    except Exception:
                        pass

                self.star.setRange(0, 100)
                
                try:
                    f_pix = loadPNG(filled_pix)
                    b_pix = loadPNG(background_pix)
                    
                    if f_pix:
                        self.star.setPixmap(f_pix)
                    else:
                        logger.warning("MetrixHDStarX failed to load filled pixmap: " + str(filled_pix))
                        
                    if b_pix:
                        self.star.setBackgroundPixmap(b_pix)
                    else:
                        logger.warning("MetrixHDStarX failed to load background pixmap: " + str(background_pix))
                except Exception as e:
                    logger.error("MetrixHDStarX loadPNG error: " + str(e))

                self.star.setValue(rtng)
                self.star.show()
                self.instance.show()

        except Exception as e:
            logger.error("MetrixHDStarX UI update skipped: {}".format(
                str(e)), exc_info=True)

    def postWidgetCreate(self, instance):
        if self.star is not None:
            self.star.setRange(self.__start, self.__end)

    def setRange(self, range):
        (self.__start, self.__end) = range
        if self.star is not None:
            self.star.setRange(self.__start, self.__end)

    def getRange(self):
        return self.__start, self.__end