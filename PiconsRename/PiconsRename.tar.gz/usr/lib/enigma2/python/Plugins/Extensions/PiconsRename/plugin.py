# -*- coding: utf-8 -*-

from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console


def main(session, **kwargs):
    session.open(Console, title='Picons Rename', cmdlist=['python /usr/lib/enigma2/python/Plugins/Extensions/PiconsRename/picons-rename.py'])


def Plugins(**kwargs):
    return [PluginDescriptor(name='Picons Rename', description='Renames picons to SNP format', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon='plugin.png')]
