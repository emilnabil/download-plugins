# -*- coding: utf-8 -*-

from __future__ import print_function
from __future__ import unicode_literals

from Plugins.Plugin import PluginDescriptor

Version = "1.0.0"


def main(session, **kwargs):
    from .plugin import Xtream2AudioMain
    session.open(Xtream2AudioMain)


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Xtream2Audio",
            description="Convert Xtream IPTV channels to audio players",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]
