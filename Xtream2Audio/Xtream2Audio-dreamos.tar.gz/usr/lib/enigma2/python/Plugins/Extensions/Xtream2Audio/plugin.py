# -*- coding: utf-8 -*-

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Label import Label
import os
import sys
from enigma import getDesktop

try:
    from urllib.request import urlopen, Request
except ImportError:
    from urllib2 import urlopen, Request

try:
    import json
except ImportError:
    import simplejson as json

CONFIG_FILE = "/etc/enigma2/Xtream2Audio/playlists.txt"
IPAUDIO_PRO_FILE = "/etc/enigma2/IPAudioPro.json"
IPAUDIO_FILE = "/etc/enigma2/ipaudio.json"
IPSTREAMER_FILE = "/etc/enigma2/ipstreamer/ipstreamer_myextream.json"
AUDIOPLUS_FILE = "/etc/enigma2/audio.json"

def read_config():
    try:
        dir_name = os.path.dirname(CONFIG_FILE)
        if not os.path.exists(dir_name):
            os.makedirs(dir_name)
        if not os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "w") as f:
                f.write("")
        with open(CONFIG_FILE, "r") as f:
            lines = [x.strip() for x in f.readlines() if x.strip()]
            if not lines:
                return None, None, None, "ts"
            first_line = lines[0]
            output_format = "ts"
            if "output=m3u8" in first_line:
                output_format = "m3u8"
            if "get.php" in first_line and "username=" in first_line and "password=" in first_line:
                host = first_line.split("/get.php")[0]
                if "/:" in host:
                    host = host.replace("/:", ":")
                if host.endswith("/"):
                    host = host[:-1]
                username = ""
                if "username=" in first_line:
                    username = first_line.split("username=")[1].split("&")[0]
                password = ""
                if "password=" in first_line:
                    password = first_line.split("password=")[1].split("&")[0]
                if host and username and password:
                    return host, username, password, output_format
            if len(lines) >= 3:
                host = lines[0].strip()
                if "/:" in host:
                    host = host.replace("/:", ":")
                if host.endswith("/"):
                    host = host[:-1]
                return host, lines[1].strip(), lines[2].strip(), output_format
    except:
        pass
    return None, None, None, "ts"

def api_call(url):
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) Enigma2 IPTV",
        "Enigma2 Handoff",
        ""
    ]
    for index, ua in enumerate(user_agents):
        try:
            if ua:
                req = Request(url, headers={'User-Agent': ua})
            else:
                req = Request(url)
            response_bytes = urlopen(req, timeout=12).read()
            if sys.version_info[0] >= 3:
                response = response_bytes.decode("utf-8", "ignore")
            else:
                response = response_bytes
            if response and not response.strip().startswith("<!DOCTYPE html>"):
                return response
        except:
            continue
    return None

def get_categories(host, user, password):
    url = "%s/player_api.php?username=%s&password=%s&action=get_live_categories" % (host, user, password)
    data = api_call(url)
    if not data:
        return []
    try:
        parsed = json.loads(data)
        return parsed if isinstance(parsed, list) else []
    except:
        return []

def get_streams(host, user, password):
    url = "%s/player_api.php?username=%s&password=%s&action=get_live_streams" % (host, user, password)
    data = api_call(url)
    if not data:
        return []
    try:
        parsed = json.loads(data)
        return parsed if isinstance(parsed, list) else []
    except:
        return []

def build_stream_url(host, user, password, stream_id, container_format):
    return "%s/live/%s/%s/%s.%s" % (host, user, password, stream_id, container_format)

class Xtream2AudioChannels(Screen):
    def __init__(self, session, title, channels):
        Screen.__init__(self, session)
        self.session = session
        self.title = title
        self.channels = channels
        
        width = getDesktop(0).size().width()
        skin_file = (
            "/usr/lib/enigma2/python/Plugins/Extensions/Xtream2Audio/menus/skins/skinss_fhd.xml"
            if width >= 1920
            else "/usr/lib/enigma2/python/Plugins/Extensions/Xtream2Audio/menus/skins/skinss_hd.xml"
        )
        try:
            with open(skin_file, "r") as f:
                self.skin = f.read()
        except:
            self.skin = """
                <screen position="center,center" size="800,600" title="Channels">
                    <widget name="title" position="0,0" size="800,50" font="Regular;24" halign="center" valign="center" />
                    <widget name="list" position="10,60" size="780,500" font="Regular;20" />
                    <widget name="red" position="10,565" size="180,30" font="Regular;18" halign="center" valign="center" />
                    <widget name="green" position="210,565" size="180,30" font="Regular;18" halign="center" valign="center" />
                    <widget name="yellow" position="410,565" size="180,30" font="Regular;18" halign="center" valign="center" />
                    <widget name="blue" position="610,565" size="180,30" font="Regular;18" halign="center" valign="center" />
                </screen>
            """
        
        self["title"] = Label(title)
        self["red"] = Label("IPAudio Pro")
        self["green"] = Label("IPAudio")
        self["yellow"] = Label("IPStreamer")
        self["blue"] = Label("AudioPlus")
        
        channel_names = []
        for ch in channels:
            if isinstance(ch, tuple) and len(ch) >= 1:
                name = str(ch[0]) if ch[0] is not None else "Unknown"
                channel_names.append(name)
            else:
                channel_names.append("Unknown")
        
        self["list"] = MenuList(channel_names)
        
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {
                "ok": self.promptAddToAudio,
                "cancel": self.close,
                "red": self.promptAddToIPAudioPro,
                "green": self.promptAddToIPAudio,
                "yellow": self.promptAddToIPStreamer,
                "blue": self.promptAddToAudioPlus
            },
            -1
        )
    
    def getSelectedChannel(self):
        idx = self["list"].getSelectionIndex()
        if idx < 0 or idx >= len(self.channels):
            return None, None
        channel = self.channels[idx]
        if isinstance(channel, tuple) and len(channel) >= 2:
            return str(channel[0]), str(channel[1])
        return str(channel), None
    
    def promptAddToIPAudio(self):
        name, url = self.getSelectedChannel()
        if not name:
            return
        self.selected_name = name
        self.selected_url = url
        self.session.openWithCallback(
            lambda answer: self.addChannelToJSON(answer, IPAUDIO_FILE, "playlist", "channel", "ipaudio"),
            MessageBox,
            "Channel: %s\n\nAdd to IPAudio?" % name,
            MessageBox.TYPE_YESNO
        )
    
    def promptAddToIPAudioPro(self):
        name, url = self.getSelectedChannel()
        if not name:
            return
        self.selected_name = name
        self.selected_url = url
        self.session.openWithCallback(
            lambda answer: self.addChannelToJSON(answer, IPAUDIO_PRO_FILE, "Playlist", "streams", "ipaudiopro"),
            MessageBox,
            "Channel: %s\n\nAdd to IPAudio Pro?" % name,
            MessageBox.TYPE_YESNO
        )
    
    def promptAddToIPStreamer(self):
        name, url = self.getSelectedChannel()
        if not name:
            return
        self.selected_name = name
        self.selected_url = url
        self.session.openWithCallback(
            lambda answer: self.addChannelToJSON(answer, IPSTREAMER_FILE, "playlist", "channel", "ipstreamer"),
            MessageBox,
            "Channel: %s\n\nAdd to IPStreamer?" % name,
            MessageBox.TYPE_YESNO
        )
    
    def promptAddToAudioPlus(self):
        name, url = self.getSelectedChannel()
        if not name:
            return
        self.selected_name = name
        self.selected_url = url
        self.session.openWithCallback(
            lambda answer: self.addChannelToJSON(answer, AUDIOPLUS_FILE, None, None, "audioplus"),
            MessageBox,
            "Channel: %s\n\nAdd to AudioPlus?" % name,
            MessageBox.TYPE_YESNO
        )
    
    def promptAddToAudio(self):
        name, url = self.getSelectedChannel()
        if not name:
            return
        self.selected_name = name
        self.selected_url = url
        from Screens.ChoiceBox import ChoiceBox
        choices = [
            ("IPAudio", "ipaudio"),
            ("IPAudio Pro", "ipaudiopro"),
            ("IPStreamer", "ipstreamer"),
            ("AudioPlus", "audioplus")
        ]
        self.session.openWithCallback(
            self.audioChoiceCallback,
            ChoiceBox,
            title="Choose audio player:",
            list=choices
        )
    
    def audioChoiceCallback(self, choice):
        if choice is None:
            return
        selected_plugin = choice[1]
        if selected_plugin == "ipaudio":
            self.addChannelToJSON(True, IPAUDIO_FILE, "playlist", "channel", "ipaudio")
        elif selected_plugin == "ipaudiopro":
            self.addChannelToJSON(True, IPAUDIO_PRO_FILE, "Playlist", "streams", "ipaudiopro")
        elif selected_plugin == "ipstreamer":
            self.addChannelToJSON(True, IPSTREAMER_FILE, "playlist", "channel", "ipstreamer")
        elif selected_plugin == "audioplus":
            self.addChannelToJSON(True, AUDIOPLUS_FILE, None, None, "audioplus")
    
    def addChannelToJSON(self, answer, json_file, playlist_key, item_key, plugin_type):
        if not answer:
            return
        try:
            if plugin_type == "ipaudio":
                default_data = {"playlist": []}
            elif plugin_type == "ipaudiopro":
                default_data = {"Playlist": {"streams": []}}
            elif plugin_type == "ipstreamer":
                default_data = {"playlist": []}
            elif plugin_type == "audioplus":
                default_data = [[]]
            
            if os.path.exists(json_file):
                with open(json_file, "r") as f:
                    content = f.read().strip()
                    if content:
                        try:
                            data = json.loads(content)
                        except:
                            data = default_data
                    else:
                        data = default_data
            else:
                data = default_data
            
            if plugin_type == "audioplus":
                if not data or not isinstance(data, list):
                    data = [[]]
                if len(data) == 0:
                    data.append([])
                playlist = data[0]
                for item in playlist:
                    if item.get("url") == self.selected_url:
                        self.session.open(MessageBox, "Stream already exists!", MessageBox.TYPE_INFO)
                        return
                new_item = {
                    "name": self.selected_name,
                    "url": self.selected_url,
                    "ref": "1:0:19:0:0:0:0:0:0:0"
                }
                playlist.append(new_item)
                data[0] = playlist
            else:
                if plugin_type == "ipaudio":
                    if playlist_key not in data:
                        data[playlist_key] = []
                    playlist = data[playlist_key]
                elif plugin_type == "ipaudiopro":
                    if playlist_key not in data:
                        data[playlist_key] = {}
                    if item_key not in data[playlist_key]:
                        data[playlist_key][item_key] = []
                    playlist = data[playlist_key][item_key]
                elif plugin_type == "ipstreamer":
                    if playlist_key not in data:
                        data[playlist_key] = []
                    playlist = data[playlist_key]
                
                for item in playlist:
                    if item.get("url") == self.selected_url:
                        self.session.open(MessageBox, "Stream already exists!", MessageBox.TYPE_INFO)
                        return
                
                if plugin_type == "ipaudio":
                    new_item = {
                        "channel": self.selected_name,
                        "url": self.selected_url
                    }
                elif plugin_type == "ipaudiopro":
                    new_item = {
                        "name": self.selected_name,
                        "display_name": self.selected_name,
                        "url": self.selected_url
                    }
                elif plugin_type == "ipstreamer":
                    new_item = {
                        "channel": self.selected_name,
                        "url": self.selected_url
                    }
                playlist.append(new_item)
            
            with open(json_file, "w") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            
            self.session.open(MessageBox, "Successfully added:\n%s" % self.selected_name, MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR)

class Xtream2AudioPlaylistSelector(Screen):
    def __init__(self, session, lines_pool):
        Screen.__init__(self, session)
        self.session = session
        self.lines_pool = lines_pool
        
        width = getDesktop(0).size().width()
        skin_file = (
            "/usr/lib/enigma2/python/Plugins/Extensions/Xtream2Audio/menus/skins/skinss_fhd.xml"
            if width >= 1920
            else "/usr/lib/enigma2/python/Plugins/Extensions/Xtream2Audio/menus/skins/skinss_hd.xml"
        )
        try:
            with open(skin_file, "r") as f:
                self.skin = f.read()
        except:
            self.skin = """
                <screen position="center,center" size="800,600" title="Select Subscription">
                    <widget name="title" position="0,0" size="800,50" font="Regular;24" halign="center" valign="center" />
                    <widget name="list" position="10,60" size="780,500" font="Regular;20" />
                </screen>
            """
        
        self["title"] = Label("Select Subscription")
        display_items = []
        for item in lines_pool:
            if isinstance(item, tuple) and len(item) >= 1:
                display_items.append(str(item[0]))
            else:
                display_items.append(str(item))
        self["list"] = MenuList(display_items)
        
        self["red"] = Label("")
        self["green"] = Label("")
        self["yellow"] = Label("")
        self["blue"] = Label("")
        
        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {
                "ok": self.selectPlaylist,
                "cancel": self.exitSelector
            },
            -1
        )
    
    def selectPlaylist(self):
        idx = self["list"].getSelectionIndex()
        if idx < 0 or idx >= len(self.lines_pool):
            self.close(False)
            return
        if idx == 0:
            self.close(False)
            return
        _, chosen_raw_link = self.lines_pool[idx]
        try:
            all_lines = []
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, "r") as f:
                    all_lines = [x.strip() for x in f.readlines() if x.strip()]
            if chosen_raw_link in all_lines:
                all_lines.remove(chosen_raw_link)
            all_lines.insert(0, chosen_raw_link)
            with open(CONFIG_FILE, "w") as f:
                for line in all_lines:
                    f.write(line + "\n")
            self.close(True)
        except:
            self.close(False)
    
    def exitSelector(self):
        self.close(False)

class Xtream2AudioMain(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        width = getDesktop(0).size().width()
        skin_file = (
            "/usr/lib/enigma2/python/Plugins/Extensions/Xtream2Audio/menus/skins/skins_fhd.xml"
            if width >= 1920
            else "/usr/lib/enigma2/python/Plugins/Extensions/Xtream2Audio/menus/skins/skins_hd.xml"
        )
        try:
            with open(skin_file, "r") as f:
                self.skin = f.read()
        except:
            self.skin = """
                <screen position="center,center" size="800,600" title="Xtream2Audio">
                    <widget name="title" position="0,0" size="800,50" font="Regular;24" halign="center" valign="center" />
                    <widget name="list" position="10,60" size="780,500" font="Regular;20" />
                    <widget name="red" position="10,565" size="180,30" font="Regular;18" halign="center" valign="center" />
                    <widget name="green" position="210,565" size="180,30" font="Regular;18" halign="center" valign="center" />
                    <widget name="yellow" position="410,565" size="180,30" font="Regular;18" halign="center" valign="center" />
                    <widget name="blue" position="610,565" size="180,30" font="Regular;18" halign="center" valign="center" />
                    <widget name="menu" position="710,565" size="90,30" font="Regular;18" halign="center" valign="center" />
                </screen>
            """
        
        self["title"] = Label("Xtream2Audio")
        self["list"] = MenuList([])
        self["red"] = Label("Reset IPAudio")
        self["green"] = Label("Reset IPStreamer")
        self["yellow"] = Label("Reset IPAudio Pro")
        self["blue"] = Label("Reset AudioPlus")
        self["menu"] = Label("Select Sub.")
        
        self.categories = []
        self.streams = []
        self.container_format = "ts"
        self.host = ""
        self.user = ""
        self.password = ""
        
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "MenuActions"],
            {
                "ok": self.openCategory,
                "cancel": self.close,
                "red": self.promptResetIPAudio,
                "green": self.promptResetIPStreamer,
                "yellow": self.promptResetIPAudioPro,
                "blue": self.promptResetAudioPlus,
                "menu": self.openPlaylistSelector
            },
            -1
        )
        
        self.onFirstExecBegin.append(self.load)
    
    def load(self):
        host, user, password, container_format = read_config()
        if not host:
            self.session.open(MessageBox, "No valid subscription found!\nPlease add playlist to:\n%s" % CONFIG_FILE, MessageBox.TYPE_ERROR)
            return
        
        self.host = host
        self.user = user
        self.password = password
        self.container_format = container_format
        
        self["title"].setText("Xtream2Audio - Loading...")
        
        raw_categories = get_categories(host, user, password)
        self.streams = get_streams(host, user, password)
        
        if not raw_categories and self.streams:
            unique_cat_ids = set()
            for s in self.streams:
                cid = s.get("category_id")
                if cid and cid not in unique_cat_ids:
                    unique_cat_ids.add(cid)
                    raw_categories.append({
                        "category_id": cid,
                        "category_name": "Category ID: %s" % str(cid),
                        "category_order": 0
                    })
        
        try:
            self.categories = sorted(
                raw_categories,
                key=lambda x: int(x.get("category_order", 0)) if str(x.get("category_order", 0)).isdigit() else 0
            )
        except:
            self.categories = raw_categories
        
        menu_items = []
        for c in self.categories:
            if isinstance(c, dict):
                name = c.get("category_name")
                if name is None:
                    name = "Unknown"
            else:
                name = str(c)
            menu_items.append(str(name))
        
        self["list"].setList(menu_items)
        self["title"].setText("Xtream2Audio - Categories (%d)" % len(self.categories))
        
        if len(self.categories) == 0:
            self.session.open(MessageBox, "No categories or streams found!\nCheck your subscription.", MessageBox.TYPE_INFO)
    
    def openCategory(self):
        idx = self["list"].getSelectionIndex()
        if idx < 0 or idx >= len(self.categories):
            return
        
        selected_cat = self.categories[idx]
        if isinstance(selected_cat, dict):
            cat_id = selected_cat.get("category_id")
            cat_name = str(selected_cat.get("category_name", "Unknown"))
        else:
            cat_id = selected_cat
            cat_name = str(selected_cat)
        
        channels = []
        for s in self.streams:
            if str(s.get("category_id")) == str(cat_id):
                name = str(s.get("name", "Unknown"))
                sid = s.get("stream_id")
                if sid:
                    url = build_stream_url(self.host, self.user, self.password, sid, self.container_format)
                    channels.append((name, url))
                else:
                    channels.append((name, None))
        
        if not channels:
            self.session.open(MessageBox, "No channels in this category!", MessageBox.TYPE_INFO)
            return
        
        self.session.open(Xtream2AudioChannels, cat_name, channels)
    
    def promptResetIPAudio(self):
        self.session.openWithCallback(
            self.resetIPAudioAction,
            MessageBox,
            "Reset IPAudio playlist?",
            MessageBox.TYPE_YESNO
        )
    
    def resetIPAudioAction(self, answer):
        if not answer:
            return
        try:
            default_data = {"playlist": []}
            dir_name = os.path.dirname(IPAUDIO_FILE)
            if not os.path.exists(dir_name):
                os.makedirs(dir_name)
            with open(IPAUDIO_FILE, "w") as f:
                json.dump(default_data, f, indent=4, ensure_ascii=False)
            self.session.open(MessageBox, "IPAudio playlist reset successfully!", MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR)
    
    def promptResetIPAudioPro(self):
        self.session.openWithCallback(
            self.resetIPAudioProAction,
            MessageBox,
            "Reset IPAudio Pro playlist?",
            MessageBox.TYPE_YESNO
        )
    
    def resetIPAudioProAction(self, answer):
        if not answer:
            return
        try:
            default_data = {"Playlist": {"streams": []}}
            dir_name = os.path.dirname(IPAUDIO_PRO_FILE)
            if not os.path.exists(dir_name):
                os.makedirs(dir_name)
            with open(IPAUDIO_PRO_FILE, "w") as f:
                json.dump(default_data, f, indent=4, ensure_ascii=False)
            self.session.open(MessageBox, "IPAudio Pro playlist reset successfully!", MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR)
    
    def promptResetIPStreamer(self):
        self.session.openWithCallback(
            self.resetIPStreamerAction,
            MessageBox,
            "Reset IPStreamer playlist?",
            MessageBox.TYPE_YESNO
        )
    
    def resetIPStreamerAction(self, answer):
        if not answer:
            return
        try:
            default_data = {"playlist": []}
            dir_name = os.path.dirname(IPSTREAMER_FILE)
            if not os.path.exists(dir_name):
                os.makedirs(dir_name)
            with open(IPSTREAMER_FILE, "w") as f:
                json.dump(default_data, f, indent=4, ensure_ascii=False)
            self.session.open(MessageBox, "IPStreamer playlist reset successfully!", MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR)
    
    def promptResetAudioPlus(self):
        self.session.openWithCallback(
            self.resetAudioPlusAction,
            MessageBox,
            "Reset AudioPlus playlist?",
            MessageBox.TYPE_YESNO
        )
    
    def resetAudioPlusAction(self, answer):
        if not answer:
            return
        try:
            default_data = [[]]
            dir_name = os.path.dirname(AUDIOPLUS_FILE)
            if not os.path.exists(dir_name):
                os.makedirs(dir_name)
            with open(AUDIOPLUS_FILE, "w") as f:
                json.dump(default_data, f, indent=4, ensure_ascii=False)
            self.session.open(MessageBox, "AudioPlus playlist reset successfully!", MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR)
    
    def openPlaylistSelector(self):
        lines_pool = []
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    for line in f:
                        line_str = line.strip()
                        if not line_str:
                            continue
                        if line_str.startswith("http") and (
                            "output=ts" in line_str or
                            "output=m3u8" in line_str or
                            line_str.endswith("ts") or
                            line_str.endswith("m3u8") or
                            "type=m3u" in line_str
                        ):
                            display_str = line_str
                            if "&password=" in line_str:
                                display_str = line_str.split("&password=")[0]
                            elif "password=" in line_str:
                                display_str = line_str.split("password=")[0]
                            lines_pool.append((display_str, line_str))
            except:
                pass
        
        if not lines_pool:
            self.session.open(MessageBox, "No subscriptions found in playlists.txt!", MessageBox.TYPE_INFO)
            return
        
        self.session.openWithCallback(
            self.playlistSelectorCallback,
            Xtream2AudioPlaylistSelector,
            lines_pool
        )
    
    def playlistSelectorCallback(self, dynamic_altered=False):
        if dynamic_altered:
            self.categories = []
            self.streams = []
            self["list"].setList([])
            self.load()

def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return [
        PluginDescriptor(
            name="Xtream2Audio",
            description="Convert Xtream IPTV channels to audio players",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]

def main(session, **kwargs):
    session.open(Xtream2AudioMain)

