# -*- coding: utf-8 -*-

import os
import socket

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "0.0.0.0"

def check_internet():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return "Online"
    except:
        return "Offline"

def get_image_name():
    try:
        with open("/etc/issue", "r") as f:
            return f.readline().strip().split()[0]
    except:
        return "Unknown"

def get_python_version():
    import sys
    return "Python %d.%d" % (sys.version_info.major, sys.version_info.minor)

def get_storage_info():
    try:
        stat = os.statvfs("/")
        total = (stat.f_blocks * stat.f_frsize) / (1024 * 1024 * 1024)
        free = (stat.f_bfree * stat.f_frsize) / (1024 * 1024 * 1024)
        return "Storage: %.1f/%.1f GB" % (free, total)
    except:
        return "Storage: N/A"

def get_ram_info():
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if "MemTotal" in line:
                    total = int(line.split()[1]) / 1024
                if "MemFree" in line:
                    free = int(line.split()[1]) / 1024
            return "RAM: %.0f/%.0f MB" % (free, total)
    except:
        return "RAM: N/A"
