# -*- coding: utf-8 -*-

Version = "1.0.0"

def main(session, **kwargs):
    from plugin import Xtream2AudioMain
    session.open(Xtream2AudioMain)

def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return [
        PluginDescriptor(
            name="Xtream2Audio",
            description="Convert Xtream IPTV channels to audio players",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        )
    ]
