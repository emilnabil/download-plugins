# -*- coding: utf-8 -*-
from .plugin import Plugins

__version__ = "1.0.0"
__author__ = "Emil"
__description__ = "إدارة الحزم والمجلدات وتنظيف النظام"
