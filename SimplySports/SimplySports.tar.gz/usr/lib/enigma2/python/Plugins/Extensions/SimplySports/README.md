# SimplySports
A plugin to show sport fixtures and game results for enigma2 satellites. 
