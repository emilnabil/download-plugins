# -*- coding: utf-8 -*-
# E2iPlayerUpdater v5.0
# Features: Skin.xml, Release Notes, Install if missing, Arabic/English
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Button import Button
from Components.Sources.StaticText import StaticText
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import quitMainloop, eTimer
import os, json, urllib.request, threading, time, re, datetime, shutil, tarfile, zipfile
import traceback
import subprocess
# ============================================================
# SKIN LOADING (from external skin.xml)
# ============================================================
_SKIN_PATH = resolveFilename(
    SCOPE_PLUGINS,
    "Extensions/E2iPlayerUpdater/skin.xml"
)
try:
    from skin import loadSkin
    if os.path.exists(_SKIN_PATH):
        loadSkin(_SKIN_PATH)
        print(f"[E2iPlayerUpdater] skin.xml loaded: {_SKIN_PATH}")
    else:
        print(f"[E2iPlayerUpdater] skin.xml NOT found: {_SKIN_PATH}")
except Exception as _e:
    print(f"[E2iPlayerUpdater] skin load error: {_e}")
# ============================================================
# PATHS
# ============================================================
PLUGIN_DIR   = "/usr/lib/enigma2/python/Plugins/Extensions/E2iPlayerUpdater"
PLUGIN_PATH  = "/usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer"
VERSION_PY   = os.path.join(PLUGIN_PATH, "version.py")
VERSION_PY2  = os.path.join(PLUGIN_PATH, "iptvplayer", "version.py")
VERSION_FILE = os.path.join(PLUGIN_DIR, "last_release.txt")
SKIPPED_FILE = os.path.join(PLUGIN_DIR, "skipped_versions.txt")
SNOOZE_FILE  = os.path.join(PLUGIN_DIR, "snooze_until.txt")
DEBUG_LOG    = "/tmp/e2iplayer_updater_debug.log"
REPO_API = "https://api.github.com/repos/oe-mirrors/e2iplayer/releases/latest"
REPO_ZIP = "https://github.com/oe-mirrors/e2iplayer/archive/refs/heads/python3.zip"
# ============================================================
# CONFIG
# ============================================================
config.plugins.e2iupdater = ConfigSubsection()
config.plugins.e2iupdater.enabled          = ConfigYesNo(default=True)
config.plugins.e2iupdater.check_on_start   = ConfigYesNo(default=True)
config.plugins.e2iupdater.show_ok_message  = ConfigYesNo(default=False)
config.plugins.e2iupdater.backup_enabled   = ConfigYesNo(default=True)
config.plugins.e2iupdater.debug_enabled    = ConfigYesNo(default=False)
config.plugins.e2iupdater.sound_enabled    = ConfigYesNo(default=True)
config.plugins.e2iupdater.show_release_notes = ConfigYesNo(default=True)
config.plugins.e2iupdater.periodic_enabled = ConfigYesNo(default=False)
config.plugins.e2iupdater.periodic_hours   = ConfigSelection(
    default="6",
    choices=[("1", "1 hour"), ("2", "2 hours"), ("4", "4 hours"),
             ("6", "6 hours"), ("12", "12 hours"), ("24", "24 hours")]
)
config.plugins.e2iupdater.snooze_hours     = ConfigSelection(
    default="6",
    choices=[("1", "1 hour"), ("3", "3 hours"), ("6", "6 hours"),
             ("12", "12 hours"), ("24", "24 hours"), ("168", "1 week")]
)
config.plugins.e2iupdater.language = ConfigSelection(
    default="ar",
    choices=[("ar", "العربية"), ("en", "English")]
)
config.plugins.e2iupdater.backup_location = ConfigSelection(
    default="auto",
    choices=[
        ("auto",         "Auto (HDD/USB)"),
        ("/media/hdd",   "HDD (/media/hdd)"),
        ("/media/usb",   "USB (/media/usb)"),
    ]
)
# ============================================================
# TRANSLATIONS
# ============================================================
TRANSLATIONS = {
    "ar": {
        "menu_title":      "مُحدِّث E2iPlayer",
        "menu_check":      "🔍 فحص التحديثات الآن",
        "menu_settings":   "⚙️ الإعدادات",
        "menu_status":     "📊 الحالة",
        "menu_skip_list":  "📋 الإصدارات المُتجاهَلة",
        "menu_clear_skip": "🗑️ مسح قائمة التجاهل",
        "menu_clear_snooze": "⏰ مسح قائمة التأجيل",
        "menu_about":      "ℹ️ حول",
        "menu_remove_xxx": "🚫 حذف هوست XXX",
        "menu_install_torr": "📥 تنصيب TorrServer",  
        "update_title":    "🎉 تحديث E2iPlayer متوفر!",
        "install_title":   "📥 E2iPlayer غير مثبت!",
        "installed":       "المثبت",
        "new_version":     "الجديد",
        "release":         "الإصدار",
        "date":            "التاريخ",
        "whats_new":       "🆕 الجديد في الإصدار",
        "no_release_notes": "لا توجد ملاحظات إصدار",
        "btn_update":      "تحديث الآن (أخضر)",
        "btn_remind":      "تذكير لاحقاً (أصفر)",
        "btn_skip":        "تجاهل الإصدار (أحمر)",
        "backup_msg":      "سيتم إنشاء نسخة احتياطية في:\n{path}\n\nسيتم حذف الإصدار القديم!\n\nهل تريد المتابعة؟",
        "install_msg":     "E2iPlayer غير مثبت!\n\nالإصدار المتاح: {tag}\n{name}\nالتاريخ: {date}\n\nهل تريد تثبيته الآن؟",
        "install_confirm": "سيتم تثبيت E2iPlayer:\n\nالإصدار: {tag}\n{name}\nالتاريخ: {date}\n\nهل تريد المتابعة؟",
        "install_no_net":  "E2iPlayer غير مثبت!\n\nفشل الاتصال بـ GitHub!",
        "snoozed":         "تم تأجيل التذكير لمدة {hours} ساعة.",
        "skipped":         "تم تجاهل الإصدار {tag}.\nلن يتم سؤالك عن هذا الإصدار مرة أخرى.",
        "restart_now":     "سيتم إعادة تشغيل Enigma2 الآن...",
        "update_failed":   "فشل التحديث!\nراجع /tmp/e2iplayer_updater_debug.log",
        "latest_version":  "لديك أحدث إصدار!\n\nالمثبت: {installed}\nالرسمي: {remote}",
        "settings_title":  "إعدادات E2iPlayer Updater",
        "cfg_enabled":     "تفعيل المُحدِّث",
        "cfg_check_start": "فحص عند فتح IPTVPlayer",
        "cfg_show_ok":     "إظهار رسالة 'أحدث إصدار'",
        "cfg_snooze":      "مدة التأجيل",
        "cfg_debug":       "تسجيل التشخيص (Debug)",
        "cfg_sound":       "صوت التنبيه",
        "cfg_release_notes": "إظهار الجديد في الإصدار",
        "cfg_periodic":    "فحص دوري في الخلفية",
        "cfg_periodic_h":  "فترة الفحص الدوري",
        "cfg_language":    "اللغة",
        "save":            "حفظ",
        "cancel":          "إلغاء",
        "no_skipped":      "لا توجد إصدارات مُتجاهَلة.",
        "skipped_list":    "الإصدارات المُتجاهَلة:\n\n{list}",
        "skip_cleared":    "تم مسح قائمة التجاهل.",
        "snooze_cleared":  "تم مسح قائمة التأجيل.",
        "no_snooze":       "لا يوجد تأجيل نشط.",
        "snooze_status":   "التأجيل النشط:\nحتى {until}",
        "cfg_backup":      "عمل نسخة احتياطية قبل التحديث",
        "cfg_backup_loc":  "مكان حفظ النسخة الاحتياطية",
        "direct_update":   "تحديث مباشر (بدون باكب)",
        "backup_update":   "تحديث مع نسخة احتياطية",
        "xxx_removed":     "تم حذف {count} ملف هوست XXX.",
        "xxx_not_found":   "لا توجد ملفات هوست XXX.",
        "xxx_confirm":     "سيتم حذف جميع ملفات هوست XXX.\n\nهل تريد المتابعة؟",
        "torr_installed":  "تم تثبيت TorrServer بنجاح!",
        "torr_failed":     "فشل تثبيت TorrServer!",
        # TorrServer
        "torr_unsupported_arch": "❌ معمارية غير مدعومة: {arch}",
        "torr_confirm":          "سيتم تنصيب TorrServer:\n\n"
                                 "المعمارية: {arch} ({torr_arch})\n"
                                 "المسار: {path}\n\n"
                                 "سيتم تحميل آخر إصدار من GitHub الرسمي.\n\n"
                                 "هل تريد المتابعة؟",
        "torr_download_fail":    "❌ فشل الحصول على رابط TorrServer!\n\n"
                                 "المعمارية: {torr_arch}\n"
                                 "تحقق من اتصالك بالإنترنت.",
        "torr_too_small":        "❌ الملف صغير جداً ({size} bytes)\n"
                                 "قد يكون التحميل فشل!",
        "torr_ok":               "✅ تم تثبيت TorrServer!\n\n"
                                 "الإصدار: {tag}\n"
                                 "المسار: {path}\n"
                                 "الحجم: {size} KB\n\n"
                                 "⚠️ للحصول على أفضل أداء:\n"
                                 "فعّل HTTP buffering و HLS/M3U8 buffering\n"
                                 "من إعدادات E2iPlayer.",
        "torr_fail":             "❌ فشل التثبيت:\n{error}",
        "menu_backup_manager": "💾 إدارة النسخ الاحتياطية",
        "backup_title":        "📂 إدارة النسخ الاحتياطية",
        "backup_do_now":       "💾 إنشاء نسخة احتياطية الآن",
        "backup_list":         "📂 عرض النسخ الاحتياطية",
        "backup_cleanup":      "🗑️ حذف النسخ القديمة",
        "backup_restore":      "🔄 استعادة من نسخة احتياطية",
        "backup_now_confirm":  "سيتم إنشاء نسخة احتياطية من E2iPlayer.\n\nهل تريد المتابعة؟",
        "backup_now_ok":       "✅ تم إنشاء النسخة الاحتياطية:\n{path}",
        "backup_now_fail":     "❌ فشل إنشاء النسخة الاحتياطية!",
        "backup_none":         "لا توجد نسخ احتياطية.",
        "backup_list_text":    "📂 النسخ الاحتياطية:\n\n{list}",
        "backup_cleanup_days": "حذف النسخ الأقدم من:",
        "backup_cleanup_confirm": "سيتم حذف النسخ الأقدم من {days} يوم.\n\nهل تريد المتابعة؟",
        "backup_cleanup_ok":   "تم حذف {count} نسخة احتياطية.",
        "backup_cleanup_none": "لا توجد نسخ لحذفها.",
        "backup_restore_confirm": "سيتم استعادة:\n{name}\n\nسيتم حذف الإصدار الحالي!\n\nهل تريد المتابعة؟",
        "backup_restore_ok":   "✅ تمت الاستعادة بنجاح!\n\nسيتم إعادة تشغيل Enigma2.",
        "backup_restore_fail": "❌ فشل الاستعادة!",
        "days_7":              "7 أيام",
        "days_30":             "30 يوم",
        "days_90":             "90 يوم",
        "days_180":            "180 يوم",
        "days_365":            "سنة",
        "backup_manage":       "📋 إدارة النسخة",
        "backup_restore_this": "🔄 استعادة هذه النسخة",
        "backup_delete_this":  "🗑️ حذف هذه النسخة",
        "backup_delete_confirm": "سيتم حذف:\n{name}\n\nهل تريد المتابعة؟",
        "backup_delete_ok":    "✅ تم حذف النسخة الاحتياطية.",
        "backup_delete_fail":  "❌ فشل حذف النسخة!",
        "backup_choice_title":   "🔄 اختر طريقة التحديث",
        "backup_choice_full":    "💾 باكب كامل (بدون نقل الملفات الخاصة)",
        "backup_choice_migrate": "📦 باكب كامل + نقل الملفات الخاصة",
        "backup_choice_none":    "⚡ تحديث مباشر (بدون باكب)",
        "backup_choice_help":    "سيتم تحديث E2iPlayer:\n\n"
                                 "• باكب كامل = نسخة احتياطية فقط\n"
                                 "• باكب + نقل = نسخة + نقل الهوستات الخاصة\n"
                                 "• تحديث مباشر = بدون نسخة احتياطية\n\n"
                                 "ما تريد؟",
        "migrate_started":       "📦 جاري نقل الملفات الخاصة...",
        "migrate_ok":            "✅ تم نقل {count} ملف خاص بنجاح.",
        "migrate_none":          "ℹ️ لا توجد ملفات خاصة للنقل.",
        "migrate_fail":          "⚠️ فشل نقل بعض الملفات!",
        "about_text":      "E2iPlayerUpdater v5.0\n\n"
                           "تم تطويره بواسطة محمد الصفطي (angel_heart) © 2026\n"
                           "مُحدِّث تلقائي احترافي لبلجن E2iPlayer\n\n"
                           "🎯 الفحص والتحديث:\n"
                           "• فحص تلقائي عند الفتح وتثبيت إذا لم يكن موجوداً\n"
                           "• 3 أزرار: تحديث / تأجيل / تجاهل  | عرض الجديد وفحص دوري\n\n"
                           "💾 النسخ الاحتياطية:\n"
                           "• باكب تلقائي قبل التحديث (اختياري)\n"
                           "• إدارة كاملة: إنشاء / عرض / حذف / استعادة | مكان قابل للتخصيص (HDD/USB)\n\n"
                           "📦 النقل الذكي:\n"
                           "• نقل الهوستات والأيقونات المخصصة | الحفاظ على الموجود (بدون استبدال) | عرض قائمة الملفات المنقولة\n\n"
                           "🛠️ أدوات إضافية:\n"
                           "• حذف هوست XXX | تنصيب TorrServer تلقائياً\n"
                           "• عرض الحالة ومسح قوائم التجاهل/التأجيل\n\n"
                           "🌍 اللغات: العربية والإنجليزية | Skin منفصل (skin.xml) | صوت تنبيه\n"
                           "المستودع: oe-mirrors/e2iplayer",
        "status_text":     "📊 الحالة\n\n"
                           "الإصدار المثبت: {installed}\n"
                           "الإصدار الرسمي: {remote}\n"
                           "آخر إصدار معروف: {local}\n"
                           "مُتجاهَل: {skipped}\n"
                           "مُؤجَّل: {snoozed}\n"
                           "الفحص الدوري: {periodic}\n"
                           "الصوت: {sound}",
        "yes":             "نعم",
        "no":              "لا",
        "on":              "مُفعَّل",
        "off":             "مُعطَّل",
    },
    "en": {
        "menu_title":      "E2iPlayer Updater",
        "menu_check":      "🔍 Check for updates now",
        "menu_settings":   "⚙️ Settings",
        "menu_status":     "📊 Status",
        "menu_skip_list":  "📋 Skipped versions",
        "menu_clear_snooze": "⏰ Clear snooze list",
        "menu_clear_skip": "🗑️ Clear skip list",
        "menu_about":      "ℹ️ About",
        "menu_remove_xxx": "🚫 Remove XXX hosts",
        "menu_install_torr":  "📥 Install TorrServer",
        "update_title":    "🎉 E2iPlayer Update Available!",
        "install_title":   "📥 E2iPlayer NOT Installed!",
        "installed":       "Installed",
        "new_version":     "New",
        "release":         "Release",
        "date":            "Date",
        "whats_new":       "🆕 What's new",
        "no_release_notes": "No release notes available",
        "btn_update":      "Update Now (Green)",
        "btn_remind":      "Remind Later (Yellow)",
        "btn_skip":        "Skip Version (Red)",
        "backup_msg":      "Backup will be created at:\n{path}\n\nOld version will be deleted!\n\nContinue?",
        "install_msg":     "E2iPlayer NOT installed!\n\nAvailable: {tag}\n{name}\nDate: {date}\n\nInstall now?",
        "install_confirm": "Will install E2iPlayer:\n\nVersion: {tag}\n{name}\nDate: {date}\n\nContinue?",
        "install_no_net":  "E2iPlayer NOT installed!\n\nGitHub connection failed!",
        "snoozed":         "Reminder snoozed for {hours} hour(s).",
        "skipped":         "Version {tag} skipped.\nYou will not be asked again.",
        "restart_now":     "Enigma2 will restart now...",
        "update_failed":   "Update failed!\nSee /tmp/e2iplayer_updater_debug.log",
        "latest_version":  "You have latest version!\n\nInstalled: {installed}\nRemote: {remote}",
        "settings_title":  "E2iPlayer Updater Settings",
        "cfg_enabled":     "Enable updater",
        "cfg_check_start": "Check when IPTVPlayer starts",
        "cfg_show_ok":     "Show 'latest version' message",
        "cfg_snooze":      "Snooze duration",
        "cfg_debug":       "Debug logging",
        "cfg_sound":       "Notification sound",
        "cfg_release_notes": "Show release notes",
        "cfg_periodic":    "Periodic background check",
        "cfg_periodic_h":  "Periodic interval",
        "cfg_language":    "Language",
        "save":            "Save",
        "cancel":          "Cancel",
        "no_skipped":      "No skipped versions.",
        "skipped_list":    "Skipped versions:\n\n{list}",
        "skip_cleared":    "Skip list cleared.",
        "snooze_cleared":  "Snooze cleared.",
        "no_snooze":       "No active snooze.",
        "snooze_status":   "Active snooze:\nuntil {until}",
        "cfg_backup":      "Backup before update",
        "cfg_backup_loc":  "Backup location",
        "direct_update":   "Direct update (no backup)",
        "backup_update":   "Update with backup",
        "xxx_removed":     "Removed {count} XXX host files.",
        "xxx_not_found":   "No XXX host files found.",
        "xxx_confirm":     "Will remove all XXX host files.\n\nContinue?",
        "torr_installed":  "TorrServer installed!",
        "torr_failed":     "TorrServer installation failed!",
        # TorrServer
        "torr_unsupported_arch": "❌ Unsupported architecture: {arch}",
        "torr_confirm":          "Will install TorrServer:\n\n"
                                 "Architecture: {arch} ({torr_arch})\n"
                                 "Path: {path}\n\n"
                                 "Will download latest version from GitHub.\n\n"
                                 "Continue?",
        "torr_download_fail":    "❌ Failed to get TorrServer download URL!\n\n"
                                 "Architecture: {torr_arch}\n"
                                 "Check your internet connection.",
        "torr_too_small":        "❌ File too small ({size} bytes)\n"
                                 "Download may have failed!",
        "torr_ok":               "✅ TorrServer installed!\n\n"
                                 "Version: {tag}\n"
                                 "Path: {path}\n"
                                 "Size: {size} KB\n\n"
                                 "⚠️ For best performance:\n"
                                 "Enable HTTP buffering and HLS/M3U8 buffering\n"
                                 "in E2iPlayer settings.",
        "torr_fail":             "❌ Installation failed:\n{error}",
        "menu_backup_manager": "💾 Backup Manager",
        "backup_title":        "📂 Backup Manager",
        "backup_do_now":       "💾 Create backup now",
        "backup_list":         "📂 Show backups",
        "backup_cleanup":      "🗑️ Cleanup old backups",
        "backup_restore":      "🔄 Restore from backup",
        "backup_now_confirm":  "Will create a backup of E2iPlayer.\n\nContinue?",
        "backup_now_ok":       "✅ Backup created:\n{path}",
        "backup_now_fail":     "❌ Backup failed!",
        "backup_none":         "No backups found.",
        "backup_list_text":    "📂 Backups:\n\n{list}",
        "backup_cleanup_days": "Delete backups older than:",
        "backup_cleanup_confirm": "Will delete backups older than {days} days.\n\nContinue?",
        "backup_cleanup_ok":   "Deleted {count} backups.",
        "backup_cleanup_none": "No backups to delete.",
        "backup_restore_confirm": "Will restore:\n{name}\n\nCurrent version will be deleted!\n\nContinue?",
        "backup_restore_ok":   "✅ Restored successfully!\n\nEnigma2 will restart.",
        "backup_restore_fail": "❌ Restore failed!",
        "days_7":              "7 days",
        "days_30":             "30 days",
        "days_90":             "90 days",
        "days_180":            "180 days",
        "days_365":            "1 year",
        "backup_manage":       "📋 Manage this backup",
        "backup_restore_this": "🔄 Restore this backup",
        "backup_delete_this":  "🗑️ Delete this backup",
        "backup_delete_confirm": "Will delete:\n{name}\n\nContinue?",
        "backup_delete_ok":    "✅ Backup deleted.",
        "backup_delete_fail":  "❌ Failed to delete backup!",
        "backup_choice_title":   "🔄 Choose Update Method",
        "backup_choice_full":    "💾 Full backup (without custom files)",
        "backup_choice_migrate": "📦 Full backup + migrate custom files",
        "backup_choice_none":    "⚡ Direct update (no backup)",
        "backup_choice_help":    "Will update E2iPlayer:\n\n"
                                 "• Full backup = backup only\n"
                                 "• Backup + Migrate = backup + copy custom hosts\n"
                                 "• Direct = no backup\n\n"
                                 "What do you want?",
        "migrate_started":       "📦 Migrating custom files...",
        "migrate_ok":            "✅ Migrated {count} custom files.",
        "migrate_none":          "ℹ️ No custom files to migrate.",
        "migrate_fail":          "⚠️ Some files failed to migrate!",
        "about_text":      "E2iPlayerUpdater v5.0\n\n"
                           "Developed by Mohamed Elsafty (angel_heart) © 2026 \n"
                           "Professional auto-updater for E2iPlayer plugin\n\n"
                           "🎯 Check & Update:\n"
                           "• Auto-check on start | Auto-install if not installed\n"
                           "• 3 buttons: Update / Remind / Skip | Show release notes | periodic check\n\n"
                           "💾 Backups:\n"
                           "• Auto backup before update (optional) | Full backup management\n"
                           "• Create / Show / Delete / Restore | Custom location (HDD/USB) | Custom location (HDD / USB)\n\n"
                           "📦 Smart Migration:\n"
                           "• Migrate custom hosts & icons | Keep existing (no overwrite) | Show migrated files list\n\n"
                           "🛠️ Extra Tools:\n"
                           "• Remove XXX hosts | Install TorrServer automatically\n"
                           "• Show full status | Clear skip & snooze lists\n\n"
                           "🌍 Languages: Arabic & English  | Separate skin (skin.xml) | Notification sound\n"
                           "Repo: oe-mirrors/e2iplayer",
        "status_text":     "📊 Status\n\n"
                           "Installed: {installed}\n"
                           "Remote: {remote}\n"
                           "Last known: {local}\n"
                           "Skipped: {skipped}\n"
                           "Snoozed: {snoozed}\n"
                           "Periodic: {periodic}\n"
                           "Sound: {sound}",
        "yes":             "Yes",
        "no":              "No",
        "on":              "ON",
        "off":             "OFF",
    }
}
def T(key):
    lang = config.plugins.e2iupdater.language.value
    return TRANSLATIONS.get(lang, TRANSLATIONS["en"]).get(key, key)
# ============================================================
# DEBUG
# ============================================================
def dbg(msg):
    if not config.plugins.e2iupdater.debug_enabled.value:
        return
    line = f"[{datetime.datetime.now().strftime('%H:%M:%S.%f')[:-3]}] {msg}"
    print("[Updater-DBG]", line)
    try:
        with open(DEBUG_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
def dbg_exc(context):
    if not config.plugins.e2iupdater.debug_enabled.value:
        return
    dbg(f"!!! EXCEPTION in {context} !!!")
    try:
        tb = traceback.format_exc()
        for ln in tb.splitlines():
            dbg("   " + ln)
    except Exception:
        pass
dbg("=" * 60)
dbg("E2iPlayerUpdater v5.0 LOADED")
dbg("=" * 60)
# ============================================================
# STATE
# ============================================================
g_session = None
g_last_check = 0
g_periodic_timer = None
g_pending_callback = None
# ============================================================
# SOUND
# ============================================================
def play_notification_sound():
    if not config.plugins.e2iupdater.sound_enabled.value:
        return
    dbg("attempting to play sound")
    sound_file = "/usr/share/sounds/notification.wav"
    if not os.path.exists(sound_file):
        for f in ["/usr/share/sounds/update_alert.wav",
                  "/usr/share/sounds/message.wav",
                  "/usr/share/sounds/info.wav",
                  "/usr/share/sounds/beep.wav"]:
            if os.path.exists(f):
                sound_file = f
                break
        else:
            dbg("no sound file found")
            return
    dbg(f"playing: {sound_file}")
    def _play():
        try:
            proc = subprocess.Popen(
                ["aplay", "-q", sound_file],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True
            )
            dbg(f"✅ aplay started (pid={proc.pid})")
        except Exception as e:
            dbg(f"❌ Sound exception: {e}")
    threading.Thread(target=_play, daemon=True).start()
# ============================================================
# FILE HELPERS
# ============================================================
def read_file(path):
    if os.path.exists(path):
        try:
            return open(path, "r", encoding="utf-8", errors="ignore").read().strip()
        except Exception:
            dbg_exc(f"read_file {path}")
    return ""
def write_file(path, content):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        dbg(f"write_file({path}) = {content!r}")
        return True
    except Exception:
        dbg_exc(f"write_file {path}")
        return False
def get_skipped_versions():
    content = read_file(SKIPPED_FILE)
    if not content:
        return set()
    return set(line.strip() for line in content.splitlines() if line.strip())
def add_skipped_version(tag):
    skipped = get_skipped_versions()
    skipped.add(tag)
    write_file(SKIPPED_FILE, "\n".join(sorted(skipped)))
    dbg(f"add_skipped_version({tag}) — total: {len(skipped)}")
def is_version_skipped(tag):
    result = tag in get_skipped_versions()
    dbg(f"is_version_skipped({tag}) = {result}")
    return result
def clear_skipped():
    try:
        if os.path.exists(SKIPPED_FILE):
            os.remove(SKIPPED_FILE)
        dbg("clear_skipped() OK")
    except Exception:
        dbg_exc("clear_skipped")
def set_snooze(hours):
    until = datetime.datetime.now() + datetime.timedelta(hours=int(hours))
    write_file(SNOOZE_FILE, until.strftime("%Y-%m-%d %H:%M:%S"))
    dbg(f"set_snooze({hours}h) until {until}")
def is_snoozed():
    content = read_file(SNOOZE_FILE)
    if not content:
        return False
    try:
        until = datetime.datetime.strptime(content, "%Y-%m-%d %H:%M:%S")
        if datetime.datetime.now() < until:
            dbg(f"is_snoozed() = True (until {until})")
            return True
        dbg("is_snoozed() = False")
        return False
    except Exception:
        dbg_exc("is_snoozed")
        return False
def get_snooze_info():
    """إرجاع معلومات التأجيل النشط"""
    content = read_file(SNOOZE_FILE)
    if not content:
        return None
    try:
        until = datetime.datetime.strptime(content, "%Y-%m-%d %H:%M:%S")
        if datetime.datetime.now() < until:
            remaining = until - datetime.datetime.now()
            hours = int(remaining.total_seconds() // 3600)
            minutes = int((remaining.total_seconds() % 3600) // 60)
            return {
                "until": content,
                "remaining": f"{hours}h {minutes}m"
            }
        return None
    except Exception:
        dbg_exc("get_snooze_info")
        return None
def clear_snooze():
    try:
        if os.path.exists(SNOOZE_FILE):
            os.remove(SNOOZE_FILE)
            dbg("clear_snooze() OK")
    except Exception:
        dbg_exc("clear_snooze")
# ============================================================
# VERSION DETECTION
# ============================================================
def get_installed_version():
    for path in [VERSION_PY, VERSION_PY2]:
        if os.path.exists(path):
            try:
                txt = open(path, "r", encoding="utf-8", errors="ignore").read()
                m = re.search(r'IPTV_VERSION\s*=\s*["\']([^"\']+)["\']', txt)
                if m:
                    ver = m.group(1).strip()
                    dbg(f"installed version = {ver}")
                    return ver
            except Exception:
                dbg_exc(f"reading {path}")
    dbg("installed version = Unknown")
    return "Unknown"
# ============================================================
# ★★★ RELEASE NOTES CLEANER ★★★
# ============================================================
def clean_release_notes(body, max_lines=15):
    """
    تنظيف ملاحظات الإصدار من markdown وتحويلها إلى نص بسيط
    """
    if not body:
        return ""
    lines = body.splitlines()
    cleaned = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # Ignore lines containing only commit URLs
        if line.startswith("**Full Changelog**"):
            continue
        if line.startswith("<!--"):
            continue
        if line.startswith("**Full Changelog**"):
            continue
        # Remove Markdown headers
        line = re.sub(r'^#+\s*', '', line)
        # Remove Markdown bold/italic formatting
        line = re.sub(r'\*\*(.+?)\*\*', r'\1', line)
        line = re.sub(r'\*(.+?)\*', r'\1', line)
        line = re.sub(r'__(.+?)__', r'\1', line)
        line = re.sub(r'_(.+?)_', r'\1', line)
        # Remove backticks
        line = re.sub(r'`(.+?)`', r'\1', line)
        # Convert Markdown links [text](url) to text
        line = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', line)
        # Remove images ![alt](url)
        line = re.sub(r'!\[([^\]]*)\]\([^\)]+\)', r'\1', line)
        # Replace - with •
        line = re.sub(r'^[-*+]\s+', '• ', line)
        cleaned.append(line)
    # Maximum number of lines
    if len(cleaned) > max_lines:
        cleaned = cleaned[:max_lines]
        cleaned.append("...")
    return "\n".join(cleaned)
# ============================================================
# REMOTE RELEASE (with body)
# ============================================================
def get_remote_release():
    try:
        req = urllib.request.Request(REPO_API, headers={"User-Agent": "Enigma2"})
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read().decode())
            tag    = data.get("tag_name")
            name   = data.get("name", "")
            date   = data.get("published_at", "")[:10]
            body   = data.get("body", "") or ""
            dbg(f"remote = {tag} | {name} | {date} | body_len={len(body)}")
            return tag, name, date, body
    except Exception:
        dbg_exc("get_remote_release")
        return None, None, None, ""
def get_local_tag():
    return read_file(VERSION_FILE)
def save_local(tag):
    write_file(VERSION_FILE, tag)
def version_to_tuple(v):
    try:
        v = v.lower().replace('v', '').strip()
        parts = re.split(r'[.\-]', v)
        return tuple(int(p) for p in parts if p.isdigit())
    except Exception:
        return (0,)
# ============================================================
# BACKUP
# ============================================================
def make_backup():
    dbg("make_backup() called")
    try:
        # ★ Set the backup location
        loc = config.plugins.e2iupdater.backup_location.value
        if loc == "auto":
            if os.path.isdir("/media/hdd"):
                backup_dir = "/media/hdd"
            elif os.path.isdir("/media/usb"):
                backup_dir = "/media/usb"
            else:
                backup_dir = "/tmp"
        else:
            backup_dir = loc if os.path.isdir(loc) else "/tmp"
        dbg(f"backup_dir = {backup_dir}")
        installed_ver = get_installed_version()
        ver_clean = re.sub(r'[^\w\.\-]', '', installed_ver)
        if not ver_clean or ver_clean == "Unknown":
            ver_clean = get_local_tag().lstrip('v')
        if not ver_clean or ver_clean == "Unknown":
            ver_clean = "unknown"
        ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        backup_name = f"IPTVPlayer-v.{ver_clean}-{ts}.tar.gz"
        backup_path = os.path.join(backup_dir, backup_name)
        with tarfile.open(backup_path, "w:gz") as tar:
            tar.add(PLUGIN_PATH, arcname="IPTVPlayer")
        dbg(f"backup = {backup_path}")
        return backup_path
    except Exception:
        dbg_exc("make_backup")
        return None
# ============================================================
# SHELL COMMAND RUNNER
# ============================================================
def run_shell(cmd, timeout=120):
    dbg(f"RUN: {cmd}")
    try:
        result = subprocess.run(
            cmd, shell=True, timeout=timeout,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            executable="/bin/sh"
        )
        out = result.stdout.decode("utf-8", errors="ignore")
        dbg(f"  rc={result.returncode}")
        if out:
            for ln in out.splitlines()[:20]:
                dbg(f"  | {ln}")
        return result.returncode == 0, out
    except subprocess.TimeoutExpired:
        dbg(f"  !!! TIMEOUT after {timeout}s")
        return False, "timeout"
    except Exception as e:
        dbg_exc("run_shell")
        return False, str(e)
# ============================================================
# REMOVE XXX HOSTS
# ============================================================
def remove_xxx_hosts():
    """حذف جميع ملفات هوست XXX من مجلد hosts"""
    dbg("remove_xxx_hosts() called")
    hosts_dir = os.path.join(PLUGIN_PATH, "hosts")
    if not os.path.isdir(hosts_dir):
        dbg(f"hosts dir not found: {hosts_dir}")
        return 0
    removed = 0
    try:
        for f in os.listdir(hosts_dir):
            # Search for hostxxx.py or hostxxx.pyo files
            if re.match(r'^hostxxx.*\.(py|pyo|pyc)$', f, re.IGNORECASE):
                path = os.path.join(hosts_dir, f)
                try:
                    os.remove(path)
                    dbg(f"removed: {f}")
                    removed += 1
                except Exception as e:
                    dbg(f"failed to remove {f}: {e}")
    except Exception:
        dbg_exc("remove_xxx_hosts")
    return removed
# ============================================================
# MIGRATE CUSTOM FILES (HOSTS + PLAYERSELECTOR + LOGOS)
# ============================================================
MIGRATE_PATHS = [
    "hosts",                        # Hosts directory
    "icons/PlayerSelector",         # PlayerSelector files
    "icons/logos",                  # Logo files
]
def _should_migrate_file(rel_path, fname):
    """
    تحديد ما إذا كان الملف يجب نقله أم لا
    القواعد:
    - hosts/      → فقط host*.py  (بدون .pyc، .pyo، __init__.py، ملفات نصية)
    - icons/...   → فقط ملفات الصور (.png، .jpg، .jpeg)
    """
    # ============ hosts files ============
    if rel_path == "hosts":
        # Ignore everything except .py files
        if not fname.endswith(".py"):
            return False
        # Ignore files starting with __
        if fname.startswith("__"):
            return False
        # Accept only host*.py files
        if fname.startswith("host") and fname.endswith(".py"):
            return True
        return False
    # ============ Icon files ============
    if rel_path.startswith("icons/"):
        # Accept image files only
        allowed_ext = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".svg")
        if fname.lower().endswith(allowed_ext):
            return True
        return False
    # By default, accept everything
    return True
def migrate_custom_files(tmp_base):
    """
    نقل الملفات الخاصة من /tmp إلى الإصدار الجديد
    - tmp_base: المجلد المؤقت الذي يحتوي على النسخة القديمة
    - لا ينقل ملفاً إذا كان موجوداً بنفس الاسم في الجديد
    - يُرجع: (count_migrated, count_skipped, count_failed)
    """
    dbg(f"migrate_custom_files(tmp_base={tmp_base})")
    migrated = 0
    skipped  = 0
    failed   = 0
    migrated_files = []   
    for rel_path in MIGRATE_PATHS:
        src_dir = os.path.join(tmp_base, rel_path)
        dst_dir = os.path.join(PLUGIN_PATH, rel_path)
        if not os.path.isdir(src_dir):
            dbg(f"  src dir not found: {src_dir}")
            continue
        # Create the destination directory if it does not exist
        try:
            os.makedirs(dst_dir, exist_ok=True)
        except Exception:
            dbg_exc(f"makedirs {dst_dir}")
            failed += 1
            continue
        # Copy files
        try:
            for root, dirs, files in os.walk(src_dir):
                for fname in files:
                    src_file = os.path.join(root, fname)
                    # Relative path within the directory
                    rel = os.path.relpath(src_file, src_dir)
                    # ★ Should this file be migrated?
                    if not _should_migrate_file(rel_path, fname):
                        dbg(f"  ⊘ filtered: {rel_path}/{rel}")
                        continue
                    dst_file = os.path.join(dst_dir, rel)
                    # If a file with the same name already exists → skip it
                    if os.path.exists(dst_file):
                        dbg(f"  ⊘ skipped (exists): {rel_path}/{rel}")
                        skipped += 1
                        continue
                    # Copy the file
                    try:
                        # Create the subdirectory if necessary
                        os.makedirs(os.path.dirname(dst_file), exist_ok=True)
                        shutil.copy2(src_file, dst_file)
                        dbg(f"  ✓ migrated: {rel_path}/{rel}")
                        migrated += 1
                        # ★ Add the relative path to the list
                        migrated_files.append(f"{rel_path}/{rel}")
                    except Exception as e:
                        dbg(f"  ✗ failed: {rel_path}/{rel} — {e}")
                        failed += 1
        except Exception:
            dbg_exc(f"walk {src_dir}")
            failed += 1
    dbg(f"migrate_custom_files: migrated={migrated}, skipped={skipped}, failed={failed}")
    return migrated, skipped, failed, migrated_files
def backup_custom_files_for_migration():
    """
    نسخ الملفات الخاصة من الإصدار الحالي إلى /tmp قبل الحذف
    - يُرجع: مسار المجلد المؤقت أو None
    """
    dbg("backup_custom_files_for_migration() called")
    tmp_base = "/tmp/e2iupdater_old_custom"
    # Clean up the old files
    try:
        if os.path.exists(tmp_base):
            shutil.rmtree(tmp_base, ignore_errors=True)
    except Exception:
        pass
    copied = 0
    for rel_path in MIGRATE_PATHS:
        src_dir = os.path.join(PLUGIN_PATH, rel_path)
        dst_dir = os.path.join(tmp_base, rel_path)
        if not os.path.isdir(src_dir):
            dbg(f"  src not found: {src_dir}")
            continue
        try:
            # Copy the entire directory
            shutil.copytree(src_dir, dst_dir)
            # Count the files
            for root, dirs, files in os.walk(dst_dir):
                copied += len(files)
            dbg(f"  ✓ copied: {rel_path}")
        except Exception:
            dbg_exc(f"copytree {src_dir}")
    if copied == 0:
        dbg("  no custom files to backup")
        return None
    dbg(f"  total files backed up for migration: {copied}")
    return tmp_base
# ============================================================
# DO UPDATE / INSTALL
# ============================================================
def do_update(session, tag, is_new_install=False, force_backup=True, migrate=False):
    """
    تحديث أو تثبيت E2iPlayer
    force_backup : True = اعمل باكب, False = لا تعمل باكب
    migrate      : True = انقل الهوستات والملفات الخاصة من القديم إلى الجديد
    """
    dbg(f"do_update({tag}, new={is_new_install}, backup={force_backup}, migrate={migrate}) START")
    # 1. Backup + migrate custom files
    backup_path = None
    migrate_tmp = None
    if (not is_new_install and 
        os.path.exists(PLUGIN_PATH) and 
        config.plugins.e2iupdater.backup_enabled.value and
        force_backup):
        backup_path = make_backup()
        dbg(f"backup created: {backup_path}")
    else:
        dbg("backup skipped")
    # ★ If the user chooses to migrate files, copy them to /tmp before deletion
    if migrate and not is_new_install and os.path.exists(PLUGIN_PATH):
        dbg("★ migrating custom files → copying to /tmp first")
        migrate_tmp = backup_custom_files_for_migration()
        if migrate_tmp:
            dbg(f"  custom files backed up to: {migrate_tmp}")
        else:
            dbg("  no custom files found")
    # 2. Remove the old version
    if os.path.exists(PLUGIN_PATH):
        dbg("step 1: remove old IPTVPlayer")
        run_shell(f"rm -rf {PLUGIN_PATH}")
    # 3. Download + extract + copy + clean up
    dbg("step 2: download + extract + install + cleanup")
    cmd = (
        f'wget --no-check-certificate "{REPO_ZIP}" -O /tmp/e2iplayer-python3.zip && '
        f'busybox unzip -o /tmp/e2iplayer-python3.zip -d /tmp/ && '
        f'cp -rf /tmp/e2iplayer-python3/IPTVPlayer /usr/lib/enigma2/python/Plugins/Extensions && '
        f'rm -f /tmp/e2iplayer-python3.zip && '
        f'rm -rf /tmp/e2iplayer-python3 && '
        f'rm -rf /tmp/e2iplayer-master && '
        f'rm -rf /tmp/e2iplayer-python3-* && '
        f'echo "=== cleanup done ===" && '
        f'ls -la /tmp/ | grep e2iplayer || echo "no e2iplayer files left in /tmp"'
    )
    ok, out = run_shell(cmd, timeout=180)
    if not ok:
        dbg("!!! install failed")
        session.open(MessageBox,
                     f"{T('update_failed')}\n\nOutput:\n{out[:500]}",
                     type=MessageBox.TYPE_ERROR, timeout=10)
        return
    # 4. Verify the installation
    dbg("step 3: verify installation")
    if not os.path.exists(PLUGIN_PATH):
        dbg("!!! PLUGIN_PATH missing after install")
        session.open(MessageBox,
                     "Install failed: PLUGIN_PATH not found!",
                     type=MessageBox.TYPE_ERROR, timeout=10)
        return
    new_ver = get_installed_version()
    dbg(f"  new installed version = {new_ver}")
    # ★ 5. Migrate custom files from /tmp to the new version
    migrate_info = ""
    if migrate and migrate_tmp and os.path.exists(migrate_tmp):
        dbg("★ migrating custom files → copying to new IPTVPlayer")
        migrated, skipped, failed, migrated_files = migrate_custom_files(migrate_tmp)
        # Clean up /tmp
        try:
            shutil.rmtree(migrate_tmp, ignore_errors=True)
            dbg(f"  cleanup: removed {migrate_tmp}")
        except Exception:
            dbg_exc("cleanup migrate_tmp")
        # ★ Build the file list (maximum of 10 files)
        max_files_to_show = 10
        if migrated_files:
            if len(migrated_files) <= max_files_to_show:
                files_list = "\n".join(f"    ✓ {f}" for f in migrated_files)
            else:
                # Show the first 10 files + the number of remaining files
                files_list = "\n".join(f"    ✓ {f}" for f in migrated_files[:max_files_to_show])
                files_list += f"\n    ... و {len(migrated_files) - max_files_to_show} ملف آخر"
        else:
            files_list = ""
        # Add information to the message
        if config.plugins.e2iupdater.language.value == "ar":
            migrate_info = f"\n📦 نقل الملفات:\n"
            migrate_info += f"• تم النقل: {migrated}\n"
            if files_list:
                migrate_info += f"{files_list}\n"
            if skipped > 0:
                migrate_info += f"• تم تجاهل (موجود): {skipped}\n"
            if failed > 0:
                migrate_info += f"• فشل: {failed}\n"
        else:
            migrate_info = f"\n📦 Files migrated:\n"
            migrate_info += f"• Migrated: {migrated}\n"
            if files_list:
                migrate_info += f"{files_list}\n"
            if skipped > 0:
                migrate_info += f"• Skipped (exists): {skipped}\n"
            if failed > 0:
                migrate_info += f"• Failed: {failed}\n"
    # 6. Save
    save_local(tag)
    clear_snooze()
    # 7. Success message
    action = "Installed" if is_new_install else "Updated"
    if config.plugins.e2iupdater.language.value == "ar":
        action = "تثبيت" if is_new_install else "تحديث"
    msg = f"E2iPlayer {action} OK!\n"
    msg += f"Version: {tag}\n"
    if new_ver and new_ver != "Unknown":
        msg += f"New installed: {new_ver}\n"
    if backup_path:
        msg += f"\nBackup: {backup_path}\n"
    else:
        if config.plugins.e2iupdater.language.value == "ar":
            msg += "\n(بدون نسخة احتياطية)\n"
        else:
            msg += "\n(No backup)\n"
    if migrate_info:
        msg += migrate_info
    msg += "\n" + T("restart_now")
    session.open(MessageBox, msg, type=MessageBox.TYPE_INFO, timeout=10)
    time.sleep(4)
    quitMainloop(3)
# ============================================================
# ★★★ UPDATE CHOICE SCREEN (with Release Notes) ★★★
# ============================================================
class UpdateChoiceScreen(Screen):
    """شاشة اختيار التحديث - مع عرض الجديد في الإصدار"""
    def __init__(self, session, installed, remote_tag, remote_name, remote_date, release_notes=""):
        Screen.__init__(self, session)
        global g_pending_callback
        self._choice_cb = g_pending_callback
        dbg(f"UpdateChoiceScreen.__init__ — _choice_cb={self._choice_cb}")
        self.remote_tag = remote_tag
        self["title"] = Label(T("update_title"))
        # ★ Build the information text
        info_text = (
            f"{T('installed')}: {installed}\n"
            f"{T('new_version')}: {remote_tag}\n"
            f"{T('release')}: {remote_name}\n"
            f"{T('date')}: {remote_date}"
        )
        # ★ Add the new features in this release
        if release_notes:
            info_text += f"\n\n{T('whats_new')}:\n{release_notes}"
        else:
            info_text += f"\n\n{T('no_release_notes')}"
        self["info"] = Label(info_text)
        self["btn1"] = Button(T("btn_update"))
        self["btn2"] = Button(T("btn_remind"))
        self["btn3"] = Button(T("btn_skip"))
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "WizardActions"],
            {
                "green":   self.on_update,
                "yellow":  self.on_remind,
                "red":     self.on_skip,
                "cancel":  self.on_cancel,
                "ok":      self.on_update,
                "left":    self.on_update,
                "right":   self.on_skip,
                "up":      self.on_update,
                "down":    self.on_skip,
                "menu":    self.on_cancel,
            }, -1
        )
        dbg("UpdateChoiceScreen.__init__ OK")
    def _call(self, ans):
        cb = getattr(self, "_choice_cb", None)
        dbg(f"★ _call({ans}) — _choice_cb={cb}")
        try:
            if cb is None:
                dbg("!!! _choice_cb is None !!!")
                return
            cb(ans)
            dbg(f"★ _choice_cb({ans}) returned OK")
        except Exception:
            dbg_exc(f"_call({ans})")
    def on_update(self):
        dbg("★ on_update pressed (GREEN)")
        self._call(0)
        self.close()
    def on_remind(self):
        dbg("★ on_remind pressed (YELLOW)")
        self._call(1)
        self.close()
    def on_skip(self):
        dbg("★ on_skip pressed (RED)")
        self._call(2)
        self.close()
    def on_cancel(self):
        dbg("★ on_cancel pressed")
        self._call(None)
        self.close()
# ============================================================
# INSTALL PROMPT
# ============================================================
def prompt_install(session, remote_tag, remote_name, remote_date):
    """عرض رسالة تثبيت E2iPlayer"""
    dbg(f"prompt_install({remote_tag})")
    def cb_confirm(ans):
        dbg(f"  cb_confirm_install ans={ans}")
        if ans:
            dbg("  → starting do_update thread (new install)")
            threading.Thread(
                target=do_update,
                args=(session, remote_tag, True),
                daemon=True
            ).start()
        else:
            dbg("  → user declined install")
    session.openWithCallback(
        cb_confirm, MessageBox,
        T("install_confirm").format(
            tag=remote_tag, name=remote_name, date=remote_date
        ),
        type=MessageBox.TYPE_YESNO
    )
# ============================================================
# CHECK LOGIC
# ============================================================
def check_in_thread(session, silent=False):
    global g_last_check, g_pending_callback
    if not config.plugins.e2iupdater.enabled.value:
        dbg("plugin disabled, skip")
        return
    if silent and (time.time() - g_last_check < 10):
        dbg("cooldown, skip")
        return
    g_last_check = time.time()
    # ★ If IPTVPlayer is not installed
    if not os.path.exists(PLUGIN_PATH):
        dbg("★ PLUGIN_PATH missing — offering install")
        remote_tag, remote_name, remote_date, _ = get_remote_release()
        if not remote_tag:
            dbg("  GitHub connection failed")
            if not silent:
                session.open(MessageBox, T("install_no_net"),
                             type=MessageBox.TYPE_ERROR, timeout=5)
            return
        dbg(f"  remote={remote_tag} name={remote_name} date={remote_date}")
        play_notification_sound()
        def cb_install(ans):
            dbg(f"★★★★ cb_install ans={ans} ★★★★")
            if ans is None:
                return
            if ans:
                prompt_install(session, remote_tag, remote_name, remote_date)
        session.openWithCallback(
            cb_install, MessageBox,
            T("install_msg").format(
                tag=remote_tag, name=remote_name, date=remote_date
            ),
            type=MessageBox.TYPE_YESNO
        )
        dbg("check_in_thread EXIT (install prompt)")
        return
    installed_ver = get_installed_version()
    local_tag     = get_local_tag()
    remote_tag, remote_name, remote_date, remote_body = get_remote_release()
    # ★ Clean up the release notes
    release_notes = ""
    if config.plugins.e2iupdater.show_release_notes.value:
        release_notes = clean_release_notes(remote_body)
    dbg(f"installed={installed_ver} local={local_tag} remote={remote_tag} notes_len={len(release_notes)}")
    if not remote_tag:
        dbg("remote_tag None")
        return
    if is_version_skipped(remote_tag):
        dbg(f"version {remote_tag} skipped by user")
        return
    if is_snoozed():
        dbg("snoozed, skip")
        return
    installed_tuple = version_to_tuple(installed_ver)
    remote_tuple    = version_to_tuple(remote_tag)
    need_update = False
    if local_tag == "":
        save_local(remote_tag)
        if installed_ver != "Unknown" and installed_tuple < remote_tuple:
            need_update = True
    else:
        if local_tag != remote_tag:
            need_update = True
        elif installed_ver != "Unknown" and installed_tuple < remote_tuple:
            need_update = True
    dbg(f"need_update={need_update}")
    if need_update:
        play_notification_sound()
        def cb_choice(ans):
            dbg(f"★★★★ cb_choice ans={ans} ★★★★")
            if ans is None:
                dbg("  user cancelled")
                return
            if ans == 0:   # Update Now
                dbg("  → UPDATE branch")
                clear_snooze()
                # ★★★ CRITICAL CHECK ★★★
                backup_enabled = config.plugins.e2iupdater.backup_enabled.value
                dbg(f"  backup_enabled = {backup_enabled}")
                if not backup_enabled:
                    # backup=No → Direct update
                    dbg("  → backup disabled → DIRECT update")
                    threading.Thread(
                        target=do_update,
                        args=(session, remote_tag, False, False, False),
                        daemon=True
                    ).start()
                    return
                # ★ backup=Yes → 3 options
                dbg("  → backup enabled → showing 3 choices")
                def cb_choice3(choice):
                    if choice is None or choice[1] == "cancel":
                        dbg("  user cancelled 3-choice")
                        return
                    action = choice[1]
                    dbg(f"  3-choice action: {action}")
                    if action == "full":
                        # Full backup without migration
                        threading.Thread(
                            target=do_update,
                            args=(session, remote_tag, False, True, False),
                            daemon=True
                        ).start()
                    elif action == "migrate":
                        # Backup + migrate hosts
                        threading.Thread(
                            target=do_update,
                            args=(session, remote_tag, False, True, True),
                            daemon=True
                        ).start()
                    elif action == "none":
                        # Direct update
                        threading.Thread(
                            target=do_update,
                            args=(session, remote_tag, False, False, False),
                            daemon=True
                        ).start()
                installed_ver_clean = re.sub(r'[^\w\.\-]', '', installed_ver)
                if not installed_ver_clean or installed_ver_clean == "Unknown":
                    installed_ver_clean = "unknown"
                ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
                backup_name_preview = f"IPTVPlayer-v.{installed_ver_clean}-{ts}.tar.gz"
                # ★ Three-option menu
                choices = [
                    (T("backup_choice_full"),    "full"),
                    (T("backup_choice_migrate"), "migrate"),
                    (T("backup_choice_none"),    "none"),
                    (T("cancel"),                "cancel"),
                ]
                session.openWithCallback(
                    cb_choice3, ChoiceBox,
                    title=T("backup_choice_title"),
                    list=choices
                )
            elif ans == 1:  # Remind Later
                dbg("  → REMIND branch")
                hours = int(config.plugins.e2iupdater.snooze_hours.value)
                set_snooze(hours)
                session.open(MessageBox,
                             T("snoozed").format(hours=hours),
                             type=MessageBox.TYPE_INFO, timeout=4)
            elif ans == 2:  # Skip This Version
                dbg("  → SKIP branch")
                add_skipped_version(remote_tag)
                session.open(MessageBox,
                             T("skipped").format(tag=remote_tag),
                             type=MessageBox.TYPE_INFO, timeout=4)
        g_pending_callback = cb_choice
        dbg(f"set g_pending_callback = {cb_choice}")
        dbg(f"opening UpdateChoiceScreen (notes_len={len(release_notes)})")
        session.openWithCallback(
            lambda *a, **kw: None,
            UpdateChoiceScreen,
            installed_ver,
            remote_tag,
            remote_name,
            remote_date,
            release_notes
        )
    else:
        if not silent and config.plugins.e2iupdater.show_ok_message.value:
            session.open(MessageBox,
                         T("latest_version").format(
                             installed=installed_ver, remote=remote_tag),
                         type=MessageBox.TYPE_INFO, timeout=4)
    dbg("check_in_thread EXIT")
# ============================================================
# BACKUP MANAGER HELPERS
# ============================================================
def get_backup_dirs():
    """إرجاع قائمة المسارات المحتملة للباكبات"""
    loc = config.plugins.e2iupdater.backup_location.value
    dirs = []
    if loc == "auto":
        for d in ["/media/hdd", "/media/usb", "/media/mmcblk0p1", "/tmp"]:
            if os.path.isdir(d):
                dirs.append(d)
    else:
        if os.path.isdir(loc):
            dirs.append(loc)
    return dirs
def find_all_backups():
    """البحث عن جميع الباكبات وإرجاع قائمة (path, name, size, mtime)"""
    backups = []
    for d in get_backup_dirs():
        try:
            for f in os.listdir(d):
                if f.startswith("IPTVPlayer-v.") and f.endswith(".tar.gz"):
                    path = os.path.join(d, f)
                    try:
                        st = os.stat(path)
                        backups.append({
                            "path": path,
                            "name": f,
                            "size_kb": st.st_size // 1024,
                            "mtime": st.st_mtime,
                            "dir": d,
                        })
                    except Exception:
                        pass
        except Exception:
            pass
    # Sort by date (newest first)
    backups.sort(key=lambda x: x["mtime"], reverse=True)
    return backups
def format_backup_list(backups):
    """تنسيق قائمة الباكبات للنص"""
    lines = []
    for i, b in enumerate(backups, 1):
        dt = datetime.datetime.fromtimestamp(b["mtime"]).strftime("%Y-%m-%d %H:%M")
        size_mb = b["size_kb"] / 1024
        lines.append(f"{i}. {b['name']}\n   {dt}  ({size_mb:.1f} MB)")
    return "\n\n".join(lines)
def manual_backup(session):
    """إنشاء نسخة احتياطية يدوياً"""
    dbg("manual_backup() called")
    if not os.path.exists(PLUGIN_PATH):
        session.open(MessageBox,
                     "IPTVPlayer غير مثبت!",
                     type=MessageBox.TYPE_ERROR, timeout=5)
        return
    def cb_confirm(ans):
        if not ans:
            return
        def _do():
            path = make_backup()
            if path:
                session.open(MessageBox,
                             T("backup_now_ok").format(path=path),
                             type=MessageBox.TYPE_INFO, timeout=8)
            else:
                session.open(MessageBox,
                             T("backup_now_fail"),
                             type=MessageBox.TYPE_ERROR, timeout=8)
        threading.Thread(target=_do, daemon=True).start()
    session.openWithCallback(
        cb_confirm, MessageBox,
        T("backup_now_confirm"),
        type=MessageBox.TYPE_YESNO
    )
def show_backups(session):
    """عرض قائمة الباكبات"""
    dbg("show_backups() called")
    backups = find_all_backups()
    if not backups:
        session.open(MessageBox,
                     T("backup_none"),
                     type=MessageBox.TYPE_INFO, timeout=5)
        return
    text = T("backup_list_text").format(list=format_backup_list(backups))
    session.open(MessageBox, text,
                 type=MessageBox.TYPE_INFO, timeout=20)
def cleanup_backups(session):
    """حذف النسخ القديمة"""
    dbg("cleanup_backups() called")
    choices = [
        (T("days_7"),   "7"),
        (T("days_30"),  "30"),
        (T("days_90"),  "90"),
        (T("days_180"), "180"),
        (T("days_365"), "365"),
        (T("cancel"),   "cancel"),
    ]
    def cb_choice(choice):
        if choice is None or choice[1] == "cancel":
            return
        days = int(choice[1])
        def cb_confirm(ans):
            if not ans:
                return
            backups = find_all_backups()
            if not backups:
                session.open(MessageBox,
                             T("backup_cleanup_none"),
                             type=MessageBox.TYPE_INFO, timeout=5)
                return
            cutoff = time.time() - (days * 24 * 3600)
            removed = 0
            for b in backups:
                if b["mtime"] < cutoff:
                    try:
                        os.remove(b["path"])
                        removed += 1
                        dbg(f"removed: {b['name']}")
                    except Exception:
                        pass
            if removed > 0:
                session.open(MessageBox,
                             T("backup_cleanup_ok").format(count=removed),
                             type=MessageBox.TYPE_INFO, timeout=5)
            else:
                session.open(MessageBox,
                             T("backup_cleanup_none"),
                             type=MessageBox.TYPE_INFO, timeout=5)
        session.openWithCallback(
            cb_confirm, MessageBox,
            T("backup_cleanup_confirm").format(days=days),
            type=MessageBox.TYPE_YESNO
        )
    session.openWithCallback(
        cb_choice, ChoiceBox,
        title=T("backup_cleanup_days"),
        list=choices
    )
def manage_single_backup(session, backup):
    """إدارة نسخة احتياطية واحدة (استعادة / حذف)"""
    dbg(f"manage_single_backup: {backup['name']}")
    choices = [
        (T("backup_restore_this"), "restore"),
        (T("backup_delete_this"),  "delete"),
        (T("cancel"),              "cancel"),
    ]
    def cb(choice):
        if choice is None or choice[1] == "cancel":
            return
        action = choice[1]
        dbg(f"manage_single_backup action: {action}")
        # ============================================
        # Restore
        # ============================================
        if action == "restore":
            def cb_confirm(ans):
                if not ans:
                    return
                def _restore():
                    dbg(f"restoring from {backup['path']}")
                    try:
                        # Remove the current version
                        if os.path.exists(PLUGIN_PATH):
                            shutil.rmtree(PLUGIN_PATH, ignore_errors=True)
                        # Extract the backup
                        with tarfile.open(backup["path"], "r:gz") as tar:
                            tar.extractall("/usr/lib/enigma2/python/Plugins/Extensions/")
                        if not os.path.exists(PLUGIN_PATH):
                            session.open(MessageBox,
                                         T("backup_restore_fail"),
                                         type=MessageBox.TYPE_ERROR, timeout=8)
                            return
                        session.open(MessageBox,
                                     T("backup_restore_ok"),
                                     type=MessageBox.TYPE_INFO, timeout=8)
                        time.sleep(4)
                        quitMainloop(3)
                    except Exception as e:
                        dbg_exc("restore_backup")
                        session.open(MessageBox,
                                     f"{T('backup_restore_fail')}\n\n{e}",
                                     type=MessageBox.TYPE_ERROR, timeout=8)
                threading.Thread(target=_restore, daemon=True).start()
            session.openWithCallback(
                cb_confirm, MessageBox,
                T("backup_restore_confirm").format(name=backup["name"]),
                type=MessageBox.TYPE_YESNO
            )
        # ============================================
        # Delete
        # ============================================
        elif action == "delete":
            def cb_confirm(ans):
                if not ans:
                    return
                try:
                    os.remove(backup["path"])
                    dbg(f"deleted: {backup['path']}")
                    session.open(MessageBox,
                                 T("backup_delete_ok"),
                                 type=MessageBox.TYPE_INFO, timeout=4)
                except Exception as e:
                    dbg_exc("delete_backup")
                    session.open(MessageBox,
                                 f"{T('backup_delete_fail')}\n\n{e}",
                                 type=MessageBox.TYPE_ERROR, timeout=8)
            session.openWithCallback(
                cb_confirm, MessageBox,
                T("backup_delete_confirm").format(name=backup["name"]),
                type=MessageBox.TYPE_YESNO
            )
    session.openWithCallback(
        cb, ChoiceBox,
        title=T("backup_manage"),
        list=choices
    )
def restore_backup(session):
    """عرض قائمة الباكبات — كل باكب له قائمة فرعية (استعادة / حذف)"""
    dbg("restore_backup() called")
    backups = find_all_backups()
    if not backups:
        session.open(MessageBox,
                     T("backup_none"),
                     type=MessageBox.TYPE_INFO, timeout=5)
        return
    # ★ Backup list
    choices = []
    for i, b in enumerate(backups, 1):
        dt = datetime.datetime.fromtimestamp(b["mtime"]).strftime("%Y-%m-%d %H:%M")
        size_mb = b["size_kb"] / 1024
        label = f"{i}. {b['name']}  ({dt}, {size_mb:.1f} MB)"
        choices.append((label, b))   # ★ Pass the entire dictionary
    choices.append((T("cancel"), None))
    def cb(choice):
        if choice is None or choice[1] is None:
            return
        backup = choice[1]
        # ★ Open a submenu for the selected backup
        manage_single_backup(session, backup)
    session.openWithCallback(
        cb, ChoiceBox,
        title=T("backup_title"),
        list=choices
    )
def backup_manager(session):
    """القائمة الفرعية لإدارة الباكبات"""
    dbg("backup_manager() called")
    choices = [
        (T("backup_do_now"),  "do_now"),
        (T("backup_list"),    "list"),
        (T("backup_cleanup"), "cleanup"),
        (T("backup_restore"), "restore"),
        (T("cancel"),         "cancel"),
    ]
    def cb(choice):
        if choice is None or choice[1] == "cancel":
            return
        action = choice[1]
        dbg(f"backup manager choice: {action}")
        if action == "do_now":
            manual_backup(session)
        elif action == "list":
            show_backups(session)
        elif action == "cleanup":
            cleanup_backups(session)
        elif action == "restore":
            restore_backup(session)
    session.openWithCallback(
        cb, ChoiceBox,
        title=T("backup_title"),
        list=choices
    )
# ============================================================
# MAIN MENU
# ============================================================
def main_menu(session, **kwargs):
    dbg("main_menu() called")
    choices = [
        (T("menu_check"),      "check"),
        (T("menu_settings"),   "settings"),
        (T("menu_status"),          "status"),
        (T("menu_backup_manager"),  "backup_manager"),
        (T("menu_skip_list"),  "skip_list"),
        (T("menu_clear_skip"), "clear_skip"),
        (T("menu_clear_snooze"), "clear_snooze"),
        (T("menu_remove_xxx"),   "remove_xxx"),
        (T("menu_install_torr"), "install_torr"),
        (T("menu_about"),      "about"),
        (T("cancel"),          "cancel"),
    ]
    def cb(choice):
        if choice is None:
            return
        action = choice[1]
        dbg(f"menu choice: {action}")
        if action == "check":
            threading.Thread(
                target=check_in_thread, args=(session, False), daemon=True
            ).start()
        elif action == "settings":
            session.open(E2iUpdaterConfigScreen)
        elif action == "backup_manager":
            backup_manager(session)
        elif action == "status":
            if not os.path.exists(PLUGIN_PATH):
                installed = "غير مثبت"
            else:
                installed = get_installed_version()
            local     = get_local_tag()
            skipped   = ", ".join(get_skipped_versions()) or "—"
            snoozed   = "—"
            if is_snoozed():
                until = read_file(SNOOZE_FILE)
                snoozed = f"until {until}"
            periodic  = T("on") if config.plugins.e2iupdater.periodic_enabled.value else T("off")
            sound     = T("on") if config.plugins.e2iupdater.sound_enabled.value else T("off")
            remote_tag, _, _, _ = get_remote_release()
            text = T("status_text").format(
                installed=installed,
                remote=remote_tag or "—",
                local=local or "—",
                skipped=skipped,
                snoozed=snoozed,
                periodic=periodic,
                sound=sound,
            )
            session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=10)
        elif action == "skip_list":
            skipped = get_skipped_versions()
            if not skipped:
                text = T("no_skipped")
            else:
                text = T("skipped_list").format(list="\n".join(sorted(skipped)))
            session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=10)
        elif action == "clear_skip":
            clear_skipped()
            session.open(MessageBox, T("skip_cleared"),
                         type=MessageBox.TYPE_INFO, timeout=4)
        elif action == "clear_snooze":
            info = get_snooze_info()
            if info is None:
                session.open(MessageBox, T("no_snooze"),
                             type=MessageBox.TYPE_INFO, timeout=4)
            else:
                def cb_confirm_snooze(ans):
                    if ans:
                        clear_snooze()
                        session.open(MessageBox, T("snooze_cleared"),
                                     type=MessageBox.TYPE_INFO, timeout=4)
                session.openWithCallback(
                    cb_confirm_snooze, MessageBox,
                    T("snooze_status").format(until=info["until"]) +
                    f"\n\n{T('cancel')} / OK?",
                    type=MessageBox.TYPE_YESNO
                )
        elif action == "remove_xxx":
            def cb_confirm_xxx(ans):
                if ans:
                    count = remove_xxx_hosts()
                    if count > 0:
                        session.open(MessageBox,
                                     T("xxx_removed").format(count=count),
                                     type=MessageBox.TYPE_INFO, timeout=4)
                    else:
                        session.open(MessageBox, T("xxx_not_found"),
                                     type=MessageBox.TYPE_INFO, timeout=4)
            session.openWithCallback(
                cb_confirm_xxx, MessageBox,
                T("xxx_confirm"),
                type=MessageBox.TYPE_YESNO
            )
        elif action == "install_torr":
            install_torrserver(session)
        elif action == "about":
            session.open(MessageBox, T("about_text"),
                         type=MessageBox.TYPE_INFO, timeout=10)
        elif action == "cancel":
            return
    session.openWithCallback(cb, ChoiceBox, title=T("menu_title"), list=choices)
def manual_check(session):
    main_menu(session)
# ============================================================
# INSTALL TORRSERVER
# ============================================================
def install_torrserver(session):
    """تنصيب TorrServer من GitHub الرسمي في مسار دائم"""
    dbg("install_torrserver() called")
    # ========================================================
    # 1. Detect the device architecture
    # ========================================================
    try:
        arch = subprocess.check_output(["uname", "-m"]).decode().strip()
    except Exception:
        arch = "unknown"
    dbg(f"arch = {arch}")
    arch_map = {
        "armv7l":  "arm7",
        "armv6l":  "arm7",
        "aarch64": "arm64",
        "mips":    "mips",
        "mipsel":  "mipsle",
        "x86_64":  "amd64",
    }
    torr_arch = arch_map.get(arch)
    if not torr_arch:
        session.open(MessageBox,
                     T("torr_unsupported_arch").format(arch=arch),
                     type=MessageBox.TYPE_ERROR, timeout=6)
        return
    # ========================================================
    # 2. ★ Determine a permanent installation path (not /tmp)
    # ========================================================
    def get_install_dir():
        """إرجاع مسار تثبيت دائم فقط"""
        loc = config.plugins.e2iupdater.backup_location.value
        # If the user selected a specific path
        if loc == "hdd":
            if os.path.isdir("/media/hdd"):
                return "/media/hdd"
            # Fallback: /usr/bin
            return None  # → Use /usr/bin
        elif loc == "usb":
            if os.path.isdir("/media/usb"):
                return "/media/usb"
            return None  # → Use /usr/bin
        elif loc == "auto":
            # Automatic selection: HDD, then USB, then /usr/bin
            if os.path.isdir("/media/hdd"):
                return "/media/hdd"
            elif os.path.isdir("/media/usb"):
                return "/media/usb"
            return None  # → Use /usr/bin
        return None
    # ★ Get the installation directory
    install_dir = get_install_dir()
    # If no writable path is available → use /usr/bin
    if install_dir:
        target = os.path.join(install_dir, "TorrServer")
        # ★ Get the installation directory
        if not os.access(install_dir, os.W_OK):
            dbg(f"{install_dir} not writable, falling back to /usr/bin")
            install_dir = None
            target = "/usr/bin/TorrServer"
    else:
        # If no writable path is available → use /usr/bin
        install_dir = "/usr/bin"
        target = "/usr/bin/TorrServer"
    dbg(f"install_dir = {install_dir}")
    dbg(f"target = {target}")
    # ========================================================
    # 3. TorrServer Releases API
    # ========================================================
    TORRSERVER_API = "https://api.github.com/repos/YouROK/TorrServer/releases/latest"
    def get_latest_version():
        try:
            req = urllib.request.Request(TORRSERVER_API,
                                         headers={"User-Agent": "Enigma2"})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read().decode())
                tag = data.get("tag_name", "")
                assets = data.get("assets", [])
                # ★ Find the appropriate asset
                # TorrServer-linux-arm7 / TorrServer-linux-arm64 / etc.
                candidates = []
                for asset in assets:
                    name = asset.get("name", "").lower()
                    if "linux" in name and torr_arch in name:
                        candidates.append(asset)
                if not candidates:
                    dbg(f"no asset found for {torr_arch}")
                    return tag, None
                # Select the first match
                chosen = candidates[0]
                dbg(f"chosen asset: {chosen.get('name')}")
                return tag, chosen.get("browser_download_url")
        except Exception:
            dbg_exc("get_latest_version")
            return None, None
    # ========================================================
    # 4. Confirmation message
    # ========================================================
    def cb_confirm(ans):
        if not ans:
            return
        def _install():
            tag, url = get_latest_version()
            if not url:
                session.open(MessageBox,
                             T("torr_download_fail").format(torr_arch=torr_arch),
                             type=MessageBox.TYPE_ERROR, timeout=8)
                return
            dbg(f"downloading TorrServer: {url}")
            dbg(f"target: {target}")
            try:
                # ★ Download
                urllib.request.urlretrieve(url, target)
                # ★ chmod 755
                os.chmod(target, 0o755)
                dbg(f"chmod 755 OK")
                # ★ Verify the file size
                size = os.path.getsize(target)
                dbg(f"file size = {size} bytes")
                if size < 1000:
                    session.open(MessageBox,
                                 T("torr_too_small").format(size=size),
                                 type=MessageBox.TYPE_ERROR, timeout=8)
                    return
                # ★ Success
                session.open(MessageBox,
                             T("torr_ok").format(
                                 tag=tag,
                                 path=target,
                                 size=size // 1024
                             ),
                             type=MessageBox.TYPE_INFO, timeout=12)
            except Exception as e:
                dbg_exc("install_torrserver")
                session.open(MessageBox,
                             T("torr_fail").format(error=str(e)),
                             type=MessageBox.TYPE_ERROR, timeout=8)
        threading.Thread(target=_install, daemon=True).start()
    # ★ Confirmation message text (translated)
    session.openWithCallback(
        cb_confirm, MessageBox,
        T("torr_confirm").format(
            arch=arch,
            torr_arch=torr_arch,
            path=target
        ),
        type=MessageBox.TYPE_YESNO
    )
# ============================================================
# PERIODIC CHECK
# ============================================================
def start_periodic_check():
    global g_periodic_timer
    if not config.plugins.e2iupdater.periodic_enabled.value:
        dbg("periodic check disabled")
        return
    if g_periodic_timer is not None:
        dbg("periodic timer already running")
        return
    try:
        hours = int(config.plugins.e2iupdater.periodic_hours.value)
        interval_ms = hours * 3600 * 1000
        dbg(f"starting periodic check every {hours} hour(s)")
        g_periodic_timer = eTimer()
        g_periodic_timer.callback.append(lambda: threading.Thread(
            target=check_in_thread,
            args=(g_session, True),
            daemon=True
        ).start())
        g_periodic_timer.start(interval_ms, False)
    except Exception:
        dbg_exc("start_periodic_check")
# ============================================================
# CONFIG SCREEN
# ============================================================
class E2iUpdaterConfigScreen(ConfigListScreen, Screen):
    """شاشة الإعدادات"""
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["key_red"]   = Label(T("cancel"))
        self["key_green"] = Label(T("save"))
        self["actions"] = ActionMap(
            ["SetupActions", "ColorActions"],
            {
                "red":    self.keyCancel,
                "green":  self.keySave,
                "cancel": self.keyCancel,
            }, -2
        )
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session)
        self.build_list()
    def build_list(self):
        self.list = [
            getConfigListEntry(T("cfg_language"),        config.plugins.e2iupdater.language),
            getConfigListEntry(T("cfg_enabled"),         config.plugins.e2iupdater.enabled),
            getConfigListEntry(T("cfg_check_start"),     config.plugins.e2iupdater.check_on_start),
            getConfigListEntry(T("cfg_show_ok"),         config.plugins.e2iupdater.show_ok_message),
            getConfigListEntry(T("cfg_backup"),          config.plugins.e2iupdater.backup_enabled),
            getConfigListEntry(T("cfg_backup_loc"),      config.plugins.e2iupdater.backup_location),
            getConfigListEntry(T("cfg_release_notes"),   config.plugins.e2iupdater.show_release_notes),
            getConfigListEntry(T("cfg_sound"),           config.plugins.e2iupdater.sound_enabled),
            getConfigListEntry(T("cfg_snooze"),          config.plugins.e2iupdater.snooze_hours),
            getConfigListEntry(T("cfg_periodic"),        config.plugins.e2iupdater.periodic_enabled),
            getConfigListEntry(T("cfg_periodic_h"),      config.plugins.e2iupdater.periodic_hours),
            getConfigListEntry(T("cfg_debug"),           config.plugins.e2iupdater.debug_enabled),
        ]
        self["config"].list = self.list
        self["config"].l.setList(self.list)
    def keySave(self):
        for x in self["config"].list:
            x[1].save()
        try:
            config.plugins.e2iupdater.save()
        except Exception:
            pass
        global g_periodic_timer
        if g_periodic_timer is not None:
            try:
                g_periodic_timer.stop()
                g_periodic_timer = None
            except Exception:
                pass
        start_periodic_check()
        self.close()
    def keyCancel(self):
        for x in self["config"].list:
            x[1].cancel()
        self.close()
# ============================================================
# PATCH E2iPlayerWidget
# ============================================================
def patch_e2iplayer_widget():
    try:
        from Plugins.Extensions.IPTVPlayer.components.iptvplayerwidget import E2iPlayerWidget
        if getattr(E2iPlayerWidget, "_e2iupdater_patched", False):
            dbg("E2iPlayerWidget already patched")
            return True
        original_init = E2iPlayerWidget.__init__
        E2iPlayerWidget._e2iupdater_original_init = original_init
        def patched_init(self, *args, **kwargs):
            E2iPlayerWidget._e2iupdater_original_init(self, *args, **kwargs)
            if not config.plugins.e2iupdater.check_on_start.value:
                return
            def delayed():
                time.sleep(5)
                try:
                    if g_session:
                        check_in_thread(g_session, silent=True)
                except Exception:
                    dbg_exc("delayed check")
            threading.Thread(target=delayed, daemon=True).start()
        E2iPlayerWidget.__init__ = patched_init
        E2iPlayerWidget._e2iupdater_patched = True
        dbg("E2iPlayerWidget patched OK")
        return True
    except Exception as ex:
        dbg(f"E2iPlayerWidget not available (probably not installed): {ex}")
        return False
# ============================================================
# SESSIONSTART
# ============================================================
def sessionstart(reason, **kwargs):
    global g_session
    if reason != 0:
        return
    session = kwargs.get("session")
    if not session:
        return
    g_session = session
    dbg("sessionstart, g_session set")
    patch_e2iplayer_widget()
    start_periodic_check()
# ============================================================
# PLUGINS DESCRIPTOR
# ============================================================
def Plugins(**kwargs):
    dbg("Plugins() descriptor called")
    return [
        PluginDescriptor(
            name="E2iPlayer Updater",
            description="Check updates / فحص التحديثات",
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart
        ),
        PluginDescriptor(
            name="E2iPlayer Updater",
            description="Check updates / فحص التحديثات",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main_menu
        ),
        PluginDescriptor(
            name="E2iPlayer Updater",
            description="Check updates / فحص التحديثات",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main_menu
        ),
    ]