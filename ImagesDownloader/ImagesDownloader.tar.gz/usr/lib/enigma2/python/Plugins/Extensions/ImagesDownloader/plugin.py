# -*- coding: utf-8 -*-
import os
import sys
import json
import time
import socket
import subprocess
import threading
import re

try:
    from urllib.parse import quote
    from urllib.request import urlopen, Request
    from urllib.error import URLError
except ImportError:
    from urllib import quote
    from urllib2 import urlopen, Request, URLError

try:
    import requests
except ImportError:
    requests = None

from enigma import getDesktop, eListboxPythonMultiContent, gFont, loadPNG, eTimer
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, fileExists
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Components.Sources.Clock import Clock
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import (
    MultiContentEntryText,
    MultiContentEntryPixmapAlphaTest,
)

if sys.version_info[0] == 2:
    text_type = unicode
    binary_type = str
else:
    text_type = str
    binary_type = bytes

try:
    _
except NameError:
    def _(text):
        return text

PLUGIN_VERSION = "2.0"
PLUGIN_DESC = "Images Downloader - Download Enigma2 Images"
PLUGIN_DIR = resolveFilename(SCOPE_PLUGINS, "Extensions/ImagesDownloader")
IMG_DIR = os.path.join(PLUGIN_DIR, "images")
PLUGIN_ICON_PATH = os.path.join(PLUGIN_DIR, "plugin.png")

def get_resolution():
    desktop_size = getDesktop(0).size()
    if desktop_size.width() >= 1920:
        return "FHD"
    else:
        return "HD"

res = get_resolution()

def safe_path(path):
    if path is None:
        return ""
    if sys.version_info[0] == 2:
        if isinstance(path, text_type):
            return path.encode('utf-8', 'ignore')
    return str(path)

PLUGIN_DIR = safe_path(PLUGIN_DIR)
IMG_DIR = safe_path(IMG_DIR)
PLUGIN_ICON_PATH = safe_path(PLUGIN_ICON_PATH)

def get_internet_status():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except Exception:
        return False

def get_ip_address():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "No IP"

def to_gui_text(x):
    if x is None:
        return ""
    try:
        if sys.version_info[0] == 2:
            if isinstance(x, text_type):
                return x.encode('utf-8', 'ignore')
            elif isinstance(x, binary_type):
                return x
            else:
                return str(x)
        else:
            if isinstance(x, binary_type):
                return x.decode('utf-8', 'ignore')
            return str(x)
    except Exception:
        return ""

def json_loads_safe(data):
    try:
        if sys.version_info[0] == 2 and isinstance(data, binary_type):
            try:
                data = data.decode('utf-8', 'ignore')
            except UnicodeDecodeError:
                pass
        return json.loads(data)
    except Exception:
        return {}

def download_url(url, timeout=10):
    try:
        req = Request(url, headers={'User-Agent': 'ImagesDownloader/%s' % PLUGIN_VERSION})
        if sys.version_info[0] == 2:
            response = urlopen(req, timeout=timeout)
            data = response.read()
            if isinstance(data, binary_type):
                return data.decode('utf-8', 'ignore')
            return data
        else:
            with urlopen(req, timeout=timeout) as response:
                return response.read().decode('utf-8', 'ignore')
    except Exception as e:
        print("[ImagesDownloader] download error:", str(e))
        return None

class CheckList(MenuList):
    def __init__(self, lst, enableWrapAround=True):
        MenuList.__init__(self, lst, enableWrapAround, eListboxPythonMultiContent)
        if get_resolution() == "FHD":
            self.l.setItemHeight(56)
            self.l.setFont(0, gFont("Regular", 28))
        else:
            self.l.setItemHeight(40)
            self.l.setFont(0, gFont("Regular", 16))

HD_SKIN_LIST = """
<screen position="center,center" size="1280,720" title="Images Downloader">
    <ePixmap position="0,0" size="1280,720" pixmap="%s/back.png" zPosition="-1" />
    <widget source="title" render="Label" position="50,90" size="700,60"
        font="Regular;50" halign="center" valign="center"
        foregroundColor="#ffffff" backgroundColor="#000000" />
    <widget name="list" position="50,180" size="650,400" scrollbarMode="showOnDemand" backgroundColor="#000000" transparent="0" />
    <widget source="key_red" render="Label"
        position="80,600" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#C11B17" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="80,600" size="250,60" zPosition="3" backgroundColor="#C11B17" transparent="0" />
    <eLabel cornerRadius="18" position="85,605" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_green" render="Label"
        position="340,600" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#347235" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="340,600" size="250,60" zPosition="2" backgroundColor="#347235" transparent="0" />
    <eLabel cornerRadius="18" position="345,605" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_yellow" render="Label"
        position="600,600" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#EAC117" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="600,600" size="250,60" zPosition="2" backgroundColor="#EAC117" transparent="0" />
    <eLabel cornerRadius="18" position="605,605" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="session.VideoPicture" render="Pig" position="750,120" size="480,320" zPosition="1" backgroundColor="#ff000000" />
    <ePixmap position="900,20" zPosition="2" size="200,100" pixmap="%s/logo.png" alphatest="on" />
    <widget source="CurrentTime" render="Label" position="1100,666" size="250,50" font="Regular;32" halign="left" valign="center" foregroundColor="#0049bbff" backgroundColor="#20000000" transparent="1" zPosition="2">
        <convert type="ClockToText">Default</convert>
    </widget>
</screen>
"""

FHD_SKIN_LIST = """
<screen position="center,center" size="1920,1080" title="Images Downloader">
    <ePixmap position="0,0" size="1920,1080" pixmap="%s/back.png" zPosition="-1" />
    <widget source="title" render="Label" position="50,90" size="700,60"
        font="Regular;50" halign="center" valign="center"
        foregroundColor="#ffffff" backgroundColor="#000000" />
    <widget name="list" position="50,180" size="1000,565" scrollbarMode="showOnDemand" backgroundColor="#000000" transparent="0" />
    <widget source="key_red" render="Label"
        position="80,995" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#C11B17" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="80,990" size="250,60" zPosition="3" backgroundColor="#C11B17" transparent="0" />
    <eLabel cornerRadius="18" position="85,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_green" render="Label"
        position="340,995" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#347235" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="340,990" size="250,60" zPosition="2" backgroundColor="#347235" transparent="0" />
    <eLabel cornerRadius="18" position="345,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_yellow" render="Label"
        position="600,995" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#EAC117" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="600,990" size="250,60" zPosition="2" backgroundColor="#EAC117" transparent="0" />
    <eLabel cornerRadius="18" position="605,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="session.VideoPicture" render="Pig" position="1100,180" size="750,550" zPosition="4" backgroundColor="#ff000000" />
    <eLabel cornerRadius="18" position="1095,175" size="760,560" zPosition="2" backgroundColor="#0049bbff" transparent="0" />
    <ePixmap position="1250,40" zPosition="2" size="400,100" pixmap="%s/logo.png" alphatest="on" />
    <widget source="CurrentTime" render="Label" position="1650,986" size="350,60" font="Regular;36" halign="left" valign="center" foregroundColor="#0049bbff" backgroundColor="#20000000" transparent="1" zPosition="2">
        <convert type="ClockToText">Default</convert>
    </widget>
</screen>
"""

class ImagesDownloaderScreen(Screen):
    GROUPS = [
        ["classm", "starsatlx", "genius", "evo", "galaxym6", "axodin", "axodinc", "odinm7"],
        ["geniuse3hd", "evoe3hd", "axase3", "axase3c", "e3hd"],
        ["maram9", "odinm9"],
        ["ventonhdx", "sezam5000hd", "mbtwin", "beyonwizt3", "inihdx"],
        ["sezam1000hd", "xpeedlx1", "xpeedlx2", "mbmini", "atemio5x00", "bwidowx", "inihde"],
        ["atemio6000", "atemio6100", "atemio6200", "mbminiplus", "mbhybrid", "bwidowx2", "beyonwizt2", "opticumtt", "evoslim", "xpeedlxpro", "inihde2"],
        ["xpeedlx3", "sezammarvel", "atemionemesis", "mbultra", "beyonwizt4", "inihdp"],
        ["xp1000mk", "xp1000max", "sf8", "xp1000plus", "xp1000"],
        ["mixoslumi", "eboxlumi"],
        ["mixosf7", "ebox7358"],
        ["mixosf5mini", "gi9196lite", "ebox5100"],
        ["mixosf5", "gi9196m", "ebox5000"],
        ["sogno8800hd", "uniboxhde", "blackbox7405"],
        ["enfinity", "marvel1", "ew7358"],
        ["mutant2400", "quadbox2400", "hd2400"],
        ["mutant11", "hd11"],
        ["mutant1100", "vizyonvita", "hd1100"],
        ["mutant1200", "hd1200"],
        ["mutant1265", "hd1265"],
        ["mutant1500", "hd1500"],
        ["mutant500c", "hd500c"],
        ["mutant530c", "hd530c"],
        ["vimastec1000", "vs1000"],
        ["enibox", "mago", "x1plus", "sf108", "vg5000"],
        ["t2cable", "jj7362"],
        ["x2plus", "ew7356"],
        ["bre2ze", "ew7362"],
        ["evomini", "ch62lc"],
        ["zgemmash1", "zgemmas2s", "zgemmass", "zgemmash2", "sh1"],
        ["zgemmahs", "zgemmah2s", "zgemmah2h", "novatwin", "novacombo", "zgemmah3ac", "zgemmah32tc", "zgemmah2splus", "h3"],
        ["zgemmaslc", "lc"],
        ["zgemmai55", "novaip", "i55"],
        ["zgemmai55plus", "i55plus"],
        ["zgemmai55se", "i55se"],
        ["zgemmah4", "h4"],
        ["zgemmah5", "zgemmah52s", "zgemmah5ac", "zgemmah52tc", "zgemmah52splus", "h5"],
        ["zgemmah6", "h6"],
        ["zgemmah7", "h7", "zgemmah7s", "multibox-4k-ultra-hd"],
        ["zgemmah17combo", "h17"],
        ["zgemmah82h", "h8"],
        ["zgemmah9s", "zgemmah9t", "zgemmah9splus", "zgemmah92s", "zgemmah92h", "h9"],
        ["zgemmah92hse", "zgemmah9sse", "h9se"],
        ["zgemmah9combose", "zgemmah9twinse", "h9combose"],
        ["zgemmah9combo", "zgemmah9twin", "h9combo"],
        ["zgemmah102s", "zgemmah102h", "zgemmah10combo", "h10"],
        ["zgemmah11s", "zgemmah112h", "h11"],
        ["zgemmahzeros", "hzero"],
        ["xcombo", "vg2000"],
        ["tyrant", "vg1000"],
        ["mbmicro", "e4hd", "e4hdhybrid", "7000s"],
        ["mbmicrov2", "7005s"],
        ["twinboxlcd", "singleboxlcd", "7100s"],
        ["twinboxlcdci5", "7105s"],
        ["sf208", "sf228", "7210s"],
        ["sf238", "7215s"],
        ["9910lx", "7220s"],
        ["9911lx", "e4hdcombo", "9920lx", "7225s"],
        ["odin2hybrid", "7300s"],
        ["odinplus", "7400s"],
        ["e4hdultra", "protek4k", "8100s"],
        ["xpeedlxcs2", "xpeedlxcc", "et7x00mini", "ultramini"],
        ["mbtwinplus", "sf3038", "alphatriple", "g300"],
        ["sf128", "sf138", "g100"],
        ["bre2zet2c", "g101"],
        ["osmega", "xc7346"],
        ["spycat", "osmini", "spycatmini", "osminiplus", "spycatminiplus", "xc7362"],
        ["spycat4kmini", "spycat4k", "spycat4kcombo", "xc7439"],
        ["dcube", "mkcube", "ultima", "cube"],
        ["amikomini", "dynaspark", "dynasparkplus", "amiko8900", "sognorevolution", "arguspingulux", "arguspinguluxmini", "arguspinguluxplus", "sparkreloaded", "sabsolo", "fulanspark1", "sparklx", "gis8120", "spark"],
        ["dynaspark7162", "amikoalien", "sognotriple", "sparktriplex", "sabtriple", "sparkone", "giavatar", "spark7162"],
        ["tm2t", "tmnano", "tmnano2t", "tmsingle", "tmtwin", "iqonios100hd", "iqonios300hd", "iqonios300hdv2", "optimussos1", "mediabox", "iqonios200hd", "roxxs200hd", "mediaart200hd", "optimussos2", "dags7335"],
        ["tmnano2super", "tmnano3t", "force1", "force1plus", "megaforce1plus", "worldvisionf1", "worldvisionf1plus", "optimussos1plus", "optimussos2plus", "optimussos3plus", "dags7356"],
        ["tmnanose", "tmnanosem2", "tmnanosem2plus", "tmnanosecombo", "force2plus", "force2", "megaforce2", "optimussos", "force2se", "fusionhd", "fusionhdse", "purehd", "force2nano", "tmnanom3", "valalinux", "dags7362"],
        ["force2plushv", "purehdse", "lunix", "lunixco", "dags73625"],
        ["revo4k", "force3uhd", "force3uhdplus", "tmtwin4k", "galaxy4k", "tm4ksuper", "lunix34k", "dags7252"],
        ["force4", "lunix4k", "dags72604"],
        ["gb800se", "gb800ue", "gb7325"],
        ["gb800seplus", "gb800ueplus", "gbipbox", "gb7358"],
        ["gbultrase", "gbultraue", "gbx1", "gbx3", "gb7362"],
        ["gbx2", "gbultraueh", "gbx3h", "gb73625"],
        ["gbquad", "gbquadplus", "gb7356"],
        ["gbquad4k", "gbue4k", "gbquad4kpro", "gb7252"],
        ["gbx34k", "gb72604"],
        ["gbtrio4k", "gbip4k", "gbtrio4kpro", "gbmv200"],
        ["sf98", "force2nano", "evoslimse", "yh7362"],
        ["evoslimt2c", "yh62tc"],
        ["vipert2c", "yh625tc"],
        ["vipercombo", "yh625dt"],
        ["vipercombohdd", "ch625dt"],
        ["viperslim", "yh73625"],
        ["mutant51", "ax51", "bre2ze4k", "hd51"],
        ["mutant60", "ax60", "hd60"],
        ["mutant61", "ax61", "hd61"],
        ["mutant66se", "hd66se"],
        ["vimastec1500", "vs1500"],
        ["gi11000", "viper4k51", "et1x000"],
        ["beyonwizu4", "et13000"],
        ["dinoboth265", "axashistwin", "u41"],
        ["spycatminiv2", "anadolprohd5", "iziboxecohd", "jdhdduo", "vipertwin", "vipersingle", "u42"],
        ["turing", "u43"],
        ["axashistwinplus", "u45"],
        ["dinobot4k", "mediabox4k", "anadol4k", "u5"],
        ["axashis4kcombo", "dinobot4kl", "anadol4kv2", "anadol4kcombo", "protek4kx1", "u51"],
        ["dinobot4kplus", "axashis4kcomboplus", "u52"],
        ["dinobot4kmini", "u53"],
        ["arivacombo", "u532"],
        ["arivatwin", "u533"],
        ["dinobot4kpro", "u54"],
        ["dinobotu55", "iziboxone4k", "hitube4k", "iziboxx3", "u55"],
        ["axashisc4k", "dinobot4kelite", "u56"],
        ["viper4kv20", "protek4kx2", "iziboxelite4k", "dinobot4ktwin", "hitube4kpro", "viper4kv30", "hitube4kplus", "iziboxx4", "u57"],
        ["iziboxone4kplus", "viper4kv40", "u571"],
        ["dinobot4kse", "ferguson4k", "u5pvr"],
        ["clap4k", "cc1"],
        ["maxytecmultise", "axmultiboxse", "anadolmultiboxse", "novaler4kse", "multiboxse", "multibox-4k-se-ultra-hd"],
        ["anadolmulti", "maxytecmulti", "anadolmultitwin", "axmulticombo", "axmultitwin", "novaler4k", "multibox", "multibox-4k-ultra-hd"],
        ["novaler4kpro", "multiboxpro", "multibox-4k-pro-ultra-hd"]
    ]

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        res2 = get_resolution()
        if res2 == "FHD":
            self.skin = FHD_SKIN_LIST % (IMG_DIR, IMG_DIR)
        else:
            self.skin = HD_SKIN_LIST % (IMG_DIR, IMG_DIR)

        self["title"] = StaticText(to_gui_text(_("Images Downloader")))
        self["key_red"] = StaticText(to_gui_text(_("Back")))
        self["key_green"] = StaticText(to_gui_text(_("Select")))
        self["key_yellow"] = StaticText(to_gui_text(_("Refresh")))
        self["CurrentTime"] = Clock()

        self["list"] = CheckList([], enableWrapAround=True)

        self._png_off = loadPNG(os.path.join(IMG_DIR, "menug.png"))

        self._items = []
        
        self.hostname = self._get_hostname()
        self.box_fallbacks = self._create_box_fallbacks()
        self.current_feed = None
        self.feed_data = {}
        self.expanded_categories = []
        self.loading = False
        self.source_list = []
        
        self.timer = eTimer()
        
        self.onLayoutFinish.append(self._load_sources_from_json)

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.okPressed,
            "cancel": self.close,
            "red": self.close,
            "green": self.okPressed,
            "yellow": self.doRefresh,
        }, -1)

    def _create_box_fallbacks(self):
        box_fallbacks = {}
        for group in self.GROUPS:
            for hostname in group:
                box_fallbacks[hostname] = group
        return box_fallbacks

    def _get_hostname(self):
        try:
            with open("/etc/hostname", "r") as f:
                return f.readline().strip()
        except:
            return os.uname().nodename.strip()

    def _load_sources_from_json(self):
        try:
            json_url = "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/ImagesDownloader/images.json"
            json_content = download_url(json_url)
            
            if not json_content:
                self.session.open(MessageBox, _("Failed to download JSON from URL"), MessageBox.TYPE_ERROR)
                return

            cfg = json_loads_safe(json_content)
            
            sources = cfg.get("e2images", [])
            
            if sources:
                self.source_list = sources
            else:
                self.source_list = [
                    {"name": "OpenATV Images", "url_template": "https://images.mynonpublic.com/openatv/json/{box}"},
                    {"name": "OpenBH Images", "url_template": "https://images.openbh.net/json/{box}"},
                    {"name": "OpenDroid Images", "url_template": "https://opendroid.org/json.php?box={box}"},
                    {"name": "TeamBlue Images", "url_template": "https://images.teamblue.tech/json/{box}"},
                    {"name": "Pure2 Images", "url_template": "https://www.pur-e2.club/OU/images/json/{box}"},
                    {"name": "OpenViX Images", "url_template": "https://www.openvix.co.uk/json/{box}"},
                    {"name": "OpenPLi Images", "url_template": "https://downloads.openpli.org/json/{box}"},
                    {"name": "OpenSPA Images", "url_template": "https://openspa.webhop.info/online/json.php?box={box}"},
                    {"name": "OpenVision Images", "url_template": "https://images.openvision.dedyn.io/json/{box}"},
                    {"name": "Egami Images", "url_template": "https://image.egami-image.com/json/{box}"},
                    {"name": "OpenHDF Images", "url_template": "https://flash.hdfreaks.cc/openhdf/json/{box}"},
                    {"name": "Novaler Images", "url_template": "https://novaler.com/downloads/enigma2/{box}"}
                ]
            
            self._items = []
            for source in self.source_list:
                self._items.append({
                    "type": "source",
                    "name": source.get("name", "Unknown"),
                    "url_template": source.get("url_template", ""),
                    "icon": source.get("icon", "")
                })
            
            self._repaint()
            self["title"].setText(to_gui_text(_("Images Downloader - Select Source")))
            
        except Exception as e:
            print("[ImagesDownloader] Error loading sources:", str(e))
            self.session.open(MessageBox, _("Error loading image sources: %s") % str(e), MessageBox.TYPE_ERROR)

    def get_box_list(self, feed_name):
        if self.hostname in self.box_fallbacks:
            return self.box_fallbacks[self.hostname]
        return [self.hostname]

    def fetch_feed(self, feed_name, url_template):
        USER_AGENT = {'User-agent': 'Enigma2-FlashOnline-Style/1.0'}
        parsed = {}
        box_list = self.get_box_list(feed_name)

        if requests is None:
            for box in box_list:
                try:
                    url = url_template.format(box=box)
                    json_text = download_url(url, timeout=15)
                    if json_text:
                        try:
                            data = json_loads_safe(json_text)
                            if isinstance(data, dict):
                                for k, v in data.items():
                                    parsed[k] = v
                        except:
                            pass
                except:
                    continue
            if parsed:
                return {v: dict(sorted(parsed[v].items(), reverse=True))
                        for v in sorted(parsed.keys(), reverse=True)}
            return {"Error": {"Device unsupported": ""}}

        if "Novaler" in feed_name:
            for box in box_list:
                site = "https://novaler.com/downloads/enigma2/%s" % box
                try:
                    r = requests.get(site, headers=USER_AGENT, timeout=15)
                    r.raise_for_status()
                    html = r.text
                except Exception:
                    continue
                
                matches = re.findall(r'/uploads[^"]*\.zip', html)
                for href in matches:
                    parts = href.strip("/").split("/")
                    if len(parts) < 2:
                        continue
                    category = parts[-2]
                    file_name = parts[-1]
                    full_link = "https://novaler.com" + href
                    parsed.setdefault(category, {})[file_name] = {"link": full_link, "name": file_name}
            
            if parsed:
                return {cat: dict(sorted(parsed[cat].items(), reverse=True))
                        for cat in sorted(parsed.keys(), reverse=True)}
            return {"Error": {"Device unsupported": ""}}

        elif "OpenSPA" in feed_name:
            for box in box_list:
                try:
                    site = "https://openspa.webhop.info/online/json.php?box=%s" % box
                    r = requests.get(site, headers=USER_AGENT, timeout=15)
                    r.raise_for_status()
                    lines = r.text.splitlines()
                except Exception:
                    continue
                
                current_version = ""
                temp_name = None
                temp_link = None
                for line in lines:
                    line = line.strip()
                    if '"OPENSPA' in line:
                        current_version = line.replace('{', '').replace('}', '').replace('"', '').replace(',', '').replace(':', '').strip()
                        parsed.setdefault(current_version, {})
                        continue
                    if '"name"' in line and current_version:
                        temp_name = line.replace('"', '').replace(',', '').replace('{', '').replace('}', '').replace('name:', '').strip()
                    elif '"link"' in line and current_version:
                        temp_link = line.replace('"', '').replace(',', '').replace('link:', '').replace('\\/', '/').strip()
                    
                    if temp_name:
                        link_to_use = temp_link or "https://openspa.webhop.info/online/images/%s/%s/%s.zip" % (box, quote(current_version), quote(temp_name))
                        parsed[current_version][temp_name] = {"link": link_to_use, "name": temp_name}
                        temp_name = None
                        temp_link = None
            
            if parsed:
                return {v: dict(sorted(parsed[v].items(), reverse=True))
                        for v in sorted(parsed.keys(), reverse=True)}
            return {"Error": {"Device unsupported": ""}}

        elif "OpenHDF" in feed_name:
            for box in box_list:
                try:
                    url = url_template.format(box=box)
                    r = requests.get(url, headers=USER_AGENT, timeout=15)
                    r.raise_for_status()
                    data = r.json()
                except Exception:
                    continue

                if not isinstance(data, dict):
                    continue

                for version_title, file_dict in data.items():
                    version = version_title.replace("openHDF Images Version:", "").strip()
                    if not isinstance(file_dict, dict):
                        continue

                    parsed.setdefault(version, {})

                    for file_name, file_info in file_dict.items():
                        if not isinstance(file_info, dict):
                            continue

                        link = file_info.get("link") or file_info.get("url")
                        if not link:
                            continue

                        name = file_info.get("name") or os.path.basename(link)
                        parsed[version][file_name] = {"link": link, "name": name}
            
            if parsed:
                return {v: dict(sorted(parsed[v].items(), reverse=True))
                        for v in sorted(parsed.keys(), reverse=True)}
            return {"Error": {"Device unsupported": ""}}

        else:
            for box in box_list:
                try:
                    url = url_template.format(box=box)
                    r = requests.get(url, headers=USER_AGENT, timeout=15)
                    r.raise_for_status()
                    data = r.json()
                    if isinstance(data, dict):
                        for k, v in data.items():
                            parsed[k] = v
                except Exception:
                    continue

            if parsed:
                return {v: dict(sorted(parsed[v].items(), reverse=True))
                        for v in sorted(parsed.keys(), reverse=True)}
            return {"Error": {"Device unsupported": ""}}

    def _load_feed_thread(self, feed_name, url_template):
        self.loading = True
        try:
            data = self.fetch_feed(feed_name, url_template)
            self.feed_data = data
            self.current_feed = to_gui_text(feed_name) if feed_name else "Unknown"
            self.expanded_categories = []
        except Exception as e:
            print("[ImagesDownloader] Error loading feed:", str(e))
            self.feed_data = {"Error": {"Error": str(e)}}
            self.current_feed = to_gui_text(feed_name) if feed_name else "Unknown"
        finally:
            self.loading = False
            self.timer.start(100, True)

    def _update_display(self):
        if self.loading:
            self._items = [{"type": "loading", "name": _("Loading...")}]
            self._repaint()
            return

        if not self.current_feed:
            self._load_sources_from_json()
            return

        feed = self.feed_data
        self._items = []

        if "Error" in feed:
            self._items.append({
                "type": "error", 
                "name": _("Device unsupported or error loading images")
            })
        else:
            feed_title = self.current_feed if self.current_feed else "Unknown"
            self._items.append({
                "type": "feed",
                "name": "Back: %s" % feed_title,
                "expanded": True
            })

            for category in sorted(feed.keys(), reverse=True):
                category_expanded = category in self.expanded_categories
                symbol = "[+]" if category_expanded else "[+]"
                
                self._items.append({
                    "type": "category",
                    "name": "%s %s" % (symbol, category),
                    "category": category,
                    "expanded": category_expanded
                })

                if category_expanded:
                    for img_name, img_info in sorted(feed[category].items(), reverse=True):
                        display_name = img_info.get("name", img_name)
                        self._items.append({
                            "type": "image",
                            "name": "- %s" % display_name,
                            "image_name": display_name,
                            "category": category,
                            "url": img_info.get("link", ""),
                            "info": img_info
                        })

        self._repaint()
        try:
            if self.current_feed:
                title_text = to_gui_text(_("Images Downloader - ") + self.current_feed)
            else:
                title_text = to_gui_text(_("Images Downloader - Select Source"))
            self["title"].setText(title_text)
        except Exception as e:
            print("[ImagesDownloader] Error setting title:", str(e))
            self["title"].setText(to_gui_text(_("Images Downloader")))

    def _build_row(self, it):
        name = it.get("name", "")
        name_b = to_gui_text(name)
        
        max_len = 250
        if len(name_b) > max_len:
            name_b = name_b[:max_len-3] + "..."

        row = [ it ]
        
        icon = it.get("icon", "")
        if icon:
            icon_path = None
            possible_paths = [
                os.path.join(IMG_DIR, icon),
                os.path.join(PLUGIN_DIR, icon),
                os.path.join(PLUGIN_DIR, "images", icon),
            ]
            if icon.startswith('/'):
                possible_paths.insert(0, icon)
            
            for img_path in possible_paths:
                try:
                    img_path = safe_path(img_path)
                    if os.path.exists(img_path):
                        icon_path = img_path
                        break
                except Exception:
                    continue
            
            if icon_path:
                try:
                    item_png = loadPNG(icon_path)
                    if item_png:
                        row.append(MultiContentEntryPixmapAlphaTest(
                            pos=(10, 6), size=(44, 44),
                            png=item_png
                        ))
                        text_x = 64
                except Exception:
                    pass
        
        if len(row) == 1:
            if self._png_off:
                row.append(MultiContentEntryPixmapAlphaTest(
                    pos=(10, 6), size=(44, 44),
                    png=self._png_off
                ))
                text_x = 64
            else:
                name_b = "[ ] " + name_b
                text_x = 16

        row.append(MultiContentEntryText(
            pos=(text_x, 0), size=(620, 56), font=0, text=name_b
        ))
        return row

    def _repaint(self):
        self["list"].l.setList([ self._build_row(x) for x in self._items ])

    def _current_index(self):
        try:
            return self["list"].getSelectedIndex()
        except Exception:
            return -1

    def okPressed(self):
        idx = self._current_index()
        if idx < 0 or idx >= len(self._items):
            return
            
        item = self._items[idx]
        
        if item.get("type") == "source":
            feed_name = item.get("name", "")
            url_template = item.get("url_template", "")
            
            if feed_name and url_template:
                self.session.open(MessageBox, _("Loading images..."), MessageBox.TYPE_INFO, timeout=2)
                
                thread = threading.Thread(target=self._load_feed_thread, args=(feed_name, url_template))
                thread.start()
                
                self.timer.timeout.get().append(self._check_loading_complete)
                self.timer.start(500, True)
        
        elif item.get("type") == "feed":
            self.current_feed = None
            self.feed_data = {}
            self._update_display()
        
        elif item.get("type") == "category":
            category = item.get("category")
            if category:
                if category in self.expanded_categories:
                    self.expanded_categories.remove(category)
                else:
                    self.expanded_categories.append(category)
                self._update_display()
        
        elif item.get("type") == "image":
            url = item.get("url", "")
            image_name = item.get("image_name", "")
            
            if url:
                self._download_image(url, image_name)
        
        elif item.get("type") == "error":
            self.current_feed = None
            self.feed_data = {}
            self._update_display()

    def _check_loading_complete(self):
        if self.loading:
            self.timer.start(500, True)
        else:
            self.timer.stop()
            try:
                self._update_display()
            except Exception as e:
                print("[ImagesDownloader] Error in _update_display:", str(e))
                self.session.open(MessageBox, _("Error updating display"), MessageBox.TYPE_ERROR)

    def _download_image(self, url, filename):
        if not url:
            self.session.open(MessageBox, to_gui_text(_("No download URL available")), MessageBox.TYPE_ERROR)
            return
        
        if not filename:
            filename = _("Unknown file")
        
        safe_filename = to_gui_text(filename)
        
        try:
            message_text = _("Are you sure you want to download:\n\n%s\n\nFile will be saved to your box") % safe_filename
            safe_message = to_gui_text(message_text)
        except:
            safe_message = to_gui_text(_("Are you sure you want to download this image?"))
        
        self.session.openWithCallback(
            lambda confirmed: self._confirm_download(confirmed, url, filename),
            MessageBox,
            safe_message,
            MessageBox.TYPE_YESNO
        )

    def _confirm_download(self, confirmed, url, filename):
        if not confirmed:
            return
        
        download_paths = ["/media/hdd/images", "/media/usb/images", "/media/ba/images", "/tmp/images_download"]
        self.last_download_path = None
        for path in download_paths:
            if os.path.exists(path):
                self.last_download_path = path
                break
        
        if self.last_download_path is None:
            self.last_download_path = "/tmp/images_download"
            if not os.path.exists(self.last_download_path):
                os.makedirs(self.last_download_path)
        
        filepath = os.path.join(self.last_download_path, filename)
        self.last_download_file = filepath
        
        download_commands = [
            "echo 'Starting download...'",
            "echo 'URL: %s'" % url,
            "wget --timeout=60 --tries=3 --no-check-certificate -O '%s' '%s'" % (filepath, url),
            "if [ $? -eq 0 ]; then echo 'Download completed successfully!'; echo 'File saved to: %s'; else echo 'Download failed!'; fi" % filepath
        ]
        
        self.session.openWithCallback(
            self._download_completed,
            Console,
            to_gui_text(_("Downloading %s") % filename),
            download_commands
        )

    def _download_completed(self, result=None):
        if result is None or result == 0:
            copy_success, target_path = self._copy_to_additional_paths()
            
            if copy_success and target_path:
                self.session.open(
                    MessageBox,
                    to_gui_text(_("Image downloaded successfully!\nOriginal saved to: %s\nCopied to: %s") % (self.last_download_file, target_path)),
                    MessageBox.TYPE_INFO
                )
            else:
                self.session.open(
                    MessageBox,
                    to_gui_text(_("Image downloaded successfully!\nSaved to: %s\nNote: Could not copy to additional locations") % self.last_download_file),
                    MessageBox.TYPE_INFO
                )
        else:
            self.session.open(
                MessageBox,
                to_gui_text(_("Download failed!\nError code: %s") % str(result)),
                MessageBox.TYPE_ERROR
            )

    def _copy_to_additional_paths(self):
        try:
            if not self.last_download_file or not os.path.exists(self.last_download_file):
                return False, None
            
            source_file = self.last_download_file
            latest_file = os.path.basename(source_file)
            
            target_paths = [
                "/media/hdd/ImagesUpload",
                "/media/usb/ImagesUpload",
                "/media/hdd/open-multiboot-upload",
                "/media/usb/open-multiboot-upload",
                "/media/hdd/OPDBootUpload",
                "/media/usb/OPDBootUpload",
                "/media/hdd/EgamiBootUpload",
                "/media/usb/EgamiBootUpload",
                "/media/ba/backup"
            ]
            
            for target_path in target_paths:
                if os.path.exists(os.path.dirname(target_path)):
                    if not os.path.exists(target_path):
                        try:
                            os.makedirs(target_path, mode=0o755)
                        except Exception as e:
                            print("[ImagesDownloader] Error creating directory %s:" % target_path, str(e))
                            continue
                    
                    target_file = os.path.join(target_path, latest_file)
                    try:
                        import shutil
                        shutil.copy2(source_file, target_file)
                        print("[ImagesDownloader] File copied to:", target_file)
                        return True, target_file
                    except Exception as e:
                        print("[ImagesDownloader] Error copying file to %s:" % target_path, str(e))
                        continue
            
            return False, None
            
        except Exception as e:
            print("[ImagesDownloader] Error in _copy_to_additional_paths:", str(e))
            return False, None

    def doRefresh(self):
        if self.current_feed:
            self.session.open(MessageBox, _("Refreshing..."), MessageBox.TYPE_INFO, timeout=1)
            
            url_template = ""
            for source in self.source_list:
                if source.get("name", "") == self.current_feed:
                    url_template = source.get("url_template", "")
                    break
            
            if url_template:
                thread = threading.Thread(target=self._load_feed_thread, args=(self.current_feed, url_template))
                thread.start()
                self.timer.timeout.get().append(self._check_loading_complete)
                self.timer.start(500, True)
        else:
            self._load_sources_from_json()
            self.session.open(MessageBox, _("List refreshed"), MessageBox.TYPE_INFO, timeout=2)

def main(session, **kwargs):
    session.open(ImagesDownloaderScreen)

def menu_main(menuid, **kwargs):
    if menuid == "mainmenu":
        return [(_("Images Downloader"), main, "imagesdownloader", 50)]
    return []

def Plugins(path=None, **kwargs):
    icon = None
    possible_icon_paths = [
        PLUGIN_ICON_PATH,
        os.path.join(PLUGIN_DIR, "plugin.png"),
        os.path.join(PLUGIN_DIR, "images", "plugin.png"),
    ]
    
    for icon_path in possible_icon_paths:
        try:
            if fileExists(icon_path):
                icon = icon_path
                break
        except Exception:
            continue
    
    return [
        PluginDescriptor(
            name="Images Downloader",
            description=PLUGIN_DESC,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=icon,
            fnc=main
        ),
        PluginDescriptor(
            name="Images Downloader",
            description=PLUGIN_DESC,
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu_main,
            icon=icon
        )
    ]