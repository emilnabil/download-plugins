# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import shutil
import tarfile
import tempfile

try:
    # Py3
    from urllib.request import urlopen, Request
except Exception:
    # Py2
    from urllib2 import urlopen, Request

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.config import ConfigText, ConfigInteger, getConfigListEntry, config
from Components.ConfigList import ConfigListScreen

PLUGIN_NAME = "EmuInstaller"
PLUGIN_VERSION = "1.0"  # added feed package installation
PLUGIN_INFO = (
    "%s v%s\n"
    "Created by MNASR\n"
    "Supported images: egami, atv, pli, obh, pure2, vix\n"
    "Blue button: Add reader to oscam‑icam / ncam‑icam"
) % (PLUGIN_NAME, PLUGIN_VERSION)

# Paths for each image type
BIN_PATHS = {
    "egami": "/usr/bin",
    "atv": "/usr/bin",
    "pli": "/usr/bin",
    "obh": "/usr/bin",
    "pure2": "/usr/bin/cam",
    "vix": "/usr/softcams",
}
SCRIPT_PATHS = {
    "egami": "/usr/emu_scripts",
    "atv": "/etc/init.d",
    "pli": "/etc/init.d",
    "obh": "/usr/camscript",
    "pure2": "/usr/script/cam",
    "vix": "/etc/init.d",
}
CONFIG_PATH = "/etc/tuxbox/config"  # same for all

# URLs
BASE_URL = "https://raw.githubusercontent.com/popking159/softcam/refs/heads/master"
SCRIPT_URL_TEMPLATE = BASE_URL + "/script/{image}/emuscript.tar.gz"
BIN_URL = BASE_URL + "/emubin.tar.gz"
CONFIG_URL = BASE_URL + "/emuconfig.tar.gz"

IMAGE_VERSION_FILE = "/etc/image-version"


def read_file(path):
    try:
        with open(path, "r") as f:
            return f.read()
    except Exception:
        return ""


def detect_image_key():
    """Return image key: egami, atv, pli, obh, pure2, vix or None."""
    data = read_file(IMAGE_VERSION_FILE).lower()
    if "egami" in data:
        return "egami"
    if "openatv" in data or "atv" in data:
        return "atv"
    if "pli" in data:
        return "pli"
    if "openbh" in data or "obh" in data:
        return "obh"
    if "pure2" in data:
        return "pure2"
    if "openvix" in data or "vix" in data:
        return "vix"
    return None


def download_to(url, out_path, timeout=20):
    req = Request(url)
    fh = urlopen(req, timeout=timeout)
    try:
        data = fh.read()
    finally:
        fh.close()
    with open(out_path, "wb") as f:
        f.write(data)


def extract_to_target(tar_path, target_dir):
    """
    Extract the contents of tar_path into target_dir.
    Handles both flat tarballs and those with internal directories.
    """
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)

    with tempfile.TemporaryDirectory(prefix="emuextract_") as tmpdir:
        with tarfile.open(tar_path, "r:gz") as tf:
            tf.extractall(tmpdir)

        for item in os.listdir(tmpdir):
            src = os.path.join(tmpdir, item)
            dst = os.path.join(target_dir, item)
            if os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)


def generate_reader_label(protocol, filepath):
    """
    Generate a unique label for a new reader.
    Protocol: 'cccam' or 'mgcamd' (newcamd)
    """
    base = "Custom_CCcam_" if protocol == "cccam" else "Custom_NewCamd_"
    max_num = 0
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            for line in f:
                if line.strip().startswith("label") and base in line:
                    try:
                        num = int(line.split("=")[-1].strip().replace(base, ""))
                        max_num = max(max_num, num)
                    except:
                        pass
    return base + str(max_num + 1)


def append_reader_to_file(filepath, reader_block):
    """Append a reader block to the given file."""
    dirname = os.path.dirname(filepath)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    with open(filepath, "a") as f:
        if os.path.getsize(filepath) > 0:
            f.write("\n")  # separate from existing content
        f.write(reader_block)


def install_feed_packages(session):
    """
    Install softcam-support and libdvbcsa from the image feed using opkg.
    Shows appropriate message boxes and returns True if opkg is available.
    """
    if not os.path.exists('/usr/bin/opkg'):
        session.open(MessageBox, "opkg not found. Cannot install from feed.", MessageBox.TYPE_WARNING, timeout=5)
        return False

    try:
        # Update package list
        session.open(MessageBox, "Updating package list...", MessageBox.TYPE_INFO, timeout=2)
        ret = os.system('opkg update >/dev/null 2>&1')
        if ret != 0:
            session.open(MessageBox, "opkg update failed. Continuing anyway...", MessageBox.TYPE_WARNING, timeout=5)

        # Install packages
        session.open(MessageBox, "Installing softcam-support and libdvbcsa...", MessageBox.TYPE_INFO, timeout=2)
        ret = os.system('opkg install softcam-support libdvbcsa >/dev/null 2>&1')
        if ret == 0:
            session.open(MessageBox, "softcam-support and libdvbcsa installed successfully.", MessageBox.TYPE_INFO, timeout=3)
        else:
            session.open(MessageBox, "softcam-support or libdvbcsa not found in feed.\nContinuing...", MessageBox.TYPE_WARNING, timeout=5)
    except Exception as e:
        session.open(MessageBox, "Error installing from feed: %s" % str(e), MessageBox.TYPE_WARNING, timeout=5)

    return True


# -------------------------------------------------------------------
# Input screen for new reader parameters
# -------------------------------------------------------------------
class AddReaderInput(ConfigListScreen, Screen):
    skin = """
    <screen name="AddReaderInput" position="center,center" size="800,320" title="Add Reader">
        <widget name="config" position="10,10" size="780,250" scrollbarMode="showOnDemand" itemHeight="50" />
        <widget source="key_red" render="Label" position="10,270" size="160,40" font="Regular;22" foregroundColor="#f5516d" zPosition="1" halign="center" valign="center" />
        <widget source="key_green" render="Label" position="180,270" size="160,40" font="Regular;22" foregroundColor="#92ef80" zPosition="1" halign="center" valign="center" />
        <eLabel name="" position="10,306" size="160,8" backgroundColor="#f5516d" zPosition="3" />
        <eLabel name="" position="180,306" size="160,8" backgroundColor="#92ef80" zPosition="3" />
    </screen>
    """

    def __init__(self, session, softcam, protocol, callback):
        Screen.__init__(self, session)
        self.softcam = softcam          # 'oscam-icam' or 'ncam-icam'
        self.protocol = protocol        # 'cccam' or 'mgcamd'
        self.callback = callback

        # Determine file path for generating default label
        base_dir = "/etc/tuxbox/config"
        if self.softcam == "oscam-icam":
            filepath = os.path.join(base_dir, "oscam-icam", "oscam.server")
        else:
            filepath = os.path.join(base_dir, "ncam-icam", "ncam.server")
        default_label = generate_reader_label(self.protocol, filepath)

        # Config entries
        self.label = ConfigText(default=default_label, fixed_size=False)
        self.host = ConfigText(default="", fixed_size=False)
        self.port = ConfigText(default="", fixed_size=False)
        self.username = ConfigText(default="", fixed_size=False)
        self.password = ConfigText(default="", fixed_size=False)

        self.list = []
        self.list.append(getConfigListEntry("Label", self.label))
        self.list.append(getConfigListEntry("Host", self.host))
        self.list.append(getConfigListEntry("Port", self.port))
        self.list.append(getConfigListEntry("Username", self.username))
        self.list.append(getConfigListEntry("Password", self.password))

        ConfigListScreen.__init__(self, self.list, session)

        self["key_red"] = StaticText("Cancel")
        self["key_green"] = StaticText("Save")

        self["actions"] = ActionMap(
            ["ColorActions", "OkCancelActions"],
            {
                "red": self.cancel,
                "green": self.save,
                "cancel": self.cancel,
            },
            -2
        )

    def cancel(self):
        self.close()

    def save(self):
        # Basic validation
        if not self.label.value or not self.host.value or not self.port.value or not self.username.value or not self.password.value:
            self.session.open(MessageBox, "All fields are required!", MessageBox.TYPE_ERROR)
            return
        # Build reader block
        if self.protocol == "cccam":
            block = self._build_cccam_block()
        else:
            block = self._build_newcamd_block()
        # Determine file path
        base_dir = "/etc/tuxbox/config"
        if self.softcam == "oscam-icam":
            filepath = os.path.join(base_dir, "oscam-icam", "oscam.server")
        else:
            filepath = os.path.join(base_dir, "ncam-icam", "ncam.server")
        # Append to file
        try:
            append_reader_to_file(filepath, block)
            self.session.open(MessageBox, "Reader added successfully!", MessageBox.TYPE_INFO, timeout=3)
        except Exception as e:
            self.session.open(MessageBox, "Failed to write file:\n%s" % str(e), MessageBox.TYPE_ERROR)
        self.close()

    def _build_cccam_block(self):
        return """[reader]
label                         = {label}
protocol                      = cccam
device                        = {host},{port}
user                          = {user}
password                      = {pwd}
inactivitytimeout             = -1
group                         = 1
emmcache                      = 1,2,2,1
disablecrccws                 = 1
cccversion                    = 2.3.2
""".format(label=self.label.value, host=self.host.value, port=self.port.value,
           user=self.username.value, pwd=self.password.value)

    def _build_newcamd_block(self):
        return """[reader]
label                         = {label}
protocol                      = newcamd
device                        = {host},{port}
key                           = 0102030405060708091011121314
user                          = {user}
password                      = {pwd}
inactivitytimeout             = -1
disableserverfilter           = 1
group                         = 1
emmcache                      = 1,2,2,1
disablecrccws                 = 1
""".format(label=self.label.value, host=self.host.value, port=self.port.value,
           user=self.username.value, pwd=self.password.value)


# -------------------------------------------------------------------
# Main plugin screen
# -------------------------------------------------------------------
class EmuInstaller(Screen):
    skin = """
    <screen name="EmuInstaller" position="center,center" size="800,260" title="Emu Installer">
        <widget source="key_red" render="Label" position="540,20" size="240,40" font="Regular;22" foregroundColor="#f5516d" zPosition="9" />
        <widget source="key_green" render="Label" position="540,80" size="240,40" font="Regular;22" foregroundColor="#92ef80" zPosition="9" />
        <widget source="key_yellow" render="Label" position="540,140" size="240,40" font="Regular;22" foregroundColor="#ffd65c" zPosition="9" />
        <widget source="key_blue" render="Label" position="540,200" size="240,40" font="Regular;22" zPosition="9" foregroundColor="#47c8ff" />
        <eLabel name="" position="520,20" size="2,220" backgroundColor="white" />
        <widget source="status" render="Label" position="20,20" size="480,220" font="Regular; 24" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("%s v%s" % (PLUGIN_NAME, PLUGIN_VERSION))

        self["key_red"] = StaticText("Exit")
        self["key_green"] = StaticText("INSTALL EMU")
        self["key_yellow"] = StaticText("UPDATE EMU")
        self["key_blue"] = StaticText("ADD READER")
        self["status"] = StaticText("")

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "InfoActions"],
            {
                "cancel": self.close,
                "red": self.close,
                "green": self.install_all,
                "yellow": self.update_choice,
                "blue": self.add_reader,
                "info": self.show_info,
            },
            -1
        )

        self.onLayoutFinish.append(self.refresh_ui)

    def refresh_ui(self):
        image = detect_image_key() or "Unknown"
        self["status"].text = (
            "Detected image: %s\n"
            "\n\n"
            "Press GREEN to install all components.\n\n"
            "Press YELLOW to update a single component.\n\n"
            "Press BLUE to add a reader." % image
        )

    def install_all(self):
        image = detect_image_key()
        if not image:
            self.session.open(MessageBox, "Image not recognized. Cannot proceed.", MessageBox.TYPE_ERROR)
            return

        # First try to install required packages from feed
        install_feed_packages(self.session)

        tmp_script = "/tmp/emuscript.tar.gz"
        tmp_bin = "/tmp/emubin.tar.gz"
        tmp_config = "/tmp/emuconfig.tar.gz"

        script_url = SCRIPT_URL_TEMPLATE.format(image=image)

        try:
            self.session.open(MessageBox, "Downloading script package...", MessageBox.TYPE_INFO, timeout=2)
            download_to(script_url, tmp_script)
            self.session.open(MessageBox, "Downloading binary package...", MessageBox.TYPE_INFO, timeout=2)
            download_to(BIN_URL, tmp_bin)
            self.session.open(MessageBox, "Downloading config package...", MessageBox.TYPE_INFO, timeout=2)
            download_to(CONFIG_URL, tmp_config)
        except Exception as e:
            self.session.open(MessageBox, "Download failed:\n%s" % str(e), MessageBox.TYPE_ERROR)
            return

        try:
            extract_to_target(tmp_script, SCRIPT_PATHS[image])
            extract_to_target(tmp_bin, BIN_PATHS[image])
            extract_to_target(tmp_config, CONFIG_PATH)
        except Exception as e:
            self.session.open(MessageBox, "Extraction failed:\n%s" % str(e), MessageBox.TYPE_ERROR)
            return
        finally:
            for f in (tmp_script, tmp_bin, tmp_config):
                try:
                    os.remove(f)
                except Exception:
                    pass

        self.session.open(MessageBox, "Installation completed successfully!", MessageBox.TYPE_INFO, timeout=5)
        self.refresh_ui()

    def update_choice(self):
        image = detect_image_key()
        if not image:
            self.session.open(MessageBox, "Image not recognized. Cannot update.", MessageBox.TYPE_ERROR)
            return

        choices = [
            ("Binary (emu only)", "bin"),
            ("Script (init/emu_scripts)", "script"),
            ("Config files", "config")
        ]
        self.session.openWithCallback(self.update_component, ChoiceBox, title="Select component to update", list=choices)

    def update_component(self, choice):
        if choice is None:
            return
        image = detect_image_key()
        component = choice[1]

        if component == "bin":
            url = BIN_URL
            target = BIN_PATHS[image]
        elif component == "script":
            url = SCRIPT_URL_TEMPLATE.format(image=image)
            target = SCRIPT_PATHS[image]
        elif component == "config":
            url = CONFIG_URL
            target = CONFIG_PATH
        else:
            return

        tmp_file = "/tmp/update_%s.tar.gz" % component

        try:
            self.session.open(MessageBox, "Downloading %s..." % component, MessageBox.TYPE_INFO, timeout=2)
            download_to(url, tmp_file)
            extract_to_target(tmp_file, target)
        except Exception as e:
            self.session.open(MessageBox, "Update failed:\n%s" % str(e), MessageBox.TYPE_ERROR)
            return
        finally:
            try:
                os.remove(tmp_file)
            except Exception:
                pass

        self.session.open(MessageBox, "%s updated successfully." % component.capitalize(), MessageBox.TYPE_INFO, timeout=3)
        self.refresh_ui()

    def add_reader(self):
        # Step 1: choose softcam (oscam-icam / ncam-icam)
        choices = [
            ("oscam-icam", "oscam-icam"),
            ("ncam-icam", "ncam-icam")
        ]
        self.session.openWithCallback(self.add_reader_softcam_chosen, ChoiceBox, title="Select softcam", list=choices)

    def add_reader_softcam_chosen(self, choice):
        if choice is None:
            return
        self.selected_softcam = choice[1]   # store for later use
        # Step 2: choose protocol (cccam / mgcamd)
        choices = [
            ("CCcam", "cccam"),
            ("NewCamd (mgcamd)", "mgcamd")
        ]
        self.session.openWithCallback(self.add_reader_protocol_chosen, ChoiceBox,
                                      title="Select reader type", list=choices)

    def add_reader_protocol_chosen(self, choice):
        if choice is None:
            return
        protocol = choice[1]
        # Step 3: open input screen with stored softcam
        self.session.open(AddReaderInput, self.selected_softcam, protocol, self.add_reader_done)

    def add_reader_done(self):
        # Optional callback after reader is added
        self.refresh_ui()

    def show_info(self):
        self.session.open(MessageBox, PLUGIN_INFO, MessageBox.TYPE_INFO, timeout=10)


def main(session, **kwargs):
    session.open(EmuInstaller)


def Plugins(**kwargs):
    return [
        PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=main),
        PluginDescriptor(
            name="EmuInstaller",
            description="Install/Update emulator components + add readers",
            icon="logo.png",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main
        )
    ]