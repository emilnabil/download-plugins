from __future__ import print_function
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Button import Button
from enigma import eConsoleAppContainer

PLUGIN_VERSION = "1.1"
PLUGIN_NAME = "CiefpsettingsPanel"
PLUGINS = {
    "Ajpanel": "wget https://raw.githubusercontent.com/biko-73/AjPanel/main/installer.sh -O - | /bin/sh",
    "Aj Panel custom menu All panels By Emil": "wget https://dreambox4u.com/emilnabil237/plugins/ajpanel/emil-panel-all.sh -O - | /bin/sh",
    "Panel Lite By Emil Nabil": "wget https://dreambox4u.com/emilnabil237/plugins/ajpanel/new/emil-panel-lite.sh -O - | /bin/sh",
    "ElieSat Panel": "wget -q --no-check-certificate https://gitlab.com/eliesat/extensions/-/raw/main/ajpanel/eliesatpanel.sh -O - | /bin/sh",
   "dreamosat-downloader": "wget https://dreambox4u.com/emilnabil237/plugins/dreamosat-downloader/installer.sh  -O - | /bin/sh",
     "Epanel": "wget https://dreambox4u.com/emilnabil237/plugins/epanel/installer.sh  -O - | /bin/sh", 
    "ONEupdater": "wget https://raw.githubusercontent.com/Sat-Club/ONEupdaterE2/main/installer.sh -O - | /bin/sh",
    "linuxsat-panel": "wget https://dreambox4u.com/emilnabil237/plugins/linuxsat-panel/installer.sh -O - |/bin/sh",
    "levi45-AddonsManager": "wget https://dreambox4u.com/emilnabil237/plugins/levi45-addonsmanager/installer.sh -O - |/bin/sh",
    "Levi45MulticamManager": "wget https://dreambox4u.com/emilnabil237/plugins/levi45multicammanager/installer.sh -O - |/bin/sh",
    "SatVenusPanel": "wget https://dreambox4u.com/emilnabil237/plugins/satvenuspanel/installer.sh -O - |/bin/sh",
    "Tspanel": "wget https://dreambox4u.com/emilnabil237/plugins/tspanel/installer.sh -O - |/bin/sh",
    "TvAddon-Panel": "wget https://dreambox4u.com/emilnabil237/plugins/tvaddon/installer.sh -O - |/bin/sh", "Elsafty-Tv-Radio-Steaming": "wget https://dreambox4u.com/emilnabil237/settings/elsafty/installer.sh -O - | /bin/sh", "Channels Emil": "wget https://raw.githubusercontent.com/emilnabil/channel-emil-nabil/main/installer.sh -O - | /bin/sh", "CiefpSettingsDownloader": "wget -q --no-check-certificate https://raw.githubusercontent.com/ciefp/CiefpSettingsDownloader/main/installer.sh -O - | /bin/sh",
    "CiefpsettingsMotor": "wget https://raw.githubusercontent.com/ciefp/CiefpsettingsMotor/main/installer.sh -O - | /bin/sh", "CiefpWhitelistStreamrelay": "wget -q --no-check-certificate https://raw.githubusercontent.com/ciefp/CiefpWhitelistStreamrelay/main/installer.sh -O - | /bin/sh", "CiefpSettingsT2miAbertis": "wget -q --no-check-certificate https://raw.githubusercontent.com/ciefp/CiefpSettingsT2miAbertis/main/installer.sh -O - | /bin/sh",
    "ArabicSavior": "wget http://dreambox4u.com/emilnabil237/plugins/ArabicSavior/installer.sh  -O - | /bin/sh",
    "Epg Grabber": "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh",
    "FootOnsat": "wget https://dreambox4u.com/emilnabil237/plugins/FootOnsat/installer.sh -O - | /bin/sh",
    "E2iplayer": "wget -qO- --no-check-certificate https://mohamed_os.gitlab.io/e2iplayer/online-setup | bash",
    "ChocholousekPicons": "https://github.com/s3n0/e2plugins/raw/master/ChocholousekPicons/online-setup -qO - | bash -s install",
    "CrashLogViewer": "wget https://dreambox4u.com/emilnabil237/plugins/crashlogviewer/install-CrashLogViewer.sh -qO - | /bin/sh",
    "IptoSat": "wget https://dreambox4u.com/emilnabil237/plugins/iptosat/installer.sh -qO - | /bin/sh",
    "IpAudio_6.7 Py2": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudio/installer.sh -O - | /bin/sh",
    "IpAudio_7.4 Py3": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudio/ipaudio-7.4-ffmpeg.sh -O - | /bin/sh",
    "IpAudioPro": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudiopro/installer.sh -O - | /bin/sh",
    "Multistalker Pro": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/MultiStalkerPro/installer.sh -O - | /bin/sh",
    "The Weather": "wget https://raw.githubusercontent.com/biko-73/TheWeather/main/installer.sh -O - | /bin/sh",
    "Youtube": "wget https://dreambox4u.com/emilnabil237/plugins/YouTube/installer.sh -qO - | /bin/sh",
    "BouquetMakerXtream": "wget http://dreambox4u.com/emilnabil237/plugins/BouquetMakerXtream/installer.sh -qO - | /bin/sh",
    "XcPlugin Forever": "wget https://raw.githubusercontent.com/Belfagor2005/xc_plugin_forever/main/installer.sh -qO - | /bin/sh",
    "Xklass Iptv": "wget https://dreambox4u.com/emilnabil237/plugins/xklass/installer.sh -O - | /bin/sh",
    "X-Streamity": "wget https://raw.githubusercontent.com/biko-73/xstreamity/main/installer.sh -qO - | /bin/sh",
    "JediMakerXtream": "wget https://raw.githubusercontent.com/biko-73/JediMakerXtream/main/installer.sh -qO - | /bin/sh",
    "HasBahCa": "wget https://dreambox4u.com/emilnabil237/plugins/HasBahCa/installer.sh -qO - | /bin/sh",
    "KeyAdder": "wget -q --no-check-certificate https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh -O - |/bin/sh",
    "feeds-finder": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/feeds-finder/installer.sh -O - | /bin/sh",
    "MyCam-Plugin": "wget https://dreambox4u.com/emilnabil237/plugins/mycam/installer.sh -O - | /bin/sh",
    "RaedQuickSignal": "wget https://raw.githubusercontent.com/fairbird/RaedQuickSignal/main/installer.sh -O - | /bin/sh",
    "SubsSupport_2.1": "wget https://dreambox4u.com/emilnabil237/plugins/SubsSupport/subssupport_2.1.sh -O - | /bin/sh",
    "XtraEvante": "wget https://github.com/digiteng/xtra/raw/main/xtraEvent.sh -qO - | /bin/sh",
    "Wget": "opkg install wget",
  "Curl": "opkg install curl",
  "UPDATE ENIGMA2 ALL PYTHON": "wget https://raw.githubusercontent.com/emil237/updates-enigma/main/update-all-python.sh -O - | /bin/sh",
   "Super Script": "wget https://dreambox4u.com/emilnabil237/script/Super_Script.sh -O - | /bin/sh",
  "OpenATV softcamfeed": "wget -O - -q http://updates.mynonpublic.com/oea/feed | bash",
    "OpenATV Develop feed": "wget -O - -q https://feeds2.mynonpublic.com/devel-feed | bash",
     "Repair-Inodes-From-Hdd": "wget https://raw.githubusercontent.com/emil237/scripts/refs/heads/main/repair-hdd.sh -O - | /bin/sh",
 "FIX-ipk-Package-Installation": "wget https://dreambox4u.com/emilnabil237/script/fix-ipk-package-installation.sh -O - | /bin/sh",
  "update": "opkg update",
    "astra-sm": "opkg install astra-sm",
    "reboot": "reboot",
    "restartEnigma2": "killall -9 enigma2",
    "gstplayer": "opkg install gstplayer",
    "Streamlinksrv": "opkg install streamlinksrv",
    "dabstreamer": "opkg install dabstreamer",
    "eti_tools": "opkg install eti-tools",
    "dvbsnoop": "opkg install dvbsnoop",
    "stop enigma2 and network": "init 1",
    "stop enigma2": "init 2",
    "Starts Enigma2 normally": "init 3",
    "stop enigma2": "init 4",
    "stop enigma2": "init 5",
    "Reboots Enigma2": "nit 6",
    "Deep Standby": "init 0",
    "Oscam Mohamed_OS": "wget https://dreambox4u.com/emilnabil237/emu/installer-oscam.sh  -O - | /bin/sh",
    "Ncam fairman": "wget https://dreambox4u.com/emilnabil237/emu/installer-ncam.sh -O - | /bin/sh",
    "Oscam Emu biko-73": "wget https://raw.githubusercontent.com/biko-73/OsCam_EMU/main/installer.sh -O - | /bin/sh",
    "MADMAX IMPOSSIBLE SKIN OPENATV": "wget https://bit.ly/3cg1664 -qO - | /usr/bin/python",
    "BO-HLALA FHD SKIN": "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerB.sh -O - | /bin/sh",
    "Metrix-FHD": "wget http://ipkinstall.ath.cx/ipk-install/MetrixFHD/MetrixFHD.sh -qO - | /bin/sh",
    "Red-Dragon-FHD": "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerD.sh -O - | /bin/sh",
    "Nitro AdvanceFHD": "wget https://raw.githubusercontent.com/biko-73/NitroAdvanceFHD/main/installer.sh -qO - | /bin/sh",
    "Desert skin": "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerDs.sh -O - | /bin/sh",
    "FreeServerCCcam": "wget https://ia803104.us.archive.org/0/items/freecccamserver/installer.sh -qO - | /bin/sh",
}

class CiefpsettingsPanel(Screen):
    skin = """
    <screen name="CiefpsettingsPanel" position="center,center" size="1200,800" title="Ciefpsettings Panel">
        <widget name="menu" position="20,20" size="1160,600" scrollbarMode="showOnDemand" font="Regular;24" />
        <widget name="status" position="20,640" size="880,30" font="Regular;24" halign="center" />
        <widget name="key_red" position="20,700" size="300,60" font="Regular;24" halign="center" backgroundColor="#9F1313" />
        <widget name="key_green" position="450,700" size="300,60" font="Regular;24" halign="center" backgroundColor="#1F771F" />
        <widget name="key_blue" position="880,700" size="300,60" font="Regular;24" halign="center" backgroundColor="#13389F" />
    </screen>
    """
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        self["menu"] = MenuList([key.encode("utf-8") for key in PLUGINS.keys()])
        self["status"] = Label("Select a plugin to install")
        self["key_red"] = Button("Red: Exit")
        self["key_green"] = Button("Green/OK: Install")
        self["key_blue"] = Button("Blue: Restart Enigma2")

        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions"],
            {
                "red": self.close,
                "green": self.install_plugin,
                "ok": self.install_plugin,
                "blue": self.restart_enigma2,
                "cancel": self.close,
            },
        )

        self.container = eConsoleAppContainer()
        self.container.appClosed.append(self.command_finished)

    def install_plugin(self):
        selected = self["menu"].getCurrent()
        if selected:
            selected = selected.decode("utf-8")
            command = PLUGINS[selected]
            self["status"].setText("Installing {}...".format(selected))
            self.container.execute(command)

    def command_finished(self, retval):
        if retval == 0:
            self["status"].setText("Installation complete!")
        else:
            self["status"].setText("Error during installation!")

    def restart_enigma2(self):
        self.container.execute("init 4 && init 3")
        self.close()


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Ciefpsettings Panel", 
            description="Manage and install plugins (Version {})".format(PLUGIN_VERSION),
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=lambda session, **kwargs: session.open(CiefpsettingsPanel),
        )
    ]
