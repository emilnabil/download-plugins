from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Button import Button
from Components.Pixmap import Pixmap
from enigma import eConsoleAppContainer
import urllib.request
import json
import os

PLUGIN_VERSION = "v2.0"

PLUGINS = {
    "############ ( PANELS ) ############": "", 
    "Ajpanel": "wget https://raw.githubusercontent.com/biko-73/AjPanel/main/installer.sh -O - | /bin/sh",
    "Aj Panel custom menu All panels By Emil": "wget https://dreambox4u.com/emilnabil237/plugins/ajpanel/emil-panel-all.sh -O - | /bin/sh",
    "Panel Lite By Emil Nabil": "wget https://dreambox4u.com/emilnabil237/plugins/ajpanel/new/emil-panel-lite.sh -O - | /bin/sh",
    "ElieSat Panel": "wget -q --no-check-certificate https://gitlab.com/eliesat/extensions/-/raw/main/ajpanel/eliesatpanel.sh -O - | /bin/sh",
   "dreamosat-downloader": "wget https://dreambox4u.com/emilnabil237/plugins/dreamosat-downloader/installer.sh  -O - | /bin/sh",
     "Epanel": "wget https://dreambox4u.com/emilnabil237/plugins/epanel/installer.sh  -O - | /bin/sh", 
    "ONEupdater": "wget https://raw.githubusercontent.com/Sat-Club/ONEupdaterE2/main/installer.sh -O - | /bin/sh",
    "linuxsat-panel": "wget https://dreambox4u.com/emilnabil237/plugins/linuxsat-panel/installer.sh -O - |/bin/sh",
  "levi45-AddonsManager": "wget https://dreambox4u.com/emilnabil237/plugins/levi45-addonsmanager/installer.sh -O - |/bin/sh",
  "Levi45MulticamManager": "wget https://dreambox4u.com/emilnabil237/plugins/levi45multicammanager/installer.sh -O - |/bin/sh",
    "SatVenusPanel": "wget https://dreambox4u.com/emilnabil237/plugins/satvenuspanel/installer.sh -O - |/bin/sh",
    "Tspanel": "wget https://dreambox4u.com/emilnabil237/plugins/tspanel/installer.sh -O - |/bin/sh",
    "TvAddon-Panel": "wget https://dreambox4u.com/emilnabil237/plugins/tvaddon/installer.sh -O - |/bin/sh",
    "############ ( MULTIBOOT ) ############": "", 
    "EgamiBoot": "wget https://raw.githubusercontent.com/emil237/egamiboot/refs/heads/main/installer.sh  -O - | /bin/sh",
    "Neoboot_v9.65": "wget https://dreambox4u.com/emilnabil237/plugins/neoboot-v9.65/iNB.sh  -O - | /bin/sh",
    "Neoboot_v9.60": "wget https://dreambox4u.com/emilnabil237/plugins/neoboot-v9.60/iNB.sh  -O - | /bin/sh",
"Neoboot_v9.58": "wget https://dreambox4u.com/emilnabil237/plugins/neoboot-v9.58/iNB.sh  -O - | /bin/sh",
"Neoboot_v9.54": "wget https://raw.githubusercontent.com/emil237/neoboot_9.54/main/installer.sh  -O - | /bin/sh",
"OpenMultiboot_1.3": "wget https://raw.githubusercontent.com/emil237/openmultiboot/main/installer.sh  -O - | /bin/sh",
"OpenMultiboot-E2turk-1.3": "wget https://raw.githubusercontent.com/e2TURK/omb-enhanced/main/install.sh  -O - | /bin/sh",
    "############ ( CHANNELS ) ############": "", 
    "Elsafty-Tv-Radio-Steaming": "wget https://dreambox4u.com/emilnabil237/settings/elsafty/installer.sh -O - | /bin/sh", 
    "Channels Emil": "wget https://raw.githubusercontent.com/emilnabil/channel-emil-nabil/main/installer.sh -O - | /bin/sh",
"############ ( PLUGINS ) ############": "", "CiefpSettingsDownloader": "wget -q --no-check-certificate https://raw.githubusercontent.com/ciefp/CiefpSettingsDownloader/main/installer.sh -O - | /bin/sh",
    "CiefpsettingsMotor": "wget https://raw.githubusercontent.com/ciefp/CiefpsettingsMotor/main/installer.sh -O - | /bin/sh", "CiefpWhitelistStreamrelay": "wget -q --no-check-certificate https://raw.githubusercontent.com/ciefp/CiefpWhitelistStreamrelay/main/installer.sh -O - | /bin/sh", "CiefpSettingsT2miAbertis": "wget -q --no-check-certificate https://raw.githubusercontent.com/ciefp/CiefpSettingsT2miAbertis/main/installer.sh -O - | /bin/sh",
    "ArabicSavior": "wget http://dreambox4u.com/emilnabil237/plugins/ArabicSavior/installer.sh  -O - | /bin/sh",
    "Alajre": "wget https://dreambox4u.com/emilnabil237/plugins/alajre/installer.sh -qO - | /bin/sh",
    "AthanTimes": "wget https://dreambox4u.com/emilnabil237/plugins/athantimes/installer.sh -O - | /bin/sh",
    "Ansite": "wget http://dreambox4u.com/emilnabil237/plugins/ansite/installer.sh -qO - | /bin/sh",
    "Quran-karem": "wget https://dreambox4u.com/emilnabil237/plugins/quran/installer.sh -qO - | /bin/sh",
    "E2m3u2bouquet": "wget https://dreambox4u.com/emilnabil237/plugins/e2m3u2bouquet/installer.sh -O - | /bin/sh",
    "Epg Grabber": "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh",
    "FootOnsat": "wget https://dreambox4u.com/emilnabil237/plugins/FootOnsat/installer.sh -O - | /bin/sh",
    "E2iplayer": "wget -qO- --no-check-certificate https://mohamed_os.gitlab.io/e2iplayer/online-setup | bash",
    "ChocholousekPicons": "https://github.com/s3n0/e2plugins/raw/master/ChocholousekPicons/online-setup -qO - | bash -s install",
    "CrashLogViewer": "wget https://dreambox4u.com/emilnabil237/plugins/crashlogviewer/install-CrashLogViewer.sh -qO - | /bin/sh",
    "HistoryZapSelector": "wget https://dreambox4u.com/emilnabil237/plugins/historyzap/installer.sh -O - | /bin/sh",
    "IptoSat": "wget https://dreambox4u.com/emilnabil237/plugins/iptosat/installer.sh -qO - | /bin/sh",
    "IpAudio_6.7 Py2": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudio/installer.sh -O - | /bin/sh",
    "IpAudio_7.4 Py3": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudio/ipaudio-7.4-ffmpeg.sh -O - | /bin/sh",
    "IpAudioPro": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudiopro/installer.sh -O - | /bin/sh",
    "JediEpgXtream": "wget https://dreambox4u.com/emilnabil237/plugins/jediepgextream/installer.sh -O - | /bin/sh",
   "Multi-Stalker": "wget https://dreambox4u.com/emilnabil237/plugins/multistalker/installer.sh -O - | /bin/sh",
    "Multistalker Pro": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/MultiStalkerPro/installer.sh -O - | /bin/sh",
    "The Weather": "wget https://raw.githubusercontent.com/biko-73/TheWeather/main/installer.sh -O - | /bin/sh",
    "Youtube": "wget https://dreambox4u.com/emilnabil237/plugins/YouTube/installer.sh -qO - | /bin/sh",
"BouquetMakerXtream": "wget http://dreambox4u.com/emilnabil237/plugins/BouquetMakerXtream/installer.sh -qO - | /bin/sh",
    "QuarterPounder": "wget http://dreambox4u.com/emilnabil237/script/quarterpounder.sh -qO - | /bin/sh",
    "XcPlugin Forever": "wget https://raw.githubusercontent.com/Belfagor2005/xc_plugin_forever/main/installer.sh -qO - | /bin/sh",
    "Xklass Iptv": "wget https://dreambox4u.com/emilnabil237/plugins/xklass/installer.sh -O - | /bin/sh",
    "X-Streamity": "wget https://raw.githubusercontent.com/biko-73/xstreamity/main/installer.sh -qO - | /bin/sh",
    "JediMakerXtream": "wget https://raw.githubusercontent.com/biko-73/JediMakerXtream/main/installer.sh -qO - | /bin/sh",
    "HasBahCa": "wget https://dreambox4u.com/emilnabil237/plugins/HasBahCa/installer.sh -qO - | /bin/sh",
    "KeyAdder": "wget -q --no-check-certificate https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh -O - |/bin/sh",
    "feeds-finder": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/feeds-finder/installer.sh -O - | /bin/sh",
    "MyCam-Plugin": "wget https://dreambox4u.com/emilnabil237/plugins/mycam/installer.sh -O - | /bin/sh",
    "RaedQuickSignal": "wget https://raw.githubusercontent.com/fairbird/RaedQuickSignal/main/installer.sh -O - | /bin/sh",
    "VertualKeyboard": "wget https://raw.githubusercontent.com/emil237/NewVirtualKeyBoard/main/installer.sh -O - | /bin/sh",
    "ShootYourScreen-Py3": "wget -q --no-check-certificate https://raw.githubusercontent.com/emil237/ShootYourScreen-Py3/main/ShootYourScreen-py3.sh -O - | /bin/sh",
    "SubsSupport_2.1": "wget https://dreambox4u.com/emilnabil237/plugins/SubsSupport/subssupport_2.1.sh -O - | /bin/sh",
  "XtraEvante_v4.6": "wget https://github.com/emil237/download-plugins/raw/main/Xtraevent-v4.6.sh -qO - | /bin/sh",
    "XtraEvante_v5.2": "wget https://github.com/digiteng/xtra/raw/main/xtraEvent.sh -qO - | /bin/sh",
  "XtraEvante_v5.3": "wget https://raw.githubusercontent.com/emil237/download-plugins/main/xtraEvent_5.3.sh -qO - | /bin/sh",
  "xtraevent_v6.798": "wget https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent_6.798.sh -qO - | /bin/sh",
"############ ( TOOLS ) ############": "", 
    "Wget": "opkg install wget",
  "Curl": "opkg install curl",
  "UPDATE ENIGMA2 ALL PYTHON": "wget https://raw.githubusercontent.com/emil237/updates-enigma/main/update-all-python.sh -O - | /bin/sh",
 "servicescanupdates_1.2": "wget https://dreambox4u.com/emilnabil237/plugins/servicescanupdates/servicescanupdates.sh -O - | /bin/sh",
   "Super Script": "wget https://dreambox4u.com/emilnabil237/script/Super_Script.sh -O - | /bin/sh",
  "OpenATV softcamfeed": "wget -O - -q http://updates.mynonpublic.com/oea/feed | bash",
 "Fix Softcam OpenPli": "wget https://raw.githubusercontent.com/emil237/download-plugins/main/softcam-support-pli.sh -O - | /bin/sh",
    "Update OpenATV Develop feed": "wget -O - -q https://feeds2.mynonpublic.com/devel-feed | bash",
     "Repair-Inodes-From-Hdd": "wget https://raw.githubusercontent.com/emil237/scripts/refs/heads/main/repair-hdd.sh -O - | /bin/sh", "FIX-ipk-Package-Installation": "wget https://dreambox4u.com/emilnabil237/script/fix-ipk-package-installation.sh -O - | /bin/sh",
  "update": "opkg update",
    "astra-sm": "opkg install astra-sm",
    "gstplayer": "opkg install gstplayer",
    "Streamlinksrv": "opkg install streamlinksrv",
    "dabstreamer": "opkg install dabstreamer",
    "eti_tools": "opkg install eti-tools",
    "dvbsnoop": "opkg install dvbsnoop", 

"############ ( SOFTCAMS ) ############": "", 
    "Cccam": "wget https://dreambox4u.com/emilnabil237/emu/installer-cccam.sh -O - | /bin/sh",
    "Oscam Mohamed_OS": "wget https://dreambox4u.com/emilnabil237/emu/installer-oscam.sh  -O - | /bin/sh",
    "Ncam fairman": "wget https://dreambox4u.com/emilnabil237/emu/installer-ncam.sh -O - | /bin/sh",
    "Oscam Emu biko-73": "wget https://raw.githubusercontent.com/biko-73/OsCam_EMU/main/installer.sh -O - | /bin/sh",
"############ ( SKINS ) ############": "", 
"BO-HLALA FHD SKIN": "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerB.sh -O - | /bin/sh",
    "Red-Dragon-FHD": "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerD.sh -O - | /bin/sh",
    "Nitro AdvanceFHD": "wget https://raw.githubusercontent.com/biko-73/NitroAdvanceFHD/main/installer.sh -qO - | /bin/sh",
    "Desert skin": "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerDs.sh -O - | /bin/sh", 

  "############ ( Free ) ############": "", 
    "FreeServerCCcam": "wget https://ia803104.us.archive.org/0/items/freecccamserver/installer.sh -qO - | /bin/sh", 
 
"###### ( BootlogoSwapper ) ######": "", 
"BootlogoSwapper Atv": "wget http://dreambox4u.com/emilnabil237/script/bootlogoswapper-Atv.sh -O - | /bin/sh",
"BootlogoSwapper-christmas": "wget http://dreambox4u.com/emilnabil237/script/bootlogoswapper-christmas.sh -O - | /bin/sh",
"BootlogoSwapper-OpenPli": "wget http://dreambox4u.com/emilnabil237/script/bootlogoswapper-pli.sh -O - | /bin/sh",
"bootlogoSwapper-OpenBH": "wget http://dreambox4u.com/emilnabil237/script/bootlogoswapper-OpenBH.sh  -O - | /bin/sh",
"BootlogoSwapper_Egami": "wget http://dreambox4u.com/emilnabil237/script/bootLogoswapper-Egami.sh -O - | /bin/sh",
"BootlogoSwapper_OpenVix": "wget http://dreambox4u.com/emilnabil237/script/bootlogoswapper-OpenVix.sh -O - | /bin/sh",
"BootlogoSwapper_PURE2": "wget http://dreambox4u.com/emilnabil237/script/bootLogoswapper-Pure2.sh -O - | /bin/sh",
"BootlogoSwapper_Kids": "wget http://dreambox4u.com/emilnabil237/script/bootlogoswapper-kids.sh -O - | /bin/sh",
"BootlogoSwapper_Ramadan": "wget http://dreambox4u.com/emilnabil237/script/bootlogo-swapper-ramadan.sh -O - | /bin/sh",
"###### ( Images ) ######": "", 
"Image BlackHole-3.1.0": "wget https://dreambox4u.com/emilnabil237/images/BlackHole-3.1.0.sh -O - | /bin/sh",
"Image-Egami-10.4": "wget https://dreambox4u.com/emilnabil237/images/egami-10.4.sh -O - | /bin/sh",
"Image-Openatv-6.4": "wget https://dreambox4u.com/emilnabil237/images/openatv-6.4.sh -O - | /bin/sh",
"Image-Openatv-7.0": "wget https://dreambox4u.com/emilnabil237/images/openatv-7.0.sh  -O - | /bin/sh",
"Image_Openatv-7.1": "wget https://dreambox4u.com/emilnabil237/images/openatv-7.1.sh -O - | /bin/sh",
"Image_Openatv-7.2": "wget https://dreambox4u.com/emilnabil237/images/openatv-7.2.sh -O - | /bin/sh",
"Image_Openatv-7.3": "wget https://dreambox4u.com/emilnabil237/images/openatv-7.3.sh -O - | /bin/sh",
"Image_Openatv-7.4": "wget https://dreambox4u.com/emilnabil237/images/openatv-7.4.sh -O - | /bin/sh",
"Image_Openatv-7.5": "wget https://dreambox4u.com/emilnabil237/images/openatv-7.5.sh -O - | /bin/sh",
"Image_Openatv-7.5.1": "wget https://dreambox4u.com/emilnabil237/images/openatv-7.5.1.sh -O - | /bin/sh",
"Image_OpenBlackHole-4.4": "wget https://dreambox4u.com/emilnabil237/images/openblackhole-4.4-for-vuplus-only.sh -O - | /bin/sh",
"Image_OpenBlackHole-5.0": "wget https://dreambox4u.com/emilnabil237/images/openblackhole-5.0.sh -O - | /bin/sh",
"Image_OpenBlackHole-5.1": "wget https://dreambox4u.com/emilnabil237/images/openblackhole-5.1.sh -O - | /bin/sh",
"Image_OpenBlackHole-5.2": "wget https://dreambox4u.com/emilnabil237/images/openblackhole-5.2.sh -O - | /bin/sh",
"Image_OpenBlackHole-5.3": "wget https://dreambox4u.com/emilnabil237/images/openblackhole-5.3.sh -O - | /bin/sh",
"Image_OpenBlackHole-5.4": "wget https://dreambox4u.com/emilnabil237/images/openblackhole-5.4.sh -O - | /bin/sh",
"Image_OpenDroid-7.1": "wget https://dreambox4u.com/emilnabil237/images/opendroid-7.1.sh -O - | /bin/sh",
"Image_OpenDroid-7.3": "wget https://dreambox4u.com/emilnabil237/images/opendroid-7.3.sh -O - | /bin/sh",
"Image_Openpli-7.3": "wget https://dreambox4u.com/emilnabil237/images/openpli-7.3.sh -O - | /bin/sh",
"Image_Openpli-8.3": "wget https://dreambox4u.com/emilnabil237/images/openpli-8.3.sh -O - | /bin/sh",
"Image_OpenPli-8.3-Time-Shift": "wget https://dreambox4u.com/emilnabil237/images/openpli-8.3-py2-TimeShift.sh -O - | /bin/sh",
"Image_OpenPli-9.0-Time-Shift": "wget https://dreambox4u.com/emilnabil237/images/openpli-9.0-py3-TimeShift.sh -O - | /bin/sh",
"Image_Openpli-9.0": "wget https://dreambox4u.com/emilnabil237/images/openpli-9.0.sh -O - | /bin/sh",
"Image_OpenPli develop": "wget https://dreambox4u.com/emilnabil237/images/openpli-develop.sh -O - | /bin/sh",
"Image_openspa-8.4.xxx": "wget https://dreambox4u.com/emilnabil237/images/openspa-8.4.xxx.sh -O - | /bin/sh",
"Image_Openvix-6.6.004": "wget https://dreambox4u.com/emilnabil237/images/openvix-6.6.004.sh -O - | /bin/sh",
"Image_OpenVision-py2-10.3-r395": "wget https://dreambox4u.com/emilnabil237/images/openvision/OpenVision-py2-10.3-r395.sh -O - | /bin/sh",
"Image_Pure2-7.4": "wget https://dreambox4u.com/emilnabil237/images/pure2-7.4.sh -O - | /bin/sh",
"Image_VTI-15.0.02": "wget https://dreambox4u.com/emilnabil237/images/vti-15.0.02.sh -O - | /bin/sh",
"###### ( Picons ) ######": "", 
"Picons intelsat_31.5w": "wget https://dreambox4u.com/emilnabil237/picons/intelsat_31.5w/installer.sh -O - | /bin/sh",
"Picons hispasat_30.0w": "wget https://dreambox4u.com/emilnabil237/picons/hispasat_30.0w/installer.sh -O - | /bin/sh",
"Picons intelsat_27.5w": "wget https://dreambox4u.com/emilnabil237/picons/intelsat_27.5w/installer.sh -O - | /bin/sh",
"Picons intelsat_24.5w": "wget https://dreambox4u.com/emilnabil237/picons/intelsat_24.5w/installer.sh -O - | /bin/sh",
"Picons ses4_22.0w": "wget https://dreambox4u.com/emilnabil237/picons/ses4_22.0w/installer.sh -O - | /bin/sh",
"Picons nss7_20.0w": "wget https://dreambox4u.com/emilnabil237/picons/nss7_20.0w/installer.sh -O - | /bin/sh",
"Picons telstar_15.0w": "wget https://dreambox4u.com/emilnabil237/picons/telstar_15.0w/installer.sh -O - | /bin/sh",
"Picons express_14w": "wget https://dreambox4u.com/emilnabil237/picons/express_14w/installer.sh -O - | /bin/sh",
"Picons express_11.0w-14.0w": "wget https://dreambox4u.com/emilnabil237/picons/express_11.0w-14.0w/installer.sh -O - | /bin/sh",
"Picons Nilesat_7W+8W": "wget https://dreambox4u.com/emilnabil237/picons/nilesat/installer.sh -O - | /bin/sh",
"Picons eutelsat_5.0w": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_5.0w/installer.sh -O - | /bin/sh",
"Picons Amos_4.0W": "wget https://dreambox4u.com/emilnabil237/picons/amos_4.0w/installer.sh -O - | /bin/sh",
"Picons abs_3.0w": "wget https://dreambox4u.com/emilnabil237/picons/abs_3.0w/installer.sh -O - | /bin/sh",
"Picons thor_0.8w": "wget https://dreambox4u.com/emilnabil237/picons/thor_0.8w/installer.sh -O - | /bin/sh",
"Picons bulgariasat_1.9e": "wget https://dreambox4u.com/emilnabil237/picons/bulgariasat_1.9e/installer.sh -O - | /bin/sh",
"Picons eutelsat_3.0e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_3.0e/installer.sh -O - | /bin/sh",
"Picons astra_4.8e": "wget https://dreambox4u.com/emilnabil237/picons/astra_4.8e/installer.sh -O - | /bin/sh",
"Picons eutelsat_7.0e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_7.0e/installer.sh -O - | /bin/sh",
"Picons eutelsat_9.0e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_9.0e/installer.sh -O - | /bin/sh",
"Picons eutelsat_10.0e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_10.0e/installer.sh -O - | /bin/sh",
"Picons hotbird_13.0e": "wget https://dreambox4u.com/emilnabil237/picons/hotbird_13.0e/installer.sh -O - | /bin/sh",
"Picons eutelsat_16.0e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_16.0e/installer.sh -O - | /bin/sh",
"Picons astra_19.2e": "wget https://dreambox4u.com/emilnabil237/picons/astra_19.2e/installer.sh -O - | /bin/sh",
"Picons eutelsat_21.6e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_21.6e/installer.sh -O - | /bin/sh",
"Picons astra_23.5e": "wget https://dreambox4u.com/emilnabil237/picons/astra_23.5e/installer.sh -O - | /bin/sh",
"Picons eshail_25.5e": "wget https://dreambox4u.com/emilnabil237/picons/eshail_25.5e/installer.sh -O - | /bin/sh",
"Picons badr_26.0e": "wget https://dreambox4u.com/emilnabil237/picons/badr_26.0e/installer.sh -O - | /bin/sh",
"Picons astra_28.2e": "wget https://dreambox4u.com/emilnabil237/picons/astra_28.2e/installer.sh -O - | /bin/sh",
"Picons arabsat_30.5e": "wget https://dreambox4u.com/emilnabil237/picons/arabsat_30.5e/installer.sh -O - | /bin/sh",
"Picons astra_31.5e": "wget https://dreambox4u.com/emilnabil237/picons/astra_31.5e/installer.sh -O - | /bin/sh",
"Picons eutelsat-intelsat_33.0e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat-intelsat_33.0e/installer.sh -O - | /bin/sh",
"Picons eutelsat_36.0e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_36.0e/installer.sh -O - | /bin/sh",
"Picons hellas-sat_39.0e": "wget https://dreambox4u.com/emilnabil237/picons/hellas-sat_39.0e/installer.sh -O - | /bin/sh",
"Picons turksat_42.0e": "wget https://dreambox4u.com/emilnabil237/picons/turksat_42.0e/installer.sh -O - | /bin/sh",
"Picons azerspace_45.0e": "wget https://dreambox4u.com/emilnabil237/picons/azerspace_45.0e/installer.sh -O - | /bin/sh",
"Picons azerspace_46.0e": "wget https://dreambox4u.com/emilnabil237/picons/azerspace_46.0e/installer.sh -O - | /bin/sh",
"Picons turksat_50.0e_56.0e_57e": "wget https://dreambox4u.com/emilnabil237/picons/turksat_50.0e_56.0e_57e/installer.sh -O - | /bin/sh",
"Picons belintersat_51.5e": "wget https://dreambox4u.com/emilnabil237/picons/belintersat_51.5e/installer.sh -O - | /bin/sh",
"Picons turkmenalem_52.0e": "wget https://dreambox4u.com/emilnabil237/picons/turkmenalem_52.0e/installer.sh -O - | /bin/sh",
"Picons alyahsat_52.5e": "wget https://dreambox4u.com/emilnabil237/picons/alyahsat_52.5e/installer.sh -O - | /bin/sh",
"Picons express_53.0e": "wget https://dreambox4u.com/emilnabil237/picons/express_53.0e/installer.sh -O - | /bin/sh",
"Picons gsat-yamal_54.9e": "wget https://dreambox4u.com/emilnabil237/picons/gsat-yamal_54.9e/installer.sh -O - | /bin/sh",
"Picons intelsat_60.0e_66.0e_68.0e": "wget https://dreambox4u.com/emilnabil237/picons/intelsat_60.0e_66.0e_68.0e/installer.sh -O - | /bin/sh",
"Picons intelsat_62.0e": "wget https://dreambox4u.com/emilnabil237/picons/intelsat_62.0e/installer.sh -O - | /bin/sh",
"Picons eutelsat_70.0e_74.9e_75.0e": "wget https://dreambox4u.com/emilnabil237/picons/eutelsat_70.0e_74.9e_75.0e/installer.sh -O - | /bin/sh",
"Picons Intelsat_72.1e": "wget https://dreambox4u.com/emilnabil237/picons/Intelsat_72.1e/installer.sh -O - | /bin/sh",
"Picons abs_75.0e": "wget https://dreambox4u.com/emilnabil237/picons/abs_75.0e/installer.sh -O - | /bin/sh",
}

class CiefpsettingsPanel(Screen):
    skin = """
    <screen name="CiefpsettingsPanel" position="center,center" size="950,650" title="Ciefpsettings Panel Mod By Emil Nabil">
        <widget name="menu" position="10,10" size="450,500" scrollbarMode="showOnDemand" font="Regular;24" 
backgroundColor="#000000" foregroundColor="#FFFFFF" foregroundColorSelected="#FFFF00" />  
        <widget name="background" position="470,10" size="450,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CiefpsettingsPanel/background.png" zPosition="-1" alphatest="on" />
        <widget name="status" position="10,520" size="450,30" transparent="1" font="Regular;22" halign="center" />
        <widget name="key_red" position="470,530" size="110,40" font="Regular;18" halign="center" backgroundColor="#9F1313" />
        <widget name="key_green" position="590,530" size="110,40" font="Regular;18" halign="center" backgroundColor="#1F771F" />
        <widget name="key_yellow" position="710,530" size="110,40" font="Regular;18" halign="center" backgroundColor="#FFC000" />
        <widget name="key_blue" position="830,530" size="110,40" font="Regular;18" halign="center" backgroundColor="#13389F" />
    </screen>
    """

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)

        self["menu"] = MenuList(list(PLUGINS.keys()))
        self["background"] = Pixmap()
        self["status"] = Label("Select a plugin to install")
        self["key_red"] = Button("Exit")
        self["key_green"] = Button("Install")
        self["key_yellow"] = Button("Update")
        self["key_blue"] = Button("Restart E2")

        self["actions"] = ActionMap(
            ["ColorActions", "SetupActions", "OkCancelActions"],
            {
                "red": self.close,
                "green": self.install_plugin,
                "yellow": self.update_plugin,
                "blue": self.restart_enigma2,
                "cancel": self.close,
                "ok": self.install_plugin,
            },
        )

        self.container = eConsoleAppContainer()
        self.container.appClosed.append(self.command_finished)

    def install_plugin(self):
        selected = self["menu"].getCurrent()
        if selected:
            command = PLUGINS[selected]
            self["status"].setText(f"Installing {selected}...")
            self.container.execute(command)

    def update_plugin(self):
        self["status"].setText("Updating plugin...")
        update_command = "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/Ciefp-Panel/Ciefp-Panel.sh -O - | /bin/sh"
        self.container.execute(update_command)

    def command_finished(self, retval):
        if retval == 0:
            self["status"].setText("Operation completed successfully!")
        else:
            self["status"].setText("Operation failed!")

    def restart_enigma2(self):
        self.container.execute("killall -9 enigma2")
        self.close()


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Ciefpsettings Panel",
            description=f"Manage and install plugins (Version {PLUGIN_VERSION})",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=lambda session, **kwargs: session.open(CiefpsettingsPanel),
        )
    ]








