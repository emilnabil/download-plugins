from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigText, ConfigSubsection, getConfigListEntry
from Components.ActionMap import ActionMap
from Components.Button import Button
from Plugins.Plugin import PluginDescriptor
import os
import urllib.request
from urllib.error import URLError, HTTPError

config.plugins.MultiIptvAdder = ConfigSubsection()
config.plugins.MultiIptvAdder.url = ConfigText(default="http://example.com", fixed_size=False)
config.plugins.MultiIptvAdder.port = ConfigText(default="8080", fixed_size=False)
config.plugins.MultiIptvAdder.username = ConfigText(default="user", fixed_size=False)
config.plugins.MultiIptvAdder.password = ConfigText(default="pass", fixed_size=False)

class MultiIptvAdderScreen(ConfigListScreen, Screen):
    skin = """
        <screen position="center,center" size="800,400" title="Multi IPTV Adder">
            <widget name="config" position="10,10" size="780,300" itemHeight="70" font="Bold;40" scrollbarMode="showOnDemand" />
            <widget name="key_red" position="10,350" size="240,40" backgroundColor="red" font="Bold;35" valign="center" halign="center" />
            <widget name="key_green" position="280,350" size="240,40" backgroundColor="green" font="Bold;35" valign="center" halign="center" />
            <widget name="key_blue" position="550,350" size="240,40" backgroundColor="blue" font="Bold;35" valign="center" halign="center" />
        </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self.list = [
            getConfigListEntry("URL:", config.plugins.MultiIptvAdder.url),
            getConfigListEntry("Port:", config.plugins.MultiIptvAdder.port),
            getConfigListEntry("Username:", config.plugins.MultiIptvAdder.username),
            getConfigListEntry("Password:", config.plugins.MultiIptvAdder.password),
        ]

        ConfigListScreen.__init__(self, self.list)

        self["key_red"] = Button("Exit")
        self["key_green"] = Button("Send")
        self["key_blue"] = Button("Check Server")
        self["message_label"] = Label("Welcome to Multi IPTV Adder")

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "red": self.close,
            "green": self.send_data,
            "blue": self.check_data,
            "cancel": self.close,
        }, -1)

    def send_data(self):
        if self.is_default_data():
            self.session.open(MessageBox, "Default data not changed!", MessageBox.TYPE_ERROR)
            return
        self.save_data()
        self["message_label"].setText("Data sent successfully!")
        self.session.open(MessageBox, "Data sent successfully!", MessageBox.TYPE_INFO)

    def is_default_data(self):
        url = config.plugins.MultiIptvAdder.url.value.rstrip('/')
        port = config.plugins.MultiIptvAdder.port.value
        username = config.plugins.MultiIptvAdder.username.value
        password = config.plugins.MultiIptvAdder.password.value

        return (
            url == "http://example.com" and
            port == "8080" and
            username == "user" and
            password == "pass"
        )

    def save_data(self):
        url = config.plugins.MultiIptvAdder.url.value.rstrip('/')
        port = config.plugins.MultiIptvAdder.port.value
        username = config.plugins.MultiIptvAdder.username.value
        password = config.plugins.MultiIptvAdder.password.value

        full_url = f"{url}:{port}/get.php?username={username}&password={password}&type=m3u&output=ts"
        data = full_url + "\n"

        files_to_save = [
            "/etc/enigma2/bouquetmakerxtream/playlists.txt",
            "/etc/enigma2/jediplaylists/playlists.txt",
            "/etc/enigma2/xklass/playlists.txt",
            "/etc/enigma2/xstreamity/playlists.txt",
            "/etc/enigma2/e2iplayer/playlists.txt",
            "/etc/enigma2/xc/xclink.txt"
        ]

        for file_path in files_to_save:
            try:
                directory = os.path.dirname(file_path)
                if not os.path.exists(directory):
                    os.makedirs(directory, exist_ok=True)
                with open(file_path, "a") as f:
                    f.write(data)
            except Exception as e:
                self.session.open(MessageBox, f"Error saving to {file_path}: {str(e)}", MessageBox.TYPE_ERROR)
                return

        self["message_label"].setText("Data saved successfully!")
        self.session.open(MessageBox, "Data saved successfully!", MessageBox.TYPE_INFO)
        self.run_shell_script()

    def check_data(self):
        url = config.plugins.MultiIptvAdder.url.value.rstrip('/')
        port = config.plugins.MultiIptvAdder.port.value
        username = config.plugins.MultiIptvAdder.username.value
        password = config.plugins.MultiIptvAdder.password.value

        test_result = self.test_server_connection(url, port, username, password)
        info_message = (
            f"● Server URL:\n{url}:{port}/get.php\n"
            f"● Username: {username}\n"
            f"● Password: {password}\n"
            f"\nConnection Check: {test_result}"
        )

        self["message_label"].setText(info_message)
        self.session.open(MessageBox, info_message, MessageBox.TYPE_INFO)

    def test_server_connection(self, url, port, username, password):
        try:
            test_url = f"{url}:{port}/get.php?username={username}&password={password}&type=m3u&output=ts"
            req = urllib.request.Request(test_url)
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    return "✅ Connection Successful"
                else:
                    return f"❌ Invalid Response (Code: {response.status})"
        except HTTPError as e:
            return f"❌ HTTP Error: {e.code}"
        except URLError as e:
            return f"❌ URL Error: {e.reason}"
        except Exception as e:
            return f"❌ General Error: {str(e)}"

    def run_shell_script(self):
        script_path = "/usr/lib/enigma2/python/Plugins/Extensions/MultiIptvAdder/multi_iptv_adder.sh"
        if os.path.exists(script_path):
            os.system(script_path)
        else:
            self.session.open(MessageBox, "Shell script not found!", MessageBox.TYPE_ERROR)

    def close(self):
        config.plugins.MultiIptvAdder.url.value = "http://example.com"
        config.plugins.MultiIptvAdder.port.value = "8080"
        config.plugins.MultiIptvAdder.username.value = "user"
        config.plugins.MultiIptvAdder.password.value = "pass"
        config.plugins.MultiIptvAdder.save()
        Screen.close(self)

def main(session, **kwargs):
    session.open(MultiIptvAdderScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="MultiIptvAdder",
            description="Add IPTV playlists",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="icon.png"
        )
    ]




