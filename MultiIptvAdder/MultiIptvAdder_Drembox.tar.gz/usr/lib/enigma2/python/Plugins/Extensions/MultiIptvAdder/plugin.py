# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigText, ConfigSubsection, getConfigListEntry
from Components.ActionMap import ActionMap
from Components.Button import Button
from Plugins.Plugin import PluginDescriptor
import os
import urllib2
from urllib2 import HTTPError, URLError
import ConfigParser

config.plugins.MultiIptvAdder = ConfigSubsection()
config.plugins.MultiIptvAdder.url = ConfigText(default="http://example.com", fixed_size=False)
config.plugins.MultiIptvAdder.port = ConfigText(default="8080", fixed_size=False)
config.plugins.MultiIptvAdder.username = ConfigText(default="user", fixed_size=False)
config.plugins.MultiIptvAdder.password = ConfigText(default="pass", fixed_size=False)

class CaseSensitiveConfigParser(ConfigParser.RawConfigParser):
    def optionxform(self, optionstr):
        return optionstr
    
    def write(self, fp):
        for section in self._sections:
            fp.write("[%s]\n" % section)
            for (key, value) in self._sections[section].items():
                if key != "__name__":
                    fp.write("%s=%s\n" % (key, value))
            fp.write("\n")

class MultiIptvAdderScreen(ConfigListScreen, Screen):
    skin = """
        <screen position="center,center" size="800,400" title="Multi IPTV Adder">
            <widget name="config" position="10,10" size="780,300" scrollbarMode="showOnDemand" />
            <widget name="key_red" position="10,350" size="240,40" backgroundColor="red" font="Regular;35" valign="center" halign="center" />
            <widget name="key_green" position="280,350" size="240,40" backgroundColor="green" font="Regular;35" valign="center" halign="center" />
            <widget name="key_blue" position="550,350" size="240,40" backgroundColor="blue" font="Regular;35" valign="center" halign="center" />
        </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self.list = [
            getConfigListEntry("URL:", config.plugins.MultiIptvAdder.url),
            getConfigListEntry("Port:", config.plugins.MultiIptvAdder.port),
            getConfigListEntry("Username:", config.plugins.MultiIptvAdder.username),
            getConfigListEntry("Password:", config.plugins.MultiIptvAdder.password),
        ]

        ConfigListScreen.__init__(self, self.list)

        self["key_red"] = Button("Exit")
        self["key_green"] = Button("Send")
        self["key_blue"] = Button("Check Server")

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "red": self.close,
            "green": self.send_data,
            "blue": self.check_data,
            "ok": self.keyOK,
            "cancel": self.close,
        }, -1)

    def keyOK(self):
        current = self["config"].getCurrent()
        if current:
            self.openKeyboard(current[1])

    def openKeyboard(self, entry):
        self.session.openWithCallback(
            lambda x: self.keyboardCallback(x, entry),
            VirtualKeyBoard,
            title="Enter value:",
            text=entry.value
        )

    def keyboardCallback(self, text, entry):
        if text is not None:
            entry.value = text
            self["config"].invalidateCurrent()

    def send_data(self):
        if self.is_default_data():
            self.session.open(MessageBox, "Default data not changed!", MessageBox.TYPE_ERROR)
            return
        self.save_data()
        self.session.open(MessageBox, "Data sent successfully!", MessageBox.TYPE_INFO)

    def is_default_data(self):
        url = config.plugins.MultiIptvAdder.url.value.rstrip('/')
        port = config.plugins.MultiIptvAdder.port.value
        username = config.plugins.MultiIptvAdder.username.value
        password = config.plugins.MultiIptvAdder.password.value

        return (
            url == "http://example.com" and
            port == "8080" and
            username == "user" and
            password == "pass"
        )

    def save_data(self):
        url = config.plugins.MultiIptvAdder.url.value.rstrip('/')
        port = config.plugins.MultiIptvAdder.port.value
        username = config.plugins.MultiIptvAdder.username.value
        password = config.plugins.MultiIptvAdder.password.value

        full_url = "%s:%s/get.php?username=%s&password=%s&type=m3u&output=ts\n" % (
            url, port, username, password
        )

        files_to_save = [
            "/etc/enigma2/bouquetmakerxtream/playlists.txt",
            "/etc/enigma2/jediplaylists/playlists.txt",
            "/etc/enigma2/xklass/playlists.txt",
            "/etc/enigma2/xstreamity/playlists.txt",
            "/etc/enigma2/e2iplayer/playlists.txt",
            "/etc/enigma2/xc/xclink.txt"
        ]

        for file_path in files_to_save:
            try:
                directory = os.path.dirname(file_path)
                if not os.path.exists(directory):
                    os.makedirs(directory)
                with open(file_path, "a") as f:
                    f.write(full_url)
            except Exception as e:
                print "Error saving to %s: %s" % (file_path, str(e))

        iptosat_path = "/etc/enigma2/iptosat.conf"
        try:
            config_parser = CaseSensitiveConfigParser()
            if os.path.exists(iptosat_path):
                config_parser.read(iptosat_path)
            
            if not config_parser.has_section('IPtoSat'):
                config_parser.add_section('IPtoSat')
            
            config_parser.set('IPtoSat', 'Host', "%s:%s" % (url, port))
            config_parser.set('IPtoSat', 'User', username)
            config_parser.set('IPtoSat', 'Pass', password)
            
            with open(iptosat_path, 'w') as configfile:
                config_parser.write(configfile)
                
        except Exception as e:
            print "Error saving to %s: %s" % (iptosat_path, str(e))

        self.run_shell_script()

    def check_data(self):
        url = config.plugins.MultiIptvAdder.url.value.rstrip('/')
        port = config.plugins.MultiIptvAdder.port.value
        username = config.plugins.MultiIptvAdder.username.value
        password = config.plugins.MultiIptvAdder.password.value

        test_result = self.test_server_connection(url, port, username, password)
        info_message = (
            "Server URL:\n%s:%s/get.php\n"
            "Username: %s\n"
            "Password: %s\n"
            "\nConnection Check: %s"
        ) % (url, port, username, password, test_result)

        self.session.open(MessageBox, info_message, MessageBox.TYPE_INFO)

    def test_server_connection(self, url, port, username, password):
        try:
            test_url = "%s:%s/get.php?username=%s&password=%s&type=m3u&output=ts" % (
                url, port, username, password
            )
            req = urllib2.Request(test_url)
            response = urllib2.urlopen(req, timeout=10)
            if response.getcode() == 200:
                return "Connection Successful"
            else:
                return "Invalid Response (Code: %s)" % response.getcode()
        except HTTPError as e:
            return "HTTP Error: %s" % e.code
        except URLError as e:
            return "URL Error: %s" % e.reason
        except Exception as e:
            return "General Error: %s" % str(e)

    def run_shell_script(self):
        script_path = "/usr/lib/enigma2/python/Plugins/Extensions/MultiIptvAdder/multi_iptv_adder.sh"
        if os.path.exists(script_path):
            os.system("sh " + script_path)
        else:
            print "Shell script not found: %s" % script_path

    def close(self):
        config.plugins.MultiIptvAdder.url.save()
        config.plugins.MultiIptvAdder.port.save()
        config.plugins.MultiIptvAdder.username.save()
        config.plugins.MultiIptvAdder.password.save()
        Screen.close(self)

def main(session, **kwargs):
    session.open(MultiIptvAdderScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Multi IPTV Adder",
            description="Add IPTV playlists to multiple plugins",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            fnc=main,
            icon="/usr/lib/enigma2/python/Plugins/Extensions/MultiIptvAdder/icon.png"
        )
    ]