from Plugins.Plugin import PluginDescriptor
from .LiveMatch import main as LiveMatchMain

def menuHook(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("LiveMatch", LiveMatchMain, "matchlive_menu", 46)]
    return []

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="LiveMatch",
            description="Live football scores",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icons/LiveMatch.png",
            fnc=LiveMatchMain
        ),
        PluginDescriptor(
            name="LiveMatch",
            description="Live football scores",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=LiveMatchMain
        ),
        PluginDescriptor(
            name="LiveMatch",
            description="Live football scores",
            where=PluginDescriptor.WHERE_MENU,
            fnc=menuHook
        ),
    ]

