#!/bin/sh
echo "Checking dependencie python requests"
echo ""
echo "Updating feeds"
opkg update
echo ""
if python -c "import requests" &> /dev/null; then
	echo "Requests library already installed"
else
	opkg install python3-requests
fi
exit 0
