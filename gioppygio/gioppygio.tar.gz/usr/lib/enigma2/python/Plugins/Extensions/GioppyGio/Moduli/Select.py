# -*- coding: UTF-8 -*-
# Please don't remove this disclaimer
# code by Madhouse
_L=' \xa0 '
_K='Select All'
_J='/usr/lib/enigma2/python/Plugins/Extensions/GioppyGio/Moduli/Settings/Select'
_I='Key_Blue'
_H='Key_Yellow'
_G='dateDow'
_F='text'
_E='namesat'
_D='bouquets.tv'
_C=True
_B='1'
_A='B'
from.import _
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Plugins.Plugin import PluginDescriptor
from Tools.LoadPixmap import LoadPixmap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.MultiContent import MultiContentEntryText,MultiContentEntryPixmapAlphaTest
import sys,os,glob,shutil
from.Config import*
from enigma import getDesktop,eListboxPythonMultiContent,gFont,RT_HALIGN_LEFT,RT_HALIGN_RIGHT,RT_VALIGN_CENTER,RT_HALIGN_CENTER,eDVBDB
if getDesktop(0).size().width()==1920:skins='/usr/lib/enigma2/python/Plugins/Extensions/GioppyGio/Skin/fhd/';giopath='/usr/lib/enigma2/python/Plugins/Extensions/GioppyGio/Panel/'
else:skins='/usr/lib/enigma2/python/Plugins/Extensions/GioppyGio/Skin/hd/';giopath='/usr/lib/enigma2/python/Plugins/Extensions/GioppyGio/Panel/default/'
class MenuListSelect(MenuList):
	def __init__(self,list,enableWrapAround=_C):
		A='gioppyregular';MenuList.__init__(self,list,enableWrapAround,eListboxPythonMultiContent);screenwidth=getDesktop(0).size().width()
		if screenwidth and screenwidth==1920:self.l.setFont(0,gFont(A,32));self.l.setFont(1,gFont(A,24));self.l.setItemHeight(80)
		else:self.l.setFont(0,gFont(A,20));self.l.setFont(1,gFont(A,14));self.l.setItemHeight(50)
class ListSelect:
	def __init__(self):0
	def readSaveList(self):
		try:
			with open(_J)as jw:jjw=jw.readlines()
			list=[]
			for x in jjw:
				try:
					jx=x.strip().split('---',1)
					if len(jx)==2:list.append((jx[0],jx[1]))
				except Exception as e:print('[ListSelect] Error parsing line:',x,e)
			return list
		except IOError:print('[ListSelect] Select file not found or not readable.');return[]
		except Exception as e:print('[ListSelect] Error reading Select file:',e);return[]
	def SaveList(self,list_to_save):
		try:
			with open(_J,'w')as jw:
				for(dir,name)in list_to_save:jw.write(dir+'---'+name+'\n')
		except Exception as e:print('[ListSelect] Error saving Select file:',e)
	def readBouquetsList(self,pwd,bouquetname):
		try:f=open(pwd+'/'+bouquetname)
		except Exception as e:print('[ListSelect] Error opening bouquet file:',pwd+'/'+bouquetname,e);return[]
		ret=[]
		with f:
			while _C:
				line=f.readline()
				if line=='':break
				line=line.strip()
				if not line.startswith('#SERVICE'):continue
				parts=line.split(':')
				if len(parts)>10:
					service_ref_data=parts[10]
					if service_ref_data.startswith('FROM BOUQUET "'):filename=service_ref_data.split('"')[1]
					else:filename=None
					if filename:
						bouquet_path=os.path.join(pwd,filename);bouquet_name=filename
						try:
							with open(bouquet_path)as fb:
								first_line=fb.readline().strip()
								if first_line.startswith('#NAME '):bouquet_name=first_line[6:].strip()
						except IOError:print(f"[ListSelect] Warning: Could not read bouquet file {bouquet_path} referenced in {bouquetname}")
						except Exception as e_inner:print(f"[ListSelect] Error reading NAME from {bouquet_path}: {e_inner}")
						ret.append([filename,bouquet_name])
		return ret
	def readBouquetsTvList(self,pwd):return self.readBouquetsList(pwd,_D)
	def TvList(self):
		jload=self.readSaveList();self.bouquetlist=[];selected_map={(dir,name)for(dir,name)in jload};all_bouquets=self.readBouquetsTvList('/etc/enigma2')
		if not all_bouquets:print('[ListSelect] Warning: No bouquets found in /etc/enigma2/bouquets.tv')
		for(bq_dir,bq_name)in all_bouquets:value=_B if(bq_dir,bq_name)in selected_map else'0';self.bouquetlist.append((bq_dir,bq_name,value))
		return self.bouquetlist
class MenuSelect(Screen):
	def __init__(self,session):
		A=False;self.session=session
		if getDesktop(0).size().width()==1920:skin_path=skins+'MenuSelectfhd.xml'
		else:skin_path=skins+'MenuSelecthd.xml'
		with open(skin_path,'r')as f:self.skin=f.read()
		Screen.__init__(self,session);self.ListSelect=ListSelect();self[_E]=Label('');self[_F]=Label('');self[_G]=Label('');self['Key_Red']=Label(_('Exit'));self['Key_Green']=Label(_('Customize'));self[_H]=Label(_('Move'));self[_I]=Label(_(_K));self['Key_Personal']=Label('');self['version']=Label(_('Settings & Picons V.%s by GioppyGio')%version);self['A']=MenuListSelect([]);self[_A]=MenuListSelect([]);self[_A].selectionEnabled(1);self.jA=[];self.jB=[];self.move_mode=A;self.all_selected=A;self['actions']=ActionMap(['OkCancelActions','ColorActions','SetupActions','DirectionActions','ChannelSelectBaseActions'],{'ok':self.OkSelect,'up':self.keyUp,'down':self.keyDown,'green':self.saveAndPersonalize,'yellow':self.toggleMoveMode,'blue':self.selectAll,'cancel':self.close_screen,'left':self[_A].pageUp,'right':self[_A].pageDown,'nextBouquet':self[_A].pageUp,'prevBouquet':self[_A].pageDown,'red':self.close_screen},-2);self.onLayoutFinish.append(self.initialLoad)
	def initialLoad(self):self.Info();self.Menu();self.MenuA();self.updateYellowKeyLabel();self._update_blue_button_text()
	def close_screen(self):self.close()
	def Info(self):
		try:Type,AutoTimer,Personal,NumberSat,NameSat,Date,NumberDtt,DowDate,NameInfo=Load();newdate=''if str(Date)=='0'else f" - {ConverDate(Date)}";newDowDate=_('Last Update: Never')if str(DowDate)=='0'else f"{_('Last Update: ')}{DowDate}";self[_E].setText(f"{NameInfo}{newdate}");self[_G].setText(newDowDate)
		except Exception:self[_E].setText(_('Error loading info'));self[_G].setText('')
	def saveAndPersonalize(self):
		selected_count=sum(1 for entry in self.jA if entry[0][2]==_B)
		if selected_count==0:self.session.open(MessageBox,_('You have not selected any bouquet!'),MessageBox.TYPE_INFO)
		else:self.session.openWithCallback(self.doPersonalizeBouquets,MessageBox,_('Save the current order and selection and reload bouquets?'),MessageBox.TYPE_YESNO)
	def doPersonalizeBouquets(self,result):
		B='userbouquet.*.tv';A='*.*'
		if result is _C:
			backup_folder='/etc/enigma2/SelectFolder_backup';enigma2_path='/etc/enigma2/'
			try:
				if not os.path.exists(backup_folder):os.makedirs(backup_folder)
				else:
					for f in glob.glob(os.path.join(backup_folder,A)):os.remove(f)
				for filename in glob.glob(os.path.join(enigma2_path,B)):shutil.copy(filename,backup_folder)
				for filename in glob.glob(os.path.join(enigma2_path,_D)):shutil.copy(filename,backup_folder)
				for pattern in['*.bouquetmakerxtream*.tv','*.jmx*.tv','*.jedimakerxtream*.tv','*.iptvdiv.tv']:
					for filename in glob.glob(os.path.join(enigma2_path,pattern)):
						if os.path.basename(filename)not in[os.path.basename(f)for f in glob.glob(os.path.join(backup_folder,A))]:shutil.copy(filename,backup_folder)
				with open(os.path.join(enigma2_path,_D),'w')as Writebouquets:
					Writebouquets.write('#NAME User - bouquets (TV)\n')
					for entry in self.jA:
						dir_file,name,value=entry[0]
						if value==_B:line=f'#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "{dir_file}" ORDER BY bouquet\n';Writebouquets.write(line)
				referenced_files={entry[0][0]for entry in self.jA if entry[0][2]==_B}
				for filename in glob.glob(os.path.join(enigma2_path,B)):
					if os.path.basename(filename)not in referenced_files:os.remove(filename)
				eDVBDB.getInstance().reloadServicelist();eDVBDB.getInstance().reloadBouquets()
				for filename in glob.glob(os.path.join(enigma2_path,'*.del')):
					try:os.remove(filename)
					except OSError as e:print(f"Error removing {filename}: {e}")
				if os.path.exists(backup_folder)and os.path.isdir(backup_folder):shutil.rmtree(backup_folder)
				MyMessage=_('Bouquets order and selection saved successfully!');self.session.open(MessageBox,MyMessage,MessageBox.TYPE_INFO,timeout=5);self.close()
			except Exception:self.session.open(MessageBox,_('An error occurred while saving bouquets.\nCheck the log for details.'),MessageBox.TYPE_ERROR)
		else:print('[MenuSelect] Bouquet personalization cancelled by user.')
	def toggleMoveMode(self):self.move_mode=not self.move_mode;self.updateYellowKeyLabel()
	def updateYellowKeyLabel(self):
		if self.move_mode:self[_H].setText(_('Moving (UP/DOWN)'))
		else:self[_H].setText(_('Move (Toggle)'))
	def keyUp(self):
		if self.move_mode:self.moveItem(-1)
		else:self[_A].up()
	def keyDown(self):
		if self.move_mode:self.moveItem(1)
		else:self[_A].down()
	def moveItem(self,direction):
		idx=self[_A].getSelectedIndex();list_len=len(self.jA)
		if not 0<=idx<list_len:return
		current_selection=self[_A].getCurrent()
		if current_selection:
			current_value=current_selection[0][2]
			if current_value==_B:
				if direction==-1 and idx>0:self.jA[idx],self.jA[idx-1]=self.jA[idx-1],self.jA[idx];self[_A].setList(self.jA);self[_A].moveToIndex(idx-1);self._update_selected_list();self.MenuA()
				elif direction==1 and idx<list_len-1:self.jA[idx],self.jA[idx+1]=self.jA[idx+1],self.jA[idx];self[_A].setList(self.jA);self[_A].moveToIndex(idx+1);self._update_selected_list();self.MenuA()
				else:0
			else:self.session.open(MessageBox,_('The bouquet to be moved must first be selected!'),MessageBox.TYPE_ERROR)
	def hauptListEntry(self,dir,name,value):
		res=[(dir,name,value)];width=getDesktop(0).size().width();fhd=width==1920;icon_path_on=giopath+('gg_on.png'if fhd else'gg_onhd.png');icon_path_off=giopath+('gg_off.png'if fhd else'gg_offhd.png');icon=icon_path_off if value==_B else icon_path_on
		try:display_name=name.split(_L)[0]
		except:display_name=name
		if fhd:res.append(MultiContentEntryText(pos=(73,8),size=(625,45),font=0,text=display_name,flags=RT_HALIGN_LEFT));res.append(MultiContentEntryPixmapAlphaTest(pos=(20,13),size=(30,30),png=LoadPixmap(cached=_C,path=icon)))
		else:res.append(MultiContentEntryText(pos=(43,3),size=(625,45),font=0,text=display_name,flags=RT_HALIGN_LEFT));res.append(MultiContentEntryPixmapAlphaTest(pos=(8,5),size=(30,30),png=LoadPixmap(cached=_C,path=icon)))
		return res
	def hauptListEntryA(self,name):
		res=[name];width=getDesktop(0).size().width();fhd=width==1920
		try:display_name=name.split(_L)[0]
		except:display_name=name
		if fhd:res.append(MultiContentEntryText(pos=(20,4),size=(339,36),font=0,text=display_name,flags=RT_HALIGN_LEFT))
		else:res.append(MultiContentEntryText(pos=(10,0),size=(233,26),font=0,text=display_name,flags=RT_HALIGN_LEFT))
		return res
	def MenuA(self):
		self.jB=[]
		for entry in self.jA:
			dir_file,name,value=entry[0]
			if value==_B:self.jB.append(self.hauptListEntryA(name))
		self['A'].setList(self.jB)
		if not self.jB:self[_F].setText(_('Please select\nwhat you want\nto keep!'))
		else:self[_F].setText(' ')
		self[_A].selectionEnabled(1);self['A'].selectionEnabled(0)
	def Menu(self):
		self.jA=[];bouquet_data=self.ListSelect.TvList()
		for(dir_file,name,value)in bouquet_data:self.jA.append(self.hauptListEntry(dir_file,name,value))
		self[_A].setList(self.jA);self._update_blue_button_text()
	def OkSelect(self):
		current_selection=self[_A].getCurrent()
		if not current_selection:return
		idx=self[_A].getSelectedIndex()
		if 0<=idx<len(self.jA):dir_file,name,current_value=self.jA[idx][0];new_value=_B if current_value=='0'else'0';self.jA[idx]=self.hauptListEntry(dir_file,name,new_value);self[_A].setList(self.jA);self[_A].moveToIndex(idx);self._update_selected_list();self._update_blue_button_text();self.MenuA()
		else:print(f"[MenuSelect] Error OkSelect: Selected index {idx} out of bounds for self.jA (len={len(self.jA)})")
	def selectAll(self):
		new_value='0'if self.all_selected else _B;new_list=[]
		for entry in self.jA:dir_file,name,_=entry[0];new_list.append(self.hauptListEntry(dir_file,name,new_value))
		self.jA=new_list;self[_A].setList(self.jA);self.all_selected=not self.all_selected;self._update_selected_list();self._update_blue_button_text();self.MenuA()
	def _update_selected_list(self):
		list_to_save_select=[]
		for entry in self.jA:
			d,n,v=entry[0]
			if v==_B:list_to_save_select.append((d,n))
		if self.ListSelect:self.ListSelect.SaveList(list_to_save_select)
	def _update_blue_button_text(self):
		all_items_selected=all(entry[0][2]==_B for entry in self.jA)
		if all_items_selected:self[_I].setText(_('Deselect All'))
		else:self[_I].setText(_(_K))
