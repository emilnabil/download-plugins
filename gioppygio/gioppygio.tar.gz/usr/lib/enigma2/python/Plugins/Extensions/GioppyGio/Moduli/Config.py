# -*- coding: UTF-8 -*-
# Please don't remove this disclaimer
# Code by Madhouse
_A='0'
import os,sys,xml.etree.cElementTree as ET
from.Setting import*
from io import BytesIO
version='1.4'
def OnclearMem():os.system('sync');os.system('echo 3 > /proc/sys/vm/drop_caches')
Directory=os.path.dirname(sys.modules[__name__].__file__)
if not os.path.exists(f"{Directory}/Settings"):os.system(f"mkdir {Directory}/GioppyGio")
if not os.path.exists(f"{Directory}/Settings/Temp"):os.system(f"mkdir {Directory}/Settings/Temp")
def ConverDate(Date):
	if not Date:return
	day=Date[:2];month=Date[-6:][:2];year=Date[-4:];return f"{day}-{month}-{year}"
def Downloadxml():
	import requests
	try:
		UrlGitXml='https://raw.githubusercontent.com/GioppyGio/list-xml/main/new_set.xml';Header={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'};response=requests.get(UrlGitXml,headers=Header,timeout=(3,2))
		if response.status_code==200:return response.content
		else:return
	except requests.exceptions.RequestException as e:print(f"Error: {e}");return
def DownloadSetting():
	A=None;ListSettings=[]
	try:
		xml_content=Downloadxml()
		if xml_content is A:return ListSettings
		mdom=ET.parse(BytesIO(xml_content));root=mdom.getroot();rule_sets=['Sat','Satdual','Sattrial','Satquadri','Satmotor','dtt']
		for ruleset_name in rule_sets:
			ruleset=next((x for x in root if x.tag=='ruleset'and x.get('name')==ruleset_name),A)
			if ruleset is not A:
				for rule in ruleset:
					if rule.tag=='rule'and rule.get('type')=='Marker':NumberSat=rule.get('Number','');NameSat=rule.get('Name','');LinkSat=rule.get('Link','');DateSat=rule.get('Date','');ListSettings.append((NumberSat,NameSat,LinkSat,DateSat,_A,_A,_A,_A))
			else:print(f"Warning: ruleset '{ruleset_name}'.")
	except Exception as e:print(f"Error parsing XML: {e}")
	return ListSettings
def Load():
	I='NameInfo';H='DowDate';G='NumberDtt';F='jDateSat';E='NameSat';D='NumberSat';C='Personal';B='Type';A='AutoTimer';defaults={A:_A,B:_A,C:_A,D:'1',E:'Mono (13°E)',F:_A,G:_A,H:_A,I:_A};settings_file=os.path.join(Directory,'Settings','Date')
	if os.path.exists(settings_file):
		try:
			with open(settings_file,'r')as f:
				for line in f:
					if'='in line:
						key,value=line.strip().split('=',1);key=key.strip();value=value.strip()
						if key in defaults:defaults[key]=value
		except Exception:pass
	else:
		os.makedirs(os.path.dirname(settings_file),exist_ok=True)
		with open(settings_file,'w')as f:
			for(key,value)in defaults.items():f.write(f"{key} = {value}\n")
	return defaults[B],defaults[A],defaults[C],defaults[D],defaults[E],defaults[F],defaults[G],defaults[H],defaults[I]
def WriteSave(Type,AutoTimer,Personal,NumberSat,NameSat,Date,NumberDtt,DowDate,NameInfo):
	lines=[f"AutoTimer = {AutoTimer}\n",f"Type = {Type}\n",f"Personal = {Personal}\n",f"NumberSat = {NumberSat}\n",f"NameSat = {NameSat}\n",f"jDateSat = {Date}\n",f"NumberDtt = {NumberDtt}\n",f"DowDate = {DowDate}\n",f"NameInfo = {NameInfo}\n"]
	with open(f"{Directory}/Settings/Date",'w')as xf:xf.writelines(lines)
