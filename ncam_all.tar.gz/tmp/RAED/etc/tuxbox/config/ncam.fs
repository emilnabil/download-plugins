#### "*******************************************"
#### "*          << RAED - fairbird >>          *"
#### "*******************************************"
#### "****************************************************************"             
#### "*Read more: https://www.tunisia-sat.com/forums/threads/3539021/*"
#### "****************************************************************"
##################################
# To Enable Free Server delete #
##################################
######### TivuSat (Not Stable - غير ثابت) ###################
#https://cardshare.us 17002
#https://cardshare.us 27005
#https://cardshare.us 35002
#https://cardshare.us 46005
#https://cardshare.us 57002
############################################################
#SERVER1 # Working
#SERVER16
#SERVER19
#SERVER21
#SERVER22
############################################################ 
### These servers working but need some seconds to pring C line And Activte it - هذه السيرفرات تعمل ولكن تحتاج إلى ثواني لتتفعل
#SERVER2
#SERVER3
#SERVER9
#SERVER1
#SERVER11
########################################################
#SERVER0 ## more than 50 server in one server (Some Stable - ثابت نسبياًُ)
#SERVER30 ## more than 50 server in one server (Some Stable - ثابت نسبياًُ)
#SERVER31 ## more than 100 server in one server (Not Stable - غير ثابت)
