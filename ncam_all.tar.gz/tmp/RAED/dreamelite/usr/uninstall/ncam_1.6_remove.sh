#!/bin/sh

########################################
######      Edited by RAED        ######
########################################

killall -9 ncam
sleep 5
rm -rf /usr/bin/ncam
rm -rf /usr/script/ncam_1.6_em.sh
rm -rf /usr/uninstall/ncam_1.6_remove.sh

exit 0
