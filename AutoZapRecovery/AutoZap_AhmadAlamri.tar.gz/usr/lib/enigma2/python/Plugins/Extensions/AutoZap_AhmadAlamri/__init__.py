# -*- coding: utf-8 -*-
# AutoZap Recovery by Ahmad Alamri
