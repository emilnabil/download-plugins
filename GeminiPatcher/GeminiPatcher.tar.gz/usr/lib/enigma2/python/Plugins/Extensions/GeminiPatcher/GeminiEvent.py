# -*- coding: utf-8 -*-
from Components.Converter.Converter import Converter
from Components.Element import cached
import os
import json
import codecs

# دالة تحديد مسار الكاش (مدمجة لضمان العمل من أي مكان)
def get_cache_file():
    filename = "gemini_cache.json"
    paths = ["/media/hdd", "/media/usb", "/media/mmc", "/tmp"]
    
    # البحث عن ملف موجود
    for p in paths:
        full = os.path.join(p, filename)
        if os.path.exists(full):
            return full
            
    # العودة للمسار الافتراضي إذا لم يوجد
    for p in paths:
        if os.path.exists(p):
            return os.path.join(p, filename)
    return "/tmp/" + filename

CACHE_FILE = get_cache_file()

class GeminiEvent(Converter, object):
    # تعريف الثوابت كما في Enigma2 الأصلي
    NAME = 0
    SHORT_DESCRIPTION = 1
    EXTENDED_DESCRIPTION = 2
    FULL_DESCRIPTION = 3
    ID = 4

    def __init__(self, type):
        Converter.__init__(self, type)
        # تحديد النوع بدقة كما يطلبه السكين
        if type == "Name":
            self.type = self.NAME
        elif type == "ShortDescription":
            self.type = self.SHORT_DESCRIPTION
        elif type == "ExtendedDescription":
            self.type = self.EXTENDED_DESCRIPTION
        elif type == "FullDescription":
            self.type = self.FULL_DESCRIPTION
        elif type == "ID":
            self.type = self.ID
        else:
            # افتراضي
            self.type = self.NAME

    @cached
    def getText(self):
        event = self.source.event
        if event is None:
            return ""
            
        # إذا طلب السكين ID، نعيده فوراً (لا يحتاج ترجمة)
        if self.type == self.ID:
            return str(event.getEventId())

        original_name = event.getEventName()
        if not original_name:
            return ""

        # --- محاولة جلب الترجمة ---
        search_name = original_name.strip()
        translated_title = None
        translated_desc = None
        
        # نحدث مسار الكاش في كل مرة لضمان التزامن
        current_cache = get_cache_file()
        
        if os.path.exists(current_cache):
            try:
                with codecs.open(current_cache, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                item = data.get(search_name)
                if item:
                    translated_title = item.get("title")
                    translated_desc = item.get("desc")
            except:
                pass

        # --- منطق العرض ---
        
        # 1. إذا طلب الاسم (Name)
        if self.type == self.NAME:
            if translated_title:
                return str(translated_title)
            return original_name

        # 2. إذا طلب أي نوع من الوصف (Description)
        # Gemini يعطينا وصفاً واحداً شاملاً، لذا نستخدمه لكل أنواع الوصف في حال توفره
        if translated_desc:
            return str(translated_desc)

        # 3. Fallback (في حال عدم وجود ترجمة)
        # هنا نعيد البيانات الأصلية بدقة حسب طلب السكين لتجنب اختفاء EPG
        if self.type == self.SHORT_DESCRIPTION:
            return event.getShortDescription()
        
        elif self.type == self.EXTENDED_DESCRIPTION:
            return event.getExtendedDescription()
            
        elif self.type == self.FULL_DESCRIPTION:
            # المنطق القياسي لـ FullDescription في Enigma2
            short = event.getShortDescription()
            ext = event.getExtendedDescription()
            if short and ext:
                return short + "\n" + ext
            elif short:
                return short
            elif ext:
                return ext
            return ""
            
        return ""

    text = property(getText)

    def changed(self, what):
        Converter.changed(self, what)