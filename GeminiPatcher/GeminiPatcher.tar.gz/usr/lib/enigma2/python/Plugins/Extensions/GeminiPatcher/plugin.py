# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.LocationBox import LocationBox
from Screens.Standby import TryQuitMainloop
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigText, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Tools.Directories import fileExists, resolveFilename, SCOPE_SKIN
import os
import re
import shutil
from twisted.internet import threads

# --- بصمتك ---
MY_SIGNATURE = "Mod by: Smoo.sa" 

try:
    from . import gemini_api
except ImportError:
    import gemini_api

def get_lang():
    try: return config.osd.language.value
    except: return "en_EN"

def _(en, ar):
    if "ar" in get_lang().lower(): return ar
    return en

config.plugins.GeminiEPG = ConfigSubsection()
config.plugins.GeminiEPG.apikey = ConfigText(default="", visible_width=80, fixed_size=False)

class GeminiMainScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.main_title = "Gemini AI EPG Patcher"
        
        self.skin = """
        <screen name="GeminiMainScreen" position="center,center" size="1000,600" title="{title}" flags="wfNoBorder" backgroundColor="#101010">
            <eLabel position="0,0" size="1000,55" backgroundColor="#1a1a1a" zPosition="-1" />
            <widget name="title_header" position="20,10" size="600,40" font="Regular;32" foregroundColor="#ffd700" backgroundColor="#1a1a1a" transparent="1" valign="center" />
            <widget name="status" position="500,15" size="480,30" font="Regular;22" foregroundColor="#00ff00" backgroundColor="#1a1a1a" halign="right" transparent="1" valign="center" />
            <eLabel position="0,55" size="1000,2" backgroundColor="#ffd700" />
            
            <eLabel position="20,70" size="960,220" backgroundColor="#202020" zPosition="-1" />
            <widget name="lbl_curr" position="30,75" size="940,30" font="Regular;24" foregroundColor="#00ccff" backgroundColor="#202020" transparent="1" />
            <widget name="curr_title" position="30,110" size="940,35" font="Regular;28" foregroundColor="#ffffff" backgroundColor="#202020" transparent="1" />
            <widget name="curr_desc" position="30,150" size="940,130" font="Regular;22" foregroundColor="#cccccc" backgroundColor="#202020" transparent="1" />

            <eLabel position="20,305" size="960,220" backgroundColor="#202020" zPosition="-1" />
            <widget name="lbl_next" position="30,310" size="940,30" font="Regular;24" foregroundColor="#ffa500" backgroundColor="#202020" transparent="1" />
            <widget name="next_title" position="30,345" size="940,35" font="Regular;28" foregroundColor="#ffffff" backgroundColor="#202020" transparent="1" />
            <widget name="next_desc" position="30,385" size="940,130" font="Regular;22" foregroundColor="#cccccc" backgroundColor="#202020" transparent="1" />

            <eLabel position="0,545" size="1000,55" backgroundColor="#1a1a1a" zPosition="-1" />
            <widget name="key_green" position="20,552" size="230,40" font="Regular;24" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" halign="center" valign="center" zPosition="1" />
            <widget name="key_yellow" position="265,552" size="230,40" font="Regular;24" foregroundColor="#000000" backgroundColor="#ffff00" transparent="0" halign="center" valign="center" zPosition="1" />
            <widget name="key_blue" position="510,552" size="230,40" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#0000ff" transparent="0" halign="center" valign="center" zPosition="1" />
            <widget name="key_red" position="755,552" size="225,40" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#ff0000" transparent="0" halign="center" valign="center" zPosition="1" />
            <widget name="signature" position="830,510" size="150,30" font="Regular;18" foregroundColor="#777777" backgroundColor="#202020" halign="right" transparent="1" />
        </screen>""".format(title=self.main_title)

        self["title_header"] = Label(self.main_title)
        self["status"] = Label(_("Ready", "جاهز للعمل"))
        self["lbl_curr"] = Label(_("Current Event", "الحدث الحالي"))
        self["curr_title"] = Label("")
        self["curr_desc"] = Label("")
        self["lbl_next"] = Label(_("Next Event", "الحدث التالي"))
        self["next_title"] = Label("")
        self["next_desc"] = Label("")
        self["key_green"] = Label(_("Translate", "ترجمة"))
        self["key_yellow"] = Label(_("Patch Skin", "باتش السكين"))
        self["key_blue"] = Label(_("API Key", "مفتاح API"))
        self["key_red"] = Label(_("Exit", "خروج"))
        self["signature"] = Label(MY_SIGNATURE)

        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "green": self.start_translate,
            "ok": self.start_translate,
            "yellow": self.patch_skin_check,
            "blue": self.setup_key,
            "red": self.close,
            "cancel": self.close
        }, -1)
        
        self.onLayoutFinish.append(self.prepare_data)
        self.onLayoutFinish.append(self.inject_bundled_key)

    def inject_bundled_key(self):
        plugin_path = os.path.dirname(os.path.abspath(__file__))
        bundled_key_file = os.path.join(plugin_path, "gemini.key")
        if not os.path.exists(bundled_key_file): return
        targets = ["/media/hdd/keys", "/media/usb/keys"]
        for base_dir in targets:
            if os.path.exists(os.path.join(base_dir, "gemini.key")): return 
        injected = False
        target_path = ""
        for base_dir in targets:
            mount_point = os.path.dirname(base_dir)
            if os.path.exists(mount_point):
                if not os.path.exists(base_dir):
                    try: os.makedirs(base_dir)
                    except: continue
                try:
                    shutil.copyfile(bundled_key_file, os.path.join(base_dir, "gemini.key"))
                    target_path = os.path.join(base_dir, "gemini.key")
                    injected = True
                    break 
                except: pass
        if injected:
            self["status"].setText(_("Key Injected to: ", "تم نقل المفتاح إلى: ") + target_path)

    def prepare_data(self):
        service = self.session.nav.getCurrentService()
        info = service and service.info()
        self.ev_now = info and info.getEvent(0)
        self.ev_next = info and info.getEvent(1)
        if self.ev_now:
            self.now_t = self.ev_now.getEventName()
            self.now_d = (self.ev_now.getShortDescription() or "") + "\n" + (self.ev_now.getExtendedDescription() or "")
            self["curr_title"].setText(self.now_t)
            self["curr_desc"].setText(self.now_d)
            self.check_cache(self.now_t, "now")
        if self.ev_next:
            self.next_t = self.ev_next.getEventName()
            self.next_d = (self.ev_next.getShortDescription() or "") + "\n" + (self.ev_next.getExtendedDescription() or "")
            self["next_title"].setText(self.next_t)
            self["next_desc"].setText(self.next_d)
            self.check_cache(self.next_t, "next")

    def check_cache(self, title, type):
        try:
            import json, codecs
            cfile = "/tmp/gemini_cache.json"
            paths = ["/media/hdd", "/media/usb", "/media/mmc", "/tmp"]
            for p in paths:
                if os.path.exists(os.path.join(p, "gemini_cache.json")):
                    cfile = os.path.join(p, "gemini_cache.json")
                    break
            if os.path.exists(cfile):
                with codecs.open(cfile, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                key = title.strip()
                if key in data:
                    res = data[key]
                    if type == "now":
                        self["curr_title"].setText(res["title"])
                        self["curr_desc"].setText(res["desc"])
                    else:
                        self["next_title"].setText(res["title"])
                        self["next_desc"].setText(res["desc"])
        except: pass

    def start_translate(self):
        if not self.ev_now: return
        self["status"].setText(_("Translating Current...", "جاري ترجمة الحالي..."))
        txt = self.now_t + "\n" + self.now_d
        threads.deferToThread(gemini_api.get_translation, txt).addCallback(self.done_now).addErrback(self.error)

    def done_now(self, res):
        if res and "title" in res:
            self["curr_title"].setText(res["title"])
            self["curr_desc"].setText(res["desc"])
            if self.ev_next:
                self["status"].setText(_("Translating Next...", "جاري ترجمة التالي..."))
                txt = self.next_t + "\n" + self.next_d
                threads.deferToThread(gemini_api.get_translation, txt).addCallback(self.done_next).addErrback(self.error)
            else:
                self["status"].setText(_("Done", "تمت الترجمة"))
        else: self["status"].setText("Error Now")

    def done_next(self, res):
        if res and "title" in res:
            self["next_title"].setText(res["title"])
            self["next_desc"].setText(res["desc"])
            self["status"].setText(_("All Done", "تمت المهمة بنجاح"))
        else: self["status"].setText("Error Next")

    def error(self, err): self["status"].setText("Error: " + str(err))
    def setup_key(self): self.session.open(GeminiKeySetup)

    def patch_skin_check(self):
        current_skin = config.skin.primary_skin.value
        msg = _("Current Skin: ", "السكين الحالي: ") + current_skin + \
              _("\n\nDo you want to patch it? (Backup will be created)", "\n\nهل أنت متأكد من رغبتك في تعديله؟ (سيتم عمل نسخة احتياطية)")
        self.session.openWithCallback(self.do_patch, MessageBox, msg, MessageBox.TYPE_YESNO)

    def do_patch(self, ans):
        if ans:
            sk = resolveFilename(SCOPE_SKIN, config.skin.primary_skin.value)
            if not fileExists(sk): return
            shutil.copyfile(sk, sk + ".backup")
            with open(sk, 'r') as f: d = f.read()
            d = re.sub(r'(<convert type=")EventName(">Name</convert>)', r'\1GeminiEvent\2', d)
            d = re.sub(r'(<convert type=")EventName(">FullDescription</convert>)', r'\1GeminiEvent\2', d)
            d = re.sub(r'(<convert type=")EventName(">ExtendedDescription</convert>)', r'\1GeminiEvent\2', d)
            d = re.sub(r'(<convert type=")EventName(">ShortDescription</convert>)', r'\1GeminiEvent\2', d)
            
            # Smart copy logic
            base_dir = os.path.dirname(os.path.abspath(__file__))
            src_py = os.path.join(base_dir, "GeminiEvent.py")
            src_pyc = os.path.join(base_dir, "GeminiEvent.pyc")
            dst_dir = "/usr/lib/enigma2/python/Components/Converter/"
            if not os.path.exists(dst_dir): os.makedirs(dst_dir)
            try:
                if os.path.exists(src_py): shutil.copyfile(src_py, dst_dir + "GeminiEvent.py")
                elif os.path.exists(src_pyc): shutil.copyfile(src_pyc, dst_dir + "GeminiEvent.pyc")
                open(dst_dir + "__init__.py", 'a').close()
            except: pass
            
            with open(sk, 'w') as f: f.write(d)
            self.session.openWithCallback(self.restart, MessageBox, _("Restart GUI now?", "تم التعديل. إعادة التشغيل الآن؟"), MessageBox.TYPE_YESNO)

    def restart(self, ans):
        if ans: self.session.open(TryQuitMainloop, 3)

# --- كلاس إعداد المفتاح الجديد (بتصميم متطابق مع الرئيسية) ---
class GeminiKeySetup(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.title_txt = _("API Key Setup", "إعدادات المفتاح")
        
        self.skin = """
        <screen name="GeminiKeySetup" position="center,center" size="800,300" title="{title}" flags="wfNoBorder" backgroundColor="#101010">
            <eLabel position="0,0" size="800,50" backgroundColor="#1a1a1a" zPosition="-1" />
            <widget name="title_h" position="20,10" size="600,35" font="Regular;28" foregroundColor="#ffd700" backgroundColor="#1a1a1a" transparent="1" />
            <eLabel position="0,50" size="800,2" backgroundColor="#ffd700" />
            
            <widget name="config" position="20,80" size="760,50" font="Regular;26" backgroundColor="#101010" />
            
            <eLabel position="0,245" size="800,55" backgroundColor="#1a1a1a" zPosition="-1" />
            
            <widget name="btn_green" position="20,252" size="230,40" font="Regular;24" foregroundColor="#000000" backgroundColor="#00ff00" transparent="0" halign="center" valign="center" zPosition="1" />
            
            <widget name="btn_yellow" position="285,252" size="230,40" font="Regular;24" foregroundColor="#000000" backgroundColor="#ffff00" transparent="0" halign="center" valign="center" zPosition="1" />
            
            <widget name="btn_red" position="550,252" size="230,40" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#ff0000" transparent="0" halign="center" valign="center" zPosition="1" />
        </screen>""".format(title=self.title_txt)

        self["title_h"] = Label(_("Enter API Key or Select File", "أدخل المفتاح أو اختر ملف"))
        self["btn_green"] = Label(_("Save", "حفظ"))
        self["btn_yellow"] = Label(_("Browse File", "تحديد مسار"))
        self["btn_red"] = Label(_("Cancel", "إلغاء"))

        self.list = [getConfigListEntry("API Key:", config.plugins.GeminiEPG.apikey)]
        ConfigListScreen.__init__(self, self.list)
        
        self["actions"] = ActionMap(["ColorActions", "SetupActions"], {
            "green": self.save,
            "ok": self.save,
            "yellow": self.browse_key_file, # وظيفة التصفح الجديدة
            "red": self.close,
            "cancel": self.close
        }, -1)

    def browse_key_file(self):
        # فتح متصفح الملفات لاختيار المجلد الذي يحتوي على المفتاح
        try:
            self.session.openWithCallback(
                self.key_folder_selected,
                LocationBox,
                text=_("Select the folder containing 'gemini.key'", "اختر المجلد الذي يحتوي على ملف gemini.key"),
                currDir="/tmp/"
            )
        except Exception as e:
            self.session.open(MessageBox, "Error opening browser: " + str(e), MessageBox.TYPE_ERROR)

    def key_folder_selected(self, path):
        if path:
            # التحقق من وجود الملف في المسار المختار
            key_file = os.path.join(path, "gemini.key")
            if os.path.exists(key_file):
                try:
                    with open(key_file, 'r') as f:
                        key_value = f.read().strip()
                    
                    if key_value:
                        # تعبئة الخانة بالمفتاح المقروء
                        config.plugins.GeminiEPG.apikey.value = key_value
                        # تحديث العرض
                        self["config"].setList(self.list)
                        self.session.open(MessageBox, _("Key found and loaded!", "تم العثور على المفتاح وتحميله! اضغط حفظ."), MessageBox.TYPE_INFO)
                    else:
                        self.session.open(MessageBox, _("File is empty!", "الملف فارغ!"), MessageBox.TYPE_ERROR)
                except Exception as e:
                    self.session.open(MessageBox, "Read Error: " + str(e), MessageBox.TYPE_ERROR)
            else:
                self.session.open(MessageBox, _("gemini.key not found in this folder!", "ملف gemini.key غير موجود في هذا المجلد!"), MessageBox.TYPE_ERROR)

    def save(self):
        for x in self["config"].list: x[1].save()
        target = "/usr/keys/gemini.key"
        if os.path.exists("/media/hdd/keys"): target = "/media/hdd/keys/gemini.key"
        elif os.path.exists("/media/usb/keys"): target = "/media/usb/keys/gemini.key"
        else:
            if not os.path.exists("/usr/keys"): os.makedirs("/usr/keys")
        
        try:
            with open(target, "w") as f: f.write(config.plugins.GeminiEPG.apikey.value)
            self.close()
        except Exception as e:
            self.session.open(MessageBox, "Save Error: " + str(e), MessageBox.TYPE_ERROR)

def main(session, **kwargs): session.open(GeminiMainScreen)
def Plugins(**kwargs):
    name = "Gemini AI EPG Patcher"
    desc = "AI EPG Translator & Patcher"
    return [
        PluginDescriptor(name=name, description=desc, where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main),
        PluginDescriptor(name=name, description=desc, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)
    ]