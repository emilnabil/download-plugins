# -*- coding: utf-8 -*-
import os
import json
import codecs

# دالة ذكية لتحديد مسار الكاش الموحد
def get_cache_file_path():
    filename = "gemini_cache.json"
    possible_paths = [
        "/media/hdd",
        "/media/usb",
        "/media/mmc",
        "/tmp"
    ]
    
    # 1. البحث عن الملف إذا كان موجوداً مسبقاً (للحفاظ على الترجمات القديمة)
    for path in possible_paths:
        full_path = os.path.join(path, filename)
        if os.path.exists(full_path):
            return full_path
            
    # 2. إذا لم يوجد، نختار أفضل مسار لإنشاء الجديد (HDD > USB > TMP)
    for path in possible_paths:
        if os.path.exists(path):
            return os.path.join(path, filename)
            
    return "/tmp/" + filename

CACHE_FILE = get_cache_file_path()

# دالة البحث عن المفتاح
def get_api_key():
    key_paths = [
        "/media/hdd/keys/gemini.key",
        "/media/usb/keys/gemini.key",
        "/usr/keys/gemini.key"
    ]
    for key_file in key_paths:
        if os.path.exists(key_file):
            try:
                with open(key_file, 'r') as f:
                    return f.read().strip()
            except:
                pass
    return None

def save_to_cache(original_title_key, final_title, final_desc):
    current_cache = {}
    if os.path.exists(CACHE_FILE):
        try:
            with codecs.open(CACHE_FILE, 'r', encoding='utf-8') as f:
                current_cache = json.load(f)
        except:
            pass
    
    key = original_title_key.strip()
    current_cache[key] = {
        "title": final_title,
        "desc": final_desc
    }
    
    try:
        with codecs.open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(current_cache, f, ensure_ascii=False, indent=4)
    except:
        pass

def get_translation(text_to_translate):
    api_key = get_api_key()
    if not api_key:
        return {"error": "API Key Missing!"}

    original_title = text_to_translate.split('\n')[0].strip()
    
    # قراءة الكاش
    if os.path.exists(CACHE_FILE):
        try:
            with codecs.open(CACHE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if original_title in data:
                return data[original_title]
        except:
            pass

    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + api_key
    
    safe_text = text_to_translate.replace('"', ' ').replace("'", " ").strip()
    
    prompt = """
    Task: Translate TV event info.
    1. Title: Translate to Arabic / English.
    2. Description: Translate to Arabic.
    3. Output format strictly: Title ||| Description
    Input: %s
    """ % safe_text
    
    data = {"contents": [{"parts": [{"text": prompt}]}]}
    json_req = "/tmp/gemini_req.json"
    
    try:
        with codecs.open(json_req, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        
        cmd = 'curl -s -k --max-time 15 -H "Content-Type: application/json" -d @%s "%s"' % (json_req, url)
        stream = os.popen(cmd)
        output = stream.read()
        
        if os.path.exists(json_req):
            os.remove(json_req)

        if '"text":' in output:
            response = json.loads(output)
            raw = response['candidates'][0]['content']['parts'][0]['text'].strip()
            
            ft = ""
            fd = ""

            if "|||" in raw:
                parts = raw.split("|||")
                ft = parts[0].strip()
                fd = parts[1].strip() if len(parts) > 1 else ""
            else:
                ft = raw
                fd = raw
            
            save_to_cache(original_title, ft, fd)
            return {"title": ft, "desc": fd}
        else:
            return {"error": "API Error"}
            
    except Exception as e:
        return {"error": str(e)}