﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
CutsClear Plugin
Dynamic version loader for Enigma2
Compiled by iet5
"""

import os

# ============================================================================
# Read version dynamically
# ============================================================================
def get_version():
    """Read version from version.txt file"""
    version_file = os.path.join(os.path.dirname(__file__), 'version.txt')
    
    # Default fallback version
    default_version = "1.0"
    
    try:
        if os.path.exists(version_file):
            with open(version_file, 'r') as f:
                version_text = f.read().strip()
                return version_text if version_text else default_version
        else:
            return default_version
    except:
        return default_version

# Set version dynamically
__version__ = get_version()
__author__ = "iet5"
__license__ = "GPL"

# ============================================================================
# Export required components for Enigma2
# ============================================================================
# Important: These exports are required for Enigma2 plugin system
try:
    from plugin import PluginDescriptor, main, Plugins
except ImportError as e:
    # If import fails, it's OK - plugin.py will handle it
    pass