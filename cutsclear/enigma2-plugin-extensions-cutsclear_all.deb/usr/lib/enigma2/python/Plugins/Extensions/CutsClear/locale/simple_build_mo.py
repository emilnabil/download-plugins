cat > simple_build_mo.py << 'EOF'
#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys

def create_mo_file(po_file, mo_file):
    """Create a simple .mo file from .po file."""
    try:
        # For Dreambox, we can use an empty .mo file as workaround
        # The plugin will fall back to the original msgid if .mo is empty
        with open(mo_file, 'wb') as f:
            # Write minimal valid .mo header
            # Magic number, revision, count=0 (empty)
            f.write(b'\xde\x12\x04\x95')  # Magic number
            f.write(b'\x00\x00\x00\x00')  # Revision
            f.write(b'\x00\x00\x00\x00')  # Number of strings
            f.write(b'\x00\x00\x00\x1c')  # Offset of original table
            f.write(b'\x00\x00\x00\x1c')  # Offset of translation table
            f.write(b'\x00\x00\x00\x00')  # Size of hash table
            f.write(b'\x00\x00\x00\x00')  # Offset of hash table
        
        print(f"Created minimal .mo file: {mo_file}")
        print("Note: For full translation, install gettext tools:")
        print("opkg update && opkg install gettext")
        
    except Exception as e:
        print(f"Error: {str(e)}")

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    locale_dir = os.path.join(base_dir, "locale")
    
    for lang in ["ar", "en"]:
        po_path = os.path.join(locale_dir, lang, "LC_MESSAGES", "CutClear.po")
        mo_path = os.path.join(locale_dir, lang, "LC_MESSAGES", "CutClear.mo")
        
        if os.path.exists(po_path):
            create_mo_file(po_path, mo_path)
        else:
            print(f"Warning: {po_path} not found")

if __name__ == "__main__":
    main()
EOF

python simple_build_mo.py