from .koronaiptv import Korona


class OTTProvider(Korona):
	NAME = "TopIPTV"
