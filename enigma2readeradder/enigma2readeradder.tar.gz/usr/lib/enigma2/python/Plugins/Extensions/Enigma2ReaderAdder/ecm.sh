#!/bin/bash



# الحصول على SID عبر السكريبت الجديد
SID=$(python3 /usr/lib/enigma2/python/Components/Converter/GetSID.py)

CamName={"oscam","ncam"}

# مسارات الملفات
ecm_file="/tmp/ecm.info"
output_file="/etc/tuxbox/config/${CamName}.dvbapi"

# استخراج القيم من ecm.info
caid=$(grep 'caid: 0x' "$ecm_file" | awk '{print $2}' | sed 's/0x//' )
provid=$(grep 'prov: 0x' "$ecm_file" | awk '{print $2}' | sed 's/0x//')
pid=$(grep 'pid: 0x' "$ecm_file" | awk '{print $2}' | sed 's/0x//')
chid=$(grep 'chid: 0x' "$ecm_file" | awk '{print $2}' | sed 's/0x//')

# التحقق من وجود جميع الحقول
if [[ -z "$caid" || -z "$provid" || -z "$pid" || -z "$chid" ]]; then
    echo "Error: Missing data in $ecm_file"
    exit 1
fi

# إنشاء السطر الجديد
new_line="\nP: $caid:$provid:$SID:$pid:$chid"

# إضافة السطر إلى الملف الهدف
echo ""
echo "${new_line}" >> "$output_file"

echo "تم تحديث $output_file بنجاح!"