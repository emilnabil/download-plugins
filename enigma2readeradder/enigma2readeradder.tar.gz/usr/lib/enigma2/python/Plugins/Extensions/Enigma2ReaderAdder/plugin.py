from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigSelection, ConfigYesNo, ConfigInteger
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.MenuList import MenuList
import os
import re

CCCAM_VERSIONS = [
    "2.0.11", "2.1.1", "2.1.2", "2.1.3",
    "2.2.0", "2.2.1", "2.2.2", "2.3.0",
    "2.3.1", "2.3.2"
]

CCCRECONNECT_VALUES = [(str(i), str(i)) for i in range(0, 9001, 50)]
CACHEEX_MODES = [
    ("1", "Cache Pull"), 
    ("2", "Cache Push"), 
    ("3", "Reverse Cache Push")
]
CACHEEX_MAXHOP = [(str(i), str(i)) for i in range(0, 11)]

class AddServerScreen(Screen, ConfigListScreen):
    skin = """
    <screen position="center,center" size="800,700" title="Enigma2 Reader Adder By:Ismail9875" backgroundColor="#B3EFEFF1">
        <widget name="config" position="50,60" size="700,570" fontSelected="Regular, 45" itemHeightSelected="50" font="Regular; 40" itemHeight="50" backgroundColor="#B3EFEFF1" foregroundColor="black" backgroundColorSelected="#21000000" />
        <widget name="infoLabel" backgroundColor="black" position="center,10" size="500,40" font="Regular;35" halign="center" valign="center" foregroundColor="#EFEFF1" cornerRadius="35" transparent="0"/>
        <widget name="key_red" foregroundColor="black" position="20,645" size="160,50" font="Regular;35" halign="center" valign="center" transparent="0" backgroundColor="red" cornerRadius="35" zposition="2"/>
        <widget name="key_green" foregroundColor="black" position="210,645" size="160,50" font="Regular;35" halign="center" valign="center" transparent="0" backgroundColor="green" cornerRadius="35" zposition="2"/>
        <widget name="key_yellow" foregroundColor="black" position="410,645" size="160,50" font="Regular;35" halign="center" valign="center" transparent="0" backgroundColor="yellow" cornerRadius="35" zposition="2"/>
        <widget name="key_blue" foregroundColor="black" position="620,645" size="160,50" font="Regular;35" halign="center" valign="center" transparent="0" backgroundColor="blue" cornerRadius="35" zposition="2"/>
    </screen>
    """

    def __init__(self, session, server_data=None):
        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])

        self.server_data = server_data.copy() if server_data else self.get_default_data()
        self.is_editing = server_data is not None
        self.original_label = server_data["label"] if server_data else None

        self.init_config_elements()
        
        self.protocol.addNotifier(self.update_fields, initial_call=True)
        self.enable.addNotifier(self.update_fields, initial_call=False)
        self.advanced.addNotifier(self.update_fields, initial_call=False)
        self.cacheex.addNotifier(self.update_fields, initial_call=False)

        self["actions"] = ActionMap(["SetupActions", "ColorActions", "HelpActions"], {
            "cancel": self.exit,
            "ok": self.open_keyboard,
            "green": self.save_config,
            "red": self.exit,
            "yellow": self.ask_file_to_view,
            "blue": self.refresh,
            "info": self.show_field_info,
        }, -1)

        self["infoLabel"] = Label("Press OK to edit selected field")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Browse")
        self["key_blue"] = Label("Refresh")
        self.create_setup()

    def init_config_elements(self):
        self.label = ConfigText(default=self.server_data["label"])
        self.enable = ConfigSelection(choices=[("1", "Enabled"), ("0", "Disabled")], default=self.server_data["enable"])
        self.protocol = ConfigSelection(choices=[
            ("cccam", "CCcam"), 
            ("newcamd", "NewCamd"), 
            ("mgcamd", "MgCamd"), 
            ("cacheex", "CacheEx"), 
            ("internal", "Internal")
        ], default=self.server_data["protocol"])
        
        self.host = ConfigText(default=self.server_data["host"])
        self.port = ConfigInteger(default=self.server_data["port"], limits=(0, 65535))
        
        self.user = ConfigText(default=self.server_data["user"])
        self.password = ConfigText(default=self.server_data["password"])
        self.group = ConfigSelection(choices=[(str(i), str(i)) for i in range(1, 65)], default=self.server_data["group"])
        self.cccversion = ConfigSelection(choices=CCCAM_VERSIONS, default=self.server_data["cccversion"])
        self.key = ConfigText(default=self.server_data["key"])
        self.keepalive = ConfigSelection(choices=[("1", "Enabled"), ("0", "Disabled")], default=self.server_data["keepalive"])
        self.caid = ConfigText(default=self.server_data["caid"])
        self.ident = ConfigText(default=self.server_data["ident"])
        self.chid = ConfigText(default=self.server_data["chid"])
        self.disablecrccws_only_for = ConfigText(default=self.server_data["disablecrccws_only_for"])
        self.advanced = ConfigYesNo(default=self.server_data["advanced"])
        self.cccreconnect = ConfigSelection(choices=CCCRECONNECT_VALUES, default=self.server_data["cccreconnect"])
        self.cccmaxhops = ConfigSelection(choices=[(str(i), str(i)) for i in range(0, 11)], default=self.server_data["cccmaxhops"])
        
        # CacheEx settings
        self.cacheex = ConfigYesNo(default=self.server_data["cacheex"])
        self.cacheex_mode = ConfigSelection(choices=CACHEEX_MODES, default=self.server_data["cacheex_mode"])
        self.cacheex_maxhop = ConfigSelection(choices=CACHEEX_MAXHOP, default=self.server_data["cacheex_maxhop"])

    def get_default_data(self):
        return {
            "label": "server_name",
            "enable": "1",
            "protocol": "cccam",
            "host": "example.com",
            "port": 10000,
            "user": "username",
            "password": "password",
            "group": "1",
            "cccversion": "2.0.11",
            "key": "0102030405060708091011121314",
            "caid": "",
            "ident": "",
            "chid": "",
            "keepalive": "1",
            "disablecrccws_only_for": "",
            "advanced": False,
            "cccreconnect": "0",
            "cccmaxhops": "0",
            "cacheex": False,
            "cacheex_mode": "1",
            "cacheex_maxhop": "0"
        }

    def reset_fields(self, result=None):
        default_data = self.get_default_data()
        for field in default_data:
            getattr(self, field).value = default_data[field]
        
        self.is_editing = False
        self.original_label = None
        self.server_data = default_data.copy()
        
        self.update_fields()
        self.create_setup()
        self["config"].setList(self["config"].list)

    def update_fields(self, config_element=None):
        if self.protocol.value == "internal":
            self.host.value = "/dev/sci0"
            self.port.value = 0
        else:
            self.host.value = "example.com"
        self.create_setup()

    def create_setup(self):
        self.list = [
            ("Server Label", self.label, "Special name to differentiate servers."),
            ("Status", self.enable, "Enable or disable the server."),
            ("Protocol", self.protocol, "Select the protocol (CCcam, NewCamd, MgCamd, etc.)."),
            ("Host", self.host, "Enter the server host (e.g., example.com)."),
            ("Port", self.port if self.protocol.value != "internal" else None, "Enter the server port (0-65535)."),
            ("Username", self.user if self.protocol.value != "internal" else None, "Enter the username for authentication."),
            ("Password", self.password if self.protocol.value != "internal" else None, "Enter the password for authentication."),
            ("Group", self.group, "Select the group for the server (1-64)."),
            ("CCcam Version", self.cccversion if self.protocol.value == "cccam" else None, "Select the CCcam version."),
            ("Key", self.key if self.protocol.value in ["newcamd", "mgcamd"] else None, "Enter the key for NewCamd or MgCamd."),
            ("Advanced Options", self.advanced, "Enable advanced options."),
        ]

        if self.advanced.value:
            advanced_fields = [
                ("CAID", self.caid, "Enter the CAID for the server."),
                ("Ident", self.ident, "Enter the ident for the server."),
                ("CHID", self.chid, "Enter the CHID for the server."),
                ("Keepalive", self.keepalive, "Enable or disable keepalive."),
                ("Disable CRC Check For", self.disablecrccws_only_for, """
                You Can use most than 1 caid & provid .
                Examples: 
                1 - 1814:000000,000001,000002,000007,025225,005211;1810:000000,
                004601.....
                for the Viacces caid you can tape this method :
                0500:030B00,031000,030A00;0500:020A00,091500 .
                """)
            ]
            
            if self.protocol.value == "cccam":

                
                advanced_fields.extend([
                    ("Reconnect Time < 9000", self.cccreconnect, "Set the reconnect time (0-9000)."),
                    ("CCC Max Hops < 10", self.cccmaxhops, "Set the maximum hops (0-10).")
                ])
                
                advanced_fields.append(("Enable CacheEx", self.cacheex, "Enable CacheEx features"))
                
                if self.cacheex.value:
                    advanced_fields.extend([
                        ("CacheEx Mode", self.cacheex_mode, "Select CacheEx operation mode"),
                        ("CacheEx MaxHop", self.cacheex_maxhop, "Set maximum hop count for CacheEx (0-10)")
                    ])
            self.list += advanced_fields

        self["config"].list = [item[:2] for item in self.list if item[1] is not None]
        self["config"].setList(self["config"].list)

    def show_field_info(self):
        current = self["config"].getCurrent()
        if current:
            for item in self.list:
                if item[0] == current[0]:
                    self.session.open(
                        MessageBox,
                        item[2],
                        MessageBox.TYPE_INFO,
                        title=item[0]
                    )
                    break

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current and isinstance(current[1], ConfigText):
            self.session.openWithCallback(
                self.keyboard_callback,
                VirtualKeyBoard,
                title=f"Enter {current[0]}",
                text=current[1].value
            )

    def keyboard_callback(self, text):
        if text:
            current_item = self["config"].getCurrent()
            if current_item:
                current_item[1].value = text

    def save_config(self):
        self.server_data.update({k: getattr(self, k).value for k in self.server_data.keys()})
        
        if self.save_to_file():
            message = "Configuration saved!"
            
            callback = self.reset_fields
            message += "\nAll Fields reseted to default values"
            
            self.session.openWithCallback(
                lambda _: callback(),
                MessageBox,
                message,
                MessageBox.TYPE_INFO,
                timeout=3
            )
        else:
            self.session.open(
                MessageBox,
                "Failed to save configuration!",
                MessageBox.TYPE_ERROR
            )

    def generate_config_content(self):
        config_lines = ["[reader]"]
        config_lines.append(f"label             ={self.server_data['label']}")
        config_lines.append(f"enable            ={self.server_data['enable']}")
        config_lines.append(f"protocol          ={self.server_data['protocol']}")
        device = f"{self.server_data['host']},{self.server_data['port']}"
        config_lines.append(f"device            ={device}")

        if self.server_data['protocol'] != "internal":
            config_lines.append(f"user = {self.server_data['user']}")
            config_lines.append(f"password = {self.server_data['password']}")
        
        optional_fields = []
        if self.server_data['protocol'] == "cccam":
            optional_fields.append(('cccversion', 'cccversion'))
            optional_fields.append(('cccreconnect', 'cccreconnect'))
            optional_fields.append(('cccmaxhops', 'cccmaxhops'))
            
            if self.server_data['cacheex']:
                optional_fields.extend([
                    ('cacheex', 'cacheex'),
                    ('cacheex_mode', 'cacheex_mode'),
                    ('cacheex_maxhop', 'cacheex_maxhop')
                ])
                
        elif self.server_data['protocol'] in ["newcamd", "mgcamd"]:
            optional_fields.append(('key', 'key'))
        
        config_lines.append(f"group = {self.server_data['group']}")
       
        if self.server_data['advanced']:
            advanced_fields = [
                ('caid', 'caid'),
                ('ident', 'ident'),
                ('chid', 'chid'),
                ('keepalive', 'keepalive'),
                ('disablecrccws_only_for', 'disablecrccws_only_for')
            ]
            optional_fields.extend(advanced_fields)
        
        for key, field in optional_fields:
            value = self.server_data.get(key, '')
            if str(value).strip():
                config_lines.append(f"{field} = {value}")
        
        return config_lines

    def save_to_file(self):
        try:
            config_content = self.generate_config_content()
            formatted_content = "\n".join(config_content) + "\n"
            config_dir = "/etc/tuxbox/config"
            
            for filename in ["oscam.server", "ncam.server"]:
                file_path = os.path.join(config_dir, filename)
                
                if not os.path.exists(file_path):
                    continue
                
                backup_file = file_path + ".bak"
                if os.path.exists(backup_file):
                    os.remove(backup_file)
                os.rename(file_path, backup_file)
                
                with open(backup_file, 'r') as f:
                    content = f.read()
                
                new_content = content + "\n" + formatted_content
                
                with open(file_path, 'w') as f:
                    f.write(new_content.strip())
            
            return True
            
        except Exception as e:
            print("Save error:", str(e))
            return False

    def exit(self):
        self.close()

    def refresh(self):
        self.session.open(
            MessageBox,
            "Refresh service not available",
            MessageBox.TYPE_INFO,
            timeout=3
        )

    def ask_file_to_view(self):
        choices = [
            ("oscam.server", "/etc/tuxbox/config/oscam.server"),
            ("ncam.server", "/etc/tuxbox/config/ncam.server"),
        ]
        self.session.openWithCallback(
            self.open_server_viewer,
            ChoiceBox,
            title="Select file to view:",
            list=choices
        )

    def open_server_viewer(self, choice):
        if choice:
            self.session.open(ServerListScreen, choice[1])

class ServerListScreen(Screen):
    skin = """
    <screen position="center,center" size="800,700" title="Server List" backgroundColor="#B3EFEFF1" >
        <widget name="info" position="center,10" size="700,60" font="Regular;50" halign="center"  valign="center" backgroundColor="black" foregroundColor="#EFEFF1" cornerRadius="50" />
        <widget name="serverlist" position="50,80" size="700,580"  itemHeight="70" font="Regular, 60" valign="center" halign="center" backgroundColor="#B3EFEFF1" foregroundColor="white" backgroundColorSelected="#B3213555"  />
    </screen>
    """

    def __init__(self, session, filename):
        Screen.__init__(self, session)
        self.filename = filename
        self.serverlist = []
        self["serverlist"] = MenuList([])
        self["info"] = Label("Select Server")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "HelpActions"], {
            "ok": self.show_details,
            "cancel": self.close,
            "red": self.close,
            "info": self.show_server_info,
        }, -1)
        self.load_servers()

    def show_server_info(self):
        # كود لعرض معلومات السيرفر
        current_server = self.getCurrentServer()
        if current_server:
            self.session.open(MessageBox, current_server.info, MessageBox.TYPE_INFO)

    def load_servers(self):
        try:
            with open(self.filename, 'r') as f:
                content = f.read()
            
            servers = re.findall(r'\[reader\](.*?)(?=\n\[|\Z)', content, re.DOTALL)
            self.serverlist = []
            
            for server in servers:
                label_match = re.search(r'label\s*=\s*(.*?)(\n|$)', server)
                if label_match:
                    label = label_match.group(1).strip().strip('"')
                    self.serverlist.append((label, server.strip()))
            
            self["serverlist"].setList([x[0] for x in self.serverlist])
        except Exception as e:
            self["info"].setText(f"Error: {str(e)}")

    def show_details(self):
        selected = self["serverlist"].getCurrent()
        if selected:
            full_config = next((x[1] for x in self.serverlist if x[0] == selected), None)
            if full_config:
                self.session.open(
                    MessageBox,
                    full_config,
                    MessageBox.TYPE_INFO,
                    title="Server Configuration"
                )
                
def main(session, **kwargs):
    session.open(AddServerScreen)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Enigma2 Reader Adder",
        description="OSCam/NCam Server Management Tool",
        icon="Enigma2ReaderAdder.png",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main
    )