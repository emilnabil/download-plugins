from Components.config import ConfigText, ConfigSelection, ConfigYesNo, ConfigInteger, getConfigListEntry
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ConfigList import ConfigListScreen
from Components.ScrollLabel import ScrollLabel
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Screens.MessageBox import MessageBox
from Components.MenuList import MenuList
from Screens.ChoiceBox import ChoiceBox
from requests.auth import HTTPBasicAuth
from Tools.Directories import fileExists
from Components.Label import Label
from Screens.Screen import Screen
from socket import timeout
from enigma import ePixmap, getDesktop
from enigma import *
import subprocess
import requests
import os
import re

CCCAM_VERSIONS = [
    "2.0.11", "2.1.1", "2.1.2", "2.1.3",
    "2.2.0", "2.2.1", "2.2.2", "2.3.0",
    "2.3.1", "2.3.2"
]

CACHEEX_MODES = [
    ("1", "Cache Pull"),
    ("2", "Cache Push"),
    ("3", "Reverse Cache Push")
]

CCCRECONNECT_VALUES = [(str(i), str(i)) for i in range(0, 9001, 50)]
CACHEEX_MAXHOP = [(str(i), str(i)) for i in range(0, 11)]
mhrz_VALUES = [(str(i), str(i)) for i in range(0, 9001, 1)]
Card_mhrz_VALUES = [(str(i), str(i)) for i in range(0, 9001, 1)]

class AddServerScreen(Screen, ConfigListScreen):
    skin_fhd = """
    <screen position="center,center"
        zposition="0"
        size="1400,788"
        title="Enigma2 Reader Adder v3.0 By:Ismail9875"
        backgroundColor="#21000000">
        <widget name="config"
            zposition="1"
            position="center,50"
            size="1200,650"
            font="Regular_bold; 48"
            itemHeight="55"
            backgroundColor="#21000000"
            foregroundColor="#F5F5F5"
            backgroundColorSelected="#21000000"
            foregroundColorSelected="#FFD700" />

        <widget name="infoLabel"
            zposition="1"
            backgroundColor="#3B211C84"
            position="center,5"
            size="500,40"
            font="bold;35"
            halign="center"
            valign="center"
            foregroundColor="#EFEFF1"
            cornerRadius="35"
            transparent="0"/>

        <widget name="key_red"
            foregroundColor="red"
            position="100,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_green"
            foregroundColor="green"
            position="400,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_yellow"
            foregroundColor="yellow"
            position="700,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="yellow"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_blue"
            foregroundColor="blue"
            position="1000,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="blue"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>
        <eLabel name="white_line" backgroundColor="red" transparent="0" size="300,2" position="150,775" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="300,2" position="400,775" />
        <eLabel name="white_line" backgroundColor="yellow" transparent="0" size="300,2" position="700,775" />
        <eLabel name="white_line" backgroundColor="blue" transparent="0" size="300,3" position="1000,775" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="1400,1" position="0,718" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center"
        zposition="0"
        size="930,525"
        title="Enigma2 Reader Adder v3.0 By:Ismail9875"
        backgroundColor="#21000000">
        <widget name="config"
            zposition="1"
            position="center,35"
            size="800,430"
            font="Regular_bold; 32"
            itemHeight="37"
            backgroundColor="#21000000"
            foregroundColor="#F5F5F5"
            backgroundColorSelected="#21000000"
            foregroundColorSelected="#FFD700" />

        <widget name="infoLabel"
            zposition="1"
            backgroundColor="#3B211C84"
            position="center,5"
            size="330,27"
            font="bold;23"
            halign="center"
            valign="center"
            foregroundColor="#EFEFF1"
            cornerRadius="23"
            transparent="0"/>

        <widget name="key_red"
            foregroundColor="red"
            position="70,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_green"
            foregroundColor="green"
            position="270,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_yellow"
            foregroundColor="yellow"
            position="470,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="yellow"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_blue"
            foregroundColor="blue"
            position="670,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="blue"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>
        <eLabel name="white_line" backgroundColor="red" transparent="0" size="200,2" position="100,515" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="200,2" position="270,515" />
        <eLabel name="white_line" backgroundColor="yellow" transparent="0" size="200,2" position="470,515" />
        <eLabel name="white_line" backgroundColor="blue" transparent="0" size="200,2" position="670,515" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="930,1" position="0,475" />
    </screen>
    """

    def __init__(self, session, server_data=None):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])

        self.server_data = server_data.copy() if server_data else self.get_default_data()
        self.is_editing = server_data is not None
        self.original_label = server_data["label"] if server_data else None
        self.init_config_elements()

        self.protocol.addNotifier(self.update_fields, initial_call=True)
        self.enable.addNotifier(self.update_fields, initial_call=False)
        self.advanced.addNotifier(self.update_fields, initial_call=False)
        self.cacheex.addNotifier(self.update_fields, initial_call=False)

        self["actions"] = ActionMap(["SetupActions", "ColorActions", "HelpActions", "MenuActions"], {
            "cancel": self.exit,
            "ok": self.open_keyboard,
            "green": self.save_config,
            "red": self.exit,
            "yellow": self.ask_file_to_view,
            "blue": self.update_plugin,
            "info": self.show_field_info,
            "menu": self.Menu_Options,
        }, -1)

        self["infoLabel"] = Label("Press OK to edit selected field")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Browse")
        self["key_blue"] = Label("Update")
        self.create_setup()

    def init_config_elements(self):
        self.label = ConfigText(default=self.server_data["label"], fixed_size=False)
        self.enable = ConfigSelection(choices=[("1", "Enabled"), ("0", "Disabled")], default=self.server_data["enable"])
        self.protocol = ConfigSelection(choices=[
            ("cccam", "CCcam"),
            ("newcamd", "NewCamd"),
            ("mgcamd", "MgCamd"),
            ("cacheex", "CacheEx"),
            ("internal", "Internal")
        ], default=self.server_data["protocol"])

        device = self.server_data.get("device", "").split(",")
        self.host = ConfigText(default=device[0] if len(device) > 0 else "", fixed_size=False)
        self.port = ConfigInteger(default=int(device[1]) if len(device) > 1 else 0, limits=(0, 65535))

        self.user = ConfigText(default=self.server_data["user"], fixed_size=False)
        self.password = ConfigText(default=self.server_data["password"], fixed_size=False)
        self.group = ConfigSelection(choices=[(str(i), str(i)) for i in range(1, 65)], default=self.server_data["group"])
        self.cccversion = ConfigSelection(choices=CCCAM_VERSIONS, default=self.server_data["cccversion"])
        self.key = ConfigText(default=self.server_data["key"])
        self.keepalive = ConfigSelection(choices=[("1", "Enabled"), ("0", "Disabled")], default=self.server_data["keepalive"])
        self.caid = ConfigText(default=self.server_data["caid"], fixed_size=False)
        self.ident = ConfigText(default=self.server_data["ident"], fixed_size=False)
        self.chid = ConfigText(default=self.server_data["chid"], fixed_size=False)
        self.disablecrccws_only_for = ConfigText(default=self.server_data["disablecrccws_only_for"], fixed_size=False)
        self.advanced = ConfigYesNo(default=self.server_data["advanced"])
        self.cccreconnect = ConfigSelection(choices=CCCRECONNECT_VALUES, default=self.server_data["cccreconnect"])
        self.cccmaxhops = ConfigSelection(choices=[(str(i), str(i)) for i in range(0, 11)], default=self.server_data["cccmaxhops"])

        self.cacheex = ConfigYesNo(default=self.server_data["cacheex"])
        self.cacheex_mode = ConfigSelection(choices=CACHEEX_MODES, default=self.server_data["cacheex_mode"])
        self.cacheex_maxhop = ConfigSelection(choices=CACHEEX_MAXHOP, default=self.server_data["cacheex_maxhop"])
        self.pin = ConfigText(default=self.server_data["pin"])
        self.mhrz = ConfigSelection(choices=mhrz_VALUES, default=self.server_data["mhrz"])
        self.boxid = ConfigText(default=self.server_data["boxid"], fixed_size=False)
        self.detect = ConfigSelection(choices=[
            ("cd", "cd")
        ], default=self.server_data["detect"])
        self.card_mhrz = ConfigSelection(choices=Card_mhrz_VALUES, default=self.server_data["card_mhrz"])

    def get_default_data(self):
        return {
            "label": "server_name",
            "enable": "1",
            "protocol": "cccam",
            "host": "example.com",
            "port": 10000,
            "user": "username",
            "password": "password",
            "group": "1",
            "cccversion": "2.0.11",
            "key": "0102030405060708091011121314",
            "caid": "",
            "ident": "",
            "chid": "",
            "keepalive": "1",
            "disablecrccws_only_for": "",
            "advanced": False,
            "cccreconnect": "0",
            "cccmaxhops": "0",
            "cacheex": False,
            "cacheex_mode": "1",
            "cacheex_maxhop": "0",
            "pin": "1234",
            "boxid": "1234567",
            "mhrz": 200,
            "detect": "cd",
            "card_mhrz": 450,
        }

    def reset_fields(self, result=None):
        default_data = self.get_default_data()
        for field in default_data:
            getattr(self, field).value = default_data[field]

        self.is_editing = False
        self.original_label = None
        self.server_data = default_data.copy()

        self.update_fields()
        self.create_setup()
        self["config"].setList(self["config"].list)

    def update_fields(self, config_element=None):
        if self.protocol.value == "internal":
            self.host.value = "/dev/sci0"
            self.port.value = 0
        self.create_setup()

    def create_setup(self):
        self.list = [
            (" Server Label", self.label, "Special name to differentiate servers."),
            (" Status", self.enable, "Enable or disable the server."),
            (" Protocol", self.protocol, "Select the protocol (CCcam, NewCamd, MgCamd, etc.)."),
            (" Host", self.host, "Enter the server host (e.g., example.com)."),
            (" Port", self.port if self.protocol.value != "internal" else None, "Enter the server port (0-65535)."),
            (" Username", self.user if self.protocol.value != "internal" else None, "Enter the username for authentication."),
            (" Password", self.password if self.protocol.value != "internal" else None, "Enter the password for authentication."),
            (" Group", self.group, "Select the group for the server (1-64)."),
            (" CCcam Version", self.cccversion if self.protocol.value == "cccam" else None, "Select the CCcam version."),
            (" Key", self.key if self.protocol.value in ["newcamd", "mgcamd"] else None, "Enter the key for NewCamd or MgCamd."),
            (" Advanced Options", self.advanced, "Enable advanced options."),
        ]

        if self.advanced.value:
            if self.protocol.value != "internal":
                advanced_fields = [
                    (" CAID", self.caid, "Enter the CAID for the server."),
                    (" Ident", self.ident, "Enter the ident for the server."),
                    (" CHID", self.chid, "Enter the CHID for the server."),
                    (" Keepalive", self.keepalive, "Enable or disable keepalive."),
                    (" Disable CRC Check For", self.disablecrccws_only_for, """
                    You Can use most than 1 caid & provid.
                    Examples:
                    1 - 1814:000000,000001,000002,000007,025225,005211;1810:000000,
                    004601.....
                    for the Viacces caid you can tape this method:
                    0500:030B00,031000,030A00;0500:020A00,091500.
                    """)
                ]
            elif self.protocol.value == "internal":
                advanced_fields = [
                    (" CAID", self.caid, "Enter the CAID for the server."),
                    (" Keepalive", self.keepalive, "Enable or disable keepalive."),
                    (" Pin Code", self.pin, "Enter Pin."),
                    (" BoxID", self.boxid, "Enter the ID Of box."),
                    (" Mhrz", self.mhrz),
                    (" Detect", self.detect),
                    (" Card Mhrz", self.card_mhrz)
                ]

            if self.protocol.value == "cccam":
                advanced_fields.extend([
                    (" Reconnect Time < 9000", self.cccreconnect, "Set the reconnect time (0-9000)."),
                    (" CCC Max Hops < 10", self.cccmaxhops, "Set the maximum hops (0-10).")
                ])

                advanced_fields.append((" Enable CacheEx", self.cacheex, "Enable CacheEx features"))

                if self.cacheex.value:
                    advanced_fields.extend([
                        (" CacheEx Mode", self.cacheex_mode, "Select CacheEx operation mode"),
                        (" CacheEx MaxHop", self.cacheex_maxhop, "Set maximum hop count for CacheEx (0-10)")
                    ])
            self.list += advanced_fields

        self["config"].list = [item[:2] for item in self.list if item[1] is not None]
        self["config"].setList(self["config"].list)

    def show_field_info(self):
        current = self["config"].getCurrent()
        if current:
            for item in self.list:
                if item[0] == current[0]:
                    self.session.open(
                        MessageBox,
                        item[2],
                        MessageBox.TYPE_INFO,
                        title=item[0]
                    )
                    break

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current and isinstance(current[1], ConfigText):
            self.session.openWithCallback(
                self.keyboard_callback,
                VirtualKeyBoard,
                title=f"Enter {current[0]}",
                text=current[1].value
            )

    def keyboard_callback(self, text):
        if text:
            current_item = self["config"].getCurrent()
            if current_item:
                current_item[1].value = text

    def save_config(self):
        self.server_data.update({
            "label": self.label.value,
            "enable": self.enable.value,
            "protocol": self.protocol.value,
            "host": self.host.value,
            "port": self.port.value,
            "user": self.user.value,
            "password": self.password.value,
            "group": self.group.value,
            "cccversion": self.cccversion.value,
            "key": self.key.value,
            "keepalive": self.keepalive.value,
            "caid": self.caid.value,
            "ident": self.ident.value,
            "chid": self.chid.value,
            "disablecrccws_only_for": self.disablecrccws_only_for.value,
            "advanced": self.advanced.value,
            "cccreconnect": self.cccreconnect.value,
            "cccmaxhops": self.cccmaxhops.value,
            "cacheex": self.cacheex.value,
            "cacheex_mode": self.cacheex_mode.value,
            "cacheex_maxhop": self.cacheex_maxhop.value,
            "pin": self.pin.value,
            "detect": self.detect.value,
            "mhrz": self.mhrz.value,
            "boxid": self.boxid.value,
            "card_mhrz": self.card_mhrz.value,
        })

        if self.save_to_file():
            message = "Configuration saved!"
            callback = self.reset_fields
            message += "\nAll Fields reseted to default values"

            self.session.openWithCallback(
                lambda _: callback(),
                MessageBox,
                message,
                MessageBox.TYPE_INFO,
                timeout=3
            )
        else:
            self.session.open(
                MessageBox,
                "Failed to save configuration!",
                MessageBox.TYPE_ERROR
            )

    def generate_config_content(self):
        config_lines = ["[reader]"]
        config_lines.append(f"label               = {self.server_data['label']}")
        config_lines.append(f"enable              = {self.server_data['enable']}")
        config_lines.append(f"protocol            = {self.server_data['protocol']}")

        device = f"{self.server_data['host']},{self.server_data['port']}"
        config_lines.append(f"device              = {device}")

        if self.server_data['protocol'] != "internal":
            config_lines.append(f"user              = {self.server_data['user']}")
            config_lines.append(f"password          = {self.server_data['password']}")

        optional_fields = []
        if self.server_data['protocol'] == "cccam":
            optional_fields.append(('cccversion', 'cccversion'))
            optional_fields.append(('cccreconnect', 'cccreconnect'))
            optional_fields.append(('cccmaxhops', 'cccmaxhops'))

            if self.server_data['cacheex']:
                optional_fields.extend([
                    ('cacheex', 'cacheex'),
                    ('cacheex_mode', 'cacheex_mode'),
                    ('cacheex_maxhop', 'cacheex_maxhop')
                ])

        elif self.server_data['protocol'] in ["newcamd", "mgcamd"]:
            optional_fields.append(('key', 'key'))

        config_lines.append(f"group             = {self.server_data['group']}")

        if self.server_data['advanced']:
            advanced_fields = [
                ('caid', 'caid'),
                ('ident', 'ident'),
                ('chid', 'chid'),
                ('keepalive', 'keepalive'),
                ('disablecrccws_only_for', 'disablecrccws_only_for')
            ]
            optional_fields.extend(advanced_fields)

        for key, field in optional_fields:
            value = self.server_data.get(key, '')
            if str(value).strip():
                config_lines.append(f"{field}               = {value}")

        return config_lines

    def save_to_file(self):
        try:
            config_content = self.generate_config_content()
            formatted_content = "\n".join(config_content) + "\n"
            config_dir = "/etc/tuxbox/config"

            for filename in ["oscam.server", "ncam.server"]:
                file_path = os.path.join(config_dir, filename)

                if not os.path.exists(file_path):
                    continue

                backup_file = file_path + ".bak"
                if os.path.exists(backup_file):
                    os.remove(backup_file)
                os.rename(file_path, backup_file)

                with open(backup_file, 'r') as f:
                    content = f.read()

                new_content = content + "\n" + formatted_content

                with open(file_path, 'w') as f:
                    f.write(new_content.strip())

            return True

        except Exception as e:
            print("Save error:", str(e))
            return False

    def get_installed_version(self):
        try:
            output = os.popen("opkg list-installed enigma2-plugin-extensions-enigma2readeradder").read()
            if output:
                version_match = re.search(r'enigma2-plugin-extensions-enigma2readeradder - (\d+\.\d+\.\d+)', output)
                if version_match:
                    return version_match.group(1)
            return None
        except Exception as e:
            print(f"Error getting installed version: {str(e)}")
            return None

    def get_latest_version(self):
        try:
            output = os.popen("opkg list enigma2-plugin-extensions-enigma2readeradder").read()
            if output:
                version_match = re.search(r'enigma2-plugin-extensions-enigma2readeradder - (\d+\.\d+\.\d+)', output)
                if version_match:
                    return version_match.group(1)
            return None
        except Exception as e:
            print(f"Error getting latest version: {str(e)}")
            return None

    def update_plugin(self):
        installed_version = self.get_installed_version()
        latest_version = self.get_latest_version()

        if installed_version is None or latest_version is None:
            self.session.open(
                MessageBox,
                "Failed to check plugin versions. Please check your internet connection.",
                MessageBox.TYPE_ERROR,
                timeout=5
            )
            return

        if installed_version == latest_version:
            self.session.open(
                MessageBox,
                "You are already using the latest version of the plugin.",
                MessageBox.TYPE_INFO,
                timeout=5
            )
        else:
            try:
                os.system("opkg update && opkg upgrade enigma2-plugin-extensions-enigma2readeradder")

                self.session.open(
                    MessageBox,
                    "Plugin updated successfully! Please restart Enigma2.",
                    MessageBox.TYPE_INFO,
                    timeout=5
                )
            except Exception as e:
                self.session.open(
                    MessageBox,
                    f"Failed to update plugin: {str(e)}",
                    MessageBox.TYPE_ERROR,
                    timeout=5
                )

    def Menu_Options(self):
        self.session.open(Menu_Options)

    def ConfFileSelector(self):
        self.session.open(ConfFileSelector)

    def DVBAPIFileSelector(self):
        self.session.open(DVBAPIFileSelector)

    def exit(self):
        self.close()

    def refresh(self):
        self.session.open(
            MessageBox,
            "Refresh service not available",
            MessageBox.TYPE_INFO,
            timeout=3
        )

    def ask_file_to_view(self):
        choices = [
            ("oscam.server", "/etc/tuxbox/config/oscam.server"),
            ("ncam.server", "/etc/tuxbox/config/ncam.server"),
        ]
        self.session.openWithCallback(
            self.open_server_viewer,
            ChoiceBox,
            title="Select file to view:",
            list=choices
        )

    def open_server_viewer(self, choice):
        if choice:
            self.session.open(ServerListScreen, choice[1])

class ServerListScreen(Screen):
    skin_fhd = """
    <screen position="center,center" size="1400,788" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="info" position="center,5" size="700,40"  font="bold;38" halign="center"  valign="center" backgroundColor="#211C84" foregroundColor="#EFEFF1" cornerRadius="35" />
        <widget name="serverlist" position="center,90" size="1200,600" itemHeight="150" font="bold;65" valign="center" halign="center" />
        <widget name="key_red"
            foregroundColor="red"
            position="100,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_green"
            foregroundColor="green"
            position="400,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_yellow"
            foregroundColor="yellow"
            position="700,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="yellow"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_blue"
            foregroundColor="blue"
            position="1000,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="blue"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>
        <eLabel name="white_line" backgroundColor="red" transparent="0" size="300,2" position="150,775" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="300,2" position="400,775" />
        <eLabel name="white_line" backgroundColor="yellow" transparent="0" size="300,2" position="700,775" />
        <eLabel name="white_line" backgroundColor="blue" transparent="0" size="300,3" position="1000,775" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="1400,3" position="0,716" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center" size="930,525" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="info" position="center,5" size="465,27" font="bold;25" halign="center" valign="center" backgroundColor="#211C84" foregroundColor="#EFEFF1" cornerRadius="23" />
        <widget name="serverlist" position="center,60" size="800,400" itemHeight="100" font="bold;43" valign="center" halign="center" />
        <widget name="key_red"
            foregroundColor="red"
            position="70,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_green"
            foregroundColor="green"
            position="270,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_yellow"
            foregroundColor="yellow"
            position="470,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="yellow"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_blue"
            foregroundColor="blue"
            position="670,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="blue"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>
        <eLabel name="white_line" backgroundColor="red" transparent="0" size="200,2" position="100,515" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="200,2" position="270,515" />
        <eLabel name="white_line" backgroundColor="yellow" transparent="0" size="200,2" position="470,515" />
        <eLabel name="white_line" backgroundColor="blue" transparent="0" size="200,2" position="670,515" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="930,1" position="0,475" />
    </screen>
    """

    def __init__(self, session, filename):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        self.filename = filename
        self.serverlist = []
        self["serverlist"] = MenuList([])
        self["info"] = Label("Select Server")
        self["key_red"] = Label("Close")
        self["key_green"] = Label("Test")
        self["key_yellow"] = Label("Edit")
        self["key_blue"] = Label("Delete")

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "HelpActions"], {
            "ok": self.show_details,
            "cancel": self.close,
            "red": self.close,
            "green": self.checkConnection,
            "yellow": self.edit_server,
            "blue": self.delete_server,
            "info": self.show_server_info,
        }, -1)
        self.load_servers()

    def show_server_info(self):
        current_server = self.getCurrentServer()
        if current_server:
            self.session.open(MessageBox, current_server, MessageBox.TYPE_INFO)

    def load_servers(self):
        try:
            with open(self.filename, 'r') as f:
                content = f.read()

            servers = re.findall(r'\[reader\](.*?)(?=\n\[|\Z)', content, re.DOTALL)
            self.serverlist = []

            for server in servers:
                label_match = re.search(r'label\s*=\s*(.*?)(\n|$)', server)
                if label_match:
                    label = label_match.group(1).strip().strip('"')
                    self.serverlist.append((label, server.strip()))

            self["serverlist"].setList([x[0] for x in self.serverlist])
        except Exception as e:
            self["info"].setText(f"Error: {str(e)}")

    def show_details(self):
        selected = self["serverlist"].getCurrent()
        if selected:
            full_config = next((x[1] for x in self.serverlist if x[0] == selected), None)
            if full_config:
                self.session.open(
                    MessageBox,
                    full_config,
                    MessageBox.TYPE_INFO,
                    title="Server Configuration"
                )

    def save_changes(self):
        self.session.open(
            MessageBox,
            "No changes to save!",
            MessageBox.TYPE_INFO,
            timeout=3
        )

    def edit_server(self):
        selected = self["serverlist"].getCurrent()
        if selected:
            self.session.open(
                EditReaderScreen,
                selected
            )

    def delete_server(self):
        selected = self["serverlist"].getCurrent()
        if selected:
            self.session.openWithCallback(
                self.confirm_delete,
                MessageBox,
                f"Are you sure you want to delete server '{selected}'?",
                MessageBox.TYPE_YESNO
            )

    def confirm_delete(self, result):
        if result:
            selected = self["serverlist"].getCurrent()
            if selected:
                try:
                    with open(self.filename, 'r') as f:
                        lines = f.readlines()

                    reader_indices = []
                    for i, line in enumerate(lines):
                        if line.strip().startswith('[reader]'):
                            reader_indices.append(i)

                    selected_index = -2
                    for i, line in enumerate(lines):
                        label_match = re.search(r'label\s*=\s*(.*?)(\n|$)', line)
                        if label_match and label_match.group(1).strip().strip('"') == selected:
                            selected_index = i
                            break

                    if selected_index != -2:
                        start_reader_index = -1
                        for idx in reader_indices:
                            if idx <= selected_index:
                                start_reader_index = idx
                            else:
                                break

                        if start_reader_index == -1:
                            self.session.open(
                                MessageBox,
                                f"Server '{selected}' has no [reader] section!",
                                MessageBox.TYPE_ERROR,
                                timeout=3
                            )
                            return

                        end_reader_index = len(lines)
                        for idx in reader_indices:
                            if idx > start_reader_index:
                                end_reader_index = idx
                                break

                        del lines[start_reader_index:end_reader_index]

                        with open(self.filename, 'w') as f:
                            f.writelines(lines)

                        self.load_servers()

                        self.session.open(
                            MessageBox,
                            f"Server '{selected}' deleted successfully!",
                            MessageBox.TYPE_INFO,
                            timeout=3
                        )
                    else:
                        self.session.open(
                            MessageBox,
                            f"Server '{selected}' not found!",
                            MessageBox.TYPE_ERROR,
                            timeout=3
                        )

                except Exception as e:
                    self.session.open(
                        MessageBox,
                        f"Error deleting server: {str(e)}",
                        MessageBox.TYPE_ERROR,
                        timeout=3
                    )

    def getCurrentServer(self):
        selected = self["serverlist"].getCurrent()
        if selected:
            return next((x[1] for x in self.serverlist if x[0] == selected), None)
        return None

    def checkConnection(self):
        selected = self["serverlist"].getCurrent()
        if selected:
            full_config = next((x[1] for x in self.serverlist if x[0] == selected), None)
            if full_config:
                device_match = re.search(r'device\s*=\s*([^,]+),([^\s]+)', full_config)
                if device_match:
                    host = device_match.group(1).strip()
                    port = device_match.group(2).strip()

                    try:
                        result = subprocess.run(["telnet", host, port], timeout=3, capture_output=True, text=True)
                        if "Connected" in result.stdout or "Escape character is" in result.stdout:
                            self.session.open(MessageBox, f"Server: {host}:{port} - Connected", MessageBox.TYPE_INFO, timeout=3)
                        else:
                            self.session.open(MessageBox, f"Server: {host}:{port} - No Connection", MessageBox.TYPE_ERROR, timeout=3)
                    except subprocess.TimeoutExpired:
                        self.session.open(MessageBox, f"Server: {host}:{port} - Connection Timeout", MessageBox.TYPE_ERROR, timeout=3)
                    except Exception as e:
                        self.session.open(MessageBox, f"Error checking connection: {str(e)}", MessageBox.TYPE_ERROR, timeout=3)
                else:
                    self.session.open(MessageBox, "Invalid device format! Expected: device = host,port", MessageBox.TYPE_ERROR, timeout=3)
            else:
                self.session.open(MessageBox, "Server configuration not found!", MessageBox.TYPE_ERROR, timeout=3)
        else:
            self.session.open(MessageBox, "No server selected!", MessageBox.TYPE_ERROR, timeout=3)

class EditReaderScreen(Screen, ConfigListScreen):
    skin_fhd = """
    <screen position="center,center" size="1400,788" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="config" position="center,60" size="1200,620"  itemHeight="60" font="bold, 51" backgroundColor="#10000000" foregroundColor="white" foregroundColorSelected="#FFD700" backgroundColorSelected="#21000000" />
        <widget name="infoLabel" backgroundColor="#211C84" position="center,10" size="500,40" font="bold; 35" halign="center" valign="center" foregroundColor="#EFEFF1" cornerRadius="35" transparent="0"/>
        <widget name="key_red"
            foregroundColor="red"
            position="100,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_green"
            foregroundColor="green"
            position="400,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_yellow"
            foregroundColor="yellow"
            position="700,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="yellow"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <widget name="key_blue"
            foregroundColor="blue"
            position="1000,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="blue"
            cornerRadius="35"
            zposition="2"
            transparent="1"/>

        <eLabel name="white_line" backgroundColor="red" transparent="0" size="300,2" position="150,775" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="300,2" position="400,775" />
        <eLabel name="white_line" backgroundColor="yellow" transparent="0" size="300,2" position="700,775" />
        <eLabel name="white_line" backgroundColor="blue" transparent="0" size="300,2" position="1000,775" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="1400,3" position="0,716" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center" size="930,525" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="config" position="center,40" size="800,410" itemHeight="40" font="bold, 34" backgroundColor="#10000000" foregroundColor="white" foregroundColorSelected="#FFD700" backgroundColorSelected="#21000000" />
        <widget name="infoLabel" backgroundColor="#211C84" position="center,10" size="330,27" font="bold; 23" halign="center" valign="center" foregroundColor="#EFEFF1" cornerRadius="23" transparent="0"/>
        <widget name="key_red"
            foregroundColor="red"
            position="70,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_green"
            foregroundColor="green"
            position="270,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_yellow"
            foregroundColor="yellow"
            position="470,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="yellow"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <widget name="key_blue"
            foregroundColor="blue"
            position="670,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="blue"
            cornerRadius="23"
            zposition="2"
            transparent="1"/>

        <eLabel name="white_line" backgroundColor="red" transparent="0" size="200,2" position="100,515" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="200,2" position="270,515" />
        <eLabel name="white_line" backgroundColor="yellow" transparent="0" size="200,2" position="470,515" />
        <eLabel name="white_line" backgroundColor="blue" transparent="0" size="200,2" position="670,515" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="930,1" position="0,475" />
    </screen>
    """

    def __init__(self, session, server_label):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])

        self.server_label = server_label
        self.original_server_data = self.load_server_data()
        self.server_data = self.original_server_data.copy()
        self.init_config_elements()

        self["actions"] = ActionMap(["SetupActions", "ColorActions", "HelpActions"], {
            "cancel": self.exit,
            "ok": self.open_keyboard,
            "green": self.save_config,
            "red": self.exit,
            "yellow": self.ask_file_to_view,
            "blue": self.refresh,
            "info": self.show_field_info,
        }, -1)

        self["infoLabel"] = Label("Press OK to edit selected field")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Browse")
        self["key_blue"] = Label("Update")
        self.create_setup()

    def load_server_data(self):
        server_data = {}
        config_files = ["/etc/tuxbox/config/oscam.server", "/etc/tuxbox/config/ncam.server"]
        for config_file in config_files:
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    content = f.read()
                servers = re.findall(r'\[reader\](.*?)(?=\n\[|\Z)', content, re.DOTALL)
                for server in servers:
                    label_match = re.search(r'label\s*=\s*(.*?)(\n|$)', server)
                    if label_match and label_match.group(1).strip().strip('"') == self.server_label:
                        server_data = self.parse_server_config(server)
                        server_data["file"] = config_file
                        break
        return server_data

    def parse_server_config(self, server_config):
        server_data = {}
        for line in server_config.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                server_data[key.strip()] = value.strip().strip('"')
        return server_data

    def init_config_elements(self):
        self.label = ConfigText(default=self.server_data.get("label", ""), fixed_size=False)
        self.enable = ConfigSelection(choices=[("1", "Enabled"), ("0", "Disabled")], default=self.server_data.get("enable", "1"))
        self.protocol = ConfigSelection(choices=[
            ("cccam", "CCcam"),
            ("newcamd", "NewCamd"),
            ("mgcamd", "MgCamd"),
            ("cacheex", "CacheEx"),
            ("internal", "Internal")
        ], default=self.server_data.get("protocol", "cccam"))

        # Parse host and port from device field
        device = self.server_data.get("device", "").split(",")
        self.host = ConfigText(default=device[0] if len(device) > 0 else "", fixed_size=False)
        self.port = ConfigInteger(default=int(device[1]) if len(device) > 1 else 0, limits=(0, 65535))

        self.user = ConfigText(default=self.server_data.get("user", ""), fixed_size=False)
        self.password = ConfigText(default=self.server_data.get("password", ""), fixed_size=False)
        self.group = ConfigSelection(choices=[(str(i), str(i)) for i in range(1, 65)], default=self.server_data.get("group", "1"))
        self.cccversion = ConfigSelection(choices=CCCAM_VERSIONS, default=self.server_data.get("cccversion", "2.0.11"))
        self.key = ConfigText(default=self.server_data.get("key", ""))
        self.keepalive = ConfigSelection(choices=[("1", "Enabled"), ("0", "Disabled")], default=self.server_data.get("keepalive", "1"))
        self.caid = ConfigText(default=self.server_data.get("caid", ""), fixed_size=False)
        self.ident = ConfigText(default=self.server_data.get("ident", ""), fixed_size=False)
        self.chid = ConfigText(default=self.server_data.get("chid", ""), fixed_size=False)
        self.disablecrccws_only_for = ConfigText(default=self.server_data.get("disablecrccws_only_for", ""), fixed_size=False)
        self.advanced = ConfigYesNo(default=self.server_data.get("advanced", False))
        self.cccreconnect = ConfigSelection(choices=CCCRECONNECT_VALUES, default=self.server_data.get("cccreconnect", "0"))
        self.cccmaxhops = ConfigSelection(choices=[(str(i), str(i)) for i in range(0, 11)], default=self.server_data.get("cccmaxhops", "0"))
        self.cacheex = ConfigYesNo(default=self.server_data.get("cacheex", False))
        self.cacheex_mode = ConfigSelection(choices=CACHEEX_MODES, default=self.server_data.get("cacheex_mode", "1"))
        self.cacheex_maxhop = ConfigSelection(choices=CACHEEX_MAXHOP, default=self.server_data.get("cacheex_maxhop", "0"))

        # Add notifiers to update the setup when protocol or advanced options change
        self.protocol.addNotifier(self.update_fields, initial_call=True)
        self.advanced.addNotifier(self.update_fields, initial_call=False)
        self.cacheex.addNotifier(self.update_fields, initial_call=False)

    def update_fields(self, config_element=None):
        if self.protocol.value == "internal":
            self.host.value = "/dev/sci0"
            self.port.value = 0
        self.create_setup()

    def create_setup(self):
        self.list = [
            (" Server Label", self.label, "Special name to differentiate servers."),
            (" Status", self.enable, "Enable or disable the server."),
            (" Protocol", self.protocol, "Select the protocol (CCcam, NewCamd, MgCamd, etc.)."),
            (" Host", self.host, "Enter the server host (e.g., example.com)."),
            (" Port", self.port if self.protocol.value != "internal" else None, "Enter the server port (0-65535)."),
            (" Username", self.user if self.protocol.value != "internal" else None, "Enter the username for authentication."),
            (" Password", self.password if self.protocol.value != "internal" else None, "Enter the password for authentication."),
            (" Group", self.group, "Select the group for the server (1-64)."),
            (" CCcam Version", self.cccversion if self.protocol.value == "cccam" else None, "Select the CCcam version."),
            (" Key", self.key if self.protocol.value in ["newcamd", "mgcamd"] else None, "Enter the key for NewCamd or MgCamd."),
            (" Advanced Options", self.advanced, "Enable advanced options."),
        ]

        if self.advanced.value:
            advanced_fields = [
                (" CAID", self.caid, "Enter the CAID for the server."),
                (" Ident", self.ident, "Enter the ident for the server."),
                (" CHID", self.chid, "Enter the CHID for the server."),
                (" Keepalive", self.keepalive, "Enable or disable keepalive."),
                (" Disable CRC Check For", self.disablecrccws_only_for, """
                You Can use more than 1 caid & provid.
                Examples:
                1 - 1814:000000,000001,000002,000007,025225,005211;1810:000000,
                004601.....
                for the Viacces caid you can tap this method:
                0500:030B00,031000,030A00;0500:020A00,091500.
                """)
            ]

            if self.protocol.value == "cccam":
                advanced_fields.extend([
                    (" Reconnect Time < 9000", self.cccreconnect, "Set the reconnect time (0-9000)."),
                    (" CCC Max Hops < 10", self.cccmaxhops, "Set the maximum hops (0-10).")
                ])

                advanced_fields.append((" Enable CacheEx", self.cacheex, "Enable CacheEx features"))

                if self.cacheex.value:
                    advanced_fields.extend([
                        (" CacheEx Mode", self.cacheex_mode, "Select CacheEx operation mode"),
                        (" CacheEx MaxHop", self.cacheex_maxhop, "Set maximum hop count for CacheEx (0-10)")
                    ])
            self.list += advanced_fields

        additional_fields = []
        for key, value in self.server_data.items():
            if key not in [
                "label", "enable", "protocol", "device", "user", "password",
                "group", "cccversion", "key", "keepalive", "caid", "ident", "chid",
                "disablecrccws_only_for", "advanced", "cccreconnect", "cccmaxhops",
                "cacheex", "cacheex_mode", "cacheex_maxhop", "file"
            ]:
                additional_fields.append((key, ConfigText(default=value, fixed_size=False), f"Additional option: {key}"))

        self.list += additional_fields
        self["config"].list = [item[:2] for item in self.list if item[1] is not None]
        self["config"].setList(self["config"].list)

    def save_config(self):
        # Generate device value from host and port
        device_value = f"{self.host.value},{self.port.value}" if self.protocol.value != "internal" else "/dev/sci0,0"

        self.server_data.update({
            "label": self.label.value,
            "enable": self.enable.value,
            "protocol": self.protocol.value,
            "device": device_value,  # Store device as host,port
            "user": self.user.value,
            "password": self.password.value,
            "group": self.group.value,
            "cccversion": self.cccversion.value,
            "key": self.key.value,
            "keepalive": self.keepalive.value,
            "caid": self.caid.value,
            "ident": self.ident.value,
            "chid": self.chid.value,
            "disablecrccws_only_for": self.disablecrccws_only_for.value,
            "advanced": str(self.advanced.value).lower(),
            "cccreconnect": self.cccreconnect.value,
            "cccmaxhops": self.cccmaxhops.value,
            "cacheex": str(self.cacheex.value).lower(),
            "cacheex_mode": self.cacheex_mode.value,
            "cacheex_maxhop": self.cacheex_maxhop.value,
        })

        for item in self.list:
            if isinstance(item[1], ConfigText) and item[0] not in [
                " Server Label", "Status", "Protocol", "Host", "Port", "Username",
                "Password", "Group", "CCcam Version", "Key", "Advanced Options",
                "CAID", "Ident", "CHID", "Keepalive", "Disable CRC Check For",
                "Reconnect Time < 9000", "CCC Max Hops < 10", "Enable CacheEx",
                "CacheEx Mode", "CacheEx MaxHop"
            ]:
                self.server_data[item[0]] = item[1].value

        if self.save_to_file():
            message = "Configuration saved!"
            self.session.open(
                MessageBox,
                message,
                MessageBox.TYPE_INFO,
                timeout=3
            )
        else:
            self.session.open(
                MessageBox,
                "Failed to save configuration!",
                MessageBox.TYPE_ERROR
            )

    def generate_config_content(self):
        changed_fields = {}
        for key, value in self.server_data.items():
            if key != "file" and (key not in self.original_server_data or self.original_server_data[key] != value):
                changed_fields[key] = value

        config_lines = []
        if "label" in changed_fields:
            config_lines.append(f"label             = {changed_fields.get('label', '')}")
        if "enable" in changed_fields:
            config_lines.append(f"enable            = {changed_fields.get('enable', '1')}")
        if "protocol" in changed_fields:
            config_lines.append(f"protocol          = {changed_fields.get('protocol', 'cccam')}")
        if "device" in changed_fields:
            config_lines.append(f"device            = {changed_fields.get('device', '')}")

        if self.server_data.get('protocol') != "internal":
            if "user" in changed_fields:
                config_lines.append(f"user              = {changed_fields.get('user', '')}")
            if "password" in changed_fields:
                config_lines.append(f"password          = {changed_fields.get('password', '')}")

        optional_fields = []
        if self.server_data.get('protocol') == "cccam":
            if "cccversion" in changed_fields:
                optional_fields.append(('cccversion', 'cccversion'))
            if "cccreconnect" in changed_fields:
                optional_fields.append(('cccreconnect', 'cccreconnect'))
            if "cccmaxhops" in changed_fields:
                optional_fields.append(('cccmaxhops', 'cccmaxhops'))
            if self.server_data.get('cacheex') and "cacheex" in changed_fields:
                optional_fields.append(('cacheex', 'cacheex'))
            if "cacheex_mode" in changed_fields:
                optional_fields.append(('cacheex_mode', 'cacheex_mode'))
            if "cacheex_maxhop" in changed_fields:
                optional_fields.append(('cacheex_maxhop', 'cacheex_maxhop'))
        elif self.server_data.get('protocol') in ["newcamd", "mgcamd"]:
            if "key" in changed_fields:
                optional_fields.append(('key', 'key'))

        if "group" in changed_fields:
            config_lines.append(f"group             = {changed_fields.get('group', '1')}")

        if self.server_data.get('advanced'):
            advanced_fields = []
            if "caid" in changed_fields:
                advanced_fields.append(('caid', 'caid'))
            if "ident" in changed_fields:
                advanced_fields.append(('ident', 'ident'))
            if "chid" in changed_fields:
                advanced_fields.append(('chid', 'chid'))
            if "keepalive" in changed_fields:
                advanced_fields.append(('keepalive', 'keepalive'))
            if "disablecrccws_only_for" in changed_fields:
                advanced_fields.append(('disablecrccws_only_for', 'disablecrccws_only_for'))
            optional_fields.extend(advanced_fields)

        for key, field in optional_fields:
            if key in changed_fields:
                value = changed_fields.get(key, '')
                if str(value).strip():
                    config_lines.append(f"{field} = {value}")

        for key, value in changed_fields.items():
            if key not in [
                "label", "enable", "protocol", "device", "user", "password",
                "group", "cccversion", "key", "keepalive", "caid", "ident", "chid",
                "disablecrccws_only_for", "advanced", "cccreconnect", "cccmaxhops",
                "cacheex", "cacheex_mode", "cacheex_maxhop"
            ]:
                config_lines.append(f"{key} = {value}")

        return config_lines

    def save_to_file(self):
        try:
            config_file = self.server_data.get("file", "/etc/tuxbox/config/oscam.server")
            if not os.path.exists(config_file):
                return False

            with open(config_file, 'r') as f:
                lines = f.readlines()

            line_indices = {}
            current_reader = None
            server_found = False
            reader_start_index = None

            for index, line in enumerate(lines):
                line = line.strip()
                if line.startswith("[reader]"):
                    current_reader = index
                    reader_start_index = index
                elif current_reader is not None and "=" in line:
                    key = line.split("=", 1)[0].strip()
                    label_match = re.match(r'label\s*=\s*(.*?)(\s|$)', line, re.IGNORECASE)
                    if label_match and label_match.group(1).strip().strip('"') == self.server_label:
                        server_found = True
                        line_indices[key] = index
                    elif label_match:
                        current_reader = None
                    else:
                        line_indices[key] = index
                elif line.startswith("[reader]") or (not line and current_reader is not None):
                    current_reader = None

            if not server_found:
                return False

            changed_lines = self.generate_config_content()
            if not changed_lines:
                return True

            # Ensure device line is placed after protocol
            device_line = f"device            = {self.server_data.get('device', '')}"
            device_inserted = False
            for changed_line in changed_lines[:]:
                key = changed_line.split("=", 1)[0].strip()
                if key == "device":
                    changed_lines.remove(changed_line)
                    continue
                if key == "protocol":
                    changed_lines.insert(changed_lines.index(changed_line) + 1, device_line)
                    device_inserted = True

            if not device_inserted:
                changed_lines.insert(1, device_line)

            for changed_line in changed_lines:
                key = changed_line.split("=", 1)[0].strip()
                if key in line_indices:
                    lines[line_indices[key]] = changed_line + "\n"
                else:
                    lines.insert(reader_start_index + 1, changed_line + "\n")
                    for k, idx in line_indices.items():
                        if idx >= reader_start_index + 1:
                            line_indices[k] += 1
                    reader_start_index += 1

            with open(config_file, 'w') as f:
                f.writelines(lines)

            return True

        except Exception as e:
            print(f"Save error: {str(e)}")
            return False

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current and isinstance(current[1], ConfigText):
            self.session.openWithCallback(
                self.keyboard_callback,
                VirtualKeyBoard,
                title=f"Enter {current[0]}",
                text=current[1].value
            )

    def keyboard_callback(self, text):
        if text:
            current_item = self["config"].getCurrent()
            if current_item:
                current_item[1].value = text

    def ask_file_to_view(self):
        choices = [
            ("oscam.server", "/etc/tuxbox/config/oscam.server"),
            ("ncam.server", "/etc/tuxbox/config/ncam.server"),
        ]
        self.session.openWithCallback(
            self.open_server_viewer,
            ChoiceBox,
            title="Select file to view:",
            list=choices
        )

    def open_server_viewer(self, choice):
        if choice:
            self.session.open(ServerListScreen, choice[1])

    def exit(self):
        self.close()

    def refresh(self):
        self.session.open(
            MessageBox,
            "Refresh service not available",
            MessageBox.TYPE_INFO,
            timeout=3
        )

    def show_field_info(self):
        current = self["config"].getCurrent()
        if current:
            for item in self.list:
                if item[0] == current[0]:
                    self.session.open(
                        MessageBox,
                        item[2],
                        MessageBox.TYPE_INFO,
                        title=item[0]
                    )
                    break

class ConfFileSelector(Screen):
    skin_fhd = """
    <screen position="center,center" size="1400,788" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#19000000" >
        <widget name="list" position="center,90" size="1200,600" itemHeight="150" font="bold;65" valign="center" halign="center" />
        <widget name="info" position="center,10" size="1200,80" font="bold;40" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="35"/>
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="1400,3" position="0,716" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center" size="930,525" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#19000000" >
        <widget name="list" position="center,60" size="800,400" itemHeight="100" font="bold;43" valign="center" halign="center" />
        <widget name="info" position="center,10" size="800,50" font="bold;25" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="23"/>
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="930,1" position="0,475" />
    </screen>
    """

    def __init__(self, session):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        self["info"] = Label("Please Select file")
        self["list"] = MenuList([])
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.selectFile,
            "cancel": self.close
        })
        self.loadFiles()

    def loadFiles(self):
        files = []
        config_dir = "/etc/tuxbox/config/"
        for f in os.listdir(config_dir):
            if f.endswith(".conf"):
                files.append(f)
        self["list"].setList(files)

    def selectFile(self):
        selected = self["list"].getCurrent()
        if selected:
            file_path = f"/etc/tuxbox/config/{selected}"
            self.session.open(ConfigFileEditor, file_path)
            self.close()

class ConfigFileEditor(Screen, ConfigListScreen):
    skin_fhd = """
    <screen position="center,center" size="1400,788" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="config" position="center,80" size="1200,620" itemHeight="80" font="bold,65" valign="center" backgroundColor="#21000000"/>
        <widget name="info" position="center,10" size="1200,60" font="bold;50" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="35"/>
        <widget name="key_red"
            foregroundColor="red"
            position="150,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="35"
            zPosition="2"
            transparent="1"/>

        <widget name="key_green"
            foregroundColor="green"
            position="950,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="35"
            zPosition="2"
            transparent="1"/>

        <eLabel name="white_line" backgroundColor="red" transparent="0" size="300,2" position="150,775" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="300,2" position="950,775" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="1400,3" position="0,716" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center" size="930,525" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="config" position="center,50" size="800,410" itemHeight="50" font="bold,43" valign="center" backgroundColor="#21000000"/>
        <widget name="info" position="center,10" size="800,40" font="bold;30" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="23"/>
        <widget name="key_red"
            foregroundColor="red"
            position="100,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="23"
            zPosition="2"
            transparent="1"/>

        <widget name="key_green"
            foregroundColor="green"
            position="630,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="23"
            zPosition="2"
            transparent="1"/>

        <eLabel name="white_line" backgroundColor="red" transparent="0" size="200,2" position="100,515" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="200,2" position="630,515" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="930,1" position="0,475" />
    </screen>
    """

    def __init__(self, session, filepath):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])

        self.filepath = filepath
        self.original_lines = []
        self.config_entries = {}
        self.line_indices = {}

        self["info"] = Label("Press 'OK' Or tape from Remote to change Value")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.exit,
            "green": self.save_config,
            "red": self.exit,
            "ok": self.open_keyboard,
        }, -2)

        self.load_config_file()
        self.init_config_elements()
        self.create_config_list()

    def load_config_file(self):
        if not fileExists(self.filepath):
            return

        with open(self.filepath, "r") as f:
            for idx, line in enumerate(f):
                cleaned_line = line.strip()
                self.original_lines.append(line.rstrip('\n'))
                if "=" in cleaned_line and not cleaned_line.startswith("#"):
                    key, value = cleaned_line.split("=", 1)
                    key = key.strip()
                    value = value.split("#")[0].strip()
                    self.line_indices[key] = idx

    def init_config_elements(self):
        self.cccam_cfg_enabled = ConfigSelection(
            choices=[("0", "Disable"), ("1", "Enable")],
            default=self.get_value("cccam_cfg_enabled", "0")
        )
        self.cccam_cfg_path = ConfigSelection(
            choices=["/etc", "/etc/tuxbox", "/etc/tuxbox/config", "media/hdd"],
            default=self.get_value("cccam_cfg_path", "/etc")
        )
        self.stream_relay_enabled = ConfigSelection(
            choices=[("0", "disable"), ("1", "enable")],
            default=self.get_value("stream_relay_enabled", "0")
        )
        self.stream_relay_ctab = ConfigText(default=self.get_value("stream_relay_ctab", ""), fixed_size=False)

        self.httpport = ConfigInteger(default=int(self.get_value("httpport", "8080")), limits=(0, 9999))
        self.httpport.text = lambda x: f"{x:04d}"

        self.ecminfo_type = ConfigSelection(
            choices=self.get_ecminfo_choices(),
            default=self.get_value("ecminfo_type", "0")
        )
        self.delayer = ConfigInteger(default=int(self.get_value("delayer", "0")), limits=(0, 999))
        self.delayer.text = lambda x: f"{x:04d}"
        self.dvbapi_enabled = ConfigSelection(
            choices=[("0", "disable"), ("1", "enable")],
            default=self.get_value("dvbapi_enabled", "1")
        )

        self.boxtype = ConfigSelection(
            choices=[
                "dreambox", "duckbox", "ufs910", "dbox2", "ipbox",
                "ipbox-pmt", "dm7000", "qboxhd", "coolstream",
                "nuemo", "pc", "pc-nodmx", "samygo"
            ],
            default=self.get_value("boxtype", "dreambox")
        )

    def get_ecminfo_choices(self):
        if "oscam.conf" in self.filepath:
            return [("0", "OSCam"),
                    ("1", "OSCam ecmtime in ms"),
                    ("2", "WiCard"),
                    ("3", "MGCamd"),
                    ("4", "CCCam"),
                    ("5", "Camd3"),
                    ("6", "GBox")]
        return [
            ("0", "NCam"),
            ("1", "NCam ecmtime in ms"),
            ("2", "WiCard"),
            ("3", "MGCamd"),
            ("4", "CCCam"),
            ("5", "Camd3"),
            ("6", "GBox")
        ]

    def get_value(self, key, default):
        for line in self.original_lines:
            if line.startswith(key + " ="):
                return line.split("=", 1)[1].strip().split("#")[0].strip()
        return default

    def create_config_list(self):
        config_list = [
            getConfigListEntry(_("=== Global Settings ==="), None),
            getConfigListEntry(_("  CCCam Config Enabled"), self.cccam_cfg_enabled),
            getConfigListEntry(_("  CCCam Config Path"), self.cccam_cfg_path),
            getConfigListEntry(_("=== Stream Relay ==="), None),
            getConfigListEntry(_("  Stream Relay Enabled"), self.stream_relay_enabled),
            getConfigListEntry(_("  Stream Relay CTAB"), self.stream_relay_ctab),
            getConfigListEntry(_("=== Web Interface ==="), None),
            getConfigListEntry(_("  HTTP Port"), self.httpport),
            getConfigListEntry(_("=== Advanced ==="), None),
            getConfigListEntry(_("  DVBAPI Enable"), self.dvbapi_enabled),
            getConfigListEntry(_("  ECM Info Type"), self.ecminfo_type),
            getConfigListEntry(_("  Delayer"), self.delayer),
            getConfigListEntry(_("=== Hardware ==="), None),
            getConfigListEntry(_("  Box Type"), self.boxtype)
        ]

        self["config"].list = [entry for entry in config_list if entry[1] is not None]

    def save_config(self):
        try:
            modified_lines = self.original_lines.copy()

            for key in self.line_indices:
                config_obj = getattr(self, key, None)
                if config_obj:
                    idx = self.line_indices[key]
                    value = config_obj.value

                    if isinstance(config_obj, ConfigInteger):
                        formatted_value = f"{value:04d}"
                    else:
                        formatted_value = str(value)

                    original_line = modified_lines[idx]
                    comment = original_line.split("#", 1)[1] if "#" in original_line else ""
                    modified_line = f"{key} = {formatted_value}"
                    if comment:
                        modified_line += f" # {comment}"

                    modified_lines[idx] = modified_line

            with open(self.filepath, "w") as f:
                f.write("\n".join(modified_lines))

            self.session.open(
                MessageBox,
                _("Settings saved successfully!"),
                MessageBox.TYPE_INFO,
                timeout=3
            )
            self.close()

        except Exception as e:
            self.session.open(
                MessageBox,
                _("Error saving file: ") + str(e),
                MessageBox.TYPE_ERROR,
                timeout=3
            )

    def open_keyboard(self):
        current = self["config"].getCurrent()
        if current and current[1]:
            self.session.openWithCallback(
                self.keyboard_callback,
                VirtualKeyBoard,
                title=current[0],
                text=str(current[1].value)
            )

    def keyboard_callback(self, text):
        if text and self["config"].getCurrent():
            current_item = self["config"].getCurrent()[1]
            try:
                if isinstance(current_item, ConfigInteger):
                    current_item.value = int(text)
                else:
                    current_item.value = text
                self["config"].invalidateCurrent()
            except ValueError:
                pass

    def exit(self):
        self.close()

class Menu_Options(Screen):
    skin_fhd = """
    <screen position="center,center"
        zposition="0"
        size="1400,788"
        title="Enigma2 Reader Adder v3.0 By:Ismail9875"
        backgroundColor="#21000000">
        <widget name="info" position="100,10" size="1200,80" font="bold;35" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="35"/>
        <widget name="list" position="center,90" size="1200,600" itemHeight="150" font="bold;65" valign="center" halign="center" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center"
        zposition="0"
        size="930,525"
        title="Enigma2 Reader Adder v3.0 By:Ismail9875"
        backgroundColor="#21000000">
        <widget name="info" position="70,10" size="800,50" font="bold;25" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="23"/>
        <widget name="list" position="center,60" size="800,400" itemHeight="100" font="bold;43" valign="center" halign="center" />
    </screen>
    """

    def __init__(self, session):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        self.menu_options = [
            (".conf File", "conf"),
            (".dvbapi File", "dvbapi"),
        ]

        self["info"] = Label("Please Select Option")
        self["list"] = MenuList(self.menu_options)
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.menu_callback,
            "cancel": self.close
        }, -1)

    def menu_callback(self):
        selected = self["list"].getCurrent()
        if selected:
            if selected[1] == "conf":
                self.ConfFileSelector()
            elif selected[1] == "dvbapi":
                self.DVBAPIFileSelector()

    def ConfFileSelector(self):
        self.session.open(ConfFileSelector)

    def DVBAPIFileSelector(self):
        self.session.open(DVBAPIFileSelector)

class DVBAPIFileSelector(Screen):
    skin_fhd = """
    <screen position="center,center" size="1400,788" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000" >
        <widget name="list" position="center,90" size="1200,600" itemHeight="150" font="bold;65" valign="center" halign="center" />
        <widget name="info" position="100,10" size="1200,80" font="bold;49" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="35"/>
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="1400,3" position="0,716" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center" size="930,525" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000" >
        <widget name="list" position="center,60" size="800,400" itemHeight="100" font="bold;43" valign="center" halign="center" />
        <widget name="info" position="70,10" size="800,50" font="bold;30" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="23"/>
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="930,1" position="0,475" />
    </screen>
    """

    def __init__(self, session):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        self["info"] = Label("Please Select file")
        self["list"] = MenuList([])
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.selectFile,
            "cancel": self.exit
        })
        self.loadFiles()

    def loadFiles(self):
        files = []
        config_dir = "/etc/tuxbox/config/"
        for f in os.listdir(config_dir):
            if f.endswith(".dvbapi"):
                files.append(f)
        self["list"].setList(files)

    def selectFile(self):
        selected = self["list"].getCurrent()
        if selected:
            file_path = f"/etc/tuxbox/config/{selected}"
            self.session.open(DVBAPIEditor, file_path)

    def exit(self):
        self.close()

class DVBAPIEditor(Screen, ConfigListScreen):
    skin_fhd = """
    <screen position="center,center" size="1400,788" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="config" position="center,80" size="1200,620" font="bold;55" itemHeight="60" backgroundColor="#21000000" foregroundColor="white"/>
        <widget name="info" position="center,5" size="750,45" font="bold;40" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="35"/>
        <widget name="key_red"
            foregroundColor="red"
            position="100,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="35"
            zPosition="2"
            transparent="1"/>
        <widget name="key_green"
            foregroundColor="green"
            position="400,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="35"
            zPosition="2"
            transparent="1"/>
        <widget name="key_yellow"
            foregroundColor="yellow"
            position="700,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="yellow"
            cornerRadius="35"
            zPosition="2"
            transparent="1"/>
        <widget name="key_blue"
            foregroundColor="blue"
            position="1000,720"
            size="300,50"
            font="bold;35"
            halign="center"
            valign="center"
            backgroundColor="blue"
            cornerRadius="35"
            zPosition="2"
            transparent="1"/>
        <eLabel name="white_line" backgroundColor="red" transparent="0" size="300,2" position="150,775" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="300,2" position="400,775" />
        <eLabel name="white_line" backgroundColor="yellow" transparent="0" size="300,2" position="700,775" />
        <eLabel name="white_line" backgroundColor="blue" transparent="0" size="300,2" position="1000,775" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="1400,3" position="0,716" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center" size="930,525" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="config" position="center,50" size="800,410" font="bold;36" itemHeight="40" backgroundColor="#21000000" foregroundColor="white"/>
        <widget name="info" position="center,5" size="500,30" font="bold;25" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="23"/>
        <widget name="key_red"
            foregroundColor="red"
            position="70,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="red"
            cornerRadius="23"
            zPosition="2"
            transparent="1"/>
        <widget name="key_green"
            foregroundColor="green"
            position="270,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="green"
            cornerRadius="23"
            zPosition="2"
            transparent="1"/>
        <widget name="key_yellow"
            foregroundColor="yellow"
            position="470,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="yellow"
            cornerRadius="23"
            zPosition="2"
            transparent="1"/>
        <widget name="key_blue"
            foregroundColor="blue"
            position="670,480"
            size="200,35"
            font="bold;23"
            halign="center"
            valign="center"
            backgroundColor="blue"
            cornerRadius="23"
            zPosition="2"
            transparent="1"/>
        <eLabel name="white_line" backgroundColor="red" transparent="0" size="200,2" position="100,515" />
        <eLabel name="white_line" backgroundColor="green" transparent="0" size="200,2" position="270,515" />
        <eLabel name="white_line" backgroundColor="yellow" transparent="0" size="200,2" position="470,515" />
        <eLabel name="white_line" backgroundColor="blue" transparent="0" size="200,2" position="670,515" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="930,1" position="0,475" />
    </screen>
    """

    CAID_CHOICES = [
        ("0500", "0500"), ("0100", "0100"), ("1801", "1801"), ("1802", "1802"),
        ("1803", "1803"), ("1807", "1807"), ("1810", "1810"), ("1811", "1811"),
        ("1813", "1813"), ("1814", "1814"), ("1815", "1815"), ("1817", "1817"),
        ("1818", "1818"), ("1819", "1819"), ("181D", "181D"), ("1830", "1830"),
        ("1832", "1832"), ("1833", "1833"), ("1838", "1838"), ("1842", "1842"),
        ("1856", "1856"), ("1860", "1860"), ("1861", "1861"), ("1870", "1870"),
        ("1871", "1871"), ("1878", "1878"), ("1879", "1879"), ("1880", "1880"),
        ("1882", "1882"), ("1884", "1884"), ("1886", "1886"), ("188A", "188A"),
        ("0D90", "0D90"), ("183D", "183D"), ("183E", "183E"), ("186C", "186C"),
        ("4AF4", "4AF4"), ("4B64", "4B64"), ("4AFC", "4AFC"), ("06E2", "06E2"),
        ("06ED", "06ED"), ("069F", "069F"),
        ("0D91", "0D91"), ("0D92", "0D92"), ("0D93", "0D93"), ("0D94", "0D94"),
        ("0D95", "0D95"), ("0D96", "0D96"), ("0D97", "0D97"), ("0D98", "0D98"),
        ("0602", "0602"), ("0604", "0604"), ("0624", "0624"), ("0629", "0629"),
        ("0648", "0648"), ("0649", "0649"), ("0650", "0650"), ("0653", "0653"),
        ("0660", "0660"), ("069B", "069B"), ("0664", "0664"), ("0669", "0669"),
        ("06E2", "06E2"), ("098D", "098D"), ("098C", "098C"), ("09C4", "09C4"),
        ("094C", "094C"), ("0960", "0960"), ("0963", "0963"), ("092B", "092B"),
        ("092F", "092F"), ("09BD", "09BD"), ("0911", "0911"), ("2600", "2600"),
        ("2602", "2602"), ("2610", "2610"), ("0E00", "0E00"), ("4AEE", "4AEE"),
        ("0B00", "0B00"), ("0B01", "0B01"), ("0B02", "0B02"), ("0B03", "0B03"),
        ("0B04", "0B04"), ("0B1C", "0B1C"), ("0B1D", "0B1D"),
    ]

    CAID_PROVIDER_MAP = {
        "0500": [
            "000000", "020810", "020820", "022610", "022C00", "023100", "023800", "023A00",
            "030600", "030B00", "031000", "032100", "032110", "032830", "032900", "032920",
            "032930", "032940", "032950", "041200", "041700", "041950", "041F00", "042200",
            "042300", "042700", "042800", "042820", "042900", "043330", "043800", "050100",
            "050200", "050300", "050400", "050600", "050800", "050F00", "051900", "051910",
            "051A00", "051A10", "051A20", "051A30", "051A40", "060200", "060210", "060220",
            "060400", "060600", "060700", "060900", "042500", "007800", "060230", "060240",
            "061200", "061210", "061220", "061230", "061240", "033A00", "032A00", "040F00",
            "013000", "023000", "003311", "042820", "070210", "050810", "040F10", "040F20",
            "040F30", "040F40", "040F50", "040950", "040960", "040970", "040980", "040980",
        ],
        "1800": ["000000", "007201", "007301", "008C11", "009801", "003C01"],
        "1801": ["000000", "001101", "001103"],
        "1802": ["000000", "004801", "004901", "002101", "002111", "002011"],
        "1803": ["000000"],
        "1804": ["000000"],
        "1805": ["000000"],
        "1806": ["000000", "000101", "000102"],
        "1807": ["000000"],
        "1810": ["000000", "004601", "004701"],
        "1811": ["003311", "003411", "000000"],
        "1813": ["000000", "000068"],
        "1814": ["000000", "005211", "025211", "000001", "000002", "000003", "000004", "000005", "000006", "000007", "000008", "000009", "005225", "025225"],
        "1815": ["000000"],
        "1816": ["000000"],
        "1817": ["000000", "00006A", "00006B", "00006C", "00006D", "00006E"],
        "1818": ["000000"],
        "1819": ["000000", "00006A", "00006B", "00006C", "00006D", "00006E"],
        "181D": ["000000"],
        "1821": ["000000"],
        "1830": ["000000"],
        "1831": ["000000"],
        "1832": ["000000"],
        "1833": ["000000"],
        "1838": ["000000"],
        "183D": ["000000", "005411"],
        "183E": ["000000", "005411"],
        "1842": ["000000"],
        "1843": ["000000"],
        "1856": ["000000"],
        "1860": ["000000"],
        "1861": ["000000"],
        "1862": ["000000"],
        "1863": ["000000", "003342", "003343"],
        "1864": ["000000"],
        "1866": ["000000", "000401", "000402"],
        "1867": ["000000"],
        "1868": ["000000"],
        "186A": ["000000"],
        "186C": ["000000"],
        "186D": ["000000"],
        "1870": ["000000"],
        "1871": ["000000"],
        "1878": ["000000"],
        "1879": ["000000"],
        "1880": ["000000"],
        "1882": ["000000"],
        "1883": ["000000", "003311"],
        "1884": ["000000"],
        "1886": ["000000"],
        "188A": ["000000"],
        "0602": ["000000"],
        "0604": ["000000", "060400"],
        "0606": ["000000"],
        "0609": ["000000"],
        "0622": ["000000"],
        "0629": ["000000"],
        "0648": ["000000"],
        "0649": ["000000"],
        "0650": ["000000"],
        "0653": ["000000"],
        "06E2": ["000000"],
        "06ED": ["000000"],
        "069B": ["000000"],
        "069F": ["000000"],
        "0100": ["000000", "00006A", "00006B", "00006C", "00006D", "00006E", "000068", "003311"],
        "0E00": ["000000"],
        "0B00": ["000000"],
        "0B01": ["000000"],
        "0B02": ["000000"],
        "0B03": ["000000"],
        "0B04": ["000000"],
        "0B1C": ["000000"],
        "0B1D": ["000000"],
        "0BAA": ["000000"],
        "0D00": ["000000", "000004", "000008", "00000C"],
        "0D02": ["000000", "000004", "000008", "00000C"],
        "0D03": ["000000", "000004", "000008", "00000C"],
        "0D05": ["000000", "000004", "000008", "00000C"],
        "0D0F": ["000000", "000004", "000008", "00000C"],
        "0D22": ["000000", "000004", "000008", "00000C"],
        "0D70": ["000000", "000004", "000008", "00000C"],
        "0D94": ["000000", "000004", "000008", "00000C"],
        "0D95": ["000000", "000004", "000008", "00000C"],
        "0D96": ["000000", "000004", "000008", "00000C"],
        "0D97": ["000000", "000004", "000008", "00000C"],
        "0D98": ["000000", "000004", "000008", "00000C"],
        "2600": ["000000"],
        "2610": ["000000"],
        "2602": ["000000"],
        "4AF4": ["000000"],
        "4B64": ["000000"],
        "4AFC": ["000000"],
        "0900": ["000000"],
        "0901": ["000000"],
        "0902": ["000000"],
        "09AA": ["000000"],
        "094C": ["000000"],
        "098C": ["000000"],
        "09C4": ["000000"],
        "0960": ["000000"],
        "0963": ["000000"],
        "098D": ["000000"],
        "092B": ["000000"],
        "0911": ["000000"],
        "091F": ["000000"],
        "092F": ["000000"],
        "0903": ["000000"],
    }

    def __init__(self, session, file_path):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        ConfigListScreen.__init__(self, [])
        self.file_path = file_path
        self.ecm_data = {}
        self.session = session
        self.init_config_elements()
        self.setup_ui()
        self.onShown.append(self.update_display)

    def init_config_elements(self):
        self.action = ConfigSelection(choices=[("P", "Priority"), ("I", "Ignore")], default="P")
        self.caid = ConfigSelection(choices=self.CAID_CHOICES, default="0500")
        self.provid = ConfigSelection(
            choices=[(prov, prov) for prov in self.CAID_PROVIDER_MAP.get("0500", ["000000"])],
            default=self.CAID_PROVIDER_MAP.get("0500", ["000000"])[0]
        )
        self.sid = ConfigText(default=" ", fixed_size=False)
        self.ecmpid = ConfigText(default=" ", fixed_size=False)
        self.chid = ConfigText(default=" ", fixed_size=False)
        self.obligation = ConfigYesNo(default=False)
        self.comment = ConfigText(default=" ", fixed_size=False)

        self.caid.addNotifier(self.update_provid, initial_call=True)
        self.action.addNotifier(self.update_fields)

    def update_provid(self, config_element):
        selected_caid = self.caid.value
        provid_choices = [(prov, prov) for prov in self.CAID_PROVIDER_MAP.get(selected_caid, ["000000"])]
        self.provid = ConfigSelection(choices=provid_choices, default=provid_choices[0][0])
        self.create_setup()

    def update_fields(self, config_element=None):
        self.create_setup()

    def update_display(self):
        self.create_setup()

    def create_setup(self):
        config_list = [
            getConfigListEntry(_("  Action"), self.action),
            getConfigListEntry(_("  CAID"), self.caid),
            getConfigListEntry(_("  Provider ID"), self.provid),
            getConfigListEntry(_("  SID"), ConfigText(default=self.format_value(self.sid.value, 4), fixed_size=False)),
            getConfigListEntry(_("  ECM PID"), ConfigText(default=self.format_value(self.ecmpid.value, 4), fixed_size=False)),
            getConfigListEntry(_("  CHID"), ConfigText(default=self.format_value(self.chid.value, 4), fixed_size=False)),
            getConfigListEntry(_("  Obligation"), self.obligation),
            getConfigListEntry(_("  Comment"), self.comment),
        ]
        self["config"].list = config_list

    def format_value(self, value, length):
        return value.strip().zfill(length) if value.strip() else "0" * length

    def setup_ui(self):
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Browse")
        self["key_blue"] = Label("Get SID")
        self["info"] = Label("Press OK to edit selected field")
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.exit,
            "green": self.save_rule,
            "yellow": self.view_rules,
            "blue": self.get_current_sid,
            "ok": self.open_editor,
        }, -1)

    def open_editor(self):
        current = self["config"].getCurrent()
        if current[0] == "CAID":
            self.session.openWithCallback(
                self.caid_selected,
                ChoiceBox,
                title=_("Select CAID"),
                list=[(caid, caid) for (caid, _) in self.CAID_CHOICES] + [(_("Add New"), "new")]
            )
        elif current[0] == "Provider ID":
            self.session.openWithCallback(
                self.provid_selected,
                ChoiceBox,
                title=_("Select Provider ID"),
                list=[(prov, prov) for prov in self.CAID_PROVIDER_MAP.get(self.caid.value, ["000000"])]
            )
        else:
            self.session.openWithCallback(
                self.keyboard_callback,
                VirtualKeyBoard,
                title=f"Enter {current[0]}",
                text=str(current[1].value)
            )

    def caid_selected(self, result):
        if result:
            self.caid.setValue(result[1])
            self.update_provid(self.caid)
            self.create_setup()

    def provid_selected(self, result):
        if result:
            self.provid.setValue(result[1])
            self.create_setup()

    def keyboard_callback(self, result=None):
        if result is not None:
            current = self["config"].getCurrent()
            current[1].setValue(str(result))
            self.create_setup()

    def get_current_sid(self):
        try:
            current_service = CurrentService(self.session.nav)
            service_info = ServiceInfo(current_service, "SID")
            sid = service_info.getText()
            if sid and sid != "":
                self.sid.setValue(sid)
                self.create_setup()
                self.session.open(MessageBox, f"SID Imported: {sid}", MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(MessageBox, _("Unable to retrieve SID!"), MessageBox.TYPE_ERROR, timeout=3)
        except Exception as e:
            self.session.open(MessageBox, _("Error retrieving SID: ") + str(e), MessageBox.TYPE_ERROR, timeout=3)

    def save_rule(self):
        try:
            rule_line = self.generate_rule_line()
            with open(self.file_path, "a") as f:
                f.write(f"\n{rule_line}")
            self.session.open(MessageBox, _("Rule Saved!"), MessageBox.TYPE_INFO)
        except Exception as e:
            self.session.open(MessageBox, _("Error: ") + str(e), MessageBox.TYPE_ERROR)

    def generate_rule_line(self):
        def format_field(value, length):
            return value.strip().zfill(length) if value.strip() else None

        fields = [
            self.action.value,
            self.caid.value,
            format_field(self.provid.value, 6),
            format_field(self.sid.value, 4),
            format_field(self.ecmpid.value, 4),
            format_field(self.chid.value, 4),
        ]

        while len(fields) > 2 and fields[-1] is None:
            fields.pop()

        rule_parts = [f for f in fields if f is not None]
        rule_line = ":".join(rule_parts)

        if self.comment.value.strip():
            rule_line += f" ; {self.comment.value.strip()}"

        return rule_line

    def view_rules(self):
        self.session.open(DVBAPIViewer, self.file_path)

    def exit(self):
        self.close()

class DVBAPIViewer(Screen):
    skin_fhd = """
    <screen position="center,center" size="1400,788" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="list" position="center,90" size="1200,600" itemHeight="90" font="bold;65" valign="center" halign="center" />
        <widget name="info" position="100,10" size="1200,80" font="bold;35" cornerRadius="35" backgroundColor="#211C84" valign="center" halign="center" />
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="1400,3" position="0,716" />
    </screen>
    """

    skin_hd = """
    <screen position="center,center" size="930,525" title="Enigma2 Reader Adder v3.0 By:Ismail9875" backgroundColor="#21000000">
        <widget name="list" position="center,60" size="800,400" itemHeight="60" font="bold;43" valign="center" halign="center" />
        <widget name="info" position="70,10" size="800,50" font="bold;25" valign="center" halign="center" backgroundColor="#211C84" cornerRadius="23"/>
        <eLabel name="white_line" backgroundColor="transparent" transparent="0" size="930,1" position="0,475" />
    </screen>
    """

    def __init__(self, session, file_path):
        # تحديد السكين المناسب بناءً على دقة الشاشة
        desktop_size = getDesktop(0).size()
        if desktop_size.width() == 1920 and desktop_size.height() == 1080:
            self.skin = self.skin_fhd
        else:
            self.skin = self.skin_hd

        Screen.__init__(self, session)
        self.file_path = file_path
        self.valid_prefixes = ('P:', 'A:', 'M:', 'L:', 'W:', 'I:')
        self["list"] = MenuList([])
        self["info"] = Label("Select rule to view details")
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.show_details,
            "cancel": self.close
        }, -1)
        self.load_rules()

    def load_rules(self):
        try:
            rules = []
            if fileExists(self.file_path):
                with open(self.file_path, "r") as f:
                    for line in f:
                        stripped = line.strip()
                        if not stripped or stripped.startswith('#'):
                            continue
                        if any(stripped.startswith(prefix) for prefix in self.valid_prefixes):
                            rules.append(self.format_line(stripped))

            self["list"].setList(rules or ["No valid rules found"])

        except Exception as e:
            self["info"].setText(f"Error: {str(e)}")

    def format_line(self, line):
        parts = line.split('#', 1)
        params = parts[0].strip()
        comment = parts[1].strip() if len(parts) > 1 else ''
        return f"{params.ljust(60)} #{comment[:25]}" if comment else params

    def show_details(self):
        selected = self["list"].getCurrent()
        if selected and selected != "No valid rules found":
            self.session.open(
                MessageBox,
                self.clean_details(selected),
                MessageBox.TYPE_INFO
            )

    def clean_details(self, text):
        return text.split('#')[0].strip()

def main(session, **kwargs):
    session.open(AddServerScreen)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Enigma2 Reader Adder",
        description="OSCam/NCam Server Management Tool",
        icon="Enigma2ReaderAdder.png",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main
    )
