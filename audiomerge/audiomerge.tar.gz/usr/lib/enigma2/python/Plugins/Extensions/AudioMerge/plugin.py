# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
import os
import signal
import subprocess
import time
try:
    from urllib.parse import quote
except Exception:
    from urllib import quote
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChannelSelection import SimpleChannelSelection
try:
    from Screens.PictureInPicture import PictureInPicture
except Exception:
    PictureInPicture = None
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.config import config
from ServiceReference import ServiceReference
try:
    from enigma import eServiceReference, eDVBVolumecontrol, ePoint, eSize
except Exception:
    eServiceReference = None
    eDVBVolumecontrol = None
    ePoint = None
    eSize = None
from . import _
PLUGIN_NAME = "AudioMerge"
PLUGIN_DESC = _("Merge or transfer live audio between channels by mosad")
PLUGIN_MENU_DESC = PLUGIN_DESC
PLUGIN_VERSION = "4.0"
PLUGIN_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge"
PLUGIN_ICON = os.path.join(PLUGIN_DIR, "plugin.png")
LOG_PATH = "/tmp/audiomerge.log"
STREAM_HOST = "127.0.0.1"
STREAM_PORT = 8001
LOCAL_STREAM_HOST = "127.0.0.1"
LOCAL_STREAM_PORT = 17999
LOCAL_STREAM_PATH = "/audiomerge.ts"
DEFAULT_DELAY_MS = 0
DEFAULT_COMMENTATOR_VOLUME = 2.5
MAX_COMMENTATOR_VOLUME = 4.0
DEFAULT_AUDIO_MODE = "merge"
DEFAULT_TS_SEEK_SECONDS = 15
# HEX colors only
C_BG = "#000000"
C_PANEL = "#0A0A0A"
C_PANEL_2 = "#101010"
C_BORDER = "#252525"
C_TEXT = "#FFFFFF"
C_SUB = "#A9A9A9"
C_ACCENT = "#FFCC00"
C_ACCENT_2 = "#6EA8FF"
C_OK = "#38D27A"
C_ERR = "#FF5B5B"
def log_line(text):
    try:
        fp = open(LOG_PATH, "ab")
        if isinstance(text, bytes):
            fp.write(text)
        else:
            fp.write(("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), text)).encode("utf-8"))
        fp.close()
    except Exception:
        pass
def which(binary_name):
    path = os.environ.get("PATH", "")
    for folder in path.split(os.pathsep):
        full = os.path.join(folder, binary_name)
        if os.path.isfile(full) and os.access(full, os.X_OK):
            return full
    return None
def strip_text(text):
    if not text:
        return ""
    try:
        text = text.replace("\xc2\x86", "").replace("\xc2\x87", "")
        text = text.replace("\x86", "").replace("\x87", "")
    except Exception:
        pass
    return text
def service_name(service_ref):
    try:
        return strip_text(ServiceReference(service_ref).getServiceName())
    except Exception:
        pass
    try:
        return strip_text(service_ref.getServiceName())
    except Exception:
        pass
    try:
        return service_ref.toString()
    except Exception:
        return ""
def service_ref_string(service_ref):
    try:
        return service_ref.toString()
    except Exception:
        try:
            return str(service_ref)
        except Exception:
            return ""

def transport_key(service_ref):
    ref = service_ref_string(service_ref)
    if not ref:
        return None
    parts = ref.split(":")
    if len(parts) < 7:
        return None
    try:
        int(parts[0], 16)
        int(parts[3], 16)
        tsid = parts[4].upper()
        onid = parts[5].upper()
        namespace = parts[6].upper()
        if not tsid or not onid or not namespace:
            return None
        return (tsid, onid, namespace)
    except Exception:
        return None

def same_transport(service_ref_a, service_ref_b):
    key_a = transport_key(service_ref_a)
    key_b = transport_key(service_ref_b)
    if key_a is None or key_b is None:
        return None
    return key_a == key_b
class AudioOverlayEngine(object):
    def __init__(self):
        self.process = None
        self.output_device = None
        self.paused = False
        self.mode = None
        self.virtual_running = False
        self.stream_url = "http://%s:%s%s" % (LOCAL_STREAM_HOST, LOCAL_STREAM_PORT, LOCAL_STREAM_PATH)
    def is_running(self):
        if self.virtual_running:
            return True
        return self.process is not None and self.process.poll() is None
    def stop(self):
        had_virtual = self.virtual_running
        if self.process is None and not had_virtual:
            self.paused = False
            self.mode = None
            self.output_device = None
            return
        try:
            if self.process is not None and self.process.poll() is None:
                self.process.terminate()
        except Exception:
            pass
        time.sleep(0.2)
        try:
            if self.process is not None and self.process.poll() is None:
                self.process.kill()
        except Exception:
            pass
        self.process = None
        self.output_device = None
        self.paused = False
        self.mode = None
        self.virtual_running = False
        log_line("engine stopped")
    def mark_virtual_running(self, mode_name, label):
        self.process = None
        self.output_device = label
        self.paused = False
        self.mode = mode_name
        self.virtual_running = True
    def pause(self):
        if not self.is_running() or self.paused:
            return False
        try:
            os.kill(self.process.pid, signal.SIGSTOP)
            self.paused = True
            log_line("engine paused")
            return True
        except Exception as e:
            log_line("pause failed: %s" % e)
            return False
    def resume(self):
        if not self.is_running() or not self.paused:
            return False
        try:
            os.kill(self.process.pid, signal.SIGCONT)
            self.paused = False
            log_line("engine resumed")
            return True
        except Exception as e:
            log_line("resume failed: %s" % e)
            return False
    def _service_url(self, ref):
        ref_string = ref.toString()
        encoded = quote(ref_string, safe=":")
        return "http://%s:%s/%s" % (STREAM_HOST, STREAM_PORT, encoded)
    def _candidate_devices(self):
        return ["default", "sysdefault", "plughw:0,0", "hw:0,0", "dmix", "pulse"]
    def _probe_audio_stream(self, commentator_url):
        ffprobe_bin = which("ffprobe")
        if not ffprobe_bin:
            log_line("ffprobe not found -> skip probe")
            return None
        probe_cmd = [
            ffprobe_bin,
            "-hide_banner",
            "-loglevel", "error",
            "-rw_timeout", "3000000",
            "-analyzeduration", "1000000",
            "-probesize", "256000",
            "-f", "mpegts",
            "-select_streams", "a",
            "-show_entries", "stream=index,codec_name",
            "-of", "csv=p=0",
            commentator_url,
        ]
        log_line("ffprobe command: %s" % " ".join(probe_cmd))
        proc = None
        try:
            proc = subprocess.Popen(probe_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
            end_time = time.time() + 5.0
            while time.time() < end_time:
                if proc.poll() is not None:
                    break
                time.sleep(0.1)
            if proc.poll() is None:
                try:
                    proc.terminate()
                except Exception:
                    pass
                time.sleep(0.2)
                try:
                    if proc.poll() is None:
                        proc.kill()
                except Exception:
                    pass
                log_line("ffprobe timeout -> fallback")
                return None
            out = proc.stdout.read()
            try:
                out = out.decode("utf-8", "ignore")
            except Exception:
                pass
            log_line("ffprobe output: %s" % out.replace("\n", " | ").strip())
            for line in out.splitlines():
                parts = [x.strip() for x in line.split(",")]
                if len(parts) >= 2:
                    try:
                        idx = int(parts[0])
                    except Exception:
                        continue
                    codec = parts[1]
                    return idx, codec
        except Exception as e:
            log_line("ffprobe failed: %s" % e)
        return None
    def _build_filters(self, delay_ms, volume):
        filters = []
        try:
            delay_ms = int(delay_ms)
        except Exception:
            delay_ms = 0
        try:
            volume = float(volume)
        except Exception:
            volume = DEFAULT_COMMENTATOR_VOLUME
        if delay_ms > 0:
            filters.append("adelay=%d|%d" % (delay_ms, delay_ms))
        elif delay_ms < 0:
            ms = abs(delay_ms) / 1000.0
            filters.append("atrim=start=%0.3f" % ms)
        speech_chain = [
            "highpass=f=120",
            "lowpass=f=7800",
            "acompressor=threshold=0.20:ratio=3.0:attack=5:release=120:makeup=1.8",
            "alimiter=limit=0.97",
        ]
        filters.extend(speech_chain)
        if abs(volume - 1.0) > 0.01:
            filters.append("volume=%.2f" % volume)
        filters.append("alimiter=limit=0.97")
        return filters
    def _build_ffmpeg_overlay(self, ffmpeg_bin, commentator_url, delay_ms, volume, alsa_device, map_spec=None, profile=None):
        if profile is None:
            profile = "mpegts_fast"
        cmd = [
            ffmpeg_bin,
            "-hide_banner",
            "-loglevel", "error",
            "-nostdin",
            "-rw_timeout", "5000000",
            "-thread_queue_size", "1024",
        ]
        if profile == "mpegts_fast":
            cmd.extend(["-fflags", "+discardcorrupt", "-analyzeduration", "1000000", "-probesize", "256000", "-f", "mpegts"])
        elif profile == "mpegts_relaxed":
            cmd.extend(["-fflags", "+discardcorrupt", "-analyzeduration", "5000000", "-probesize", "2000000", "-f", "mpegts"])
        else:
            cmd.extend(["-fflags", "+discardcorrupt", "-analyzeduration", "5000000", "-probesize", "2000000"])
        cmd.extend(["-i", commentator_url])
        if map_spec:
            cmd.extend(["-map", map_spec])
        cmd.extend(["-map", "-0:v", "-map", "-0:s", "-map", "-0:d"])
        cmd.extend(["-vn", "-sn", "-dn", "-ac", "2", "-ar", "48000"])
        filters = self._build_filters(delay_ms, volume)
        if filters:
            cmd.extend(["-af", ",".join(filters)])
        cmd.extend(["-acodec", "pcm_s16le", "-f", "alsa", alsa_device])
        return cmd
    def _start_audio_to_alsa(self, commentator_ref, delay_ms, volume, mode_name):
        self.stop()
        ffmpeg_bin = which("ffmpeg") or which("avconv")
        if not ffmpeg_bin:
            raise RuntimeError("ffmpeg or avconv not found")
        commentator_url = self._service_url(commentator_ref)
        log_line("=== AudioMerge %s %s start ===" % (PLUGIN_VERSION, mode_name))
        log_line("source audio url: %s" % commentator_url)
        map_candidates = ["0:a:0?", "0:a?", "0:1?", "0:0?"]
        probe = self._probe_audio_stream(commentator_url)
        if probe:
            idx, codec = probe
            map_candidates.insert(0, "0:%d" % idx)
            log_line("%s audio stream detected: index=%d codec=%s" % (mode_name, idx, codec))
        else:
            log_line("%s audio probe fallback -> trying generic maps" % mode_name)
        tried = []
        last_error = None
        profiles = ["mpegts_fast", "mpegts_relaxed", "generic"]
        for profile in profiles:
            for map_spec in map_candidates:
                if map_spec in tried:
                    continue
                tried.append(map_spec)
                for dev in self._candidate_devices():
                    log_file = None
                    try:
                        cmd = self._build_ffmpeg_overlay(ffmpeg_bin, commentator_url, delay_ms, volume, dev, map_spec=map_spec, profile=profile)
                        log_line("trying %s profile=%s map=%s device=%s" % (mode_name, profile, map_spec, dev))
                        log_line("command: %s" % " ".join(cmd))
                        log_file = open(LOG_PATH, "ab")
                        self.process = subprocess.Popen(cmd, stdin=open(os.devnull, "rb"), stdout=log_file, stderr=log_file, close_fds=True)
                        self.output_device = dev
                        self.paused = False
                        self.mode = mode_name
                        self.virtual_running = False
                        time.sleep(1.5)
                        if self.process.poll() is not None:
                            raise RuntimeError("ffmpeg exited on %s (%s / %s)" % (dev, profile, map_spec))
                        log_line("%s started: ffmpeg -> %s (%s / %s)" % (mode_name, dev, profile, map_spec))
                        return dev
                    except Exception as e:
                        last_error = e
                        log_line("%s try failed: %s / %s / %s -> %s" % (mode_name, profile, map_spec, dev, e))
                        try:
                            if self.process and self.process.poll() is None:
                                self.process.terminate()
                                time.sleep(0.2)
                        except Exception:
                            pass
                        self.process = None
                        self.output_device = None
                        self.paused = False
                        self.mode = None
                        self.virtual_running = False
                        try:
                            if log_file:
                                log_file.close()
                        except Exception:
                            pass
        raise RuntimeError(str(last_error or ("Unable to start %s" % mode_name)))
    def start_merge(self, commentator_ref, delay_ms, volume):
        return self._start_audio_to_alsa(commentator_ref, delay_ms, volume, "merge")
def build_stream_service_ref(url, title=None):
    if eServiceReference is not None:
        try:
            ref = eServiceReference(4097, 0, url)
            try:
                if title:
                    ref.setName(title)
            except Exception:
                pass
            return ref
        except Exception as e:
            log_line("build stream service ref failed: %s" % e)
    return None
OVERLAY_ENGINE = AudioOverlayEngine()
OVERLAY_STATE = {
    "commentator_ref": None,
    "stadium_ref": None,
    "delay_ms": DEFAULT_DELAY_MS,
    "commentator_volume": DEFAULT_COMMENTATOR_VOLUME,
    "audio_mode": DEFAULT_AUDIO_MODE,
    "transfer_active": False,
    "transfer_decoder_muted": False,
    "transfer_prev_muted": None,
    "transfer_prev_pip_mode": None,
    "transfer_prev_pip_config": None,
    "transfer_hidden_enabled": True,
}
class AudioMergeInfoScreen(Screen):
    """Info / Support screen (QR codes)."""
    skin = """
    <screen name="AudioMergeInfoScreen" position="center,center" size="1480,500" title="Info" backgroundColor="#000000" cornerRadius="20" flags="wfNoBorder">
        <eLabel position="0,0" size="1480,500" backgroundColor="#000000" zPosition="-10" />
        <eLabel position="0,0" size="1480,500" backgroundColor="#0A0A0A" zPosition="-9" />
        <eLabel position="0,0" size="1480,86" backgroundColor="#101010" zPosition="-8" />
        <eLabel position="44,90" size="1392,2" backgroundColor="#252525" zPosition="-8" />
        <widget name="title_lbl" position="36,22" size="260,36" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5" />
        <widget name="header_lbl" position="0,18" size="1480,34" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5" />
        <widget name="hint_lbl" position="0,56" size="1480,26" font="Regular;22" foregroundColor="#A9A9A9" transparent="1" halign="center" zPosition="5" />
        <widget name="paypal_lbl" position="0,112" size="740,26" font="Regular;26" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5" />
        <widget name="whatsapp_lbl" position="740,112" size="740,26" font="Regular;26" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5" />
        <eLabel position="220,144" size="500,320" backgroundColor="#101010" zPosition="-8" />
        <eLabel position="760,144" size="500,320" backgroundColor="#101010" zPosition="-8" />
        <ePixmap position="320,160" size="300,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/paypal-qr.png" alphatest="blend" zPosition="6" />
        <ePixmap position="860,160" size="300,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/whatsapp-qr.png" alphatest="blend" zPosition="6" />
        <widget name="close_lbl" position="0,460" size="1480,26" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
    </screen>
    """
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["title_lbl"] = Label(_("Info"))
        self["header_lbl"] = Label(_("Support / Subscription"))
        self["hint_lbl"] = Label(_("Scan the QR codes below to contact us or make a donation."))
        self["paypal_lbl"] = Label(_("PayPal"))
        self["whatsapp_lbl"] = Label(_("WhatsApp"))
        self["close_lbl"] = Label(_("OK / EXIT : Close"))
        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {
                "ok": self.close,
                "cancel": self.close,
                "back": self.close,
            },
            -2,
        )
class AudioMergeScreen(Screen):
    skin = """
    <screen name="AudioMergeScreen" position="center,center" size="1480,500" title="AudioMerge" backgroundColor="#000000" cornerRadius="20" flags="wfNoBorder">
        <eLabel position="0,0" size="1480,500" backgroundColor="#000000" zPosition="-10" />
        <eLabel position="0,0" size="1480,500" backgroundColor="#0A0A0A" zPosition="-9" />
        <eLabel position="0,0" size="1480,76" backgroundColor="#101010" zPosition="-8" />
        <eLabel position="44,92" size="1392,2" backgroundColor="#252525" zPosition="-8" />
        <eLabel position="70,118" size="620,264" backgroundColor="#101010" zPosition="-8" />
        <eLabel position="760,118" size="650,74" backgroundColor="#101010" zPosition="-8" />
        <eLabel position="760,214" size="650,74" backgroundColor="#101010" zPosition="-8" />
        <eLabel position="760,310" size="650,74" backgroundColor="#101010" zPosition="-8" />
        <widget name="title_lbl" position="36,20" size="760,36" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5" />
        <widget name="sub_lbl" position="36,52" size="260,24" font="Regular;22" foregroundColor="#A9A9A9" transparent="1" zPosition="5" />
        <widget name="status_lbl" position="900,22" size="540,30" font="Regular;24" foregroundColor="#38D27A" halign="right" transparent="1" zPosition="5" />
        <widget name="hint_lbl" position="70,96" size="1260,20" font="Regular;20" foregroundColor="#A9A9A9" transparent="1" zPosition="5" />
        <widget name="menu" position="86,132" size="588,236" font="Regular;28" itemHeight="46" scrollbarMode="showNever"
            backgroundColor="#101010" foregroundColor="#FFFFFF" selectionBackgroundColor="#252525" selectionForegroundColor="#FFFFFF" zPosition="6" />
        <widget name="section_1" position="780,128" size="260,24" font="Regular;24" foregroundColor="#FFCC00" transparent="1" zPosition="5" />
        <widget name="value_1" position="780,156" size="610,26" font="Regular;26" foregroundColor="#FFFFFF" transparent="1" zPosition="5" noWrap="1" />
        <widget name="section_2" position="780,224" size="260,24" font="Regular;24" foregroundColor="#6EA8FF" transparent="1" zPosition="5" />
        <widget name="value_2" position="780,252" size="610,26" font="Regular;26" foregroundColor="#FFFFFF" transparent="1" zPosition="5" noWrap="1" />
        <widget name="section_3" position="780,320" size="360,24" font="Regular;24" foregroundColor="#FFCC00" transparent="1" zPosition="5" />
        <widget name="value_3" position="780,348" size="610,26" font="Regular;26" foregroundColor="#FFFFFF" transparent="1" zPosition="5" noWrap="1" />
        <ePixmap position="73,420" size="38,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/buttons/key_exit.png" alphatest="blend" zPosition="6" />
        <ePixmap position="258,420" size="38,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/buttons/key_yellow.png" alphatest="blend" zPosition="6" />
        <ePixmap position="443,420" size="38,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/buttons/key_info.png" alphatest="blend" zPosition="6" />
        <ePixmap position="628,420" size="38,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/buttons/state_play.png" alphatest="blend" zPosition="6" />
        <ePixmap position="813,420" size="38,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/buttons/state_pause.png" alphatest="blend" zPosition="6" />
        <ePixmap position="998,420" size="38,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/buttons/state_ff.png" alphatest="blend" zPosition="6" />
        <ePixmap position="1183,420" size="38,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/buttons/state_rw.png" alphatest="blend" zPosition="6" />
        <ePixmap position="1368,420" size="38,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioMerge/buttons/key_ok.png" alphatest="blend" zPosition="6" />
        <widget name="txt_exit" position="0,458" size="185,24" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
        <widget name="txt_yellow" position="185,458" size="185,24" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
        <widget name="txt_info" position="370,458" size="185,24" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
        <widget name="txt_play" position="555,458" size="185,24" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
        <widget name="txt_pause" position="740,458" size="185,24" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
        <widget name="txt_ff" position="925,458" size="185,24" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
        <widget name="txt_rw" position="1110,458" size="185,24" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
        <widget name="txt_ok" position="1295,458" size="185,24" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6" />
    </screen>
    """
    MENU_SELECT_COMMENTATOR = 0
    MENU_SELECT_STADIUM = 1
    MENU_MODE = 2
    MENU_TRANSFER_PIP = 3
    MENU_START = 4
    MENU_SYNC = 5
    MENU_VOLUME = 6
    MENU_PAUSE = 7
    MENU_STOP = 8
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.engine = OVERLAY_ENGINE
        self.commentator_ref = OVERLAY_STATE.get("commentator_ref")
        self.stadium_ref = OVERLAY_STATE.get("stadium_ref")
        self.delay_ms = OVERLAY_STATE.get("delay_ms", DEFAULT_DELAY_MS)
        self.commentator_volume = OVERLAY_STATE.get("commentator_volume", DEFAULT_COMMENTATOR_VOLUME)
        self.audio_mode = OVERLAY_STATE.get("audio_mode", DEFAULT_AUDIO_MODE)
        self.transfer_hidden_enabled = bool(OVERLAY_STATE.get("transfer_hidden_enabled", True))
        self.ts_paused = False
        if OVERLAY_STATE.get("transfer_active") and getattr(self.session, "pipshown", False):
            self.engine.mark_virtual_running("transfer", "Fullscreen PiP")
        self.menu_items = []
        self["title_lbl"] = Label(PLUGIN_NAME)
        self["sub_lbl"] = Label("")
        self["status_lbl"] = Label(_("Ready"))
        self["hint_lbl"] = Label(_("Use arrows to browse - OK to select - YELLOW = Sync - Play buttons = TimeShift"))
        try:
            self["menu"] = MenuList([], enableWrapAround=True)
        except Exception:
            self["menu"] = MenuList([])
        self["section_1"] = Label(_("Audio source"))
        self["value_1"] = Label(_("Not selected"))
        self["section_2"] = Label(_("Video / target channel"))
        self["value_2"] = Label(_("Current live service"))
        self["section_3"] = Label(_("Mode / Sync / Volume / Engine"))
        self["value_3"] = Label("Merge / 0 ms / 100% / FFmpeg")
        self["txt_exit"] = Label(_("Exit"))
        self["txt_yellow"] = Label(_("Sync"))
        self["txt_info"] = Label(_("Info"))
        self["txt_play"] = Label(_("Play"))
        self["txt_pause"] = Label(_("Playpause"))
        self["txt_ff"] = Label(_("Fastforward"))
        self["txt_rw"] = Label(_("Rewind"))
        self["txt_ok"] = Label(_("OK / Start"))
        self["actions"] = ActionMap(
            [
                "OkCancelActions",
                "DirectionActions",
                "ColorActions",
                "InfobarAudioSelectionActions",
                "InfoActions",
                "InfobarEPGActions",
                "InfobarSubtitleSelectionActions",
                "InfobarTVRadioActions",
                "HelpActions",
                "MediaPlayerActions",
                "MenuActions",
            ],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOK,
                "cancel": self.keyExit,
                "back": self.keyExit,
                "red": self.keyExit,
                "yellow": self.keySync,
                "blue": self.keyTsPlayPause,
                "audioSelection": self.keyTsPlayPause,
                "info": self.keyInfo,
                "showEPGList": self.keyInfo,
                "showSingleEPG": self.keyInfo,
                "showMultiEPG": self.keyInfo,
                "subtitle": self.keyInfo,
                "subtitleSelection": self.keyInfo,
                "showTv": self.keyInfo,
                "showRadio": self.keyInfo,
                "displayHelp": self.keyInfo,
                "play": self.keyTsPlay,
                "pause": self.keyTsPlayPause,
                "playpauseService": self.keyTsPlayPause,
                "rewind": self.keyTsRewind,
                "fastforward": self.keyTsFastForward,
                "playpause": self.keyTsPlayPause,
            },
            -2,
        )
        try:
            self["menu"].onSelectionChanged.append(self._update_hint)
        except Exception:
            pass
        self.onLayoutFinish.append(self._on_layout_finish)
        self.onClose.append(self._on_close)
    def _on_layout_finish(self):
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            current = None
        if self.stadium_ref is None and current is not None:
            self.stadium_ref = current
            OVERLAY_STATE["stadium_ref"] = current
        self._rebuild_menu()
        self._refresh_info()
        self._update_hint()
    def _on_close(self):
        if OVERLAY_STATE.get("transfer_active"):
            try:
                self._stop_transfer_pip()
                self._toggle_decoder_mute(False)
                if self.stadium_ref is not None:
                    self.session.nav.playService(self.stadium_ref)
                log_line("AudioMerge screen closed - active transfer stopped to release receiver PiP")
            except Exception as e:
                log_line("AudioMerge close cleanup failed: %s" % e)
        else:
            log_line("AudioMerge screen closed - engine kept running")
    def _selected_name(self, ref, fallback):
        if ref is None:
            return fallback
        name = service_name(ref)
        return name or fallback
    def _current_index(self):
        try:
            idx = int(self["menu"].getSelectedIndex())
        except Exception:
            idx = 0
        if idx < 0:
            idx = 0
        if idx >= len(self.menu_items):
            idx = len(self.menu_items) - 1 if self.menu_items else 0
        return idx
    def _audio_mode_label(self):
        if self.audio_mode == "transfer":
            return _("Transfer")
        return _("Merge")

    def _hidden_pip_label(self):
        return _("Enabled") if bool(getattr(self, "transfer_hidden_enabled", OVERLAY_STATE.get("transfer_hidden_enabled", True))) else _("Disabled")
    def _engine_label(self):
        if self.engine.paused:
            return "FFmpeg / paused"
        if self.engine.is_running():
            if self.engine.mode == "transfer":
                return self.engine.output_device or "Fullscreen PiP"
            return "FFmpeg / %s" % (self.engine.output_device or "running")
        return "FFmpeg"
    def _remember_pip_layout(self):
        try:
            OVERLAY_STATE["transfer_prev_pip_mode"] = config.av.pip_mode.value
        except Exception:
            OVERLAY_STATE["transfer_prev_pip_mode"] = None
        try:
            OVERLAY_STATE["transfer_prev_pip_config"] = list(config.av.pip.value)
        except Exception:
            OVERLAY_STATE["transfer_prev_pip_config"] = None

    def _restore_pip_layout(self):
        prev_mode = OVERLAY_STATE.get("transfer_prev_pip_mode")
        prev_cfg = OVERLAY_STATE.get("transfer_prev_pip_config")
        try:
            if prev_mode is not None:
                config.av.pip_mode.value = prev_mode
                config.av.pip_mode.save()
        except Exception as e:
            log_line("restore pip mode failed: %s" % e)
        try:
            if prev_cfg and len(prev_cfg) == 4:
                config.av.pip.value = prev_cfg
                config.av.pip.save()
        except Exception as e:
            log_line("restore pip geometry failed: %s" % e)
        OVERLAY_STATE["transfer_prev_pip_mode"] = None
        OVERLAY_STATE["transfer_prev_pip_config"] = None

    def _set_fullscreen_pip(self, pip_dialog):
        if pip_dialog is None:
            return
        try:
            if hasattr(pip_dialog, "setMode"):
                pip_dialog.setMode("bigpig")
                log_line("transfer PiP mode set to bigpig")
        except Exception as e:
            log_line("setMode(bigpig) failed: %s" % e)
        try:
            if hasattr(pip_dialog, "move"):
                pip_dialog.move(0, 0)
        except Exception:
            pass
        try:
            if hasattr(pip_dialog, "resize"):
                pip_dialog.resize(720, 576)
                log_line("transfer PiP resized to fullscreen")
        except Exception as e:
            log_line("PiP resize fallback failed: %s" % e)

    def _stop_transfer_pip(self):
        if not OVERLAY_STATE.get("transfer_active"):
            self._restore_pip_layout()
            return
        pip_dialog = getattr(self.session, "pip", None)
        try:
            if pip_dialog is not None and hasattr(pip_dialog, "playService"):
                pip_dialog.playService(None)
        except Exception as e:
            log_line("transfer PiP stop playService(None) failed: %s" % e)
        try:
            if pip_dialog is not None and hasattr(pip_dialog, "hide"):
                pip_dialog.hide()
        except Exception:
            pass
        try:
            if hasattr(self.session, "pip"):
                del self.session.pip
        except Exception as e:
            log_line("transfer PiP delete failed: %s" % e)
        try:
            self.session.pipshown = False
        except Exception:
            pass
        self._restore_pip_layout()
        OVERLAY_STATE["transfer_active"] = False
        if self.engine.mode == "transfer":
            self.engine.stop()
        log_line("fullscreen PiP transfer stopped")

    def _start_transfer_fullscreen_pip(self):
        if PictureInPicture is None:
            raise RuntimeError("Picture in Picture is not available on this image")
        if getattr(self.session, "pipshown", False) and not OVERLAY_STATE.get("transfer_active"):
            raise RuntimeError("Close the current PiP window first")
        if OVERLAY_STATE.get("transfer_active"):
            self._stop_transfer_pip()
        self._remember_pip_layout()
        pip_dialog = self.session.instantiateDialog(PictureInPicture)
        try:
            if hasattr(pip_dialog, "setAnimationMode"):
                pip_dialog.setAnimationMode(0)
        except Exception:
            pass
        try:
            pip_dialog.show()
        except Exception:
            pass
        started = False
        try:
            started = bool(pip_dialog.playService(self.stadium_ref))
        except Exception as e:
            log_line("fullscreen PiP playService failed: %s" % e)
            started = False
        if not started:
            try:
                pip_dialog.playService(None)
            except Exception:
                pass
            try:
                pip_dialog.hide()
            except Exception:
                pass
            self._restore_pip_layout()
            raise RuntimeError("Could not open fullscreen PiP target service")
        self.session.pip = pip_dialog
        self.session.pipshown = True
        try:
            self.session.pip.servicePath = []
        except Exception:
            pass
        self._set_fullscreen_pip(pip_dialog)
        self.engine.mark_virtual_running("transfer", "Fullscreen PiP")
        OVERLAY_STATE["transfer_active"] = True
        log_line("transfer started: Fullscreen PiP (main audio source + PiP target video)")
        return "Fullscreen PiP"

    def _toggle_decoder_mute(self, want_muted):
        if not want_muted and not OVERLAY_STATE.get("transfer_decoder_muted"):
            return True
        vc = None
        try:
            if eDVBVolumecontrol is not None:
                vc = eDVBVolumecontrol.getInstance()
        except Exception as e:
            log_line("volume control getInstance failed: %s" % e)
            vc = None
        if vc is None:
            log_line("volume control unavailable for transfer")
            return False
        try:
            current_muted = bool(vc.isMuted())
        except Exception:
            current_muted = False
        try:
            if want_muted:
                OVERLAY_STATE["transfer_prev_muted"] = current_muted
                if not current_muted:
                    try:
                        vc.volumeMute()
                    except Exception:
                        vc.volumeToggleMute()
                OVERLAY_STATE["transfer_decoder_muted"] = True
                log_line("target decoder muted for transfer")
                return True
            if not OVERLAY_STATE.get("transfer_decoder_muted"):
                return True
            prev_muted = OVERLAY_STATE.get("transfer_prev_muted")
            if prev_muted is False:
                try:
                    if hasattr(vc, "volumeUnMute"):
                        vc.volumeUnMute()
                    else:
                        vc.volumeToggleMute()
                except Exception:
                    vc.volumeToggleMute()
            OVERLAY_STATE["transfer_decoder_muted"] = False
            OVERLAY_STATE["transfer_prev_muted"] = None
            log_line("target decoder audio restored after transfer")
            return True
        except Exception as e:
            log_line("toggle decoder mute failed: %s" % e)
            return False
    def _rebuild_menu(self):
        start_label = _("Start merge")
        if self.audio_mode == "transfer":
            start_label = _("Start transfer")
        self.menu_items = [
            _("Select audio source channel"),
            _("Select video / target channel"),
            _("Audio mode: %s") % self._audio_mode_label(),
            _("Hidden PiP fullscreen: %s") % self._hidden_pip_label(),
            start_label,
            _("Sync delay: %d ms") % self.delay_ms,
            _("Source volume: %d%%") % self._volume_percent(),
            _("TimeShift controls"),
            _("Stop audio process"),
        ]
        idx = self._current_index()
        self["menu"].setList(self.menu_items)
        try:
            self["menu"].moveToIndex(idx)
        except Exception:
            pass
    def _update_hint(self):
        idx = self._current_index()
        hints = {
            self.MENU_SELECT_COMMENTATOR: _("Choose the channel that provides the audio source."),
            self.MENU_SELECT_STADIUM: _("Choose the channel that keeps the main video / target service."),
            self.MENU_MODE: _("Toggle between merge mode and transfer mode without mixing."),
            self.MENU_START: _("Start the selected mode using the chosen channels."),
            self.MENU_SYNC: _("Press YELLOW or OK to change sync. Transfer via Fullscreen PiP ignores sync."),
            self.MENU_VOLUME: _("Press OK to change source audio volume up to 400%. Merge mode now applies speech enhancement and dynamic leveling for clearer commentary. Transfer via Fullscreen PiP uses the source service volume."),
            self.MENU_PAUSE: _("Use Play / Playpause / Fastforward / Rewind buttons for TimeShift."),
            self.MENU_STOP: _("Stop the current audio backend and return to the target channel."),
        }
        self["hint_lbl"].setText(hints.get(idx, ""))
    def _volume_percent(self):
        return int(round(max(0.0, min(MAX_COMMENTATOR_VOLUME, self.commentator_volume)) * 100.0))
    def _refresh_info(self):
        commentator = self._selected_name(self.commentator_ref, _("Not selected"))
        stadium = self._selected_name(self.stadium_ref, _("Current live service"))
        self["section_1"].setText(_("Audio source"))
        self["section_2"].setText(_("Video / target channel"))
        self["section_3"].setText(_("Mode / Sync / Volume / Engine"))
        self["value_1"].setText(commentator)
        self["value_2"].setText(stadium)
        mode_label = self._audio_mode_label()
        self["value_3"].setText("%s / %d ms / %d%% / %s" % (mode_label, self.delay_ms, self._volume_percent(), self._engine_label()))
    def _set_status(self, text, ok=True):
        self["status_lbl"].setText(text)
        try:
            from skin import parseColor
            self["status_lbl"].instance.setForegroundColor(parseColor(C_OK if ok else C_ERR))
        except Exception:
            pass
    def _move_menu(self, direction):
        try:
            inst = self["menu"].instance
            if direction < 0:
                inst.moveSelection(inst.moveUp)
            else:
                inst.moveSelection(inst.moveDown)
        except Exception:
            try:
                if direction < 0:
                    self["menu"].up()
                else:
                    self["menu"].down()
            except Exception:
                pass
        self._update_hint()
    def _apply_live_update(self):
        if (self.engine.is_running() or self.engine.paused) and self.engine.mode == "merge":
            self.start_merge(restart=True)
        self._rebuild_menu()
        self._refresh_info()
    def _change_volume(self, step):
        new_volume = self.commentator_volume + step
        if new_volume < 0.0:
            new_volume = 0.0
        if new_volume > MAX_COMMENTATOR_VOLUME:
            new_volume = MAX_COMMENTATOR_VOLUME
        self.commentator_volume = round(new_volume, 2)
        OVERLAY_STATE["commentator_volume"] = self.commentator_volume
        self._set_status(_("Volume updated"), ok=True)
        self._apply_live_update()
    def _cycle_audio_mode(self):
        if self.audio_mode == "merge":
            self.audio_mode = "transfer"
        else:
            self.audio_mode = "merge"
        OVERLAY_STATE["audio_mode"] = self.audio_mode
        self._set_status(_("Audio mode updated"), ok=True)
        self._rebuild_menu()
        self._refresh_info()
    def keyUp(self):
        self._move_menu(-1)
    def keyDown(self):
        self._move_menu(1)
    def keyLeft(self):
        self.keyUp()
    def keyRight(self):
        self.keyDown()
    def _cycle_volume(self):
        presets = [0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00, 2.50, 3.00, 3.50, 4.00]
        current = round(self.commentator_volume, 2)
        try:
            idx = presets.index(current)
        except Exception:
            idx = 3
        idx += 1
        if idx >= len(presets):
            idx = 0
        self.commentator_volume = presets[idx]
        OVERLAY_STATE["commentator_volume"] = self.commentator_volume
        self._set_status(_("Volume updated"), ok=True)
        self._apply_live_update()
    def keyOK(self):
        idx = self._current_index()
        if idx == self.MENU_SELECT_COMMENTATOR:
            self.session.openWithCallback(self._commentator_selected, SimpleChannelSelection, _("Select audio source channel"), currentBouquet=True)
        elif idx == self.MENU_SELECT_STADIUM:
            self.session.openWithCallback(self._stadium_selected, SimpleChannelSelection, _("Select video / target channel"), currentBouquet=True)
        elif idx == self.MENU_MODE:
            self._cycle_audio_mode()
        elif idx == self.MENU_TRANSFER_PIP:
            self.transfer_hidden_enabled = not self.transfer_hidden_enabled
            OVERLAY_STATE["transfer_hidden_enabled"] = self.transfer_hidden_enabled
            if not self.transfer_hidden_enabled and OVERLAY_STATE.get("transfer_active"):
                self._stop_audio_process(return_to_target=True)
                self._set_status(_("Hidden PiP disabled and active transfer stopped"), ok=True)
            else:
                self._set_status(_("Hidden PiP: %s") % self._hidden_pip_label(), ok=True)
            self._rebuild_menu()
            self._refresh_info()
            self._update_hint()
        elif idx == self.MENU_START:
            self.start_merge()
        elif idx == self.MENU_SYNC:
            self.keySync()
        elif idx == self.MENU_VOLUME:
            self._cycle_volume()
        elif idx == self.MENU_PAUSE:
            self._set_status(_("Use Play / Playpause / Fastforward / Rewind buttons"), ok=True)
        elif idx == self.MENU_STOP:
            self._stop_audio_process(return_to_target=True)
    def _stop_audio_process(self, return_to_target=False):
        self._stop_transfer_pip()
        self.engine.stop()
        self._toggle_decoder_mute(False)
        if return_to_target and self.stadium_ref is not None:
            try:
                self.session.nav.playService(self.stadium_ref)
                log_line("returned to target service after audio stop")
            except Exception as e:
                log_line("return to target service failed: %s" % e)
        self._set_status(_("Audio stopped"), ok=True)
        self._refresh_info()
    def _commentator_selected(self, service_ref=None):
        if service_ref is not None:
            self.commentator_ref = service_ref
            OVERLAY_STATE["commentator_ref"] = service_ref
            self._set_status(_("Audio source selected"), ok=True)
            self._refresh_info()
    def _stadium_selected(self, service_ref=None):
        if service_ref is not None:
            self.stadium_ref = service_ref
            OVERLAY_STATE["stadium_ref"] = service_ref
            self._set_status(_("Target channel selected"), ok=True)
            self._refresh_info()
    def keySync(self):
        presets = [-500, -250, -100, 0, 100, 250, 500]
        try:
            current = presets.index(self.delay_ms)
        except Exception:
            current = 3
        current += 1
        if current >= len(presets):
            current = 0
        self.delay_ms = presets[current]
        OVERLAY_STATE["delay_ms"] = self.delay_ms
        self._set_status(_("Sync updated"), ok=True)
        self._apply_live_update()
    def keyPausePlay(self):
        if self.engine.mode == "transfer":
            self._set_status("Pause/resume is available in Merge only", ok=False)
            return
        if not self.engine.is_running() and not self.engine.paused:
            self._set_status(_("Audio not running"), ok=False)
            return
        if self.engine.paused:
            if self.engine.resume():
                self._set_status(_("Audio resumed"), ok=True)
            else:
                self._set_status(_("Resume failed"), ok=False)
        else:
            if self.engine.pause():
                self._set_status(_("Audio paused"), ok=True)
            else:
                self._set_status(_("Pause failed"), ok=False)
        self._refresh_info()
    def _get_current_service(self):
        try:
            return self.session.nav.getCurrentService()
        except Exception:
            return None
    def _ensure_timeshift_support(self):
        service = self._get_current_service()
        if service is None:
            return None, None
        pauseable = None
        seekable = None
        try:
            pauseable = service.pause()
        except Exception:
            pauseable = None
        try:
            seekable = service.seek()
        except Exception:
            seekable = None
        if pauseable is None and seekable is None:
            try:
                from Screens.InfoBar import InfoBar
                infobar = getattr(InfoBar, "instance", None)
                if infobar is not None:
                    for method_name in ("startTimeshift", "activateTimeshiftEndAndPause", "activateTimeshiftEnd"):
                        method = getattr(infobar, method_name, None)
                        if callable(method):
                            try:
                                method()
                                break
                            except Exception:
                                pass
                service = self._get_current_service()
                if service is not None:
                    try:
                        pauseable = service.pause()
                    except Exception:
                        pauseable = None
                    try:
                        seekable = service.seek()
                    except Exception:
                        seekable = None
            except Exception:
                pass
        return pauseable, seekable
    def keyTsPlay(self):
        pauseable, seekable = self._ensure_timeshift_support()
        if pauseable is None:
            self._set_status(_("TimeShift not available"), ok=False)
            return
        try:
            if hasattr(pauseable, "unpause"):
                pauseable.unpause()
            elif hasattr(pauseable, "pause"):
                pauseable.pause()
            self.ts_paused = False
            self._set_status(_("TimeShift play"), ok=True)
        except Exception as e:
            log_line("timeshift play failed: %s" % e)
            self._set_status(_("TimeShift play failed"), ok=False)
    def keyTsPlayPause(self):
        pauseable, seekable = self._ensure_timeshift_support()
        if pauseable is None:
            self._set_status(_("TimeShift not available"), ok=False)
            return
        try:
            if self.ts_paused:
                if hasattr(pauseable, "unpause"):
                    pauseable.unpause()
                elif hasattr(pauseable, "pause"):
                    pauseable.pause()
                self.ts_paused = False
                self._set_status(_("TimeShift resumed"), ok=True)
            else:
                pauseable.pause()
                self.ts_paused = True
                self._set_status(_("TimeShift paused"), ok=True)
        except Exception as e:
            log_line("timeshift playpause failed: %s" % e)
            self._set_status(_("TimeShift playpause failed"), ok=False)
    def _timeshift_seek(self, direction, seconds):
        pauseable, seekable = self._ensure_timeshift_support()
        if seekable is None:
            self._set_status(_("TimeShift not available"), ok=False)
            return
        try:
            if hasattr(seekable, "isCurrentlySeekable"):
                try:
                    if not seekable.isCurrentlySeekable():
                        self._set_status(_("TimeShift not available"), ok=False)
                        return
                except Exception:
                    pass
            pts = int(seconds * 90000)
            seekable.seekRelative(direction, pts)
            if direction < 0:
                self._set_status(_("TimeShift rewind"), ok=True)
            else:
                self._set_status(_("TimeShift fast forward"), ok=True)
        except Exception as e:
            log_line("timeshift seek failed: %s" % e)
            self._set_status(_("TimeShift seek failed"), ok=False)
    def keyTsFastForward(self):
        self._timeshift_seek(1, DEFAULT_TS_SEEK_SECONDS)
    def keyTsRewind(self):
        self._timeshift_seek(-1, DEFAULT_TS_SEEK_SECONDS)
    def start_merge(self, restart=False):
        if self.commentator_ref is None:
            self.session.open(MessageBox, _("Please select the audio source channel first."), MessageBox.TYPE_ERROR, timeout=4)
            return
        if self.stadium_ref is None:
            self.session.open(MessageBox, _("Please select the video / target channel first."), MessageBox.TYPE_ERROR, timeout=4)
            return
        OVERLAY_STATE["commentator_ref"] = self.commentator_ref
        OVERLAY_STATE["stadium_ref"] = self.stadium_ref
        OVERLAY_STATE["delay_ms"] = self.delay_ms
        OVERLAY_STATE["commentator_volume"] = self.commentator_volume
        OVERLAY_STATE["audio_mode"] = self.audio_mode
        try:
            self._stop_transfer_pip()
            self.engine.stop()
            if self.audio_mode == "merge":
                self.session.nav.playService(self.stadium_ref)
                log_line("playing target service: %s" % self._selected_name(self.stadium_ref, "target"))
                time.sleep(0.35)
                self._toggle_decoder_mute(False)
                dev = self.engine.start_merge(self.commentator_ref, self.delay_ms, self.commentator_volume)
                self._set_status(_("Merge running on %s") % dev, ok=True)
            else:
                if not self.transfer_hidden_enabled:
                    self.session.nav.playService(self.stadium_ref)
                    self._toggle_decoder_mute(False)
                    log_line("transfer start blocked: Hidden Fullscreen PiP disabled by user")
                    raise RuntimeError("Transfer requires Hidden Fullscreen PiP on this image. It is currently disabled so receiver PiP can remain available.")
                self.session.nav.playService(self.commentator_ref)
                log_line("playing source service on main decoder: %s" % self._selected_name(self.commentator_ref, "source"))
                time.sleep(0.35)
                log_line("transfer backend: Fullscreen PiP inversion")
                if self.delay_ms or abs(self.commentator_volume - DEFAULT_COMMENTATOR_VOLUME) > 0.01:
                    log_line("transfer note: Fullscreen PiP ignores sync delay and source volume filters")
                dev = self._start_transfer_fullscreen_pip()
                self._toggle_decoder_mute(False)
                self._set_status(_("Transfer running on %s") % dev, ok=True)
        except Exception as e:
            log_line("audio start exception: %s" % e)
            self._set_status(_("Start failed"), ok=False)
            try:
                self._stop_transfer_pip()
            except Exception:
                pass
            try:
                self.engine.stop()
            except Exception:
                pass
            self._toggle_decoder_mute(False)
            try:
                self.session.nav.playService(self.stadium_ref)
            except Exception:
                pass
            self.session.open(MessageBox, _("Unable to start audio process.\n\n%s") % e, MessageBox.TYPE_ERROR, timeout=8)
        self._refresh_info()
    def keyExit(self):
        self.close()
    def keyInfo(self):
        try:
            self.session.open(AudioMergeInfoScreen)
        except Exception:
            pass
def main(session, **kwargs):
    session.open(AudioMergeScreen)
def Plugins(**kwargs):
    icon_name = None
    if os.path.exists(PLUGIN_ICON):
        icon_name = "plugin.png"
    return [
        PluginDescriptor(name=PLUGIN_NAME, description=PLUGIN_DESC, where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon=icon_name, fnc=main),
        PluginDescriptor(name=PLUGIN_NAME, description=PLUGIN_DESC, where=PluginDescriptor.WHERE_PLUGINMENU, icon=icon_name, fnc=main),
    ]