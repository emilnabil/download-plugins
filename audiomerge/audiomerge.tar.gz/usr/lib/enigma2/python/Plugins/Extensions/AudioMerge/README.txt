AudioMerge 4.0

Professional audio enhancement build.

Changes:
- Raised source volume range up to 400%.
- Default commentator gain set higher for match commentary use.
- Added speech enhancement chain for clearer commentator voice.
- Added dynamic compression and limiter for stronger, more stable audio.
- Keeps merge and transfer modes available.
