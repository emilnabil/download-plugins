# -*- coding: utf-8 -*-

"""AudioMerge i18n helpers.

Enigma2 plugins typically expose a module-level _() function that wraps
gettext. This file also registers a callback so translations are reloaded
when the GUI language changes.
"""

from __future__ import absolute_import

import gettext


PLUGIN_LANGUAGE_DOMAIN = "AudioMerge"
PLUGIN_LANGUAGE_PATH = "Extensions/AudioMerge/locale"


def localeInit():
    try:
        from Tools.Directories import resolveFilename, SCOPE_PLUGINS
        gettext.bindtextdomain(
            PLUGIN_LANGUAGE_DOMAIN,
            resolveFilename(SCOPE_PLUGINS, PLUGIN_LANGUAGE_PATH),
        )
    except Exception:
        # Fallback for environments without the Enigma2 directory helpers
        pass


def _(txt):
    """Translate *txt* using this plugin's gettext domain."""
    try:
        t = gettext.dgettext(PLUGIN_LANGUAGE_DOMAIN, txt)
        if t == txt:
            t = gettext.gettext(txt)
        return t
    except Exception:
        return txt


localeInit()

try:
    from Components.Language import language

    language.addCallback(localeInit)
except Exception:
    pass
