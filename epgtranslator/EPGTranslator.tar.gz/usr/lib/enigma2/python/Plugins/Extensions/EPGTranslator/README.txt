When activated this plugin will provide a translation of programme
descriptions, using translate.google.com.
Translations for a programme are cached (in memory - there is no
persistent database)

If you start the plugin through the plugin menu it will display the
translation for the current programme.  You can move through this
channel's programme date by using the < and > keys, and move to other
services using ch+ and ch-.
If you are viewing a recording then only that recording's description
will be available - you cannot navigate through a (non-existent) EPG.

When viewing this translation screen you may press OK to be prompted to
enter text for an ad-hoc translation. You can get back to the EPG
translating screen after using this by pressing Red, or Exit to leave
completely.

Pressing the Menu key takes you to the configuration options where you
may set:

    o The Source language (the default is "auto")
    o The Destination language (the default is English)
    o An alternative Destination language.
    o The timeout (in hours) for cached entries (the default is to leave
      them in place until they would drop out of the EPG)
    o Whether to show the original description along with the
      translation
    o Back - to toggle between the main and alternative translations
    o OK - to enter text for translating

When the plugin's programme description screen is active you may also
press

    o Yellow - to completely clear the cache
    o Blue - to hide the description screen (but leave it running).
      Pressing Blue again unhides it.
    o Red - to refetch the EPG

You may also get translations in some EventView screens.  This works for
those arrived at by pressing the Info key (or equivalent) when watching
a programme or in the Grid, Single and Multi EPG (it does not work from
the InfoBar EPG). This can only see the Now + Next programmes.
Here you may toggle between original and translated text by using the
Text key and between the main and alternative translations with the
Back key.
Each new view starts in non-translating mode.
