from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigText, getConfigListEntry
from enigma import eConsoleAppContainer, eTimer
import os

config.plugins.AISubtitles = ConfigSubsection()
config.plugins.AISubtitles.enabled = ConfigSelection(default="false", choices=[("false", "Disabled"), ("true", "Enabled")])
config.plugins.AISubtitles.provider = ConfigSelection(default="auto", choices=[("auto", "Auto (Groq->Gemini)"), ("groq", "Groq Only"), ("gemini", "Gemini Only"), ("openai", "OpenAI Only")])
config.plugins.AISubtitles.api_key = ConfigText(default="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", visible_width=50, fixed_size=False)
config.plugins.AISubtitles.api_key_gemini = ConfigText(default="gen-lang-client-0521641558", visible_width=50, fixed_size=False)
config.plugins.AISubtitles.api_key_openai = ConfigText(default="16bb42c66f993751f1cbafa667d21cda63b22ec7", visible_width=50, fixed_size=False)
# New appearance settings
config.plugins.AISubtitles.background_style = ConfigSelection(default="semi_transparent", choices=[("semi_transparent", "Semi-Transparent Black"), ("transparent", "No Background")])
config.plugins.AISubtitles.text_color = ConfigSelection(default="white", choices=[("white", "White"), ("yellow", "Yellow"), ("green", "Green"), ("cyan", "Cyan"), ("orange", "Orange")])
config.plugins.AISubtitles.text_size = ConfigSelection(default="medium", choices=[("small", "Small (24)"), ("medium", "Medium (28)"), ("large", "Large (34)"), ("xlarge", "X-Large (42)"), ("mega", "Mega (52)")])
config.plugins.AISubtitles.show_keys = ConfigSelection(default="false", choices=[("false", "Hidden (****)"), ("true", "Show Keys")])

class AISubtitlesOverlay(Screen):
    # Default skin will be overridden in __init__
    skin = """
    <screen name="AISubtitlesOverlay" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="10">
        <widget name="subtitles" position="50,850" size="1820,200" font="Regular;28" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#80000000" />
        <widget name="status" position="5,5" size="200,35" font="Regular;18" foregroundColor="#00ff00" backgroundColor="#80000000" />
    </screen>
    """

    STAGE_IDLE = 0
    STAGE_DOWNLOAD = 1
    STAGE_TRANSCRIBE = 3
    STAGE_TRANSLATE = 4
    STAGE_GEMINI = 5
    
    # Color mapping
    COLOR_MAP = {
        "white": "#ffffff",
        "yellow": "#ffff00",
        "green": "#00ff00",
        "cyan": "#00ffff",
        "orange": "#ff8800"
    }
    
    # Font size mapping
    SIZE_MAP = {
        "small": 24,
        "medium": 28,
        "large": 34,
        "xlarge": 42,
        "mega": 52
    }

    def __init__(self, session):
        # Build dynamic skin based on settings
        bg_style = config.plugins.AISubtitles.background_style.value
        text_color = config.plugins.AISubtitles.text_color.value
        text_size = config.plugins.AISubtitles.text_size.value
        
        # Get actual values
        fg_color = self.COLOR_MAP.get(text_color, "#ffffff")
        font_size = self.SIZE_MAP.get(text_size, 28)
        bg_color = "#80000000" if bg_style == "semi_transparent" else "transparent"
        
        # Build skin dynamically
        self.skin = """
        <screen name="AISubtitlesOverlay" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="10">
            <widget name="subtitles" position="50,850" size="1820,200" font="Regular;{font_size}" halign="center" valign="center" foregroundColor="{fg_color}" backgroundColor="{bg_color}" />
            <widget name="status" position="5,5" size="200,35" font="Regular;18" foregroundColor="#00ff00" backgroundColor="#80000000" />
        </screen>
        """.format(font_size=font_size, fg_color=fg_color, bg_color=bg_color)
        
        Screen.__init__(self, session)
        self.session = session
        
        self["subtitles"] = Label("")
        self["status"] = Label("Initializing...")
        
        self.console = eConsoleAppContainer()
        self.console.appClosed.append(self.onProcessFinished)
        
        self.stage = self.STAGE_IDLE
        self.api_key_groq = config.plugins.AISubtitles.api_key.value
        self.api_key_gemini = config.plugins.AISubtitles.api_key_gemini.value
        self.api_key_openai = config.plugins.AISubtitles.api_key_openai.value
        self.provider_mode = config.plugins.AISubtitles.provider.value
        self.current_provider = "groq"
        
        self.wav_path = "/tmp/ai_capture.wav"
        self.raw_path = "/tmp/ai_raw.pcm"
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.close, "exit": self.close, "red": self.close
        }, -2)
        
        self.onLayoutFinish.append(self.startCycle)

    def startCycle(self):
        if self.provider_mode == "auto":
            self.current_provider = "groq"
        else:
            self.current_provider = self.provider_mode
        self["status"].setText("Live ({})".format(self.current_provider.upper()))
        self.startCapture()

    def extractIptvUrl(self, sref_str):
        try:
            parts = sref_str.split(':')
            if len(parts) >= 10:
                url_part = ':'.join(parts[10:])
                if url_part:
                    try:
                        import urllib
                        stream_url = urllib.unquote(url_part)
                    except:
                        from urllib.parse import unquote
                        stream_url = unquote(url_part)
                    
                    stream_url = stream_url.strip()
                    
                    # Remove channel name after .ts, .m3u8, etc.
                    for ext in ['.ts', '.m3u8', '.flv', '.mp4', '.mkv']:
                        if ext in stream_url:
                            idx = stream_url.find(ext) + len(ext)
                            stream_url = stream_url[:idx]
                            break
                    
                    if ' ' in stream_url:
                        stream_url = stream_url.split(' ')[0]
                    
                    if stream_url.startswith('http'):
                        return stream_url
        except:
            pass
        return None

    def startCapture(self):
        self.stage = self.STAGE_DOWNLOAD
        
        sref = self.session.nav.getCurrentlyPlayingServiceReference()
        if not sref:
            self["status"].setText("No Service")
            return

        sref_str = sref.toString()
        is_iptv = sref_str.startswith('4097:') or sref_str.startswith('5001:') or sref_str.startswith('5002:') or sref_str.startswith('8193:')
        
        try:
            if os.path.exists(self.wav_path): os.remove(self.wav_path)
            if os.path.exists(self.raw_path): os.remove(self.raw_path)
        except: pass

        if is_iptv:
            self["status"].setText("Rec (IPTV)...")
            stream_url = self.extractIptvUrl(sref_str)
            if stream_url:
                with open("/tmp/ai_iptv_url.log", "w") as f:
                    f.write(stream_url)
                cmd = "sh -c \"timeout 6 gst-launch-1.0 -q souphttpsrc location='{}' ! decodebin ! audioconvert ! audioresample ! audio/x-raw,rate=16000,channels=1,format=S16LE ! filesink location='{}'\"".format(stream_url, self.raw_path)
            else:
                self["status"].setText("Err: No URL")
                self.scheduleRetry(1000)
                return
        else:
            self["status"].setText("Rec (DVB)...")
            url = "http://127.0.0.1:8001/" + sref_str
            cmd = "sh -c \"timeout 6 gst-launch-1.0 -q souphttpsrc location='{}' ! decodebin ! audioconvert ! audioresample ! audio/x-raw,rate=16000,channels=1,format=S16LE ! filesink location='{}'\"".format(url, self.raw_path)
        
        self.console.execute(cmd)
        
        self.capture_timer = eTimer()
        self.capture_timer.callback.append(self.stopCapturePipe)
        self.capture_timer.start(6500, True)

    def stopCapturePipe(self):
        self.console.sendCtrlC() 
        self.kill_timer = eTimer()
        self.kill_timer.callback.append(self.forceFinish)
        self.kill_timer.start(1500, True)

    def forceFinish(self):
        self.console.kill()
        self.onProcessFinished(0)

    def writeWavHeader(self, raw_path, wav_path):
        try:
            with open(raw_path, "rb") as inp, open(wav_path, "wb") as out:
                audio_data = inp.read()
                data_size = len(audio_data)
                out.write(b"RIFF")
                out.write((data_size + 36).to_bytes(4, 'little'))
                out.write(b"WAVE")
                out.write(b"fmt ")
                out.write((16).to_bytes(4, 'little'))
                out.write((1).to_bytes(2, 'little'))
                out.write((1).to_bytes(2, 'little'))
                out.write((16000).to_bytes(4, 'little'))
                out.write((32000).to_bytes(4, 'little'))
                out.write((2).to_bytes(2, 'little'))
                out.write((16).to_bytes(2, 'little'))
                out.write(b"data")
                out.write(data_size.to_bytes(4, 'little'))
                out.write(audio_data)
            return True
        except:
            return False

    def onProcessFinished(self, retval):
        if hasattr(self, 'capture_timer'): self.capture_timer.stop()
        if hasattr(self, 'kill_timer'): self.kill_timer.stop()

        if self.stage == self.STAGE_DOWNLOAD:
            raw_exists = os.path.exists(self.raw_path) and os.path.getsize(self.raw_path) > 5000
            
            if not raw_exists:
                self["status"].setText("Err: Capture")
                self.scheduleRetry(1000)
                return
            
            if not self.writeWavHeader(self.raw_path, self.wav_path):
                self["status"].setText("Err: WAV")
                self.scheduleRetry(1000)
                return
            
            try:
                if os.path.exists(self.raw_path): os.remove(self.raw_path)
            except: pass

            self.stage = self.STAGE_TRANSCRIBE
            if self.current_provider == "gemini":
                self.doGeminiProcess()
            elif self.current_provider == "openai":
                self.doOpenAIProcess()
            else:
                self.doGroqTranscribe()
                
        elif self.stage == self.STAGE_TRANSCRIBE:
            if self.current_provider == "groq":
                self.doGroqTranslate()
            elif self.current_provider == "openai":
                self.doOpenAITranslate()
            else:
                self.showResultGemini()

        elif self.stage == self.STAGE_TRANSLATE:
            if self.current_provider == "openai":
                self.showResultOpenAI()
            else:
                self.showResult()

        elif self.stage == self.STAGE_GEMINI:
            self.showResultGemini()

    def doGroqTranscribe(self):
        self.stage = self.STAGE_TRANSCRIBE
        self["status"].setText("Transcribing...")

        if not self.api_key_groq.startswith("gsk_"):
             self.handleFail("Invalid Groq Key")
             return

        url = "https://api.groq.com/openai/v1/audio/transcriptions"
        cmd = 'curl -k -s --max-time 15 -X POST "{}" -H "Authorization: Bearer {}" -F "file=@{}" -F "model=whisper-large-v3" -F "response_format=json" > /tmp/groq_transcribe.json'.format(url, self.api_key_groq.strip(), self.wav_path)
        self.console.execute(cmd)

    def doGeminiProcess(self):
        self.stage = self.STAGE_GEMINI
        self["status"].setText("Gemini...")
        
        if not self.api_key_gemini:
            self["status"].setText("No Gemini Key!")
            return

        import base64, json
        try:
            with open(self.wav_path, "rb") as wav_file:
                b64_audio = base64.b64encode(wav_file.read()).decode('utf-8')
        except:
             self.handleFail("Read WAV Fail")
             return

        url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=" + self.api_key_gemini.strip()
        
        prompt_text = "Listen to this audio, transcribe it, and translate it to Arabic. Return ONLY the Arabic text. If no speech, return nothing."
        payload = {"contents": [{"parts": [{"text": prompt_text}, {"inline_data": {"mime_type": "audio/wav", "data": b64_audio}}]}]}
        
        with open("/tmp/gemini_payload.json", "w") as f:
            json.dump(payload, f)
            
        cmd = "curl -k -s --max-time 20 -X POST '{}' -H 'Content-Type: application/json' -d @/tmp/gemini_payload.json > /tmp/gemini_result.json".format(url)
        self.console.execute(cmd)

    def doGroqTranslate(self):
        import json
        text = ""
        try:
            if os.path.exists("/tmp/groq_transcribe.json"):
                with open("/tmp/groq_transcribe.json", "r") as f:
                    data = json.load(f)
                    if 'text' in data:
                        text = data['text'].strip()
        except: pass
        
        if not text or len(text) < 2:
            if self.provider_mode == "auto" and self.current_provider == "groq":
                 self.current_provider = "gemini"
                 self["status"].setText("-> Gemini")
                 self.doGeminiProcess()
                 return

            self["status"].setText("No Speech")
            self.restartLoop()
            return

        self.stage = self.STAGE_TRANSLATE
        self["status"].setText("Translating...")
        
        url = "https://api.groq.com/openai/v1/chat/completions"
        prompt = "Translate this text to Arabic. Return ONLY the translation: " + text
        json_payload = '{"model":"llama-3.1-8b-instant","messages":[{"role":"user","content":' + json.dumps(prompt) + '}]}'
        
        with open("/tmp/groq_payload.json", "w") as f:
            f.write(json_payload)
            
        cmd = "curl -k -s --max-time 10 -X POST '{}' -H 'Authorization: Bearer {}' -H 'Content-Type: application/json' -d @/tmp/groq_payload.json > /tmp/groq_translate.json".format(url, self.api_key_groq)
        self.console.execute(cmd)

    def showResultGemini(self):
        self.stage = self.STAGE_IDLE
        import json
        try:
            if os.path.exists("/tmp/gemini_result.json"):
                with open("/tmp/gemini_result.json", "r") as f:
                    response = json.load(f)
                if 'candidates' in response and len(response['candidates']) > 0:
                    parts = response['candidates'][0]['content']['parts']
                    content = parts[0]['text'].strip()
                    self["subtitles"].setText(content)
                    self["status"].setText("")
                else:
                    self["status"].setText("Gemini Empty")
        except:
             self["status"].setText("Gemini Err")
        self.restartLoop()

    def showResult(self):
        self.stage = self.STAGE_IDLE
        import json
        try:
            if os.path.exists("/tmp/groq_translate.json"):
                with open("/tmp/groq_translate.json", "r") as f:
                    response = json.load(f)
                if 'choices' in response:
                    content = response['choices'][0]['message']['content']
                    self["subtitles"].setText(content)
                    self["status"].setText("")
        except:
             pass
        self.restartLoop()
             
    def scheduleRetry(self, delay):
        self.retry_timer = eTimer() 
        self.retry_timer.callback.append(self.startCycle) 
        self.retry_timer.start(delay, True)

    def restartLoop(self):
        self.loop_timer = eTimer()
        self.loop_timer.callback.append(self.startCycle)
        self.loop_timer.start(500, True)

    def handleFail(self, msg):
        self["status"].setText(msg)
        if self.provider_mode == "auto":
            if self.current_provider == "groq":
                self["status"].setText(msg + " -> Gem")
                self.current_provider = "gemini"
                self.doGeminiProcess()
                return
            elif self.current_provider == "gemini" and self.api_key_openai:
                self["status"].setText(msg + " -> OAI")
                self.current_provider = "openai"
                self.doOpenAIProcess()
                return
        self.scheduleRetry(1000)

    def doOpenAIProcess(self):
        self.stage = self.STAGE_TRANSCRIBE
        self["status"].setText("OAI Whisper...")
        
        if not self.api_key_openai or not self.api_key_openai.startswith("sk-"):
            self["status"].setText("No OpenAI Key!")
            self.scheduleRetry(1000)
            return
        
        # Check if wav file exists and has content
        if not os.path.exists(self.wav_path) or os.path.getsize(self.wav_path) < 1000:
            self["status"].setText("OAI: No Audio")
            self.scheduleRetry(1000)
            return
        
        # Remove old response file
        try:
            if os.path.exists("/tmp/openai_transcribe.json"):
                os.remove("/tmp/openai_transcribe.json")
        except: pass
        
        # Use OpenAI Whisper API - simpler curl command
        url = "https://api.openai.com/v1/audio/transcriptions"
        cmd = 'curl -k -s --connect-timeout 10 --max-time 30 -X POST "{}" -H "Authorization: Bearer {}" -H "Content-Type: multipart/form-data" -F "file=@{}" -F "model=whisper-1" -o /tmp/openai_transcribe.json'.format(url, self.api_key_openai.strip(), self.wav_path)
        self.console.execute(cmd)

    def doOpenAITranslate(self):
        import json
        text = ""
        
        # Check if response file exists
        if not os.path.exists("/tmp/openai_transcribe.json"):
            self["status"].setText("OAI: No Response")
            self.restartLoop()
            return
        
        # Check file size
        fsize = os.path.getsize("/tmp/openai_transcribe.json")
        if fsize < 5:
            self["status"].setText("OAI: Empty File")
            self.restartLoop()
            return
        
        try:
            with open("/tmp/openai_transcribe.json", "r") as f:
                raw_content = f.read()
            
            # Try to parse as JSON
            data = json.loads(raw_content)
            
            # Check for error in response
            if 'error' in data:
                err_msg = data['error'].get('message', 'API Error')[:25]
                self["status"].setText("OAI: " + err_msg)
                self.restartLoop()
                return
            
            if 'text' in data:
                text = data['text'].strip()
                
        except json.JSONDecodeError:
            # Not JSON - might be curl error or HTML
            self["status"].setText("OAI: Not JSON")
            self.restartLoop()
            return
        except Exception as e:
            self["status"].setText("OAI Parse Err")
            self.restartLoop()
            return
        
        if not text or len(text) < 2:
            self["status"].setText("OAI: No Text")
            self.restartLoop()
            return

        self.stage = self.STAGE_TRANSLATE
        self["status"].setText("OAI Translate...")
        
        url = "https://api.openai.com/v1/chat/completions"
        prompt = "Translate this text to Arabic. Return ONLY the translation: " + text
        payload = {
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 500
        }
        
        with open("/tmp/openai_payload.json", "w") as f:
            json.dump(payload, f)
        
        cmd = "curl -k -s --max-time 15 -X POST '{}' -H 'Authorization: Bearer {}' -H 'Content-Type: application/json' -d @/tmp/openai_payload.json > /tmp/openai_result.json".format(url, self.api_key_openai)
        self.console.execute(cmd)

    def showResultOpenAI(self):
        self.stage = self.STAGE_IDLE
        import json
        try:
            if os.path.exists("/tmp/openai_result.json"):
                with open("/tmp/openai_result.json", "r") as f:
                    response = json.load(f)
                if 'choices' in response and len(response['choices']) > 0:
                    content = response['choices'][0]['message']['content'].strip()
                    self["subtitles"].setText(content)
                    self["status"].setText("")
                else:
                    self["status"].setText("OpenAI Empty")
        except:
            self["status"].setText("OpenAI Err")
        self.restartLoop()

    def close(self):
        try: self.console.sendCtrlC() 
        except: pass
        Screen.close(self)


class AISubtitlesSettings(ConfigListScreen, Screen):
    skin = """
    <screen name="AISubtitlesSettings" position="center,center" size="800,500" title="AI Subtitles Settings" flags="wfNoBorder" backgroundColor="#99000000">
        <!-- Version label top right -->
        <widget name="version" position="450,10" size="330,40" font="Regular;30" halign="right" valign="center" foregroundColor="#00ddff" backgroundColor="transparent" />
        
        <!-- Config list full width with more height -->
        <widget name="config" position="20,60" size="760,300" scrollbarMode="showOnDemand" backgroundColor="#40000000" itemHeight="38" />
        
        <!-- Credits -->
        <widget name="credits" position="20,370" size="760,35" font="Regular;20" halign="center" valign="center" foregroundColor="#888888" backgroundColor="transparent" />
        
        <!-- Buttons: Red=Close, Green=Save, Yellow=Start Live, Blue=Visual Test -->
        <widget name="key_red" position="20,420" size="185,55" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#cc0000" foregroundColor="white" />
        <widget name="key_green" position="215,420" size="185,55" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#00aa00" foregroundColor="white" />
        <widget name="key_yellow" position="410,420" size="185,55" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#ccaa00" foregroundColor="white" />
        <widget name="key_blue" position="605,420" size="185,55" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#0066cc" foregroundColor="white" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = []
        ConfigListScreen.__init__(self, self.list)
        self["key_red"] = Label("Close")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Start Live")
        self["key_blue"] = Label("Visual Test")
        self["version"] = Label("AISubtitles 1.3")
        self["credits"] = Label("Developed by ammarbary")
        self.createConfigList()
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "save": self.save, "cancel": self.close, "ok": self.save, "yellow": self.startOverlay, "red": self.close, "blue": self.visualTest
        }, -2)

    def createConfigList(self):
        self.list = []
        self.list.append(getConfigListEntry("Provider", config.plugins.AISubtitles.provider))
        self.list.append(getConfigListEntry("Show API Keys", config.plugins.AISubtitles.show_keys))
        
        # Show API keys or masked version
        if config.plugins.AISubtitles.show_keys.value == "true":
            self.list.append(getConfigListEntry("Groq API Key", config.plugins.AISubtitles.api_key))
            self.list.append(getConfigListEntry("Gemini API Key", config.plugins.AISubtitles.api_key_gemini))
            self.list.append(getConfigListEntry("OpenAI API Key", config.plugins.AISubtitles.api_key_openai))
        else:
            # Just show that keys are set (masked)
            self.list.append(getConfigListEntry("Groq API Key", config.plugins.AISubtitles.enabled))
            self.list.append(getConfigListEntry("Gemini API Key", config.plugins.AISubtitles.enabled))
            self.list.append(getConfigListEntry("OpenAI API Key", config.plugins.AISubtitles.enabled))
        
        self.list.append(getConfigListEntry("--- Appearance ---", config.plugins.AISubtitles.enabled))
        self.list.append(getConfigListEntry("Background Style", config.plugins.AISubtitles.background_style))
        self.list.append(getConfigListEntry("Text Color", config.plugins.AISubtitles.text_color))
        self.list.append(getConfigListEntry("Text Size", config.plugins.AISubtitles.text_size))
        self["config"].setList(self.list)

    def save(self):
        for x in self["config"].list:
            x[1].save()
        config.plugins.AISubtitles.save()

    def startOverlay(self):
        self.session.open(AISubtitlesOverlay)

    def visualTest(self):
        self.session.open(AISubtitlesPreview)


class AISubtitlesPreview(Screen):
    def __init__(self, session):
        # Build dynamic skin based on settings
        bg_style = config.plugins.AISubtitles.background_style.value
        text_color = config.plugins.AISubtitles.text_color.value
        text_size = config.plugins.AISubtitles.text_size.value
        
        COLOR_MAP = {"white": "#ffffff", "yellow": "#ffff00", "green": "#00ff00", "cyan": "#00ffff", "orange": "#ff8800"}
        SIZE_MAP = {"small": 24, "medium": 28, "large": 34, "xlarge": 42, "mega": 52}
        
        fg_color = COLOR_MAP.get(text_color, "#ffffff")
        font_size = SIZE_MAP.get(text_size, 28)
        bg_color = "#80000000" if bg_style == "semi_transparent" else "transparent"
        
        self.skin = """
        <screen name="AISubtitlesPreview" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="10">
            <widget name="preview" position="50,850" size="1820,200" font="Regular;{font_size}" halign="center" valign="center" foregroundColor="{fg_color}" backgroundColor="{bg_color}" />
            <widget name="info" position="50,50" size="400,40" font="Regular;20" foregroundColor="#00aaff" backgroundColor="#80000000" />
        </screen>
        """.format(font_size=font_size, fg_color=fg_color, bg_color=bg_color)
        
        Screen.__init__(self, session)
        self["preview"] = Label("Sample Translation Preview Text")
        self["info"] = Label("Press EXIT to close")
        
        self["actions"] = ActionMap(["SetupActions"], {
            "cancel": self.close, "ok": self.close
        }, -2)


def main(session, **kwargs):
    session.open(AISubtitlesSettings)

def Plugins(**kwargs):
    return PluginDescriptor(name="AI Live Subtitles", description="Real-time Translation & Subtitles", where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)
