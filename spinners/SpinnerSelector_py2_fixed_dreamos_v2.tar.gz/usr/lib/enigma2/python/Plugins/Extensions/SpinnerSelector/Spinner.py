from Components.GUIComponent import GUIComponent
from enigma import ePixmap, eTimer


class Spinner(GUIComponent):
    def __init__(self, Bilder):
        GUIComponent.__init__(self)
        self.len = 0
        self.Bilder = []
        self.SetBilder(Bilder)
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.Invalidate)
        except Exception:
            pass
        self.timer.start(100)

    def SetBilder(self, Bilder):
        self.Bilder = Bilder or []
        self.len = 0

    GUI_WIDGET = ePixmap

    def destroy(self):
        if self.timer:
            try:
                self.timer.timeout.disconnect(self.Invalidate)
            except Exception:
                pass
            self.timer.stop()
            self.timer = None

    def Invalidate(self):
        if self.instance and self.Bilder:
            if self.len >= len(self.Bilder):
                self.len = 0
            try:
                self.instance.setPixmapFromFile(self.Bilder[self.len])
            except Exception:
                pass
            self.len += 1