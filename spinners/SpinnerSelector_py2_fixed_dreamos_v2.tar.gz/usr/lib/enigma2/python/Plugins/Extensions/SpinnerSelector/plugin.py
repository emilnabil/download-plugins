# coding=ISO-8859-1
from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.config import config
try:
	from enigma import ePicLoad, getDesktop, eConsoleAppContainer
except Exception:
	ePicLoad = None
	getDesktop = lambda x: None
	eConsoleAppContainer = None
from Plugins.Extensions.SpinnerSelector.SpinnerSelector import SpinnerSelector
import os

import gettext
try:
	cat = gettext.translation('lang', '/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/po', [config.osd.language.getText()])
	_ = cat.gettext
except IOError:
	pass

def main(session, **kwargs):
	SpinnerSelector(session)
			
def autostart(reason, **kwargs):
	pass
		
def Plugins(**kwargs):
	screenwidth = getDesktop(0).size().width()
	if screenwidth and screenwidth == 1920:
		return [PluginDescriptor(name="Spinner", description=_("Configuration tool for Spinner"), where = PluginDescriptor.WHERE_PLUGINMENU, icon='pluginfhd.png', fnc=main)]
	else:
		return [PluginDescriptor(name="Spinner", description=_("Configuration tool for Spinner"), where = PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main)]
