
# -*- coding: utf-8 -*-
import os
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from skin import parseColor  # التأكد من كتابة skin بحروف صغيرة
from enigma import eConsoleAppContainer

# المسار المعتمد للبلجن
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/calculatorE2/"

class CalculatorScreen(Screen):
    # تم ضبط الارتفاع (size) والخط لضمان استيعاب 5 أسطر
    skin = """
    <screen name="CalculatorScreen" position="center,center" size="400,750" title="calculatorE2" backgroundColor="#17161b">
        <widget name="result" position="10,20" size="380,220" font="Regular;32" halign="right" valign="top" foregroundColor="#ffffff" backgroundColor="#101010" transparent="0" />
        <widget name="status" position="10,245" size="380,30" font="Regular;20" halign="right" foregroundColor="#9f9f9f" />
        
        <widget name="key_AC" position="10,290" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_neg" position="105,290" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_perc" position="200,290" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_div" position="295,290" size="95,85" font="Regular;30" halign="center" valign="center" backgroundColor="#ff9400" />
        
        <widget name="key_7" position="10,385" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_8" position="105,385" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_9" position="200,385" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_mul" position="295,385" size="95,85" font="Regular;30" halign="center" valign="center" backgroundColor="#ff9400" />
        
        <widget name="key_4" position="10,480" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_5" position="105,480" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_6" position="200,480" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_sub" position="295,480" size="95,85" font="Regular;30" halign="center" valign="center" backgroundColor="#ff9400" />
        
        <widget name="key_1" position="10,575" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_2" position="105,575" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_3" position="200,575" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_add" position="295,575" size="95,85" font="Regular;30" halign="center" valign="center" backgroundColor="#ff9400" />
        
        <widget name="key_0" position="10,670" size="180,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_dot" position="200,670" size="85,85" font="Regular;30" halign="center" valign="center" backgroundColor="#9f9f9f" />
        <widget name="key_eq" position="295,670" size="95,85" font="Regular;30" halign="center" valign="center" backgroundColor="#ff9400" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.actualiser = ""
        self.row = 1
        self.col = 0
        self.key_map = [
            ["AC", "+/-", "%", "/"],
            ["7", "8", "9", "*"],
            ["4", "5", "6", "-"],
            ["1", "2", "3", "+"],
            ["0", "0", ".", "="]
        ]
        self.names = {
            "AC": "key_AC", "+/-": "key_neg", "%": "key_perc", "/": "key_div",
            "*": "key_mul", "-": "key_sub", "+": "key_add", ".": "key_dot", "=": "key_eq",
            "0": "key_0", "1": "key_1", "2": "key_2", "3": "key_3", "4": "key_4", 
            "5": "key_5", "6": "key_6", "7": "key_7", "8": "key_8", "9": "key_9"
        }
        for key in self.names:
            self[self.names[key]] = Label(key)

        self["result"] = Label("")
        self["status"] = Label("Select and press OK")
        self["actions"] = ActionMap(["DirectionActions", "OkCancelActions"], {
            "up": self.go_up, "down": self.go_down,
            "left": self.go_left, "right": self.go_right,
            "ok": self.press_ok, "cancel": self.close
        }, -1)
        
        self.container = eConsoleAppContainer()
        self.onLayoutFinish.append(self.update_selection)

    def play_sound(self):
        sound_file = os.path.join(PLUGIN_PATH, "bip.mp3")
        if os.path.exists(sound_file):
            self.container.execute("gst-launch-1.0 playbin uri=file://%s" % sound_file)

    def update_selection(self):
        # تمييز الزر المختار بلون النص (البرتقالي)
        for r in range(5):
            for c in range(4):
                char = self.key_map[r][c]
                name = self.names[char]
                if r == self.row and c == self.col:
                    self[name].instance.setForegroundColor(parseColor("#ff9400"))
                else:
                    self[name].instance.setForegroundColor(parseColor("#ffffff"))

    def move(self, r, c):
        self.row = (self.row + r) % 5
        self.col = (self.col + c) % 4
        self.play_sound()
        self.update_selection()

    def go_up(self): self.move(-1, 0)
    def go_down(self): self.move(1, 0)
    def go_left(self): self.move(0, -1)
    def go_right(self): self.move(0, 1)

    def press_ok(self):
        self.play_sound()
        val = self.key_map[self.row][self.col]
        
        if val == "AC":
            self.actualiser = ""
            self["result"].setText("")
        elif val == "=":
            try:
                # معالجة وحساب النتيجة
                equation = self.actualiser.replace("%", "/100")
                res = eval(equation)
                formatted_res = str(res)
                
                # تنسيق الأسطر: السطر 1 و2 للعملية
                # إذا كانت العملية طويلة جداً نقسمها
                op = self.actualiser
                if len(op) > 18:
                    line1 = op[:18]
                    line2 = op[18:]
                else:
                    line1 = op
                    line2 = ""
                
                # السطر 3 لعلامة = والسطر 4 و5 للنتيجة
                display = line1 + "\n" + line2 + "\n=\n" + formatted_res
                self["result"].setText(display)
                self.actualiser = formatted_res
            except:
                self["result"].setText("\n\n\nErreur")
                self.actualiser = ""
        elif val == "+/-":
            if self.actualiser.startswith("-"):
                self.actualiser = self.actualiser[1:]
            else:
                self.actualiser = "-" + self.actualiser
            self["result"].setText(self.actualiser)
        else:
            self.actualiser += val
            self["result"].setText(self.actualiser)

def main(session, **kwargs):
    session.open(CalculatorScreen)

def Plugins(**kwargs):
    return [PluginDescriptor(
        name="calculatorE2", 
        description="Multi-line Calculator with Sound", 
        where=PluginDescriptor.WHERE_PLUGINMENU, 
        icon="plugin.png", 
        fnc=main
    )]
