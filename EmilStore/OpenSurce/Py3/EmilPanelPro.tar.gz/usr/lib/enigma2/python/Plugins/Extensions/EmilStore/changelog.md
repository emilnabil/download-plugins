# EmilPanelPro Changelog

## Version 7.6.0 (Current)

### Added
- Modular architecture
- Offline license system (fingerprint-based)
- Favorites system
- Install history
- Auto backup system
- Crash reporting
- Announcements system
- Account ping telemetry
- Statistics dashboard
- Backup manager
- Download manager
- Health check service
- Search engine
- Theme system
- Centralized notifications
- Config validator
- Auto-update plugins
- Telemetry (anonymous)
- Changelog viewer
- Task scheduler
- i18n loader

### Changed
- plugin.py slimmed down to entry point
- Update system uses version comparison
- Cache system now TTL-based

### Fixed
- Console commands no longer hang
- Script execution handles empty commands

## Version 7.6.0

### Added
- Initial release
- MAC-based licensing
- Basic panel functionality
