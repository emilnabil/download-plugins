#!/bin/sh

PLUGIN_DIR="/usr/lib/enigma2/python/Plugins/Extensions/EmilStore"
CACHE_DIR="/etc/enigma2/emilpanelpro"

echo "==========================================="
echo "  EmilPanelPro - Uninstall"
echo "==========================================="
echo ""

echo "[1/3] Removing plugin files..."
if [ -d "$PLUGIN_DIR" ]; then
    rm -rf "$PLUGIN_DIR"
    echo "Removed: $PLUGIN_DIR"
else
    echo "Not found: $PLUGIN_DIR"
fi

echo "[2/3] Removing cache..."
if [ -d "$CACHE_DIR" ]; then
    rm -rf "$CACHE_DIR"
    echo "Removed: $CACHE_DIR"
fi

echo "[3/3] Cleaning temp files..."
rm -f /tmp/emilpanel*.sh
rm -f /tmp/emilpanelpro*.log
rm -f /tmp/emilpanelpro_rejected_update.txt

echo ""
echo "Done! Restart Enigma2 to complete removal."
