# EmilPanelPro

Advanced Enigma2 Store Panel with modular architecture.

## Features

- Modular Architecture (core/catalog/ui/services)
- Offline License System
- Favorites, History, Backup
- Crash Reports & Announcements
- Multi-Image Support (OpenATV, OpenPLi, Egami, etc.)
- FHD and HD skins
- Arabic and English support

## Installation

```bash
wget -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/EmilPanelPro/emilpanelpro.sh | sh
