# -*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, absolute_import

import os
import gettext

_LOCALE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "locale")

try:
    _translation = gettext.translation("emilpanelpro", localedir=_LOCALE_DIR, fallback=True)
    _ = _translation.gettext
except Exception:
    def _(text):
        return text
