#  -*- coding: utf-8 -*-
#
#  Simple deb installer
#  
#  Support: www.dreambox-tools.info
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this converter may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

from Screens.Screen import Screen
from Screens.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Plugins.Plugin import PluginDescriptor

###########################################################################

class MySpeedtest(Screen):
	skin = """
		<screen position="100,150" size="400,300" title="simple e2Speedtest" >
			<widget name="myMenu" position="40,5" size="300,40" scrollbarMode="showOnDemand" />
			<ePixmap alphatest="blend" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/e2Speedtest/e2speedtest.png" position="5,30" size="280,260" transparent="1" zPosition="-1"/>
                        <eLabel backgroundColor="#00999999" position="290,100" size="100,50" zPosition="2" />
                        <eLabel backgroundColor="#00999999" position="290,200" size="100,50" zPosition="2" />
                        <eLabel font="Regular; 25" foregroundColor="#00FFFFFF" halign="center" position="290,100" size="100,50" text="OK" transparent="1" valign="center" zPosition="3" />
                        <eLabel font="Regular; 25" foregroundColor="#00FFFFFF" halign="center" position="290,200" size="100,50" text="EXIT" transparent="1" valign="center" zPosition="3" />
		</screen>"""

	def __init__(self, session, args = 0):
		self.session = session
		
		list = []
		list.append(("Speedtest I-Net", "com_one"))

		
		Screen.__init__(self, session)
		self["myMenu"] = MenuList(list)
		self["myActionMap"] = ActionMap(["SetupActions"],
		{
			"ok": self.go,
			"cancel": self.cancel
		}, -1)

	def go(self):
		returnValue = self["myMenu"].l.getCurrentSelection()[1]
		print "\n[MySpeedtest] returnValue: " + returnValue + "\n"
		
		if returnValue is not None:
			if returnValue is "com_one":
				self.prombt("/usr/lib/enigma2/python/Plugins/Extensions/e2Speedtest/speedtest-cli &")
				
		
			else:
				print "\n[MySpeedtest] cancel\n"
				self.close(None)

	def prombt(self, com):
		self.session.open(Console,_("output: %s") % (com), ["%s" % com])
		
	def cancel(self):
		print "\n[MySpeedtest] cancel\n"
		self.close(None)

###########################################################################

def main(session, **kwargs):
	print "\n[MySpeedtest] start\n"	
	session.open(MySpeedtest)

###########################################################################

def Plugins(**kwargs):
	return PluginDescriptor(
			name="e2Speedtest",
			description="simple e2Speedtest",
			where = PluginDescriptor.WHERE_PLUGINMENU,
			icon="e2speed.png",
			fnc=main)


