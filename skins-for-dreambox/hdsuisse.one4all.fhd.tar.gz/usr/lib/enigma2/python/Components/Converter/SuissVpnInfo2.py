#
# VpnIp_converter
#
# Coded by murxer (c) 2023
# Support: www.boxpirates.to
# E-Mail: murxer83@mail.de
#
# This converter is open source but it is NOT free software.
#
# This converter may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this converter or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this converter and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#
from Components.Converter.Converter import Converter
from Components.Element import cached
from Poll import Poll
from time import time
import json

try:
    from urllib2 import urlopen
    import cookielib
except ImportError as error:
    from urllib.request import urlopen
import os
import sys

CHECKIP = "http://ip-api.com/json"
IPDATA = '/tmp/ipdata'
IPFILE = '/tmp/ip.txt'
UPDATEPAUSE = 5


def getTxt(value):
    if sys.version_info > (3, 0):
        return str(value)
    else:
        try:
            value = value.encode("utf-8")
        except Exception as error:
            value = str(value)
            print("[VpnIp_converter]: getTxt error: %s" % str(error))
    return value


def del_ipfiles():
    if os.path.isfile(IPFILE):
        os.remove(IPFILE)
    if os.path.isfile(IPDATA):
        os.remove(IPDATA)


def get_device():
    dev_device = "tun0"
    try:
        if os.path.exists("/etc/openvpn"):
            for i in os.listdir("/etc/openvpn"):
                if i.split('.')[-1] == 'conf':
                    f = open("/etc/openvpn/%s" % i, "r").readlines()
                    for line in f:
                        if "dev" in line:
                            if not "#" == line[0]:
                                dev_device = line[4:].strip() + "0"
                                break
    except:
        dev_device = "tun0"
    return dev_device


def get_vpn_status():
    is_vpn = True if get_device() in str(os.listdir("/sys/devices/virtual/net")) else False
    return is_vpn


def get_wireguard_status():
    is_wireguard = True if "Wg0" in str(os.listdir("/sys/devices/virtual/net")) else False
    return is_wireguard


def get_ipdata():
    try:
        if not os.path.exists(IPDATA) or time() - os.path.getmtime(r"%s" % IPDATA) > UPDATEPAUSE:
            data = urlopen(CHECKIP, timeout=4).read()
            f = open(IPDATA, 'w')
            f.write(data)
            f.close()
            data = json.loads(data)
        else:
            data = json.loads(open(IPDATA, 'r').read())
        country = getTxt(data["country"])
        city = getTxt(data["city"])
        ip = getTxt(data["query"])
    except Exception as error:
        country = city = ip = None
    return country, city, ip


del_ipfiles()


class SuissVpnInfo2(Poll, Converter, object):
    def __init__(self, type):
        Converter.__init__(self, type)
        self.type = type
        Poll.__init__(self)
        self.poll_interval = 60000
        self.poll_enabled = True

    @cached
    def getBoolean(self):
        if self.type == 'VPN':
            return get_vpn_status()
        elif self.type == 'WireGuard':
            return get_wireguard_status()
        return False

    @cached
    def getText(self):
        text = ""
        if self.type in ['VPN', 'WireGuard']:
            country, city, ip = get_ipdata()
            if country and ip and city:
                ip = '%s - %s - %s' % (country, city, ip)
                if not os.path.exists(IPFILE) or ip not in open(IPFILE, 'r').readline():
                    f = open(IPFILE, 'w')
                    f.write(ip)
                    f.close()
            if os.path.exists(IPFILE):
                text = open(IPFILE, 'r').readline().replace('\n', '')
            else:
                if self.type == 'VPN':
                    text = 'VPN info error'
                elif self.type == 'WireGuard':
                    text = 'Wireguard info error'
                else:
                    text = 'Info error'
        return text

    boolean = property(getBoolean)
    text = property(getText)
