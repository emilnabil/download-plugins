from enigma import iServiceInformation
from Components.Converter.Converter import Converter
from Components.Element import cached



class m_cf_Clist(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)

	@cached
	def getText(self):	
		try:
			camdlist = open("/etc/clist.list", "r")
		except:
			return None
		if camdlist is not None:
			for current in camdlist:
				camd = current
			camdlist.close()
			return camd
		else:
			return ""

	text = property(getText)

	def changed(self, what):
		Converter.changed(self, what)
