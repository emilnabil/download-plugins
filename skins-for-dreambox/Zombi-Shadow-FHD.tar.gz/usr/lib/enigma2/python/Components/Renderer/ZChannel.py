#!/usr/bin/python
# -*- coding: utf-8 -*-

# by digiteng...07.2021
# russian and py3 support by sunriser...
# 07.2021 start edit lululla

# <ePixmap pixmap="/usr/share/enigma2/ZSkin-FHD/menu/panels/nocover.png" position="1090,302" size="270,395" />
# <widget position="1095,310" render="ZChannel" size="260,379" source="ServiceEvent" zPosition="10" />

from Components.Renderer.Renderer import Renderer
from enigma import ePixmap, ePicLoad, eTimer
from Components.AVSwitch import AVSwitch
from Components.config import config
import re
import json
import os
import socket
import shutil
import sys
global cur_skin, my_cur_skin, apikey
# w92
# w154
# w185
# w342
# w500
# w780
# original
formatImg = 'w342'
apikey = "3c3efcf47c3577558812bb9d64019d65"

PY3 = sys.version_info.major >= 3
try:
    from urllib.error import URLError, HTTPError
    from urllib.request import urlopen
    from urllib.parse import quote
except:
    from urllib2 import URLError, HTTPError
    from urllib2 import urlopen
    from urllib import quote


my_cur_skin = False
cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
path_folder = "/tmp/poster/"
if os.path.isdir("/media/hdd"):
    path_folder = "/media/hdd/poster/"
elif os.path.isdir("/media/usb"):
    path_folder = "/media/usb/poster/"
else:
    path_folder = "/tmp/poster/"
if not os.path.isdir(path_folder):
    os.makedirs(path_folder)
try:
    folder_size = sum([sum(map(lambda fname: os.path.getsize(os.path.join(path_folder, fname)), files)) for path_folder, folders, files in os.walk(path_folder)])
    ozposter = "%0.f" % (folder_size/(1024*1024.0))
    if ozposter >= "5":
        shutil.rmtree(path_folder)
except:
    pass

try:
    from Components.config import config
    language = config.osd.language.value
    language = language[:-3]
except:
    language = 'en'
    pass
print('language: ', language)

try:
    if my_cur_skin is False:
        myz_skin = "/usr/share/enigma2/%s/apikey" % cur_skin
        print('skinz namez', myz_skin)
        if os.path.exists(myz_skin):
            with open(myz_skin, "r") as f:
                apikey = f.read()
                my_cur_skin = True
        # no_cover = "/usr/share/enigma2/%s/menu/panels/nocover.png" %cur_skin
except:
    my_cur_skin = False


REGEX = re.compile(
        r'([\(\[]).*?([\)\]])|'
        r'(: odc.\d+)|'
        r'(\d+: odc.\d+)|'
        r'(\d+ odc.\d+)|(:)|'
        r'( -(.*?).*)|(,)|'
        r'!|'
        r'/.*|'
        r'\|\s[0-9]+\+|'
        r'[0-9]+\+|'
        r'\s\d{4}\Z|'
        r'([\(\[\|].*?[\)\]\|])|'
        r'(\"|\"\.|\"\,|\.)\s.+|'
        r'\"|:|'
        r'Премьера\.\s|'
        r'(х|Х|м|М|т|Т|д|Д)/ф\s|'
        r'(х|Х|м|М|т|Т|д|Д)/с\s|'
        r'\s(с|С)(езон|ерия|-н|-я)\s.+|'
        r'\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|'
        r'\.\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|'
        r'\s(ч|ч\.|с\.|с)\s\d{1,3}.+|'
        r'\d{1,3}(-я|-й|\sс-н).+|', re.DOTALL)


def intCheck():
    try:
        response = urlopen("http://google.com", None, 5)
        response.close()
    except HTTPError:
        return False
    except URLError:
        return False
    except socket.timeout:
        return False
    else:
        return True


class ZChannel(Renderer):
    def __init__(self):
        Renderer.__init__(self)
        if not intCheck:
            return
        self.timerchan = eTimer()
        self.timer20 = eTimer()

    GUI_WIDGET = ePixmap

    def changed(self, what):
        if not self.instance:
            return
        if self.timerchan:
            self.timerchan.stop()
        if self.timer20:
            self.timer20.stop()

        if what[0] == self.CHANGED_CLEAR:
            self.instance.hide()
        if what[0] != self.CHANGED_CLEAR:
            self.instance.hide()

            try:
                self.timer20.callback.append(self.delay)
            except:
                self.timer20_conn = self.timer20.timeout.connect(self.delay)
            self.timer20.start(200, True)

    def delay(self):
        self.evnt = ''
        self.pstrNm = ''
        self.evntNm = ''
        self.downloading = False
        self.event = self.source.event
        if self.event:
            # self.evnt = self.event.getEventName()
            # self.evntNm = REGEX.sub('', self.evnt).strip()
            
            self.evnt = self.event.getEventName()
            self.evntNm = REGEX.sub('', self.evnt).strip()
            self.evntNm = self.evntNm.replace('\xc2\x86', '').replace('\xc2\x87', '')
            
            print('clean event Zchannel: ', self.evntNm)
            self.pstrNm = "{}{}.jpg".format(path_folder, quote(self.evntNm))
            if os.path.exists(self.pstrNm):
                self.showPoster()
            else:
                self.instance.hide()
                try:
                    self.timerchan.callback.append(self.info)
                except:
                    self.timerchan_conn = self.timerchan.timeout.connect(self.info)
                self.timerchan.start(150, False)
        else:
            self.instance.hide()
            self.timer20.stop()
            return

    def showPoster(self):
        if os.path.exists(self.pstrNm):
            size = self.instance.size()
            self.picload = ePicLoad()
            sc = AVSwitch().getFramebufferScale()
            if self.picload:
                self.picload.setPara([size.width(), size.height(), sc[0], sc[1], False, 1, '#00000000'])
                if os.path.exists('/var/lib/dpkg/status'):
                    self.picload.startDecode(self.pstrNm, False)
                else:
                    self.picload.startDecode(self.pstrNm, 0, 0, False)
            ptr = self.picload.getData()
            if ptr is not None:
                self.instance.setPixmap(ptr)
                self.instance.show()
            else:

                self.instance.hide()
        else:
            self.instance.hide()

    def info(self):
        if self.downloading:
            return
        self.downloading = True
        try:
            url = 'http://api.themoviedb.org/3/search/tv?api_key={}&query={}'.format(apikey, quote(self.evntNm))
            # if PY3:
                # url = url.encode()
            url2 = urlopen(url).read().decode('utf-8')
            jurl = json.loads(url2)
            if 'results' in jurl:
                if 'id' in jurl['results'][0]:
                    ids = jurl['results'][0]['id']
                    url_2 = 'http://api.themoviedb.org/3/tv/' + str(ids) + '?api_key={}&language={}'.format(apikey, str(language))
                    # if PY3:
                        # url_2 = url_2.encode()
                    url_3 = urlopen(url_2).read().decode('utf-8')
                    data2 = json.loads(url_3)
                    poster = data2['poster_path']
                    if poster:
                        # self.url_poster = "http://image.tmdb.org/t/p/w185{}".format(poster) #w185 risoluzione poster
                        self.url_poster = "http://image.tmdb.org/t/p/{}{}".format(formatImg, str(poster))  # w185 risoluzione poster
                        self.savePoster()
            self.timerchan.stop()
        except:
            try:
                url = 'http://api.themoviedb.org/3/search/movie?api_key={}&query={}'.format(apikey, quote(self.evntNm))
                # if PY3:
                    # url = url.encode()
                url2 = urlopen(url).read().decode('utf-8')
                jurl = json.loads(url2)
                if 'results' in jurl:
                    if 'id' in jurl['results'][0]:
                        ids = jurl['results'][0]['id']
                        url_2 = 'http://api.themoviedb.org/3/movie/' + str(ids) + '?api_key={}&language={}'.format(apikey, str(language))
                        # if PY3:
                            # url_2 = url_2.encode()
                        url_3 = urlopen(url_2).read().decode('utf-8')
                        data2 = json.loads(url_3)
                        poster = data2['poster_path']
                        if poster:
                            # self.url_poster = "http://image.tmdb.org/t/p/w185{}".format(poster) # w185 risoluzione poster
                            self.url_poster = "http://image.tmdb.org/t/p/{}{}".format(formatImg, str(poster))
                            self.savePoster()
                self.timerchan.stop()
            except:
                self.downloading = False
                self.timerchan.stop()

    def savePoster(self):
        if not os.path.exists(path_folder):
            os.makedirs(path_folder)
        pic_image = urlopen(self.url_poster).read()
        try:
            with open(self.pstrNm, "wb") as f:
                f.write(pic_image)
            self.showPoster()
        except:
            pass
