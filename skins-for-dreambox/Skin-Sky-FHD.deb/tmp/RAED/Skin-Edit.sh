#j00zek @2015
#Edit RAED

myDir=/usr/share/enigma2/Sky_FHD

MakeChanges(){
SkinName=$1
sed -i 's/secondfont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/fontSizesOriginal=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/fontSizesCompact=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/fontSizesMinimal=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/itemHeights=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/columnsOriginal=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/compactColumn=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/colorEventPercentage=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/colorEventPercentageSelected=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/colorServiceRecording=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/columnsCompactDescription=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/scrollbarSliderBorderColor=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/scrollbarSliderForegroundColor=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/scrollbarWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setEventItemFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setColWidths=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setEventTimeFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setIconDistance=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setColGap=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setTimeWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setEventNameFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/rowSplit=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setServiceNameFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/satPosLeft=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/sliderPixmap=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/eventPercentageWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/widthEventProgressbarBorder=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/eventPercentageFont=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/progressBarWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/progressbarHeight=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/progressPercentWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/fontSizesMinimal=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/fontSizesCompact=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/fontSizesOriginal=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/serviceSelectedFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/itemsDistances=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/fieldMargins=["][^"]*["]//' $SkinName > /dev/null 2>&1
#sed -i 's/serviceItemHeight=["][^"]*["]//' $SkinName > /dev/null 2>&1
#Global screens
sed -i 's/\(name="CiList".*\) scrollbarMode="showNewer"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name=.*\) scrollbarMode="showNewer"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name=.*\) alphatest="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name=.*\) enableWrapAround="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name=.*\) iconWidth="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name=.*\) iconHeight="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name=.*\) iconMargin="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="list".*\) font="[a-zA-Z_]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="list".*\) font="[a-zA-Z_]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="list".*\) font="[a-zA-Z_]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="list".*\) font="[a-zA-Z_]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="list".*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="list".*\) font="[a-zA-Z_0-9]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="list".*\) font="[a-zA-Z_0-9]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="list".*\) font="[a-zA-Z_0-9]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\)valign="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\) font="[a-zA-Z_]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\) font="[a-zA-Z_]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\) font="[a-zA-Z_]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\) font="[a-zA-Z_]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\) font="[a-zA-Z_0-9]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\) font="[a-zA-Z_0-9]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="[a-zA-Z_]*list".*\) font="[a-zA-Z_0-9]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) scrollbarMode="showNewer"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) valign="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) font="[a-zA-Z_]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) font="[a-zA-Z_]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) font="[a-zA-Z_]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) font="[a-zA-Z_]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) font="[a-zA-Z_0-9]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) font="[a-zA-Z_0-9]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="config".*\) font="[a-zA-Z_0-9]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="menu".*\) font="[a-zA-Z_]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="menu".*\) font="[a-zA-Z_]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="menu".*\) font="[a-zA-Z_]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="menu".*\) font="[a-zA-Z_]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="menu".*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="menu".*\) font="[a-zA-Z_0-9]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="menu".*\) font="[a-zA-Z_0-9]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="menu".*\) font="[a-zA-Z_0-9]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) font="[a-zA-Z_]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) font="[a-zA-Z_]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) font="[a-zA-Z_]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) font="[a-zA-Z_]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) font="[a-zA-Z_0-9]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) font="[a-zA-Z_0-9]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) font="[a-zA-Z_0-9]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(selectionPixmap.*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(selectionPixmap=.*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) foregroundColor="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) foregroundColor="[#a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) foregroundColor="[#0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) foregroundColor="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) alphatest="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) foregroundColor="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) foregroundColor="[#a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) foregroundColor="[#0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) foregroundColor="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) font="[a-zA-Z_]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) font="[a-zA-Z_]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) font="[a-zA-Z_]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) font="[a-zA-Z_]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) font="[a-zA-Z_0-9]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) font="[a-zA-Z_0-9]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) font="[a-zA-Z_0-9]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) alphatest="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\) alphatest="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Label".*\) scrollbarMode="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="ScrollLabel".*\) itemHeight="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\) valign="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(source="languages".*\) scrollbarMode="showNewer"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/colorServiceWithAdvertisment=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/scrollbarBackgroundPicture=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/pbarShift=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/pbarHeight=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/pbarLargeWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/spaceRight=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/compactColumn=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/treeDescription=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/partIconeShiftMinimal=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/partIconeShiftCompact=["][^"]*["]//' $SkinName > /dev/null 2>&1 
sed -i 's/trashShift=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/spaceIconeText=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/partIconeShiftOriginal=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/iconsWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/dirShift=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/partIconeShift=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/pbarColourRec=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/pbarColourSeen=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/pbarColour=["][^"]*["]//' $SkinName > /dev/null 2>&1
#skinselector
sed -i 's/\(name="SkinList".*\) font="[a-zA-Z_]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="SkinList".*\) font="[a-zA-Z_]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="SkinList".*\) font="[a-zA-Z_]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="SkinList".*\) font="[a-zA-Z_]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="SkinList".*\) font="[a-zA-Z_0-9]*;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="SkinList".*\) font="[a-zA-Z_0-9]*; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="SkinList".*\) font="[a-zA-Z_0-9]* ;[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(name="SkinList".*\) font="[a-zA-Z_0-9]* ; [0-9]*"/\1/' $SkinName > /dev/null 2>&1
#Other
sed -i '/name="anglePix"/d' $SkinName > /dev/null 2>&1
sed -i '/name="angleLabel"/d' $SkinName > /dev/null 2>&1
sed -i '/name="audioLabel"/d' $SkinName > /dev/null 2>&1
sed -i '/name="chapterLabel"/d' $SkinName > /dev/null 2>&1
sed -i '/name="subtitleLabel"/d' $SkinName > /dev/null 2>&1
sed -i '/name="servicename"/d' $SkinName > /dev/null 2>&1
sed -i '/name="chosenletter"/d' $SkinName > /dev/null 2>&1
sed -i '/name="movie_off"/d' $SkinName > /dev/null 2>&1
sed -i '/name="movie_sort"/d' $SkinName > /dev/null 2>&1
sed -i '/name="curent"/d' $SkinName > /dev/null 2>&1
sed -i '/source="screen_path"/d' $SkinName > /dev/null 2>&1
sed -i '/name="VolumeText"/d' $SkinName > /dev/null 2>&1
sed -i '/name="WindowDimmer"/d' $SkinName > /dev/null 2>&1
sed -i '/name="datetime"/d' $SkinName > /dev/null 2>&1
sed -i '/name="duration"/d' $SkinName > /dev/null 2>&1
}

MakeChanges $myDir/*.xml

#myDirs='allScreens allFonts allColors'

#for mySubDir in $myDirs; do
#	for skin in `ls $myDir/$mySubDir`; do
#		echo Modyfing $skin
#		MakeChanges $myDir/$mySubDir/$skin 
#	done
#done
