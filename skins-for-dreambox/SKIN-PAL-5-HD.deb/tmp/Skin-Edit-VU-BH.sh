#j00zek @2015
#Edit RAED


myDir=/usr/share/enigma2/Pal.5.HD

MakeChanges(){
SkinName=$1
sed -i 's/secondfont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/fontSizesOriginal=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/fontSizesCompact=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/fontSizesMinimal=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/itemHeights=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/colorServiceRecording=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/scrollbarSliderBorderColor=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/scrollbarSliderForegroundColor=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/scrollbarWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setEventItemFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setColWidths=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setEventTimeFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setIconDistance=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setColGap=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setTimeWidth=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setEventNameFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/rowSplit=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setServiceNameFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/setFont=["][^"]*["]//' $SkinName > /dev/null 2>&1
sed -i 's/satPosLeft=["][^"]*["]//' $SkinName > /dev/null 2>&1
#Global screens
sed -i 's/\(render="Listbox".*\)foregroundColor="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\)foregroundColor="[#a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\)foregroundColor="[#0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\)foregroundColor="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Listbox".*\)alphatest="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\)foregroundColor="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\)foregroundColor="[#a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\)foregroundColor="[#0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\)foregroundColor="[0-9]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Progress".*\)alphatest="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
sed -i 's/\(render="Label".*\)scrollbarMode="[a-zA-Z_]*"/\1/' $SkinName > /dev/null 2>&1
#Other
sed -i '/name="anglePix"/d' $SkinName > /dev/null 2>&1
sed -i '/name="angleLabel"/d' $SkinName > /dev/null 2>&1
sed -i '/name="audioLabel"/d' $SkinName > /dev/null 2>&1
sed -i '/name="chapterLabel"/d' $SkinName > /dev/null 2>&1
sed -i '/name="subtitleLabel"/d' $SkinName > /dev/null 2>&1
sed -i '/name="servicename"/d' $SkinName > /dev/null 2>&1
}

MakeChanges $myDir/skin.xml

myDirs='allScreens allFonts allColors'

for mySubDir in $myDirs; do
	for skin in `ls $myDir/$mySubDir`; do
		echo Modyfing $skin
		MakeChanges $myDir/$mySubDir/$skin 
	done
done
