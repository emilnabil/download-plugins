# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import sys
import time
import json
import socket

PY3 = sys.version_info[0] >= 3

try:
    text_type = unicode  # noqa: F821  # python2
except NameError:
    text_type = str

try:
    binary_type = bytes
except NameError:
    binary_type = str


def ensure_text(value, encoding="utf-8", errors="ignore"):
    if value is None:
        return u""
    if isinstance(value, text_type):
        return value
    if isinstance(value, binary_type):
        try:
            return value.decode(encoding, errors)
        except Exception:
            return text_type(value)
    try:
        return text_type(value)
    except Exception:
        return u""


def safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def utc_ts():
    return int(time.time())


def local_day(ts=None):
    if ts is None:
        ts = time.time()
    return time.strftime("%Y-%m-%d", time.localtime(ts))


def mkdir_p(path):
    try:
        if not os.path.isdir(path):
            os.makedirs(path)
    except Exception:
        pass


def load_json(path, default=None):
    if default is None:
        default = {}
    try:
        if not os.path.exists(path):
            return default
        f = open(path, "rb")
        try:
            data = f.read()
        finally:
            f.close()
        text = ensure_text(data)
        return json.loads(text)
    except Exception:
        return default


def save_json(path, data):
    try:
        parent = os.path.dirname(path)
        if parent:
            mkdir_p(parent)
        payload = json.dumps(data, indent=2, sort_keys=True)
        if not PY3 and isinstance(payload, text_type):
            payload = payload.encode("utf-8")
        f = open(path, "wb")
        try:
            f.write(payload)
        finally:
            f.close()
        return True
    except Exception:
        return False


class SocketUsageTracker(object):
    patched = False
    originals = {}
    totals = {}
    since_pull = {}
    filename_cache = {}
    self_plugin_token = "/Plugins/Extensions/NetUsagePro/"

    @classmethod
    def _detect_plugin_name(cls):
        try:
            frame = sys._getframe(2)
        except Exception:
            return u"enigma2-core"
        while frame:
            try:
                code = frame.f_code
                filename = ensure_text(getattr(code, "co_filename", ""))
                if filename:
                    cached = cls.filename_cache.get(filename)
                    if cached is not None:
                        return cached
                    if cls.self_plugin_token in filename:
                        frame = frame.f_back
                        continue
                    marker = "/Plugins/"
                    if marker in filename:
                        part = filename.split(marker, 1)[1]
                        bits = [x for x in part.split("/") if x]
                        # عادة: Extensions/PluginName/...
                        if len(bits) >= 2:
                            if bits[0] in ("Extensions", "SystemPlugins") and len(bits) >= 2:
                                plugin_name = ensure_text(bits[1])
                            else:
                                plugin_name = ensure_text(bits[0])
                            cls.filename_cache[filename] = plugin_name
                            return plugin_name
                frame = frame.f_back
            except Exception:
                break
        return u"enigma2-core"

    @classmethod
    def _add(cls, plugin_name, rx=0, tx=0):
        if not plugin_name:
            plugin_name = u"unknown"
        entry = cls.totals.setdefault(plugin_name, {"rx": 0, "tx": 0})
        entry["rx"] += safe_int(rx)
        entry["tx"] += safe_int(tx)
        entry2 = cls.since_pull.setdefault(plugin_name, {"rx": 0, "tx": 0})
        entry2["rx"] += safe_int(rx)
        entry2["tx"] += safe_int(tx)

    @classmethod
    def pull_delta(cls):
        data = cls.since_pull
        cls.since_pull = {}
        return data

    @classmethod
    def _patch_method(cls, method_name, kind):
        if method_name not in cls.originals:
            cls.originals[method_name] = getattr(socket.socket, method_name, None)
        original = cls.originals.get(method_name)
        if not original:
            return

        def wrapper(sock, *args, **kwargs):
            result = original(sock, *args, **kwargs)
            try:
                plugin_name = cls._detect_plugin_name()
                if kind == "send":
                    sent = result
                    if sent is None and args:
                        try:
                            sent = len(args[0])
                        except Exception:
                            sent = 0
                    cls._add(plugin_name, tx=safe_int(sent))
                elif kind == "recv":
                    size = 0
                    if isinstance(result, (bytes, bytearray, text_type)):
                        size = len(result)
                    elif isinstance(result, tuple) and result:
                        first = result[0]
                        if isinstance(first, (bytes, bytearray, text_type)):
                            size = len(first)
                    cls._add(plugin_name, rx=size)
            except Exception:
                pass
            return result
        setattr(socket.socket, method_name, wrapper)

    @classmethod
    def patch(cls):
        if cls.patched:
            return
        cls.patched = True
        for method_name in ("send", "sendall", "sendto"):
            try:
                cls._patch_method(method_name, "send")
            except Exception:
                pass
        for method_name in ("recv", "recvfrom"):
            try:
                cls._patch_method(method_name, "recv")
            except Exception:
                pass
