# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import textwrap
import traceback
import time

from enigma import eTimer
try:
    from enigma import addFont
except Exception:
    addFont = None
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Plugins.Plugin import PluginDescriptor

from .compat import ensure_text, local_day, safe_int
from .netstats import NetUsageEngine

PLUGIN_VERSION = "1.0"
PLUGIN_NAME = "NetUsagePro"
PLUGIN_DESC = "Professional network usage monitor by mosad"
SELF_PLUGIN_NAMES = [PLUGIN_NAME, "enigma2-core"]
LOG_PATH = "/tmp/netusagepro.log"
PLUGIN_DIR = os.path.dirname(__file__)
BUTTONS_DIR = os.path.join(PLUGIN_DIR, "buttons")
FONT_DIR = os.path.join(PLUGIN_DIR, "font")
FONT_PATH = os.path.join(FONT_DIR, "tix.ttf")
LOGO_PATH = os.path.join(PLUGIN_DIR, "NetUsagePro.png")
PLUGIN_ICON = os.path.join(PLUGIN_DIR, "plugin.png")
RED_ICON = os.path.join(BUTTONS_DIR, "key_red.png")
GREEN_ICON = os.path.join(BUTTONS_DIR, "key_green.png")
YELLOW_ICON = os.path.join(BUTTONS_DIR, "key_yellow.png")
BLUE_ICON = os.path.join(BUTTONS_DIR, "key_blue.png")
EXIT_ICON = os.path.join(BUTTONS_DIR, "key_exit.png")
SKIN_FONT = "Regular"

_engine = None


def _log(msg):
    try:
        line = ensure_text(msg)
        stamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        with open(LOG_PATH, "ab") as f:
            payload = "[%s] %s\n" % (stamp, line)
            try:
                f.write(payload.encode("utf-8"))
            except Exception:
                f.write(payload)
    except Exception:
        pass


def _register_font():
    global SKIN_FONT
    try:
        if addFont is not None and os.path.exists(FONT_PATH):
            addFont(FONT_PATH, "tix", 100, 0)
            SKIN_FONT = "tix"
            _log("Font registered: %s" % FONT_PATH)
        else:
            _log("Font registration skipped")
    except Exception as e:
        _log("Font registration failed: %s" % ensure_text(e))
        SKIN_FONT = "Regular"


_register_font()


def get_engine(session=None):
    global _engine
    if _engine is None:
        _engine = NetUsageEngine(session=session)
        _engine.start()
        _log("NetUsageEngine started")
    elif session is not None and _engine.session is None:
        _engine.session = session
    return _engine


def build_skin():
    font = SKIN_FONT
    return """
    <screen name="NetUsageProScreen" position="0,0" size="1920,1080" title="NetUsagePro" backgroundColor="#040506" flags="wfNoBorder">
        <eLabel position="0,0" size="1920,1080" backgroundColor="#040506" zPosition="0" />

        <eLabel position="24,18" size="1872,106" backgroundColor="#082a62" zPosition="1" />
        <ePixmap position="48,40" size="150,60" pixmap="%s" alphatest="blend" zPosition="6" />

        <eLabel position="20,136" size="928,408" backgroundColor="#0b1120" zPosition="1" />
        <eLabel position="972,136" size="928,408" backgroundColor="#0b1120" zPosition="1" />
        <eLabel position="20,556" size="928,408" backgroundColor="#0b1120" zPosition="1" />
        <eLabel position="972,556" size="928,408" backgroundColor="#0b1120" zPosition="1" />

        <eLabel position="20,974" size="1880,84" backgroundColor="#0a1018" zPosition="1" />
        <eLabel position="20,974" size="1880,1" backgroundColor="#17395e" zPosition="2" />

        <widget name="title_text" position="228,32" size="1320,36" font="%s;31" foregroundColor="#ffffff" backgroundColor="#082a62" transparent="0" zPosition="7" />
        <widget name="status_text" position="228,72" size="1610,28" font="%s;22" foregroundColor="#dbe8f6" backgroundColor="#082a62" transparent="0" zPosition="7" />

        <widget name="overview_header" position="44,156" size="884,30" font="%s;24" foregroundColor="#6fc6ff" backgroundColor="#0b1120" transparent="0" zPosition="7" />
        <widget name="categories_header" position="996,156" size="884,30" font="%s;24" foregroundColor="#6fc6ff" backgroundColor="#0b1120" transparent="0" zPosition="7" />
        <widget name="plugins_header" position="44,576" size="884,30" font="%s;24" foregroundColor="#6fc6ff" backgroundColor="#0b1120" transparent="0" zPosition="7" />
        <widget name="live_header" position="996,576" size="884,30" font="%s;24" foregroundColor="#6fc6ff" backgroundColor="#0b1120" transparent="0" zPosition="7" />

        <widget name="overview" position="44,198" size="884,328" font="%s;21" foregroundColor="#ffffff" backgroundColor="#0b1120" transparent="0" valign="top" halign="left" zPosition="7" />
        <widget name="categories" position="996,198" size="884,328" font="%s;21" foregroundColor="#ffffff" backgroundColor="#0b1120" transparent="0" valign="top" halign="left" zPosition="7" />
        <widget name="plugins" position="44,618" size="884,328" font="%s;20" foregroundColor="#ffffff" backgroundColor="#0b1120" transparent="0" valign="top" halign="left" zPosition="7" />
        <widget name="live" position="996,618" size="884,328" font="%s;20" foregroundColor="#ffffff" backgroundColor="#0b1120" transparent="0" valign="top" halign="left" zPosition="7" />

        <ePixmap position="220,990" size="38,38" pixmap="%s" alphatest="blend" zPosition="7" />
        <ePixmap position="580,990" size="38,38" pixmap="%s" alphatest="blend" zPosition="7" />
        <ePixmap position="940,990" size="38,38" pixmap="%s" alphatest="blend" zPosition="7" />
        <ePixmap position="1300,990" size="38,38" pixmap="%s" alphatest="blend" zPosition="7" />
        <ePixmap position="1660,990" size="38,38" pixmap="%s" alphatest="blend" zPosition="7" />

        <widget name="red_label" position="179,1030" size="120,22" font="%s;20" foregroundColor="#ff5d5d" backgroundColor="#0a1018" transparent="0" halign="center" zPosition="7" />
        <widget name="green_label" position="509,1030" size="180,22" font="%s;20" foregroundColor="#7dff82" backgroundColor="#0a1018" transparent="0" halign="center" zPosition="7" />
        <widget name="yellow_label" position="899,1030" size="120,22" font="%s;20" foregroundColor="#ffe367" backgroundColor="#0a1018" transparent="0" halign="center" zPosition="7" />
        <widget name="blue_label" position="1254,1030" size="130,22" font="%s;20" foregroundColor="#74b4ff" backgroundColor="#0a1018" transparent="0" halign="center" zPosition="7" />
        <widget name="exit_label" position="1619,1030" size="120,22" font="%s;20" foregroundColor="#d8dde7" backgroundColor="#0a1018" transparent="0" halign="center" zPosition="7" />
    </screen>
    """ % (
        LOGO_PATH,
        font, font,
        font, font, font, font,
        font, font, font, font,
        RED_ICON, GREEN_ICON, YELLOW_ICON, BLUE_ICON, EXIT_ICON,
        font, font, font, font, font
    )


class NetUsageProScreen(Screen):
    skin = build_skin()

    def __init__(self, session):
        self.skin = build_skin()
        Screen.__init__(self, session)
        self.engine = get_engine(session)
        self.setTitle(PLUGIN_NAME)
        self._refresh_count = 0
        self._manual_refresh_until = 0

        self["title_text"] = Label("NetUsagePro v%s  |  Professional network usage monitor by mosad" % PLUGIN_VERSION)
        self["status_text"] = Label("UI bootstrap started...")
        self["overview_header"] = Label("Overview")
        self["categories_header"] = Label("Daily Breakdown")
        self["plugins_header"] = Label("Background Plugins / Services")
        self["live_header"] = Label("Live Monitor")
        self["overview"] = Label("Loading metrics...")
        self["categories"] = Label("Loading metrics...")
        self["plugins"] = Label("Loading metrics...")
        self["live"] = Label("Loading metrics...")
        self["red_label"] = Label("Refresh")
        self["green_label"] = Label("Reset today")
        self["yellow_label"] = Label("Notes")
        self["blue_label"] = Label("Rescan")
        self["exit_label"] = Label("Close")

        self["actions"] = ActionMap(["SetupActions", "ColorActions", "InfobarColorActions", "OkCancelActions"], {
            "cancel": self.close,
            "ok": self.manual_refresh,
            "red": self.manual_refresh,
            "green": self.reset_today,
            "yellow": self.show_note,
            "blue": self.force_scan,
        }, -1)

        self.timer = eTimer()
        self._append_callback(self.timer, self.refresh)
        self.onLayoutFinish.append(self._start)
        self.onShow.append(self._on_show)
        self.onClose.append(self._stop)
        _log("NetUsageProScreen initialized")

    def _append_callback(self, timer, fnc):
        try:
            timer.callback.append(fnc)
        except Exception:
            try:
                timer.timeout.connect(fnc)
            except Exception:
                pass

    def _set_text(self, widget_name, value):
        text = ensure_text(value)
        try:
            self[widget_name].setText(text)
        except Exception:
            try:
                self[widget_name].text = text
            except Exception:
                _log("Failed to set text for %s" % widget_name)

    def _on_show(self):
        self._set_text("status_text", "Screen shown. Preparing live data...")
        _log("NetUsageProScreen shown")

    def _start(self):
        _log("UI layout finished")
        self._set_text("status_text", "UI loaded. Auto refresh is active every 1 second.")
        self.refresh()
        try:
            self.timer.start(1000, False)
        except Exception:
            pass

    def _stop(self):
        _log("NetUsageProScreen closed")
        try:
            self.timer.stop()
        except Exception:
            pass
        try:
            self.engine.save()
        except Exception:
            pass

    def show_note(self):
        text = (
            "Accuracy notes:\n"
            "- Interface totals are exact.\n"
            "- Python plugins inside enigma2 are tracked from socket activity when visible.\n"
            "- External services are estimated from process sockets and current activity.\n"
            "- Auto refresh in this screen runs every 1 second.\n"
            "- Blue = force process rescan.\n"
            "- Log file: %s" % LOG_PATH
        )
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO)

    def manual_refresh(self):
        try:
            self._manual_refresh_until = time.time() + 2
            _log("Manual refresh requested")
        except Exception:
            pass
        self.refresh()

    def force_scan(self):
        try:
            self.engine.last_proc_scan_ts = 0
        except Exception:
            pass
        self.refresh()

    def reset_today(self):
        self.engine.reset_today()
        self.refresh()
        self.session.open(MessageBox, "Today counters were reset.", MessageBox.TYPE_INFO, timeout=3)

    def refresh(self):
        try:
            self._refresh_safe()
        except Exception:
            tb = traceback.format_exc()
            _log(tb)
            self._set_text("title_text", "%s v%s" % (PLUGIN_NAME, PLUGIN_VERSION))
            self._set_text("status_text", "Runtime error. Read: %s" % LOG_PATH)
            self._set_text("overview", "Plugin exception detected.\nRead log with:\ncat %s" % LOG_PATH)
            self._set_text("categories", ensure_text(tb)[:540])
            self._set_text("plugins", "Fallback mode active.")
            self._set_text("live", "Fallback mode active.")

    def _refresh_safe(self):
        self.engine._tick()
        day_data = self.engine.get_today()
        snap = self.engine.get_live_snapshot()
        tracked_plugins = self._tracked_plugins(day_data)
        manual_note = ""
        try:
            if time.time() < self._manual_refresh_until:
                manual_note = "   Manual refresh OK"
        except Exception:
            manual_note = ""
        self._set_text(
            "status_text",
            "Interface: %s   Mode: %s   Date: %s   Last update: %s   Python plugins: %d   Auto refresh: 1s%s" % (
                ensure_text(snap.get("iface", "-")) or "-",
                self._mode_name(snap.get("mode", "unknown")),
                local_day(),
                self._fmt_clock(day_data.get("last_update", 0)),
                len(tracked_plugins),
                manual_note
            )
        )
        self._set_text("overview", self._render_overview(day_data, snap, tracked_plugins))
        self._set_text("categories", self._render_categories(day_data))
        self._set_text("plugins", self._render_plugins(day_data, snap, tracked_plugins))
        self._set_text("live", self._render_live(snap))
        self._refresh_count += 1
        if (self._refresh_count % 30) == 0:
            _log("Refresh cycle OK (%d)" % self._refresh_count)

    def _fmt_clock(self, ts):
        try:
            return time.strftime("%H:%M:%S", time.localtime(int(ts)))
        except Exception:
            return "--:--:--"

    def _mode_name(self, mode):
        names = {
            "iptv": "IPTV",
            "sharing": "Sharing",
            "background": "Background",
            "live_tv": "Live TV",
            "unknown": "Unknown"
        }
        return names.get(mode, ensure_text(mode))

    def _clip(self, text, limit):
        text = ensure_text(text)
        if len(text) <= limit:
            return text
        if limit <= 3:
            return text[:limit]
        return text[:limit - 3] + "..."

    def _wrap_line(self, text, width=74, max_lines=2):
        text = ensure_text(text).strip()
        if not text:
            return "-"
        parts = textwrap.wrap(text, width=width)
        if not parts:
            return "-"
        if len(parts) > max_lines:
            kept = parts[:max_lines]
            if len(kept[-1]) > 3:
                kept[-1] = kept[-1][:-3] + "..."
            parts = kept
        return "\n".join(parts)

    def _percent(self, part, whole):
        whole = float(max(0, safe_int(whole)))
        if whole <= 0:
            return "0.0%%"
        return "%.1f%%" % ((float(max(0, safe_int(part))) / whole) * 100.0)

    def _sum_total(self, info):
        return safe_int(info.get("rx", 0)) + safe_int(info.get("tx", 0))

    def _tracked_plugins(self, day_data):
        rows = self.engine.summarize_pyplugins(day_data, limit=50, exclude_names=SELF_PLUGIN_NAMES)
        result = []
        for name, total, exact, info in rows:
            if total <= 0:
                continue
            result.append((name, total, exact, info))
        return result

    def _render_overview(self, day_data, snap, tracked_plugins):
        totals = day_data.get("totals", {})
        total_all = self._sum_total(totals)
        exact_plugins_total = 0
        for name, total, exact, info in tracked_plugins:
            exact_plugins_total += total
        service = self._wrap_line(day_data.get("last_service", snap.get("service", "")) or "-", 70, 2)

        lines = []
        lines.append("RX Today: %s" % self.engine.human_bytes(totals.get("rx", 0)))
        lines.append("TX Today: %s" % self.engine.human_bytes(totals.get("tx", 0)))
        lines.append("Total Today: %s" % self.engine.human_bytes(total_all))
        lines.append("Python plugins: %s" % self.engine.human_bytes(exact_plugins_total))
        lines.append("Plugin share: %s" % self._percent(exact_plugins_total, total_all))
        lines.append("Current mode: %s" % self._mode_name(snap.get("mode", "unknown")))
        lines.append("Live RX / TX: %s / %s" % (
            self.engine.human_bytes(snap.get("speed_rx", 0)),
            self.engine.human_bytes(snap.get("speed_tx", 0))
        ))
        lines.append("Service: %s" % service)
        return "\n".join(lines)

    def _render_categories(self, day_data):
        cats = day_data.get("categories", {})
        totals = day_data.get("totals", {})
        total_all = self._sum_total(totals)
        lines = []
        for key, title in (
            ("iptv", "IPTV"),
            ("sharing", "Sharing"),
            ("background", "Background"),
            ("live_tv", "Live TV"),
            ("unknown", "Unknown")
        ):
            info = cats.get(key, {})
            total = self._sum_total(info)
            lines.append("%s: %s (%s)" % (title, self.engine.human_bytes(total), self._percent(total, total_all)))
        lines.append("")
        lines.append("Method")
        lines.append("- Interface total: exact")
        lines.append("- Python plugins: exact socket tracking")
        lines.append("- External services: estimated")
        return "\n".join(lines)

    def _render_plugins(self, day_data, snap, tracked_plugins):
        lines = []
        lines.append("Python plugins")
        if not tracked_plugins:
            lines.append("- No plugin traffic captured yet")
        else:
            for name, total, exact, info in tracked_plugins[:5]:
                lines.append("- %s | %s" % (self._clip(name, 24), self.engine.human_bytes(total)))
        lines.append("")
        lines.append("Background services")
        bg_rows = []
        for row in snap.get("proc_rows", []):
            if row.get("sharing") or row.get("background"):
                bg_rows.append(row)
        if not bg_rows:
            lines.append("- No active background service now")
        else:
            for row in bg_rows[:6]:
                role = "Sharing" if row.get("sharing") else "Background"
                lines.append("- %s | %s | T%s U%s" % (
                    self._clip(row.get("name", "?"), 18),
                    role,
                    row.get("tcp", 0),
                    row.get("udp", 0)
                ))
        return "\n".join(lines)

    def _render_live(self, snap):
        proc_rows = snap.get("proc_rows", [])
        service = self._wrap_line(snap.get("service", "") or "-", 70, 2)
        lines = []
        lines.append("Interface: %s" % (ensure_text(snap.get("iface", "-")) or "-"))
        lines.append("Instant RX: %s / sec" % self.engine.human_bytes(snap.get("speed_rx", 0)))
        lines.append("Instant TX: %s / sec" % self.engine.human_bytes(snap.get("speed_tx", 0)))
        lines.append("Detected mode: %s" % self._mode_name(snap.get("mode", "unknown")))
        lines.append("Service: %s" % service)
        lines.append("Processes")
        if not proc_rows:
            lines.append("- No process socket data yet")
        else:
            for row in proc_rows[:5]:
                tags = []
                if row.get("player"):
                    tags.append("player")
                if row.get("sharing"):
                    tags.append("sharing")
                if row.get("background") and not row.get("player") and not row.get("sharing"):
                    tags.append("background")
                tag_text = "/".join(tags) if tags else "service"
                lines.append("- %s | %s | EST %s" % (
                    self._clip(row.get("name", "?"), 15),
                    self._clip(tag_text, 16),
                    row.get("established", 0)
                ))
        return "\n".join(lines)


def main(session, **kwargs):
    get_engine(session)
    session.open(NetUsageProScreen)


def sessionstart(reason=None, session=None, **kwargs):
    if session is not None:
        get_engine(session)


def autostart(reason=None, **kwargs):
    return None


def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=PLUGIN_NAME,
            description=PLUGIN_DESC,
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="plugin.png",
            fnc=main
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_AUTOSTART,
            fnc=autostart
        )
    ]
