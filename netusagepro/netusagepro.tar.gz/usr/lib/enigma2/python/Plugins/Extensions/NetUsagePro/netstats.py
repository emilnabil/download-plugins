# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import time
import errno

from enigma import eTimer

from .compat import ensure_text, safe_int, load_json, save_json, local_day, SocketUsageTracker

STATE_PATH = "/etc/enigma2/netusagepro.json"
MAX_DAYS = 14
SHARING_NAMES = ["oscam", "ncam", "cccam", "mgcamd", "camd3", "gbox", "wicardd", "evocamd"]
PLAYER_NAMES = ["gstplayer", "exteplayer3", "ffmpeg", "streamproxy", "enigma2"]
BACKGROUND_NAMES = ["python", "python2", "python3", "wget", "curl", "aria2c", "opkg"]


class NetUsageEngine(object):
    def __init__(self, session=None):
        self.session = session
        self.timer = eTimer()
        self._append_callback(self.timer, self._tick)
        self.state = load_json(STATE_PATH, default=self._new_state())
        self.current_iface = None
        self.last_iface_total = None
        self.last_save_ts = 0
        self.last_proc_scan_ts = 0
        self.cached_proc_view = []
        self.cached_proc_summary = {}
        SocketUsageTracker.patch()

    def _append_callback(self, timer, fnc):
        try:
            timer.callback.append(fnc)
        except Exception:
            try:
                timer.timeout.connect(fnc)
            except Exception:
                pass

    def _new_state(self):
        return {
            "version": 2,
            "days": {}
        }

    def start(self):
        self._tick()
        try:
            self.timer.start(5000, False)
        except Exception:
            pass

    def stop(self):
        try:
            self.timer.stop()
        except Exception:
            pass

    def _empty_day(self):
        return {
            "totals": {"rx": 0, "tx": 0},
            "categories": {
                "iptv": {"rx": 0, "tx": 0},
                "sharing": {"rx": 0, "tx": 0},
                "background": {"rx": 0, "tx": 0},
                "live_tv": {"rx": 0, "tx": 0},
                "unknown": {"rx": 0, "tx": 0}
            },
            "pyplugins": {},
            "processes": {},
            "last_iface": "",
            "last_mode": "unknown",
            "last_service": "",
            "last_update": int(time.time())
        }

    def _ensure_today(self):
        day = local_day()
        days = self.state.setdefault("days", {})
        if day not in days:
            days[day] = self._empty_day()
        keys = sorted(days.keys())
        if len(keys) > MAX_DAYS:
            for old in keys[:-MAX_DAYS]:
                try:
                    del days[old]
                except Exception:
                    pass
        return days[day]

    def _read_default_iface(self):
        try:
            f = open("/proc/net/route", "rb")
            try:
                data = ensure_text(f.read())
            finally:
                f.close()
            lines = data.splitlines()[1:]
            for line in lines:
                parts = line.split()
                if len(parts) > 2 and parts[1] == "00000000":
                    return ensure_text(parts[0])
        except Exception:
            pass
        try:
            f = open("/proc/net/dev", "rb")
            try:
                data = ensure_text(f.read())
            finally:
                f.close()
            for line in data.splitlines()[2:]:
                if ":" not in line:
                    continue
                iface = ensure_text(line.split(":", 1)[0]).strip()
                if iface and iface != "lo":
                    return iface
        except Exception:
            pass
        return "eth0"

    def _read_iface_totals(self, iface):
        try:
            f = open("/proc/net/dev", "rb")
            try:
                data = ensure_text(f.read())
            finally:
                f.close()
            for line in data.splitlines()[2:]:
                if ":" not in line:
                    continue
                left, right = line.split(":", 1)
                name = ensure_text(left).strip()
                if name != iface:
                    continue
                parts = right.split()
                if len(parts) >= 16:
                    rx = safe_int(parts[0])
                    tx = safe_int(parts[8])
                    return {"rx": rx, "tx": tx}
        except Exception:
            pass
        return None

    def _read_proc_name(self, pid):
        cmdline_text = u""
        try:
            f = open("/proc/%s/cmdline" % pid, "rb")
            try:
                cmdline_text = ensure_text(f.read())
            finally:
                f.close()
        except Exception:
            cmdline_text = u""
        if cmdline_text:
            cmdline_text = cmdline_text.replace("\x00", " ").strip()
            if cmdline_text:
                parts = [ensure_text(x) for x in cmdline_text.split(" ") if x]
                if parts:
                    first = ensure_text(parts[0]).split("/")[-1]
                    low = first.lower()
                    if low in ("python", "python2", "python3") and len(parts) > 1:
                        second = ensure_text(parts[1]).split("/")[-1]
                        if second:
                            return second
                    return first
        try:
            f = open("/proc/%s/comm" % pid, "rb")
            try:
                data = ensure_text(f.read())
            finally:
                f.close()
            if data:
                data = data.replace("\x00", " ").strip()
                if data:
                    return data.split("/")[-1].split(" ")[0]
        except Exception:
            pass
        return "pid-%s" % pid

    def _parse_proc_net(self, proto_name, path):
        items = {}
        try:
            f = open(path, "rb")
            try:
                data = ensure_text(f.read())
            finally:
                f.close()
            lines = data.splitlines()[1:]
            for line in lines:
                parts = line.split()
                if len(parts) < 10:
                    continue
                inode = parts[9]
                state = parts[3]
                items[inode] = {
                    "proto": proto_name,
                    "state": state
                }
        except Exception:
            pass
        return items

    def _scan_processes(self):
        now = time.time()
        if (now - self.last_proc_scan_ts) < 30 and self.cached_proc_view:
            return self.cached_proc_view
        inode_map = {}
        for proto_name, path in (
            ("tcp", "/proc/net/tcp"),
            ("tcp6", "/proc/net/tcp6"),
            ("udp", "/proc/net/udp"),
            ("udp6", "/proc/net/udp6")
        ):
            inode_map.update(self._parse_proc_net(proto_name, path))

        processes = {}
        try:
            proc_entries = os.listdir("/proc")
        except Exception:
            proc_entries = []
        for pid in proc_entries:
            if not pid.isdigit():
                continue
            fd_dir = "/proc/%s/fd" % pid
            try:
                fds = os.listdir(fd_dir)
            except OSError as e:
                if getattr(e, "errno", None) in (errno.ENOENT, errno.EPERM, errno.EACCES):
                    continue
                continue
            except Exception:
                continue
            proc_name = None
            entry = None
            for fd_name in fds:
                fd_path = "%s/%s" % (fd_dir, fd_name)
                try:
                    target = os.readlink(fd_path)
                except Exception:
                    continue
                if not target.startswith("socket:["):
                    continue
                inode = target[8:-1]
                meta = inode_map.get(inode)
                if not meta:
                    continue
                if proc_name is None:
                    proc_name = self._read_proc_name(pid)
                    entry = processes.setdefault(proc_name, {
                        "name": proc_name,
                        "pids": set(),
                        "tcp": 0,
                        "udp": 0,
                        "established": 0,
                        "score": 0,
                        "sharing": False,
                        "player": False,
                        "background": False
                    })
                entry["pids"].add(pid)
                proto = meta.get("proto")
                if proto.startswith("tcp"):
                    entry["tcp"] += 1
                    if meta.get("state") == "01":
                        entry["established"] += 1
                elif proto.startswith("udp"):
                    entry["udp"] += 1
                entry["score"] += 2 if meta.get("state") == "01" else 1
            if entry:
                low = proc_name.lower()
                entry["sharing"] = any(x in low for x in SHARING_NAMES)
                entry["player"] = any(x in low for x in PLAYER_NAMES)
                entry["background"] = any(x in low for x in BACKGROUND_NAMES) or (not entry["sharing"] and not entry["player"] and proc_name != "enigma2")

        rows = []
        for name, entry in processes.items():
            entry["pid_count"] = len(entry["pids"])
            entry.pop("pids", None)
            rows.append(entry)
        rows.sort(key=lambda x: (x.get("score", 0), x.get("established", 0), x.get("tcp", 0), x.get("udp", 0)), reverse=True)
        self.cached_proc_view = rows[:15]
        self.cached_proc_summary = processes
        self.last_proc_scan_ts = now
        return self.cached_proc_view

    def _detect_mode(self):
        mode = "unknown"
        service_text = u""
        try:
            if self.session and self.session.nav:
                ref = self.session.nav.getCurrentlyPlayingServiceReference()
                if ref:
                    try:
                        service_text = ensure_text(ref.toString())
                    except Exception:
                        service_text = ensure_text(ref)
        except Exception:
            service_text = u""
        low = service_text.lower()
        if low:
            if low.startswith("4097:") or low.startswith("5001:") or low.startswith("5002:"):
                mode = "iptv"
            elif "http" in low or "https" in low or "rtsp" in low or "rtmp" in low or "m3u8" in low or "%3a//" in low:
                mode = "iptv"
            else:
                mode = "live_tv"
        rows = self._scan_processes()
        if mode != "iptv":
            for row in rows:
                if row.get("player") and row.get("established", 0) > 0:
                    mode = "iptv"
                    break
        return mode, service_text, rows

    def _alloc(self, bucket, rx, tx):
        bucket["rx"] = bucket.get("rx", 0) + safe_int(rx)
        bucket["tx"] = bucket.get("tx", 0) + safe_int(tx)

    def _distribute(self, total_rx, total_tx, pyplugins, proc_rows, mode):
        remain_rx = max(0, safe_int(total_rx))
        remain_tx = max(0, safe_int(total_tx))
        py_total_rx = 0
        py_total_tx = 0
        for item in pyplugins.values():
            py_total_rx += safe_int(item.get("rx", 0))
            py_total_tx += safe_int(item.get("tx", 0))
        remain_rx = max(0, remain_rx - py_total_rx)
        remain_tx = max(0, remain_tx - py_total_tx)

        cat_weights = {}
        if mode == "iptv":
            cat_weights["iptv"] = 4
        elif mode == "live_tv":
            cat_weights["live_tv"] = 1
        sharing_rows = [x for x in proc_rows if x.get("sharing")]
        bg_rows = [x for x in proc_rows if x.get("background") and not x.get("sharing") and not x.get("player")]
        if sharing_rows:
            cat_weights["sharing"] = max(1, len(sharing_rows))
        if bg_rows:
            cat_weights["background"] = max(1, len(bg_rows))
        if not cat_weights:
            cat_weights["unknown"] = 1

        proc_weights = {}
        for name, item in pyplugins.items():
            proc_weights[name] = proc_weights.get(name, 0) + max(1, safe_int(item.get("rx", 0)) + safe_int(item.get("tx", 0)))
        for row in proc_rows:
            name = row.get("name")
            weight = safe_int(row.get("score", 0)) + safe_int(row.get("established", 0))
            if row.get("sharing"):
                weight += 2
            if row.get("player") and mode == "iptv":
                weight += 4
            if weight <= 0:
                weight = 1
            proc_weights[name] = proc_weights.get(name, 0) + weight
        if not proc_weights:
            proc_weights["enigma2"] = 1
        return remain_rx, remain_tx, cat_weights, proc_weights

    def _add_estimated_to_day(self, day_data, remain_rx, remain_tx, cat_weights, proc_weights):
        cat_total = float(sum(cat_weights.values()) or 1)
        proc_total = float(sum(proc_weights.values()) or 1)
        for cat_name, weight in cat_weights.items():
            bucket = day_data["categories"].setdefault(cat_name, {"rx": 0, "tx": 0})
            self._alloc(bucket, int(remain_rx * (weight / cat_total)), int(remain_tx * (weight / cat_total)))
        for proc_name, weight in proc_weights.items():
            bucket = day_data["processes"].setdefault(proc_name, {"rx": 0, "tx": 0, "exact": False})
            self._alloc(bucket, int(remain_rx * (weight / proc_total)), int(remain_tx * (weight / proc_total)))

    def _tick(self):
        day_data = self._ensure_today()
        self.current_iface = self._read_default_iface()
        iface_total = self._read_iface_totals(self.current_iface)
        mode, service_text, proc_rows = self._detect_mode()
        if iface_total is not None and self.last_iface_total is not None:
            d_rx = max(0, iface_total["rx"] - self.last_iface_total["rx"])
            d_tx = max(0, iface_total["tx"] - self.last_iface_total["tx"])
            day_data["totals"]["rx"] += d_rx
            day_data["totals"]["tx"] += d_tx
            py_delta = SocketUsageTracker.pull_delta()
            for name, info in py_delta.items():
                bucket = day_data["pyplugins"].setdefault(name, {"rx": 0, "tx": 0, "exact": True})
                self._alloc(bucket, info.get("rx", 0), info.get("tx", 0))
                bucket2 = day_data["processes"].setdefault(name, {"rx": 0, "tx": 0, "exact": True})
                bucket2["exact"] = True
                self._alloc(bucket2, info.get("rx", 0), info.get("tx", 0))
            remain_rx, remain_tx, cat_weights, proc_weights = self._distribute(d_rx, d_tx, py_delta, proc_rows, mode)
            self._add_estimated_to_day(day_data, remain_rx, remain_tx, cat_weights, proc_weights)
        else:
            SocketUsageTracker.pull_delta()
        self.last_iface_total = iface_total
        day_data["last_iface"] = self.current_iface or ""
        day_data["last_mode"] = mode
        day_data["last_service"] = service_text
        day_data["last_update"] = int(time.time())
        if (time.time() - self.last_save_ts) > 60:
            self.save()

    def save(self):
        self.last_save_ts = time.time()
        save_json(STATE_PATH, self.state)

    def reset_today(self):
        day = local_day()
        self.state.setdefault("days", {})[day] = self._empty_day()
        self.state["days"][day]["last_iface"] = self.current_iface or ""
        self.save()

    def get_today(self):
        return self._ensure_today()

    def human_bytes(self, value):
        value = float(max(0, safe_int(value)))
        units = ["B", "KB", "MB", "GB", "TB"]
        idx = 0
        while value >= 1024.0 and idx < len(units) - 1:
            value /= 1024.0
            idx += 1
        if idx == 0:
            return "%d %s" % (int(value), units[idx])
        return "%.2f %s" % (value, units[idx])

    def summarize_rows(self, day_data, limit=8):
        rows = []
        for name, info in day_data.get("processes", {}).items():
            total = safe_int(info.get("rx", 0)) + safe_int(info.get("tx", 0))
            rows.append((name, total, bool(info.get("exact")), info))
        rows.sort(key=lambda x: x[1], reverse=True)
        return rows[:limit]

    def summarize_pyplugins(self, day_data, limit=8, exclude_names=None):
        if exclude_names is None:
            exclude_names = []
        excluded = dict([(ensure_text(x), 1) for x in exclude_names])
        rows = []
        for name, info in day_data.get("pyplugins", {}).items():
            name = ensure_text(name)
            if name in excluded:
                continue
            total = safe_int(info.get("rx", 0)) + safe_int(info.get("tx", 0))
            rows.append((name, total, bool(info.get("exact", True)), info))
        rows.sort(key=lambda x: x[1], reverse=True)
        return rows[:limit]

    def get_live_snapshot(self):
        mode, service_text, proc_rows = self._detect_mode()
        iface = self.current_iface or self._read_default_iface()
        now_total = self._read_iface_totals(iface)
        speed_rx = 0
        speed_tx = 0
        if now_total and self.last_iface_total:
            speed_rx = max(0, now_total["rx"] - self.last_iface_total["rx"])
            speed_tx = max(0, now_total["tx"] - self.last_iface_total["tx"])
        return {
            "iface": iface,
            "mode": mode,
            "service": service_text,
            "speed_rx": speed_rx,
            "speed_tx": speed_tx,
            "proc_rows": proc_rows
        }
