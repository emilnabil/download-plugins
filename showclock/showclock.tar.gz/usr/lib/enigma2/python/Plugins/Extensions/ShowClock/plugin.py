#!/usr/bin/env python
# -*- coding: UTF-8 -*-


#  Show Clock E2
#
#  $Id$
#
#  Coded by JuSt611 © 2011
#  Derived from Permanent Clock plugin written by AliAbdul
#  and placed in the public domain. He has my thanks.
#  Support: http://www.i-have-a-dreambox.com/wbb2/thread.php?threadid=???
#
#  Provided with no warranties of any sort.
#
#  This plugin is licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  20250515 python3 recode by lululla

from enigma import ePoint, eTimer, getDesktop
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from keymapparser import readKeymap
from Components.config import config, getConfigListEntry, ConfigSubsection, ConfigSelection, ConfigText, ConfigNumber
from Screens.Screen import Screen
from Components.ConfigList import ConfigListScreen
from Screens.PiPSetup import clip
from Screens.Setup import SetupSummary
from Plugins.Plugin import PluginDescriptor
from GlobalActions import globalActionMap
from os.path import join, dirname, exists


from . import _

# costant
VERSION = "0.9"
plugin_printname = f"[ShowClock Ver. {VERSION}]"
DEBUG = False
desktop = getDesktop(0)
width, height = desktop.size().width(), desktop.size().height()


COLOR_SCHEMES = {
	"analog": _("Analog Style"),
	"cyan": _("Bright Cyan"),
	"dark": _("Dark Mode"),
	"elegant": _("Elegant White"),
	"gradient": _("Gradient Blue"),
	"green": _("Neon Green"),
	"minimal": _("Minimal White"),
	"retro": _("Stile Retro Amber"),
	"terminal": _("Terminal Green"),
	"yellow": _("Fluorescent Yellow")
}

config.plugins.ShowClock = ConfigSubsection()
config.plugins.ShowClock.name = ConfigText(default=_('Show Clock'), fixed_size=False)
config.plugins.ShowClock.menu = ConfigSelection(default='plugin', choices=[('plugin', _('Plugin menu')), ('extensions', _('Extensions menu'))])
config.plugins.ShowClock.showTimeout = ConfigNumber(default=10)
config.plugins.ShowClock.color_scheme = ConfigSelection(default="yellow", choices=list(COLOR_SCHEMES.items()))
config.plugins.ShowClock.position_x = ConfigNumber(default=int(width * 0.7))
config.plugins.ShowClock.position_y = ConfigNumber(default=45)


def clockSkin():
	scheme = config.plugins.ShowClock.color_scheme.value
	schemes = {
		"yellow": """
		<screen name="ShowClock" size="290,110" zPosition="10" backgroundColor="#FF00FF" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="7,0" size="200,80" font="Regular;72" halign="center" valign="center" backgroundColor="#FF00FF" foregroundColor="yellow" transparent="1">
				<convert type="ClockToText">Default</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="205,20" size="80,50" font="Regular;48" halign="center" valign="center" foregroundColor="white" transparent="1">
				<convert type="ClockToText">Format::%S</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="0,75" size="290,30" font="Regular;25" halign="center" valign="center" foregroundColor="white" transparent="1">
				<convert type="ClockToText">Format:%A, %d.%m.%Y</convert>
			</widget>
		</screen>""",

		"green": """
		<screen name="ShowClock" size="290,110" zPosition="10" backgroundColor="#50202020" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="5,0" size="200,80" font="Regular;72" halign="center" valign="center" foregroundColor="#00FF00" transparent="1">
				<convert type="ClockToText">Default</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="205,20" size="80,50" font="Regular;48" halign="center" valign="center" foregroundColor="white" transparent="1">
				<convert type="ClockToText">Format::%S</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="0,75" size="290,30" font="Regular;25" halign="center" valign="center" foregroundColor="#FFFF00" transparent="1">
				<convert type="ClockToText">Format:%A, %d %B %Y %H:%M</convert>
			</widget>
		</screen>""",

		"cyan": """
		<screen name="ShowClock" size="290,110" zPosition="10" backgroundColor="#50202020" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="5,0" size="200,80" font="Regular;72" halign="center" valign="center" foregroundColor="#00ccff" transparent="1">
				<convert type="ClockToText">Default</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="205,20" size="80,50" font="Regular;48" halign="center" valign="center" foregroundColor="#00ccff" transparent="1">
				<convert type="ClockToText">Format::%S</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="0,75" size="290,30" font="Regular;25" halign="center" valign="center" foregroundColor="#00ccff" transparent="1">
				<convert type="ClockToText">Format:%A, %d %B %Y %H:%M</convert>
			</widget>
		</screen>""",

		"minimal": """
		<screen name="ShowClock" size="190,80" zPosition="10" backgroundColor="#FF000000" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="1,1" size="200,80" font="Regular;72" valign="center" halign="center" foregroundColor="#00FFFF" transparent="1">
				<convert type="ClockToText">Default</convert>
			</widget>
		</screen>""",

		"retro": """
		<screen name="ShowClock" size="250,90" zPosition="10" backgroundColor="#40000000" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="10,10" size="230,70"
				font="Regular;58" foregroundColor="#FF9900" valign="center" halign="center">
				<convert type="ClockToText">Format:%H:%M:%S</convert>
			</widget>
		</screen>""",
		"elegant": """
		<screen name="ShowClock" size="320,150" zPosition="10" backgroundColor="#30101010" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="0,10" size="330,100" font="Regular;82"
				halign="center" valign="center" foregroundColor="#FFFFFF" transparent="1">
				<convert type="ClockToText">WithSeconds</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="0,110" size="330,30" font="Regular;28"
				halign="center" valign="center" foregroundColor="#AAAAAA" transparent="1">
				<convert type="ClockToText">Format:%A, %d %B %Y</convert>
			</widget>
		</screen>""",

		"dark": """
		<screen name="ShowClock" size="280,120" zPosition="10" backgroundColor="#FF000000" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="10,10" size="260,80" font="Regular;72"
				halign="center" valign="center" foregroundColor="#00FF00" transparent="1">
				<convert type="ClockToText">Format:%H:%M:%S</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="10,90" size="260,20" font="Regular;22"
				halign="center" valign="center" foregroundColor="#00FF00" transparent="1">
				<convert type="ClockToText">ShortDate</convert>
			</widget>
		</screen>""",

		"gradient": """
		<screen name="ShowClock" size="300,180" zPosition="10" backgroundColor="#40003560" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="0,30" size="300,100" font="Regular;92"
				halign="center" valign="center" foregroundColor="#00FFFF" transparent="1">
				<convert type="ClockToText">WithSeconds</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="0,140" size="300,30" font="Regular;30"
				halign="center" valign="center" foregroundColor="#80FFFF" transparent="1">
				<convert type="ClockToText">FullDate</convert>
			</widget>
		</screen>""",

		"analog": """
		<screen name="ShowClock" size="250,250" zPosition="10" backgroundColor="#50000000" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="25,25" size="200,200" font="Regular;180"
				halign="center" valign="center" foregroundColor="#FF9900" transparent="1">
				<convert type="ClockToText">Format:%H:%M</convert>
			</widget>
			<widget source="global.CurrentTime" render="Label" position="80,200" size="100,30" font="Regular;25"
				halign="center" valign="center" foregroundColor="#FF9900" transparent="1">
				<convert type="ClockToText">Format:%S</convert>
			</widget>
		</screen>""",

		"terminal": """
		<screen name="ShowClock" size="300,100" zPosition="10" backgroundColor="#FF002000" flags="wfNoBorder">
			<widget source="global.CurrentTime" render="Label" position="10,10" size="280,80" font="Regular;68"
				halign="center" valign="center" foregroundColor="#00FF00" transparent="1">
				<convert type="ClockToText">Format:%H:%M:%S</convert>
			</widget>
		</screen>"""
	}
	return schemes.get(scheme, schemes["yellow"])


class ShowClockSetup(Screen, ConfigListScreen):
	skin = """
		<screen name="ShowClockSetup" position="center,center" size="1000,500" title="Show Clock Setup" flags="wfNoBorder">
			<ePixmap pixmap="skin_default/buttons/red" position="5,5" size="140,40" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green" position="155,5" size="140,40" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow" position="310,5" size="140,40" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue" position="460,5" size="140,40" alphatest="on" />
			<widget source="key_red" render="Label" position="5,5" size="140,40" font="Regular;24" halign="center" valign="center" />
			<widget source="key_green" render="Label" position="155,5" size="140,40" font="Regular;24" halign="center" valign="center" />
			<widget source="key_yellow" render="Label" position="310,5" size="140,40" font="Regular;24" halign="center" valign="center" />
			<widget source="key_blue" render="Label" position="460,5" size="140,40" font="Regular;24" halign="center" valign="center" />
			<widget name="config" position="23,89" size="951,244" itemHeight="40" font="Regular; 30" scrollbarMode="showOnDemand" />
			<widget source="help" render="Label" position="25,350" size="950,140" font="Regular;24" halign="center" valign="center" />
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self.setup_title = _("Show Clock Setup")
		self["help"] = StaticText(_("Press OK to configure options"))
		# self.onChangedEntry = []
		self.list = [
			getConfigListEntry(_("Show timeout (seconds)"), config.plugins.ShowClock.showTimeout,
							   _('Specify how long (seconds) the clock shall be shown before it disappears. Set to "0" to show clock until hidden manually.')),
			getConfigListEntry(_("Color scheme"), config.plugins.ShowClock.color_scheme,
							   _('Display Color Selection')),
			getConfigListEntry(_("Menu position"), config.plugins.ShowClock.menu,
							   _('Specify whether plugin shall show up in plugin menu or extensions menu (needs GUI restart)')),
			getConfigListEntry(_("Plugin name"), config.plugins.ShowClock.name,
							   _('Specify plugin name to be used in menu (needs GUI restart).')),
		]
		# ConfigListScreen.__init__(self, self.list)
		ConfigListScreen.__init__(self, self.list, session=session, on_change=self.changed)
		self["config"].onSelectionChanged.append(self.configHelp)
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Save"))
		self["key_yellow"] = StaticText(_("Help"))
		self["key_blue"] = StaticText(_("Move"))
		self["setupActions"] = ActionMap(
			[
				"SetupActions",
				"ColorActions"
			],
			{
				"red": self.keyCancel,
				"green": self.keySave,
				"yellow": self.keyHelp,
				"blue": self.keyMove,
				"cancel": self.keyCancel,
				"ok": self.keyOK,
			},
			-1
		)
		self.changed()
		self.onLayoutFinish.append(self.setCustomTitle)

	def setCustomTitle(self):
		self.setTitle(' '.join((_("Show Clock Setup"), _("Ver."), VERSION)))

	def configHelp(self):
		current = self["config"].getCurrent()
		if current and len(current) > 2:
			self["help"].text = current[2]
		else:
			self["help"].text = _("No help available for this option")

	def changed(self):
		for x in self.onChangedEntry:
			try:
				x()
			except Exception:
				pass

	def getCurrentEntry(self):
		return self["config"].getCurrent()[0]

	def getCurrentValue(self):
		return str(self["config"].getCurrent()[1].getText())

	def keyCancel(self):
		self.hideKeypad()
		ConfigListScreen.keyCancel(self)

	def keySave(self):
		for x in self["config"].list:
			x[1].save()
		self.close()

	def hideKeypad(self):
		try:
			self["config"].getCurrent()[1].help_window.instance.hide()
		except AttributeError:
			pass

	def createSummary(self):
		return SetupSummary

	def keyHelp(self):
		self.mbox = self.session.open(MessageBox, _('Modify the settings to match your preferences. To change the clock position, select "Move clock" and relocate using the direction keys. Press OK to store current position and return to the setup menu or EXIT to cancel the moving.\n\nPush key "Exit long" to show the clock while watching TV. Clock will disappear after the specified timeout or by pushing key "Exit long" again.\n\nIf GP3 is installed, weekday shows up in selected language, otherwise always in english.'), MessageBox.TYPE_INFO, timeout=5)

	def keyMove(self):
		self.session.open(ShowClockPositioner)


class ShowClockPositioner(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skin = clockSkin()
		self["actions"] = ActionMap(
			[
				"PiPSetupActions"
			],
			{
				"left": self.left,
				"right": self.right,
				"up": self.up,
				"down": self.down,
				"ok": self.ok,
				"cancel": self.cancel
			},
			-1
		)
		self.onShow.append(self.setPosition)

	def setPosition(self):
		self.pos = (config.plugins.ShowClock.position_x.value, config.plugins.ShowClock.position_y.value)
		self.limit = (width - self.instance.size().width(), height - self.instance.size().height())
		self.instance.move(ePoint(*self.pos))

	def moveRelative(self, x=0, y=0):
		self.pos = (clip(self.pos[0] + x, 0, self.limit[0]), clip(self.pos[1] + y, 0, self.limit[1]))
		self.instance.move(ePoint(*self.pos))

	def left(self):
		self.moveRelative(x=-10)

	def right(self):
		self.moveRelative(x=+10)

	def up(self):
		self.moveRelative(y=-10)

	def down(self):
		self.moveRelative(y=+10)

	def ok(self):
		config.plugins.ShowClock.position_x.value = self.pos[0]
		config.plugins.ShowClock.position_y.value = self.pos[1]
		config.plugins.ShowClock.position_x.save()
		config.plugins.ShowClock.position_y.save()
		self.close()

	def cancel(self):
		self.close()


class ShowClock(Screen):
	def __init__(self, session):
		Screen.__init__(self, session)
		self.skin = clockSkin()
		self.onShow.append(self.setPosition)

	def setPosition(self):
		self.instance.move(ePoint(
			min(config.plugins.ShowClock.position_x.value, width - self.instance.size().width()),
			min(config.plugins.ShowClock.position_y.value, height - self.instance.size().height())
		))


class ShowClockMain:
	def __init__(self):
		self.dialog = None
		self.clockShown = False
		self.timer = eTimer()

		self.timer.callback.append(self.hideClock)

	def gotSession(self, session):
		self.session = session
		keymap_path = join(dirname(__file__), "keymap.xml")
		if exists(keymap_path):
			readKeymap(keymap_path)

		self.dialog = self.session.instantiateDialog(ShowClock)

		globalActionMap.actions['showClock'] = self.toggleClock

	def toggleClock(self):
		if self.clockShown:
			self.hideClock()
		else:
			self.showClock()
		self.clockShown = not self.clockShown

	def showClock(self):
		if self.dialog:
			self.dialog.show()
			timeout = config.plugins.ShowClock.showTimeout.value
			if timeout > 0:
				if hasattr(self.timer, 'startLongTimer'):
					self.timer.startLongTimer(timeout)
				else:
					self.timer.start(timeout * 1000, True)

	def hideClock(self):
		if self.timer.isActive():
			self.timer.stop()
		if self.dialog:
			self.dialog.hide()

	def shutdown(self):
		if self.timer.isActive():
			self.timer.stop()
		if self.dialog:
			self.dialog.hide()
			self.session.deleteDialog(self.dialog)
		globalActionMap.actions.pop('showClock', None)


showClock = ShowClockMain()


def sessionstart(reason, **kwargs):
	if reason == 0:
		showClock.gotSession(kwargs["session"])


def setup(session, **kwargs):
	session.open(ShowClockSetup)


def Plugins(**kwargs):
	menu_entry = [
		PluginDescriptor(
			name=config.plugins.ShowClock.name.value,
			description=config.plugins.ShowClock.menu.value,
			where=[PluginDescriptor.WHERE_PLUGINMENU if config.plugins.ShowClock.menu.value == 'plugin' else PluginDescriptor.WHERE_EXTENSIONSMENU],
			fnc=setup,
			icon="plugin.png")
	]
	menu_entry.append(PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart))
	return menu_entry
