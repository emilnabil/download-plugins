from __future__ import print_function
from __future__ import absolute_import
import os
import sys
import socket
from enigma import *
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.Sources.List import List
from Components.ActionMap import ActionMap
from Components.Console import Console as iConsole
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap
from Plugins.Plugin import PluginDescriptor

try:
    from urllib2 import urlopen
    from urllib2 import Request
except ImportError:
    from urllib.request import urlopen
    from urllib.request import Request

try:
    import urllib2 as urllib_request
except ImportError:
    import urllib.request as urllib_request

try:
    from .menus.panelmain import panelmain
    from .menus.pluginmain import pluginmain
    from .menus.systemplugins import systemplugins
    from .menus.mediamain import mediamain
    from .menus.tools import tools
    from .menus.emu import emu
    from .menus.channels import channels
    from .menus.channels_siefp_e2 import channels_siefp_e2
    from .menus.channels_morph883_e2 import channels_morph883_e2
    from .menus.channels_vhannibal import channels_vhannibal
    from .menus.multiboot_plugins import multiboot_plugins
    from .menus.bootlogos import bootlogos
    from .menus.backup import backup
    from .menus.restore import restore
    from .menus.skins import skins
    from .menus.feeds import feeds
    from .menus.spinners import spinners
    from .menus.removed import removed
    from .__init__ import Version
except (ValueError, SystemError, ImportError):
    from menus.panelmain import panelmain
    from menus.pluginmain import pluginmain
    from menus.systemplugins import systemplugins
    from menus.mediamain import mediamain
    from menus.tools import tools
    from menus.emu import emu
    from menus.channels import channels
    from menus.channels_siefp_e2 import channels_siefp_e2
    from menus.channels_morph883_e2 import channels_morph883_e2
    from menus.channels_vhannibal import channels_vhannibal
    from menus.multiboot_plugins import multiboot_plugins
    from menus.bootlogos import bootlogos
    from menus.backup import backup
    from menus.restore import restore
    from menus.skins import skins
    from menus.feeds import feeds
    from menus.spinners import spinners
    from menus.removed import removed
    from __init__ import Version

def open_file(filename, mode='r'):
    if sys.version_info[0] >= 3:
        return open(filename, mode, encoding='utf-8', errors='ignore')
    else:
        return open(filename, mode)

class emilpanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """<screen name="emilpanel" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder" title="Emil Panel">
            <widget name="Panel" position="160,105" size="270,50" font="Regular;45" halign="center" valign="center" transparent="1"/>
            <widget name="Version" position="410,110" size="150,50" font="Regular;35" halign="center" valign="center" transparent="1"/>
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1240,1" zPosition="2" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos = (120, 10), size = (600, 45), font=0, flags = RT_HALIGN_LEFT, text = 0),
                        MultiContentEntryText(pos = (600, 19), size = (600, 35), font=1, flags = RT_HALIGN_LEFT, text = 2),
                        MultiContentEntryPixmapAlphaTest(pos = (25, 5), size = (50, 40), png = 3),
                    ],
                    "fonts": [gFont("Regular", 35),gFont("Regular", 25)],
                    "itemHeight": 66
                    }
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="1285,195" size="1,665" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            
            <widget name="key_red" position="200,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#990011" foregroundColor="white" transparent="0" />
            <widget name="key_green" position="520,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#1F771F" foregroundColor="white" transparent="0" />
            <widget name="key_blue" position="840,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#13389F" foregroundColor="white" transparent="0" />
            <widget name="key_info" position="1430,1000" size="300,40" font="Regular;35" halign="center" valign="center" backgroundColor="#8A2BE2" foregroundColor="white" transparent="0" />
            
            <widget name="EmilLabel" position="350,880" size="600,100" font="Regular;60" halign="center" valign="center" foregroundColor="#00BFFF" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,410" size="550,50" zPosition="-1" />
            <widget name="DeviceInfo" position="1305,410" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,470" size="550,80" zPosition="-1" />
            <widget name="RAMInfo" position="1305,470" size="550,80" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,560" size="550,100" zPosition="-1" />
            <widget name="StorageInfo" position="1305,560" size="550,100" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,670" size="550,50" zPosition="-1" />
            <widget name="CPUInfo" position="1305,670" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,730" size="550,50" zPosition="-1" />
            <widget name="ReceiverIP" position="1305,730" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,790" size="550,50" zPosition="-1" />
            <widget name="InternetStatus" position="1305,790" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,850" size="550,50" zPosition="-1" />
            <widget name="PythonVersion" position="1305,850" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
        </screen>"""
        self.setTitle("Emil Panel")
        self.iConsole = iConsole()
        self.indexpos = None
        
        self["key_red"] = Label("Close")
        self["key_green"] = Label("OK")
        self["key_blue"] = Label("Restart")
        self["key_info"] = Label("Info")
        
        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.keyOK,
            "blue": self.reboot,
            "info": self.showInfo
        })
        
        self.list = []
        self["menu"] = List(self.list)
        self.buildMenu()
        self["Version"] = Label("V" + Version)
        self["Panel"] = Label("Emil Panel")
        self["EmilLabel"] = Label("Welcome Emil Panel")
        self["DeviceInfo"] = Label(self.getDeviceInfo())
        self["RAMInfo"] = Label(self.getRAMInfo())
        self["StorageInfo"] = Label(self.getStorageInfo())
        self["CPUInfo"] = Label(self.getCPUInfo())
        self["ReceiverIP"] = Label(self.getReceiverIP())
        self["InternetStatus"] = Label(self.getInternetStatus())
        self["PythonVersion"] = Label(self.getPythonVersion())
        self.checkForUpdate()

    def showInfo(self):
        info_path = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/info.txt")
        if fileExists(info_path):
            try:
                with open_file(info_path, "r") as f:
                    content = f.read()
                self.session.open(MessageBox, content, MessageBox.TYPE_INFO)
            except Exception as e:
                self.session.open(MessageBox, "Error reading info file: " + str(e), MessageBox.TYPE_ERROR)
        else:
            self.session.open(MessageBox, "Info file not found", MessageBox.TYPE_ERROR)

    def buildMenu(self):
        self.list = []
        menu_items = [
            ("Panel", "panel", "", "panel"),
            ("Plugins", "plugins", "", "plugins"),
            ("System Plugins", "systemplugins", "", "systemplugins"),
            ("Media", "media", "", "media"),
            ("Tools", "tools", "", "tools"),
            ("Emu", "emu", "", "emu"),
            ("Channels-Other", "channels", "", "channels"),
            ("Channels-Siefp-E2", "channels_siefp_e2", "", "ciefp"),
            ("Channels_Morph883_E2", "channels_morph883_e2", "", "morpheus"),
            ("Channels_Vhannibal", "channels_vhannibal", "", "vhannibal"),
            ("Multiboot Plugins", "multiboot_plugins", "", "multiboot"),
            ("Bootlogos", "bootlogos", "", "bootlogos"),
            ("Backup", "backup", "", "backup"),
            ("Restore", "restore", "", "restore"),
            ("Skins", "skins", "", "skins"),
            ("Feeds", "feeds", "", "feeds"),
            ("Spinners", "spinners", "", "spinners"),
            ("Remove", "removed", "", "removed"),
        ]
        
        for name, action, description, icon_name in menu_items:
            icon_path = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/" + icon_name + ".png")
            icon = LoadPixmap(cached=True, path=icon_path) if fileExists(icon_path) else None
            self.list.append((name, action, description, icon))
        
        self["menu"].setList(self.list)

    def keyOK(self):
        self.indexpos = self["menu"].getIndex()
        item = self["menu"].getCurrent()[1]
        self.select_item(item)

    def select_item(self, item):
        item = item.lower()
        if item == "panel":
            self.session.open(panelmain)
        elif item == "plugins":
            self.session.open(pluginmain)
        elif item == "systemplugins":
            self.session.open(systemplugins)
        elif item == "media":
            self.session.open(mediamain)
        elif item == "tools":
            self.session.open(tools)
        elif item == "emu":
            self.session.open(emu)
        elif item == "channels":
            self.session.open(channels)
        elif item == "channels_siefp_e2":
            self.session.open(channels_siefp_e2)
        elif item == "channels_morph883_e2":
            self.session.open(channels_morph883_e2)
        elif item == "channels_vhannibal":
            self.session.open(channels_vhannibal)
        elif item == "multiboot_plugins":
            self.session.open(multiboot_plugins)
        elif item == "bootlogos":
            self.session.open(bootlogos)
        elif item == "backup":
            self.session.open(backup)
        elif item == "restore":
            self.session.open(restore)
        elif item == "skins":
            self.session.open(skins)
        elif item == "feeds":
            self.session.open(feeds)
        elif item == "spinners":
            self.session.open(spinners)
        elif item == "removed":
            self.session.open(removed)
        else:
            self.close()

    def exit(self):
        self.close()

    def reboot(self):
        self.iConsole.ePopen('if command -v dpkg > /dev/null 2>&1; then systemctl restart enigma2; else killall -9 enigma2; fi')
        self.close()

    def checkForUpdate(self):
        cmd = 'wget -q -O /tmp/emilpanel_version.txt "https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanel/version.txt"'
        self.iConsole.ePopen(cmd, self.versionDownloaded)

    def versionDownloaded(self, result, retval, extra_args):
        if retval == 0:
            try:
                with open_file("/tmp/emilpanel_version.txt", "r") as f:
                    online_version = f.read().strip()
                if online_version > Version:
                    self.session.openWithCallback(self.updateConfirmed, MessageBox, "New version " + online_version + " available. Update now?", MessageBox.TYPE_YESNO)
                os.remove("/tmp/emilpanel_version.txt")
            except Exception as e:
                print("Error checking version:", str(e))
        else:
            print("Failed to download version file")

    def updateConfirmed(self, answer):
        if answer:
            self.doUpdate()

    def doUpdate(self):
        cmd = (
            'wget -q -O /tmp/emilpanel.tar.gz "https://github.com/emilnabil/download-plugins/raw/main/EmilPanel/emilpanel.tar.gz" && '
            'rm -rf /usr/lib/enigma2/python/Plugins/Extensions/EmilPanel && '
            'tar -xzf /tmp/emilpanel.tar.gz -C / && '
            'rm -f /tmp/emilpanel.tar.gz && '
            '( systemctl restart enigma2 || killall -9 enigma2 )'
        )
        self.iConsole.ePopen(cmd, self.updateFinished)

    def updateFinished(self, result, retval, extra_args):
        if retval != 0:
            self.session.open(MessageBox, "Update failed. Check internet connection.", MessageBox.TYPE_ERROR)

    def getDeviceInfo(self):
        model = "Unknown"
        image = "Unknown"
        version = "Unknown"
        
        try:
            model_paths = ["/proc/stb/info/vumodel", "/proc/stb/info/model"]
            for path in model_paths:
                if os.path.exists(path):
                    with open_file(path) as f:
                        model = f.read().strip()
                    break
        except:
            pass
        
        try:
            if os.path.exists("/etc/image-version"):
                with open_file("/etc/image-version") as f:
                    for line in f:
                        if "creator" in line:
                            image = line.partition("=")[2].strip()
                        elif "version" in line:
                            version = line.partition("=")[2].strip()
        except:
            pass
        
        return model + ": " + image + " " + version

    def getRAMInfo(self):
        try:
            with open_file("/proc/meminfo") as f:
                mem = {}
                for line in f:
                    parts = line.split(':')
                    if len(parts) >= 2:
                        mem[parts[0]] = parts[1].strip()
            total = int(mem["MemTotal"].split()[0]) // 1024
            free = int(mem["MemAvailable"].split()[0]) // 1024
            used = total - free
            return "RAM: " + str(total) + "MB used: " + str(used) + "MB Free: " + str(free) + "MB"
        except:
            return "RAM: Not Available"

    def getStorageInfo(self):
        info = []
        mounts = {
            'HDD': '/media/hdd',
            'USB': '/media/usb',
            'MMC': '/media/mmc'
        }
        
        for name, path in mounts.items():
            if os.path.ismount(path):
                try:
                    stat = os.statvfs(path)
                    total = (stat.f_blocks * stat.f_frsize) / (1024**3)
                    free = (stat.f_bfree * stat.f_frsize) / (1024**3)
                    used = total - free
                    info.append(name + ": " + "{:.1f}".format(used) + "GB/" + "{:.1f}".format(total) + "GB")
                except:
                    info.append(name + ": Error")
            else:
                info.append(name + ": Not Available")
        
        return "\n".join(info)

    def getCPUInfo(self):
        try:
            with open_file("/proc/cpuinfo") as f:
                cores = 0
                for line in f:
                    if "processor" in line:
                        cores += 1
            
            with open_file("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq") as f:
                speed = int(f.read().strip()) // 1000
            
            return "CPU: ARMv7, " + str(speed) + " MHz (" + str(cores) + " cores)"
        except:
            return "CPU: Not Available"

    def getReceiverIP(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return "IP: " + ip
        except:
            return "IP: N/A"

    def getInternetStatus(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect(("8.8.8.8", 53))
            s.close()
            return "Internet: Connected"
        except:
            return "Internet: Not Connected"

    def getPythonVersion(self):
        return "Python: " + sys.version.split()[0]

def main(session, **kwargs):
    session.open(emilpanel)

def menuHook(menuid):
    if menuid == "mainmenu":
        return [(_("Emil Panel"), main, "emil_panel", None)]
    return []

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Emil Panel",
            description="Emil Addons Panel",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="Emil Panel",
            description="Emil Addons Panel",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        ),
        PluginDescriptor(
            name="Emil Panel",
            description="Emil Addons Panel",
            where=PluginDescriptor.WHERE_MENU,
            fnc=menuHook
        )
    ]
