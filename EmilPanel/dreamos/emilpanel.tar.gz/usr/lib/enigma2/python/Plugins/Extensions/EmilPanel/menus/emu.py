from __future__ import print_function
from __future__ import absolute_import
import sys
import os
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.MessageBox import MessageBox
from .Console import Console
from enigma import eLabel, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

def _(text):
    return text

def open_file(filename, mode='r'):
    if sys.version_info[0] >= 3:
        return open(filename, mode, encoding='utf-8', errors='ignore')
    else:
        return open(filename, mode)

class emu(Screen):
    skin = """
        <screen name="emu" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder">
            <ePixmap position="1305,400" size="550,500" pixmap="%s" zPosition="0" />
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryPixmapAlphaTest(pos=(25,5), size=(40,40), png=3),
                        MultiContentEntryPixmapAlphaTest(pos=(70,5), size=(50,40), png=2),
                        MultiContentEntryText(pos=(140,10), size=(600,45), font=0, flags=RT_HALIGN_LEFT, text=0)
                    ],
                    "fonts": [gFont("Regular", 35), gFont("Regular", 25)],
                    "itemHeight": 66}
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1235,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1235,1" zPosition="2" />
            
            <eLabel position="200,900" size="250,50" backgroundColor="#8B0000" zPosition="4" />
            <widget name="key_red" position="200,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            <eLabel position="500,900" size="250,50" backgroundColor="#006400" zPosition="4" />
            <widget name="key_green" position="500,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel position="800,900" size="250,50" backgroundColor="#C9A000" zPosition="4" />
            <eLabel backgroundColor="#00ffffff" position="1285,195" size="1,665" zPosition="2" /> 
            <widget name="key_yellow" position="800,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
        </screen>""" % resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/background.png")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle("Panel Manager")
        self.selected_plugins = []
        
        self.checked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/checked.png"))
        self.unchecked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/unchecked.png"))
        self.plugin_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/emu.png"))

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.installSelected,
            "yellow": self.toggleSelection,
        })

        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Install"))
        self["key_yellow"] = Label(_("Select") + " (0)")

        self.list = []
        self["menu"] = List(self.list)
        self.load_plugins_list()
        self.mList()

    def load_plugins_list(self):
        self.all_plugins = [
            "Cccam",
            "gosatplus-ncam",
            "gosatplus-oscam",
            "gosatplus_v3_arm",
            "gosatplus_v3_mips",
            "gosatplus_v3_Fix",
            "Hold-flag-ncam",
            "Hold-flag-Oscam",
            "Ncam",
            "Oscam",
            "Oscam-by-Levi45",
            "Oscam-11.726-by-lenuxsat",
            "oscamicam",
            "powercam_v2-icam-arm",
            "powercam-Ncam",
            "powercam-Oscam",
            "Restore-flag-ncam",
            "Restore-flag-oscam",
            "Revcam-Ncam",
            "Revcam-Oscam",
            "Revcam",
            "Supcam-Ncam",
            "Supcam-Oscam",
            "Ultracam-Ncam",
            "Ultracam-Oscam",
            "Ultracam"
        ]

    def mList(self):
        self.list = []
        for plugin_name in self.all_plugins:
            if plugin_name in self.selected_plugins:
                icon = self.checked_icon
            else:
                icon = self.unchecked_icon
            self.list.append((plugin_name, plugin_name, self.plugin_icon, icon))
        
        self["menu"].setList(self.list)
        self.update_selection_count()

    def toggleSelection(self):
        current = self["menu"].getCurrent()
        if current:
            index = self["menu"].getIndex()
            plugin_name = current[0]
            
            if plugin_name in self.selected_plugins:
                self.selected_plugins.remove(plugin_name)
                new_icon = self.unchecked_icon
            else:
                self.selected_plugins.append(plugin_name)
                new_icon = self.checked_icon
            
            self.list[index] = (
                plugin_name,
                plugin_name,
                current[2],
                new_icon
            )
            self["menu"].updateList(self.list)
            self.update_selection_count()

    def update_selection_count(self):
        self["key_yellow"].setText(_("Select") + " (" + str(len(self.selected_plugins)) + ")")

    def installSelected(self):
        if not self.selected_plugins:
            self.showError(_("No plugins selected"))
            return

        self.install_scripts = []
        for plugin in self.selected_plugins:
            script = self.get_script(plugin)
            if not script:
                self.showError(_("Script not found for %s") % plugin)
                return
            self.install_scripts.append(script)

        self.session.openWithCallback(
            self.confirmInstallSelected,
            MessageBox,
            _("Install %d selected plugins?") % len(self.selected_plugins),
            MessageBox.TYPE_YESNO
        )

    def confirmInstallSelected(self, answer):
        if not answer or not hasattr(self, 'install_scripts'):
            return

        try:
            with open_file("/tmp/install_script.sh", "w") as f:
                f.write("#!/bin/sh\n")
                f.write("\n".join(self.install_scripts) + "\n")

            self.session.open(
                Console,
                title=_("Installing selected plugins"),
                cmdlist=[
                    "chmod +x /tmp/install_script.sh",
                    "/bin/sh /tmp/install_script.sh"
                ],
                closeOnSuccess=True
            )

            self.selected_plugins = []
            if hasattr(self, 'install_scripts'):
                del self.install_scripts
            self.mList()
        except Exception as e:
            self.showError(str(e))

    def keyOK(self):
        current = self["menu"].getCurrent()
        if current:
            plugin_name = current[0]
            self.installPlugin(plugin_name)
        else:
            self.showError(_("No plugin selected"))

    def installPlugin(self, plugin_name):
        script = self.get_script(plugin_name)
        if script:
            self.session.openWithCallback(
                lambda answer: self.executeInstall(answer, plugin_name),
                MessageBox,
                _("Install %s?") % plugin_name,
                MessageBox.TYPE_YESNO
            )
        else:
            self.showError(_("Script not found"))

    def executeInstall(self, answer, plugin_name):
        if answer:
            try:
                with open_file("/tmp/install_script.sh", "w") as f:
                    f.write("#!/bin/sh\n" + self.get_script(plugin_name) + "\n")

                self.session.open(
                    Console,
                    title=_("Installing %s") % plugin_name,
                    cmdlist=[
                        "chmod +x /tmp/install_script.sh",
                        "/bin/sh /tmp/install_script.sh"
                    ],
                    closeOnSuccess=True
                )
            except Exception as e:
                self.showError(str(e))

    def get_script(self, plugin_name):
        scripts = {
            "Cccam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-cccam.sh -O - | /bin/sh",
            "gosatplus-ncam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-gosatplus-ncam.sh -O - | /bin/sh",
            "gosatplus-oscam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-gosatplus-oscam.sh -O - | /bin/sh",
            "gosatplus_v3_arm": "wget -q --no-check-certificate http://e2.gosatplus.com/Plugin/V3/arm-openpli-installer_py3_v3.sh -O - | /bin/sh",
            "gosatplus_v3_mips": "wget -q --no-check-certificate http://e2.gosatplus.com/Plugin/V3/mips-openpli-installer_py3_v3.sh -O - | /bin/sh",
            "gosatplus_v3_Fix": "wget -q --no-check-certificate http://e2.gosatplus.com/Plugin/V3/GosatPlusPluginFixPy.sh -O - | /bin/sh",
            "Hold-flag-ncam": "opkg flag hold enigma2-plugin-softcams-ncam",
            "Hold-flag-Oscam": "opkg flag hold enigma2-plugin-softcams-oscam",
            "Ncam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-ncam.sh -O - | /bin/sh",
            "Oscam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-oscam.sh -O - | /bin/sh",
            "Oscam-by-Levi45": "wget -q --no-check-certificate https://raw.githubusercontent.com/levi-45/Levi45Emulator/main/installer.sh -O - | /bin/sh",
            "Oscam-11.726-by-lenuxsat": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/oscam-by-lenuxsat/installer.sh -O - | /bin/sh",
            "oscamicam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-oscamicam.sh -O - | /bin/sh",
            "powercam_v2-icam-arm": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/powercam/installer.sh -O - | /bin/sh",
            "powercam-Ncam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-powercam-ncam.sh -O - | /bin/sh",
            "powercam-Oscam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-powercam-oscam.sh -O - | /bin/sh",
            "Restore-flag-ncam": "opkg flag user enigma2-plugin-softcams-ncam",
            "Restore-flag-oscam": "opkg flag user enigma2-plugin-softcams-oscam",
            "Revcam-Ncam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-revcam-ncam.sh -O - | /bin/sh",
            "Revcam-Oscam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-revcam-oscam.sh -O - | /bin/sh",
            "Revcam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-revcam.sh -O - | /bin/sh",
            "Supcam-Ncam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-supcam-ncam.sh -O - | /bin/sh",
            "Supcam-Oscam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-supcam-oscam.sh -O - | /bin/sh",
            "Ultracam-Ncam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-ultracam-ncam.sh -O - | /bin/sh",
            "Ultracam-Oscam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-ultracam-oscam.sh -O - | /bin/sh",
            "Ultracam": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/emu/installer-ultracam.sh -O - | /bin/sh"
        }
        return scripts.get(plugin_name)

    def showError(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def exit(self):
        self.close()
