from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.MessageBox import MessageBox
from .Console import Console
from enigma import eLabel, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import sys

if sys.version_info[0] < 3:
    from urllib2 import urlopen
else:
    from urllib.request import urlopen

class systemplugins(Screen):
    skin = """
        <screen name="systemplugins" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder">
            <ePixmap position="1305,400" size="550,500" pixmap="%s" zPosition="0" />
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryPixmapAlphaTest(pos=(25,5), size=(40,40), png=3),
                        MultiContentEntryPixmapAlphaTest(pos=(70,5), size=(50,40), png=2),
                        MultiContentEntryText(pos=(140,10), size=(600,45), font=0, flags=RT_HALIGN_LEFT, text=0)
                    ],
                    "fonts": [gFont("Regular", 35), gFont("Regular", 25)],
                    "itemHeight": 66}
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1235,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1235,1" zPosition="2" />
            
            <eLabel position="200,900" size="250,50" backgroundColor="#8B0000" zPosition="4" />
            <widget name="key_red" position="200,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            <eLabel position="500,900" size="250,50" backgroundColor="#006400" zPosition="4" />
            <widget name="key_green" position="500,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel position="800,900" size="250,50" backgroundColor="#C9A000" zPosition="4" />
           <eLabel backgroundColor="#00ffffff" position="1285,195" size="1,665" zPosition="2" /> 
            <widget name="key_yellow" position="800,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
        </screen>""" % resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/background.png")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle("Panel Manager")
        self.selected_plugins = []
        
        self.checked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/checked.png"))
        self.unchecked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/unchecked.png"))
        self.plugin_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/systemplugins.png"))

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.installSelected,
            "yellow": self.toggleSelection,
        })

        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Install"))
        self["key_yellow"] = Label(_("Select") + " (0)")

        self.list = []
        self["menu"] = List(self.list)
        self.load_plugins_list()
        self.mList()

    def load_plugins_list(self):
        self.all_plugins = [
            _("AutomaticCleanup"),
            _("automaticvolumeadjustment_armhf"),
            _("autoresolution_armhf"),
            _("CrashlogAutoSubmit"),
            _("Disk_and_CPU_Temperature"),
            _("DynamicDisplay"),
            _("extnumberzap"),
            _("GeminiAddonManager"),
            _("GeminiBluePanel"),
            _("GeminiHwManager"),
            _("GeminiImageBackup"),
            _("MenuSort"),
            _("PluginHider"),
            _("RemoteControlSelection"),
            _("Satfinder"),
            _("SetPasswd"),
            _("SkinSelector"),
            _("SoftwareManager"),
            _("StartUpService"),
            _("Styles")
        ]

    def mList(self):
        self.list = []
        for plugin_name in self.all_plugins:
            if plugin_name in self.selected_plugins:
                icon = self.checked_icon
            else:
                icon = self.unchecked_icon
            self.list.append((plugin_name, plugin_name, self.plugin_icon, icon))
        self["menu"].setList(self.list)
        self.update_selection_count()

    def toggleSelection(self):
        current = self["menu"].getCurrent()
        if current:
            index = self["menu"].getIndex()
            plugin_name = current[0]
            
            if plugin_name in self.selected_plugins:
                self.selected_plugins.remove(plugin_name)
                new_icon = self.unchecked_icon
            else:
                self.selected_plugins.append(plugin_name)
                new_icon = self.checked_icon
            
            self.list[index] = (
                plugin_name,
                plugin_name,
                current[2],
                new_icon
            )
            self["menu"].updateList(self.list)
            self.update_selection_count()

    def update_selection_count(self):
        self["key_yellow"].setText(_("Select") + " (%d)" % len(self.selected_plugins))

    def installSelected(self):
        if not self.selected_plugins:
            self.showError(_("No plugins selected"))
            return

        self.install_scripts = []
        for plugin in self.selected_plugins:
            script = self.get_script(plugin)
            if not script:
                self.showError(_("Script not found for %s") % plugin)
                return
            self.install_scripts.append(script)

        self.session.openWithCallback(
            self.confirmInstallSelected,
            MessageBox,
            _("Install %d selected plugins?") % len(self.selected_plugins),
            MessageBox.TYPE_YESNO
        )

    def confirmInstallSelected(self, answer):
        if not answer or not hasattr(self, 'install_scripts'):
            return

        try:
            with open("/tmp/install_script.sh", "w") as f:
                f.write("#!/bin/sh\n")
                for script in self.install_scripts:
                    f.write(script + "\n")

            self.session.open(
                Console,
                title=_("Installing selected plugins"),
                cmdlist=[
                    "chmod +x /tmp/install_script.sh",
                    "/bin/sh /tmp/install_script.sh"
                ],
                closeOnSuccess=True
            )

            self.selected_plugins = []
            if hasattr(self, 'install_scripts'):
                del self.install_scripts
            self.mList()
        except Exception as e:
            self.showError(str(e))

    def keyOK(self):
        current = self["menu"].getCurrent()
        if current:
            plugin_name = current[0]
            self.installPlugin(plugin_name)
        else:
            self.showError(_("No plugin selected"))

    def installPlugin(self, plugin_name):
        script = self.get_script(plugin_name)
        if script:
            self.session.openWithCallback(
                lambda answer: self.executeInstall(answer, plugin_name),
                MessageBox,
                _("Install %s?") % plugin_name,
                MessageBox.TYPE_YESNO
            )
        else:
            self.showError(_("Script not found"))

    def executeInstall(self, answer, plugin_name):
        if answer:
            try:
                with open("/tmp/install_script.sh", "w") as f:
                    f.write("#!/bin/sh\n%s\n" % self.get_script(plugin_name))

                self.session.open(
                    Console,
                    title=_("Installing %s") % plugin_name,
                    cmdlist=[
                        "chmod +x /tmp/install_script.sh",
                        "/bin/sh /tmp/install_script.sh"
                    ],
                    closeOnSuccess=True
                )
            except Exception as e:
                self.showError(str(e))

    def get_script(self, plugin_name):
        scripts = {
            "AutomaticCleanup": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/AutomaticCleanup.sh -O - | /bin/sh",
            "automaticvolumeadjustment_armhf": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/automaticvolumeadjustment_armhf.sh -O - | /bin/sh",
            "autoresolution_armhf": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/autoresolution_armhf.sh -O - | /bin/sh",
            "CrashlogAutoSubmit": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/CrashlogAutoSubmit.sh -O - | /bin/sh",
            "Disk_and_CPU_Temperature": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/dreambox/refs/heads/main/disk_and_cpu_temperature.sh -O - | /bin/sh",
            "DynamicDisplay": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/dynamicdisplay.sh -O - | /bin/sh",
            "extnumberzap": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/extnumberzap/extnumberzap.sh -O - | /bin/sh",
            "GeminiAddonManager": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/geminiaddonmanager.sh -O - | /bin/sh",
            "GeminiBluePanel": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/geminibluepanel.sh -O - | /bin/sh",
            "GeminiHwManager": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/geminihwmanager.sh -O - | /bin/sh",
            "GeminiImageBackup": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/geminiimagebackup.sh -O - | /bin/sh",
            "MenuSort": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/MenuSort.sh -O - | /bin/sh",
            "PluginHider": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/PluginHider.sh -O - | /bin/sh",
            "RemoteControlSelection": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/RemoteControlSelection.sh -O - | /bin/sh",
            "Satfinder": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/Satfinder.sh -O - | /bin/sh",
            "SetPasswd": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/SetPasswd.sh -O - | /bin/sh",
            "SkinSelector": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/SkinSelector.sh -O - | /bin/sh",
            "SoftwareManager": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/SoftwareManager.sh -O - | /bin/sh",
            "StartUpService": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/StartUpService.sh -O - | /bin/sh",
            "Styles": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/styles.sh -O - | /bin/sh"
        }
        return scripts.get(plugin_name)

    def showError(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def exit(self):
        self.close()

