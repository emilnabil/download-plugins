from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.MessageBox import MessageBox
from .Console import Console
from enigma import eLabel, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import sys

if sys.version_info[0] < 3:
    from urllib2 import urlopen
else:
    from urllib.request import urlopen

class pluginmain(Screen):
    skin = """
        <screen name="pluginmain" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder">
            <ePixmap position="1305,400" size="500,500" pixmap="%s" zPosition="0" />
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryPixmapAlphaTest(pos=(25,5), size=(40,40), png=3),
                        MultiContentEntryPixmapAlphaTest(pos=(70,5), size=(50,40), png=2),
                        MultiContentEntryText(pos=(140,10), size=(600,45), font=0, flags=RT_HALIGN_LEFT, text=0)
                    ],
                    "fonts": [gFont("Regular", 35), gFont("Regular", 25)],
                    "itemHeight": 66}
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1235,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1235,1" zPosition="2" />
            
            <eLabel position="200,900" size="250,50" backgroundColor="#8B0000" zPosition="4" />
            <widget name="key_red" position="200,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            <eLabel position="500,900" size="250,50" backgroundColor="#006400" zPosition="4" />
            <widget name="key_green" position="500,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel position="800,900" size="250,50" backgroundColor="#C9A000" zPosition="4" />
            <widget name="key_yellow" position="800,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
        </screen>""" % resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/background.png")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("Plugin Manager")
        self.selected_plugins = []
        
        self.checked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/checked.png"))
        self.unchecked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/unchecked.png"))
        self.plugin_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/plugins.png"))

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.installSelected,
            "yellow": self.toggleSelection,
        })

        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Install"))
        self["key_yellow"] = Label(_("Select") + " (0)")

        self.list = []
        self["menu"] = List(self.list)
        self.load_plugins_list()
        self.mList()

    def load_plugins_list(self):
        self.all_plugins = [
            "ArabicSavior",
            "Astronomy",
            "BissFeedAutoKey",
            "BootlogoSwap-Dreambox",
            "BootlogoSwap-Gemini",
            "BootlogoSwap-Merlin",
            "BootlogoSwap-TS",
            "Bootvideo",
            "CacheFlush",
            "CCcaminfo",
            "channelselectionplus",
            "chocholousek-picons",
            "CrashLogoViewer",
            "CrondManager",
            "DisplaySkin",
            "Epg Grabber",
            "EPGImport",
            "EPGImport-99",
            "EPGTranslator",
            "Estalker",
            "EventDataManager",
            "Feeds-Finder",
            "Filebrowser",
            "Filmxy",
            "Footonsat",
            "Freearhey",
            "FreeCCcamServer",
            "HasBahCa",
            "HbbTv",
            "HistoryZapSelector",
            "InfobarHide",
            "Internet-Speedtest",
            "IP_Checker",
            "iptvdream",
            "Iptv-Org-Playlists",
            "IptvPlayer",
            "Iptvupdater",
            "KeyAdder",
            "levi45-freeserver",
            "levi45-settings",
            "M3uConverter",
            "MerlinSkinThemes",
            "MmPicons",
            "MoviesManager",
            "MultiCamAdder",
            "Multi-Iptv-Adder",
            "ONEupdater",
            "Pauli",
            "PluginSort",
            "Plutotv",
            "QuickButton",
            "Quran-karem",
            "Quran-karem_v2.2",
            "RaedQuickSignal",
            "scriptexecuter",
            "ServiceScanUpdates",
            "SimpleZoomPanel",
            "skincomponents-extmultilistselection",
            "Spinner-Selector",
            "SubsSupport_1.5.8-r9",
            "TheWeather",
            "TMBD",
            "TvDream",
            "TvManager",
            "TvParsa",
            "TvRaiPreview",
            "TvSettings",
            "uninstaller",
            "userscripts",
            "vavoo_1.15",
            "WeatherPlugin",
            "Wifi-Manager",
            "Wireguard-Vpn",
            "WorldCam"
        ]

    def mList(self):
        self.list = []
        for plugin_name in self.all_plugins:
            if plugin_name in self.selected_plugins:
                icon = self.checked_icon
            else:
                icon = self.unchecked_icon
            self.list.append((plugin_name, plugin_name, self.plugin_icon, icon))
        self["menu"].setList(self.list)
        self.update_selection_count()

    def toggleSelection(self):
        current = self["menu"].getCurrent()
        if current:
            index = self["menu"].getIndex()
            plugin_name = current[0]
            
            if plugin_name in self.selected_plugins:
                self.selected_plugins.remove(plugin_name)
                new_icon = self.unchecked_icon
            else:
                self.selected_plugins.append(plugin_name)
                new_icon = self.checked_icon
            
            self.list[index] = (plugin_name, plugin_name, current[2], new_icon)
            self["menu"].updateList(self.list)
            self.update_selection_count()

    def update_selection_count(self):
        self["key_yellow"].setText(_("Select") + " (%d)" % len(self.selected_plugins))

    def installSelected(self):
        if not self.selected_plugins:
            self.showError(_("No plugins selected"))
            return

        self.install_scripts = []
        for plugin in self.selected_plugins:
            script = self.get_script(plugin)
            if not script:
                self.showError(_("Script not found for %s") % plugin)
                return
            self.install_scripts.append(script)

        self.session.openWithCallback(
            self.confirmInstallSelected,
            MessageBox,
            _("Install %d selected plugins?") % len(self.selected_plugins),
            MessageBox.TYPE_YESNO
        )

    def confirmInstallSelected(self, answer):
        if not answer or not hasattr(self, 'install_scripts'):
            return

        try:
            with open("/tmp/install_script.sh", "w") as f:
                f.write("#!/bin/sh\n")
                for script in self.install_scripts:
                    f.write(script + "\n")

            self.session.open(
                Console,
                title=_("Installing selected plugins"),
                cmdlist=[
                    "chmod +x /tmp/install_script.sh",
                    "/bin/sh /tmp/install_script.sh"
                ],
                closeOnSuccess=True
            )

            self.selected_plugins = []
            if hasattr(self, 'install_scripts'):
                del self.install_scripts
            self.mList()
        except Exception as e:
            self.showError(str(e))

    def keyOK(self):
        current = self["menu"].getCurrent()
        if current:
            plugin_name = current[0]
            self.installPlugin(plugin_name)
        else:
            self.showError(_("No plugin selected"))

    def installPlugin(self, plugin_name):
        script = self.get_script(plugin_name)
        if script:
            self.session.openWithCallback(
                lambda answer: self.executeInstall(answer, plugin_name),
                MessageBox,
                _("Install %s?") % plugin_name,
                MessageBox.TYPE_YESNO
            )
        else:
            self.showError(_("Script not found"))

    def executeInstall(self, answer, plugin_name):
        if answer:
            try:
                with open("/tmp/install_script.sh", "w") as f:
                    f.write("#!/bin/sh\n%s\n" % self.get_script(plugin_name))

                self.session.open(
                    Console,
                    title=_("Installing %s") % plugin_name,
                    cmdlist=[
                        "chmod +x /tmp/install_script.sh",
                        "/bin/sh /tmp/install_script.sh"
                    ],
                    closeOnSuccess=True
                )
            except Exception as e:
                self.showError(str(e))

    def get_script(self, plugin_name):
        scripts = {
            "ArabicSavior": "wget --no-check-certificate -O - http://dreambox4u.com/emilnabil237/plugins/ArabicSavior/installer.sh -O - | /bin/sh",
            "Astronomy": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/astronomy/installer.sh -O - | /bin/sh",
            "BissFeedAutoKey": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/bissfeed-autokey/main/installer.sh -O - | /bin/sh",
            "BootlogoSwap-Dreambox": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/bootlogoswaper-dreambox.sh -O - | /bin/sh",
            "BootlogoSwap-Gemini": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/bootlogoswaper-gemini.sh -O - | /bin/sh",
            "BootlogoSwap-Merlin": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/BootlogoSwap-Merlin.sh -O - | /bin/sh",
            "BootlogoSwap-TS": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/bootlogoswaper-ts.sh -O - | /bin/sh",
            "Bootvideo": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/Bootvideo.sh -O - | /bin/sh",
            "CacheFlush": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/cacheflush/cacheflush.sh -O - | /bin/sh",
            "CCcaminfo": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/cccaminfo.sh -O - | /bin/sh",
            "channelselectionplus": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/channelselectionplus.sh -O - | /bin/sh",
            "chocholousek-picons": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/chocholousek-picons.sh -O - | /bin/sh",
            "CrashLogoViewer": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/crashlogviewer/install-CrashLogViewer.sh -O - | /bin/sh",
            "CrondManager": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/crondmanager/installer.sh -O - | /bin/sh",
            "DisplaySkin": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/displayskin.sh -O - | /bin/sh",
            "Epg Grabber": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/Epg-Grabber/installer.sh -O - | /bin/sh",
            "EPGImport": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/epgimport.sh -O - | /bin/sh",
            "EPGImport-99": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/EPGImport-99/main/installer.sh -O - | /bin/sh",
            "EPGTranslator": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/epgtranslatorlite.sh -O - | /bin/sh",
            "Estalker": "wget --no-check-certificate -O - https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EStalker/EStalker.sh -O - | /bin/sh",
            "EventDataManager": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/eventdatamanager.sh -O - | /bin/sh",
            "Feeds-Finder": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/feeds-finder/installer.sh -O - | /bin/sh",
            "Filebrowser": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/filebrowser.sh -O - | /bin/sh",
            "Filmxy": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/filmxy/filmxy.sh -O - | /bin/sh",
            "Footonsat": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/FootOnsat/installer.sh -O - | /bin/sh",
            "Freearhey": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/freearhey/freearhey.sh -O - | /bin/sh",
            "FreeCCcamServer": "wget --no-check-certificate -O - https://ia803104.us.archive.org/0/items/freecccamserver/installer.sh -O - | /bin/sh",
            "HasBahCa": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/HasBahCa/installer.sh -O - | /bin/sh",
            "HbbTv": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/hbbtv.sh -O - | /bin/sh",
            "HistoryZapSelector": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/historyzap/installer.sh -O - | /bin/sh",
            "InfobarHide": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/infobarhide.sh -O - | /bin/sh",
            "Internet-Speedtest": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/internet-speedtest.sh -O - | /bin/sh",
            "IP_Checker": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emil237/plugins/refs/heads/main/IP_Checker.sh -O - | /bin/sh",
            "iptvdream": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/main/iptvdream/iptvdream.sh -O - | /bin/sh",
            "Iptv-Org-Playlists": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/iptv-org-playlists/iptv-org-playlists.sh -O - | /bin/sh",
            "IptvPlayer": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emil237/iptvplayer/main/iptvinstaller.sh -O - | /bin/sh",
            "Iptvupdater": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/iptvupdater.sh -O - | /bin/sh",
            "KeyAdder": "wget --no-check-certificate -O - https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh -O - | /bin/sh",
            "levi45-freeserver": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emil237/plugins/refs/heads/main/levi45-freeserver/levi45-freeserver.sh -O - | /bin/sh",
            "levi45-settings": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/levi45-settings/levi45-settings.sh -O - | /bin/sh",
            "M3uConverter": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/Archimede-M3UConverter/main/installer.sh -O - | /bin/sh",
            "MerlinSkinThemes": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/merlinskinthemes.sh -O - | /bin/sh",
            "MmPicons": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/mmPicons/main/installer.sh -O - | /bin/sh",
            "MoviesManager": "wget --no-check-certificate -O - http://dreambox4u.com/emilnabil237/plugins/Transmission/MoviesManager.sh -O - | /bin/sh",
            "MultiCamAdder": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/MultiCamAdder/installer_dreambox.sh -O - | /bin/sh",
            "Multi-Iptv-Adder": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/MultiIptvAdder/installer_dreambox.sh -O - | /bin/sh",
            "ONEupdater": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Sat-Club/ONEupdaterE2/main/installer.sh -O - | /bin/sh",
            "Pauli": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/pauli.sh -O - | /bin/sh",
            "PluginSort": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/pluginsort.sh -O - | /bin/sh",
            "Plutotv": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/main/plutotv/plutotv.sh -O - | /bin/sh",
            "QuickButton": "wget --no-check-certificate -O - https://github.com/emilnabil/dreambox/raw/refs/heads/main/quickbutton.sh -O - | /bin/sh",
            "Quran-karem": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/quran/installer.sh -O - | /bin/sh",
            "Quran-karem_v2.2": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emil237/quran/main/installer.sh -O - | /bin/sh",
            "RaedQuickSignal": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/RaedQuickSignal/installer.sh -O - | /bin/sh",
            "scriptexecuter": "wget --no-check-certificate -O - http://dreambox4u.com/emilnabil237/plugins/scriptexecuter/installer.sh -O - | /bin/sh",
            "ServiceScanUpdates": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/servicescanupdates/servicescanupdates.sh -O - | /bin/sh",
            "SimpleZoomPanel": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/SimpleZooomPanel/main/installer.sh -O - | /bin/sh",
            "skincomponents-extmultilistselection": "curl -kL https://github.com/emilnabil/dreambox/raw/refs/heads/main/skincomponents-extmultilistselection.sh | bash",
            "Spinner-Selector": "wget --no-check-certificate -O - https://github.com/emilnabil/download-plugins/raw/refs/heads/main/SpinnerSelector/spinner-selector_dreamos.sh -O - | /bin/sh",
            "SubsSupport_1.5.8-r9": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/SubsSupport/installer1.sh -O - | /bin/sh",
            "TheWeather": "wget --no-check-certificate -O - https://raw.githubusercontent.com/biko-73/TheWeather/main/installer.sh -O - | /bin/sh",
            "TMBD": "wget --no-check-certificate -O - https://raw.githubusercontent.com/biko-73/TMBD/main/installer.sh -O - | /bin/sh",
            "TvDream": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/tvDream/main/installer.sh -O - | /bin/sh",
            "TvManager": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/tvManager/main/installer.sh -O - | /bin/sh",
            "TvParsa": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/tvParsa/main/installer.sh -O - | /bin/sh",
            "TvRaiPreview": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/tvRaiPreview/main/installer.sh -O - | /bin/sh",
            "TvSettings": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/tvSettings/main/installer.sh -O - | /bin/sh",
            "uninstaller": "curl -kL https://github.com/emilnabil/dreambox/raw/refs/heads/main/uninstaller.sh | bash",
            "userscripts": "curl -kL https://github.com/emilnabil/dreambox/raw/refs/heads/main/userscripts.sh | bash",
            "vavoo_1.15": "wget --no-check-certificate -O - https://dreambox4u.com/emilnabil237/plugins/vavoo/installer.sh -O - | /bin/sh",
            "WeatherPlugin": "wget --no-check-certificate -O - https://raw.githubusercontent.com/fairbird/WeatherPlugin/master/installer.sh -O - | /bin/sh",
            "Wifi-Manager": "wget --no-check-certificate -O - https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/wifimanager/wifimanager.sh -O - | /bin/sh",
            "Wireguard-Vpn": "wget --no-check-certificate -O - https://raw.githubusercontent.com/m4dhouse/Wireguard-Vpn/refs/heads/python-3.12/WireGuard.sh -O - | /bin/sh",
            "WorldCam": "wget --no-check-certificate -O - https://raw.githubusercontent.com/Belfagor2005/WorldCam/main/installer.sh -O - | /bin/sh"
        }
        return scripts.get(plugin_name)

    def showError(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def exit(self):
        self.close()
