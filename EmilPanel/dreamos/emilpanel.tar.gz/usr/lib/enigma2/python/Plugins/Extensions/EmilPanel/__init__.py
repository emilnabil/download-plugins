Panel = 'EmilPanel'
Version = '4.0'
















