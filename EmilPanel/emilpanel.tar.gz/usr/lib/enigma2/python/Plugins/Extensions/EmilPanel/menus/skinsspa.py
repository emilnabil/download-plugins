from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.MessageBox import MessageBox
from .Console import Console
from enigma import eLabel, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

class skinsspa(Screen):
    skin = """
        <screen name="skinsspa" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder">
            <ePixmap position="1305,400" size="550,500" pixmap="%s" zPosition="0" />
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryPixmapAlphaTest(pos=(25,5), size=(40,40), png=3),
                        MultiContentEntryPixmapAlphaTest(pos=(70,5), size=(50,40), png=2),
                        MultiContentEntryText(pos=(140,10), size=(600,45), font=0, flags=RT_HALIGN_LEFT, text=0)
                    ],
                    "fonts": [gFont("Regular", 35), gFont("Regular", 25)],
                    "itemHeight": 66}
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1235,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1235,1" zPosition="2" />
            
            <eLabel position="200,900" size="250,50" backgroundColor="#8B0000" zPosition="4" />
            <widget name="key_red" position="200,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Bold;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            <eLabel position="500,900" size="250,50" backgroundColor="#006400" zPosition="4" />
            <widget name="key_green" position="500,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Bold;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel position="800,900" size="250,50" backgroundColor="#C9A000" zPosition="4" />
           <eLabel backgroundColor="#00ffffff" position="1285,195" size="1,665" zPosition="2" /> 
            <widget name="key_yellow" position="800,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Bold;30" transparent="1" />
        </screen>""" % resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/background.png")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle("Panel Manager")
        self.selected_plugins = []
        
        self.checked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/checked.png"))
        self.unchecked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/unchecked.png"))
        self.plugin_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/skins.png"))

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.installSelected,
            "yellow": self.toggleSelection,
        })

        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Install"))
        self["key_yellow"] = Label(_("Select") + " (0)")

        self.list = []
        self["menu"] = List(self.list)
        self.load_plugins_list()
        self.mList()

    def load_plugins_list(self):
        self.all_plugins = [
            _("Aglare-FHD"),

_("estuary-1080-FHD")
        ]

    def mList(self):
        self.list = [
            (plugin_name, plugin_name, self.plugin_icon, 
             self.checked_icon if plugin_name in self.selected_plugins else self.unchecked_icon)
            for plugin_name in self.all_plugins
        ]
        self["menu"].setList(self.list)
        self.update_selection_count()

    def toggleSelection(self):
        current = self["menu"].getCurrent()
        if current:
            index = self["menu"].getSelectedIndex()
            plugin_name = current[0]
            
            if plugin_name in self.selected_plugins:
                self.selected_plugins.remove(plugin_name)
                new_icon = self.unchecked_icon
            else:
                self.selected_plugins.append(plugin_name)
                new_icon = self.checked_icon
            
            self.list[index] = (
                plugin_name,
                plugin_name,
                current[2],
                new_icon
            )
            self["menu"].updateList(self.list)
            self.update_selection_count()

    def update_selection_count(self):
        self["key_yellow"].setText(_("Select") + f" ({len(self.selected_plugins)})")

    def installSelected(self):
        if not self.selected_plugins:
            self.showError(_("No plugins selected"))
            return

        self.install_scripts = []
        for plugin in self.selected_plugins:
            script = self.get_script(plugin)
            if not script:
                self.showError(_("Script not found for %s") % plugin)
                return
            self.install_scripts.append(script)

        self.session.openWithCallback(
            self.confirmInstallSelected,
            MessageBox,
            _("Install %d selected plugins?") % len(self.selected_plugins),
            MessageBox.TYPE_YESNO
        )

    def confirmInstallSelected(self, answer):
        if not answer or not hasattr(self, 'install_scripts'):
            return

        try:
            with open("/tmp/install_script.sh", "w") as f:
                f.write("#!/bin/sh\n")
                f.write("\n".join(self.install_scripts) + "\n")

            self.session.open(
                Console,
                title=_("Installing selected plugins"),
                cmdlist=[
                    "chmod +x /tmp/install_script.sh",
                    "/bin/sh /tmp/install_script.sh"
                ],
                closeOnSuccess=True
            )

            self.selected_plugins = []
            del self.install_scripts
            self.mList()
        except Exception as e:
            self.showError(str(e))

    def keyOK(self):
        current = self["menu"].getCurrent()
        if current:
            plugin_name = current[0]
            self.installPlugin(plugin_name)
        else:
            self.showError(_("No plugin selected"))

    def installPlugin(self, plugin_name):
        script = self.get_script(plugin_name)
        if script:
            self.session.openWithCallback(
                lambda answer: self.executeInstall(answer, plugin_name),
                MessageBox,
                _("Install %s?") % plugin_name,
                MessageBox.TYPE_YESNO
            )
        else:
            self.showError(_("Script not found"))

    def executeInstall(self, answer, plugin_name):
        if answer:
            try:
                with open("/tmp/install_script.sh", "w") as f:
                    f.write("#!/bin/sh\n%s\n" % self.get_script(plugin_name))

                self.session.open(
                    Console,
                    title=_("Installing %s") % plugin_name,
                    cmdlist=[
                        "chmod +x /tmp/install_script.sh",
                        "/bin/sh /tmp/install_script.sh"
                    ],
                    closeOnSuccess=True
                )
            except Exception as e:
                self.showError(str(e))

    def get_script(self, plugin_name):
        scripts = {
            "Aglare-FHD": 'wget -q "--no-check-certificate" https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglareatv/installer.sh -O - | /bin/sh',

"estuary-1080-FHD": "wget https://gitlab.com/elbrins/skins/-/raw/main/Spa/Skin-estuary-1080.sh -O - | /bin/sh"
        }
        return scripts.get(plugin_name)

    def showError(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def exit(self):
        self.close()






