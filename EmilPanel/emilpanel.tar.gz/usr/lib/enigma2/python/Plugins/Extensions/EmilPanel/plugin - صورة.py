#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import socket
from enigma import *
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.ActionMap import ActionMap
from Components.Console import Console as iConsole
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap
from Plugins.Plugin import PluginDescriptor

# Import all menu modules
from .menus.panelmain import panelmain
from .menus.pluginmain import pluginmain
from .menus.systemplugins import systemplugins
from .menus.mediamain import mediamain
from .menus.tools import tools
from .menus.emu import emu
from .menus.key_plugins import key_plugins
from .menus.channels import channels
from .menus.channels_siefp_e2 import channels_siefp_e2
from .menus.channels_morph883_e2 import channels_morph883_e2
from .menus.channels_vhannibal import channels_vhannibal
from .menus.multiboot_plugins import multiboot_plugins
from .menus.bootlogos import bootlogos
from .menus.backup import backup
from .menus.restore import restore
from .menus.skinsatv import skinsatv
from .menus.skinsegami import skinsegami
from .menus.skinsobh import skinsobh
from .menus.skinsplinewpy import skinsplinewpy
from .menus.skinsvix import skinsvix
from .menus.skinsspa import skinsspa
from .menus.skinsplioldpy import skinsplioldpy
from .menus.skinsbh import skinsbh
from .menus.skinsvti import skinsvti
from .menus.images import images
from .menus.picons import picons
from .menus.removed import removed
from .__init__ import Version

class EmilPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.grid_items = 20
        self.current_position = 0
        self.skin = self.load_skin()
        self.create_grid_widgets()
        
        self.setTitle("Emil Panel")
        self.iConsole = iConsole()
        
        # Initialize labels
        self["key_red"] = Label("Close")
        self["key_green"] = Label("OK")
        self["key_blue"] = Label("Restart")
        self["Panel"] = Label("Emil Panel")
        self["Version"] = Label("V" + Version)
        self["EmilLabel"] = Label("Welcome Emil Panel")
        
        # System info widgets
        self.system_info_widgets = {
            "DeviceInfo": self.get_device_info(),
            "RAMInfo": self.get_ram_info(),
            "StorageInfo": self.get_storage_info(),
            "CPUInfo": self.get_cpu_info(),
            "ReceiverIP": self.get_receiver_ip(),
            "InternetStatus": self.get_internet_status(),
            "PythonVersion": self.get_python_version()
        }
        for name, value in self.system_info_widgets.items():
            self[name] = Label(value)
        
        # Menu items (Full list)
        self.menu_items = [
            ("Panel", "panel", "panel"),
            ("Plugins", "plugins", "plugins"),
            ("System Plugins", "systemplugins", "systemplugins"),
            ("Media", "media", "media"),
            ("Tools", "tools", "tools"),
            ("Emu", "emu", "emu"),
            ("Key Plugins", "key_plugins", "key_plugins"),
            ("Channels-Other", "channels", "channels"),
            ("Channels-Siefp-E2", "channels_siefp_e2", "ciefp"),
            ("Channels Morph883", "channels_morph883_e2", "morpheus"),
            ("Channels Vhannibal", "channels_vhannibal", "vhannibal"),
            ("Multiboot Plugins", "multiboot_plugins", "multiboot"),
            ("Bootlogos", "bootlogos", "bootlogos"),
            ("Backup", "backup", "backup"),
            ("Restore", "restore", "restore"),
            ("Skins ATV", "skinsatv", "skins"),
            ("Skins Egami", "skinsegami", "skins"),
            ("Skins OpenBH", "skinsobh", "skins"),
            ("Skins PLi Py3", "skinsplinewpy", "skins"),
            ("Skins Vix", "skinsvix", "skins")
        ]
        
        # Action Map
        self["actions"] = ActionMap(["DirectionActions", "OkCancelActions", "ColorActions"], {
            "left": self.move_left,
            "right": self.move_right,
            "up": self.move_up,
            "down": self.move_down,
            "ok": self.key_ok,
            "cancel": self.exit,
            "red": self.exit,
            "green": self.key_ok,
            "blue": self.reboot,
            "info": self.show_info
        }, -1)
        
        self.build_grid_menu()
        self.update_selection_frame()
        self.check_for_update()

    def load_skin(self):
        skin_path = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/skin.xml")
        with open(skin_path, "r") as f:
            return f.read()

    def create_grid_widgets(self):
        for i in range(1, self.grid_items + 1):
            self[f"pixmap{i}"] = Pixmap()
            self[f"label{i}"] = Label("")

    def build_grid_menu(self):
        for idx, item in enumerate(self.menu_items[:self.grid_items]):
            self[f"label{idx+1}"].setText(item[0])
            icon_path = resolveFilename(SCOPE_PLUGINS, 
                f"Extensions/EmilPanel/images/{item[2]}.png")
            pixmap = LoadPixmap(icon_path) if fileExists(icon_path) else None
            self[f"pixmap{idx+1}"].setPixmap(pixmap)

    def update_selection_frame(self):
        row = self.current_position // 5
        col = self.current_position % 5
        x = 100 + col * 210
        y = 210 + row * 220
        self["frame"].setPosition((x, y))

    def move_left(self):
        if self.current_position % 5 != 0:
            self.current_position -= 1
            self.update_selection_frame()

    def move_right(self):
        if (self.current_position % 5) < 4:
            self.current_position += 1
            self.update_selection_frame()

    def move_up(self):
        if self.current_position >= 5:
            self.current_position -= 5
            self.update_selection_frame()

    def move_down(self):
        if self.current_position < (self.grid_items - 5):
            self.current_position += 5
            self.update_selection_frame()

    def key_ok(self):
        if self.current_position < len(self.menu_items):
            selected_item = self.menu_items[self.current_position][1]
            self.handle_menu_selection(selected_item)

    def handle_menu_selection(self, item):
        handlers = {
            "panel": lambda: self.session.open(panelmain),
            "plugins": lambda: self.session.open(pluginmain),
            "systemplugins": lambda: self.session.open(systemplugins),
            "media": lambda: self.session.open(mediamain),
            "tools": lambda: self.session.open(tools),
            "emu": lambda: self.session.open(emu),
            "key_plugins": lambda: self.session.open(key_plugins),
            "channels": lambda: self.session.open(channels),
            "channels_siefp_e2": lambda: self.session.open(channels_siefp_e2),
            "channels_morph883_e2": lambda: self.session.open(channels_morph883_e2),
            "channels_vhannibal": lambda: self.session.open(channels_vhannibal),
            "multiboot_plugins": lambda: self.session.open(multiboot_plugins),
            "bootlogos": lambda: self.session.open(bootlogos),
            "backup": lambda: self.session.open(backup),
            "restore": lambda: self.session.open(restore),
            "skinsatv": lambda: self.session.open(skinsatv),
            "skinsegami": lambda: self.session.open(skinsegami),
            "skinsobh": lambda: self.session.open(skinsobh),
            "skinsplinewpy": lambda: self.session.open(skinsplinewpy),
            "skinsvix": lambda: self.session.open(skinsvix)
        }
        handler = handlers.get(item, self.exit)
        handler()

    # System Information Methods
    def get_device_info(self):
        try:
            model = "Unknown"
            model_paths = ["/proc/stb/info/vumodel", "/proc/stb/info/model"]
            for path in model_paths:
                if os.path.exists(path):
                    with open(path) as f:
                        model = f.read().strip()
                    break
            
            image = "Unknown"
            version = "Unknown"
            if os.path.exists("/etc/image-version"):
                with open("/etc/image-version") as f:
                    for line in f:
                        if "creator" in line:
                            image = line.split("=")[1].strip()
                        elif "version" in line:
                            version = line.split("=")[1].strip()
            
            return f"{model}: {image} {version}"
        except:
            return "Device Info: N/A"

    def get_ram_info(self):
        try:
            with open("/proc/meminfo") as f:
                mem = {line.split(':')[0]: line.split(':')[1].strip() for line in f}
            total = int(mem["MemTotal"].split()[0]) // 1024
            free = int(mem["MemAvailable"].split()[0]) // 1024
            used = total - free
            return f"RAM: {used}MB/{total}MB Free"
        except:
            return "RAM Info: N/A"

    # ... (Other system info methods same as original) ...

    # Update Handling
    def check_for_update(self):
        cmd = 'wget -q -O /tmp/emilpanel_version.txt "https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanel/version.txt"'
        self.iConsole.ePopen(cmd, self.version_downloaded)

    def version_downloaded(self, result, retval, extra_args):
        if retval == 0:
            try:
                with open("/tmp/emilpanel_version.txt", "r") as f:
                    online_version = f.read().strip()
                if online_version > Version:
                    self.session.openWithCallback(self.update_confirmed, 
                        MessageBox, 
                        f"New version {online_version} available!\nUpdate now?", 
                        MessageBox.TYPE_YESNO
                    )
                os.remove("/tmp/emilpanel_version.txt")
            except Exception as e:
                print(f"Version check error: {str(e)}")

    def update_confirmed(self, answer):
        if answer:
            self.do_update()

    def do_update(self):
        cmd = (
            'wget -q -O /tmp/emilpanel.tar.gz '
            '"https://github.com/emilnabil/download-plugins/raw/main/EmilPanel/emilpanel.tar.gz" && '
            'rm -rf /usr/lib/enigma2/python/Plugins/Extensions/EmilPanel && '
            'tar -xzf /tmp/emilpanel.tar.gz -C / && '
            'rm -f /tmp/emilpanel.tar.gz && '
            '( systemctl restart enigma2 || killall -9 enigma2 )'
        )
        self.iConsole.ePopen(cmd, self.update_finished)

    def update_finished(self, result, retval, extra_args):
        if retval != 0:
            self.session.open(MessageBox, 
                "Update failed! Check internet connection.", 
                MessageBox.TYPE_ERROR
            )

    def show_info(self):
        info_path = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/info.txt")
        if fileExists(info_path):
            try:
                with open(info_path, "r") as f:
                    content = f.read()
                self.session.open(MessageBox, content, MessageBox.TYPE_INFO)
            except Exception as e:
                self.session.open(MessageBox, f"Error reading info: {str(e)}", MessageBox.TYPE_ERROR)
        else:
            self.session.open(MessageBox, "Info file not found", MessageBox.TYPE_ERROR)

    def reboot(self):
        self.iConsole.ePopen('systemctl restart enigma2 || killall -9 enigma2')
        self.close()

    def exit(self):
        self.close()

def main(session, **kwargs):
    session.open(EmilPanel)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Emil Panel",
        description="Emil Addons Panel",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="icon.png",
        fnc=main
    )

