#!/usr/bin/python
# -*- coding: utf-8 -*-
import os
import sys
import socket
from enigma import *
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.Sources.List import List
from Components.ActionMap import ActionMap
from Components.Console import Console as iConsole
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap
from Plugins.Plugin import PluginDescriptor

from .menus.panelmain import panelmain
from .menus.pluginmain import pluginmain
from .menus.systemplugins import systemplugins
from .menus.mediamain import mediamain
from .menus.tools import tools
from .menus.emu import emu
from .menus.key_plugins import key_plugins
from .menus.channels import channels
from .menus.multiboot_plugins import multiboot_plugins
from .menus.bootlogos import bootlogos
from .menus.backup import backup
from .menus.restore import restore
from .menus.skinsatv import skinsatv
from .menus.skinsegami import skinsegami
from .menus.skinsobh import skinsobh
from .menus.skinsplinewpy import skinsplinewpy
from .menus.skinsvix import skinsvix
from .menus.skinsspa import skinsspa
from .menus.skinsplioldpy import skinsplioldpy
from .menus.skinsbh import skinsbh
from .menus.skinsvti import skinsvti
from .menus.images import images
from .menus.picons import picons
from .menus.removed import removed
from .__init__ import Version

class emilpanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """<screen name="emilpanel" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder" title="Emil Panel">
            <widget name="Panel" position="160,105" size="270,50" font="Regular;45" halign="center" valign="center" transparent="1"/>
            <widget name="Version" position="410,110" size="150,50" font="Regular;35" halign="center" valign="center" transparent="1"/>
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1240,1" zPosition="2" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos = (120, 10), size = (600, 45), font=0, flags = RT_HALIGN_LEFT, text = 0),
                        MultiContentEntryText(pos = (600, 19), size = (600, 35), font=1, flags = RT_HALIGN_LEFT, text = 2),
                        MultiContentEntryPixmapAlphaTest(pos = (25, 5), size = (50, 40), png = 3),
                    ],
                    "fonts": [gFont("Regular", 35),gFont("Regular", 25)],
                    "itemHeight": 66
                    }
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="1285,195" size="1,665" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            
            <widget source="key_red" render="Label" position="200,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#990011" foregroundColor="white" transparent="0" />
            <widget source="key_green" render="Label" position="520,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#1F771F" foregroundColor="white" transparent="0" />
            <widget source="key_blue" render="Label" position="840,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#13389F" foregroundColor="white" transparent="0" />
            
            <widget name="EmilLabel" position="350,880" size="600,100" font="Regular;60" halign="center" valign="center" foregroundColor="#00BFFF" transparent="1"/>
            <eLabel backgroundColor="#990011" position="1305,410" size="550,50" zPosition="-1" />
            <widget name="DeviceName" position="1305,410" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,470" size="550,50" zPosition="-1" />
            <widget name="ImageName" position="1305,470" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#008000" position="1305,530" size="550,50" zPosition="-1" />
            <widget name="ImageVersion" position="1305,530" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#19184D" position="1305,590" size="550,50" zPosition="-1" />
            <widget name="CPUInfo" position="1305,590" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#800000" position="1305,650" size="550,50" zPosition="-1" />
            <widget name="HDDInfo" position="1305,650" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#000080" position="1305,710" size="550,50" zPosition="-1" />
            <widget name="MountInfo" position="1305,710" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#006666" position="1305,770" size="550,50" zPosition="-1" />
            <widget name="ReceiverIP" position="1305,770" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#800080" position="1305,830" size="550,50" zPosition="-1" />
            <widget name="InternetStatus" position="1305,830" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#808000" position="1305,890" size="550,50" zPosition="-1" />
            <widget name="PythonVersion" position="1305,890" size="550,50" font="Bold;35" halign="center" valign="center" transparent="1"/>
        </screen>"""
        self.setTitle("Emil Panel")
        self.iConsole = iConsole()
        self.indexpos = None
        
        self["key_red"] = Label("Close")
        self["key_green"] = Label("OK")
        self["key_blue"] = Label("Restart")
        
        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.keyOK,
            "blue": self.reboot  
        })
        
        self.list = []
        self["menu"] = List(self.list)
        self.buildMenu()
        self["Version"] = Label("V" + Version)
        self["Panel"] = Label("Emil Panel")
        self["EmilLabel"] = Label("Welcome Emil Panel")
        self["DeviceName"] = Label(self.getDeviceName())
        self["ImageName"] = Label(self.getImageName())
        self["ImageVersion"] = Label(self.getImageVersion())
        self["CPUInfo"] = Label(self.getCPUInfo())
        self["HDDInfo"] = Label(self.getHDDInfo())
        self["MountInfo"] = Label(self.getMountInfo())
        self["ReceiverIP"] = Label(self.getReceiverIP())
        self["InternetStatus"] = Label(self.getInternetStatus())
        self["PythonVersion"] = Label(self.getPythonVersion())
        self.checkForUpdate()

    def buildMenu(self):
        self.list = []
        menu_items = [
            ("Panel", "panel", "", "panel"),
            ("Plugins", "plugins", "", "plugins"),
            ("System Plugins", "systemplugins", "", "systemplugins"),
            ("Media", "media", "", "media"),
            ("Tools", "tools", "", "tools"),
            ("Emu", "emu", "", "emu"),
            ("Key Plugins", "key plugins", "", "key_plugins"),
            ("Channels", "channels", "", "channels"),
            ("Multiboot Plugins", "multiboot_plugins", "", "multiboot"),
            ("Bootlogos", "bootlogos", "", "bootlogos"),
            ("Backup", "backup", "", "backup"),
            ("Restore", "restore", "", "restore"),
            ("Skins Openatv", "skinsatv", "", "skins"),
            ("Skins Egami", "skinsegami", "", "skins"),
            ("Skins OpenBH", "skinsobh", "", "skins"),
            ("Skins OpenPli_Py3", "skinsplinewpy", "", "skins"),
            ("Skins OpenVix", "skinsvix", "", "skins"),
            ("Skins OpenSpa", "skinsspa", "", "skins"),
            ("Skins OpenPli_Py2", "skinsplioldpy", "", "skins"),
            ("Skins BlackHole", "skinsbh", "", "skins"),
            ("Skins Vti", "skinsvti", "", "skins"),
            ("Images", "images", "", "images"),
            ("Picons", "picons", "", "picons"),
            ("Remove", "removed", "", "removed"),
            ("Check for Update", "update", "", "update"),
        ]
        
        for name, action, description, icon_name in menu_items:
            icon_path = resolveFilename(SCOPE_PLUGINS, f"Extensions/EmilPanel/images/{icon_name}.png")
            icon = LoadPixmap(cached=True, path=icon_path) if fileExists(icon_path) else None
            self.list.append((name, action, description, icon))
        
        self["menu"].setList(self.list)

    def keyOK(self):
        self.indexpos = self["menu"].getIndex()
        item = self["menu"].getCurrent()[1]
        self.select_item(item)

    def select_item(self, item):
        item = item.lower()
        if item == "panel":
            self.session.open(panelmain)
        elif item == "plugins":
            self.session.open(pluginmain)
        elif item == "systemplugins":
            self.session.open(systemplugins)
        elif item == "media":
            self.session.open(mediamain)
        elif item == "tools":
            self.session.open(tools)
        elif item == "emu":
            self.session.open(emu)
        elif item == "key plugins":
            self.session.open(key_plugins)
        elif item == "channels":
            self.session.open(channels)
        elif item == "multiboot_plugins":
            self.session.open(multiboot_plugins)
        elif item == "bootlogos":
            self.session.open(bootlogos)
        elif item == "backup":
            self.session.open(backup)
        elif item == "restore":
            self.session.open(restore)
        elif item == "skinsatv":
            self.session.open(skinsatv)
        elif item == "skinsegami":
            self.session.open(skinsegami)
        elif item == "skinsobh":
            self.session.open(skinsobh)
        elif item == "skinsplinewpy":
            self.session.open(skinsplinewpy)
        elif item == "skinsvix":
            self.session.open(skinsvix)
        elif item == "skinsspa":
            self.session.open(skinsspa)
        elif item == "skinsplioldpy":
            self.session.open(skinsplioldpy)
        elif item == "skinsbh":
            self.session.open(skinsbh)
        elif item == "skinsvti":
            self.session.open(skinsvti)
        elif item == "images":
            self.session.open(images)
        elif item == "picons":
            self.session.open(picons)
        elif item == "removed":
            self.session.open(removed)
        elif item == "update":
            self.checkForUpdate()
        else:
            self.close()

    def exit(self):
        self.close()

    def reboot(self): 
        self.iConsole.ePopen('if command -v dpkg > /dev/null 2>&1; then systemctl restart enigma2; else killall -9 enigma2; fi')
        self.close()

    def checkForUpdate(self):
        cmd = 'wget -q -O /tmp/emilpanel_version.txt "https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanel/version.txt"'
        self.iConsole.ePopen(cmd, self.versionDownloaded)

    def versionDownloaded(self, result, retval, extra_args):
        if retval == 0:
            try:
                with open("/tmp/emilpanel_version.txt", "r") as f:
                    online_version = f.read().strip()
                if online_version > Version:
                    self.session.openWithCallback(self.updateConfirmed, MessageBox, f"New version {online_version} available. Update now?", MessageBox.TYPE_YESNO)
                os.remove("/tmp/emilpanel_version.txt")
            except Exception as e:
                print("Error checking version:", e)
        else:
            print("Failed to download version file")

    def updateConfirmed(self, answer):
        if answer:
            self.doUpdate()

    def doUpdate(self):
        cmd = (
            'wget -q -O /tmp/emilpanel.tar.gz "https://github.com/emilnabil/download-plugins/raw/main/EmilPanel/emilpanel.tar.gz" && '
            'rm -rf /usr/lib/enigma2/python/Plugins/Extensions/EmilPanel && '
            'tar -xzf /tmp/emilpanel.tar.gz -C /usr/lib/enigma2/python/Plugins/Extensions/ && '
            'rm -f /tmp/emilpanel.tar.gz && '
            'systemctl restart enigma2 || killall -9 enigma2'
        )
        self.iConsole.ePopen(cmd, self.updateFinished)

    def updateFinished(self, result, retval, extra_args):
        if retval != 0:
            self.session.open(MessageBox, "Update failed. Check internet connection.", MessageBox.TYPE_ERROR)

    def getDeviceName(self):
        try:
            for path in ["/proc/stb/info/vumodel", "/proc/stb/info/model"]:
                if os.path.exists(path):
                    with open(path) as f:
                        return f.read().strip()
        except:
            pass
        return "Unknown"

    def getImageName(self):
        try:
            if os.path.exists("/etc/image-version"):
                with open("/etc/image-version") as f:
                    for line in f:
                        if "creator" in line:
                            return line.partition("=")[2].strip()
        except:
            pass
        return "Unknown"

    def getImageVersion(self):
        try:
            if os.path.exists("/etc/image-version"):
                with open("/etc/image-version") as f:
                    for line in f:
                        if "version" in line:
                            return line.partition("=")[2].strip()
        except:
            pass
        return "Unknown"

    def getCPUInfo(self):
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if "model name" in line:
                        return line.partition(":")[2].strip()
        except:
            pass
        return "Unknown"

    def getHDDInfo(self):
        try:
            for mount in ["/media/hdd", "/media/usb"]:
                if os.path.ismount(mount):
                    stat = os.statvfs(mount)
                    size = (stat.f_blocks * stat.f_frsize) // (1024 * 1024)
                    free = (stat.f_bfree * stat.f_frsize) // (1024 * 1024)
                    return f"HDD: {size} MB - Free: {free} MB"
        except:
            pass
        return "No Storage"

    def getMountInfo(self):
        mounts = ["/media/hdd", "/media/usb", "/media/sdcard"]
        for mount in mounts:
            if os.path.ismount(mount):
                return mount
        return "Not Mounted"

    def getReceiverIP(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return "IP: " + ip
        except:
            return "IP: N/A"

    def getInternetStatus(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect(("8.8.8.8", 53))
            s.close()
            return "Internet: Connected"
        except:
            return "Internet: Not Connected"

    def getPythonVersion(self):
        return "Python: " + sys.version.split()[0]

def main(session, **kwargs):
    session.open(emilpanel)

def menuHook(menuid):
    if menuid == "mainmenu":
        return [(_("Emil Panel"), main, "emil_panel", None)]
    return []

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Emil Panel",
            description="Emil Addons Panel",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="Emil Panel",
            description="Emil Addons Panel",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        ),
        PluginDescriptor(
            name="Emil Panel",
            description="Emil Addons Panel",
            where=PluginDescriptor.WHERE_MENU,
            fnc=menuHook
        )
    ]

