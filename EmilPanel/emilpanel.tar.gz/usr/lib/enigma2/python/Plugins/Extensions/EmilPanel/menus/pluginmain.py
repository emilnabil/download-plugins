from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.MessageBox import MessageBox
from .Console import Console
from enigma import eLabel, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

class pluginmain(Screen):
    skin = """
        <screen name="pluginmain" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder">
            <ePixmap position="1305,400" size="500,500" pixmap="%s" zPosition="0" />
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryPixmapAlphaTest(pos=(25,5), size=(40,40), png=3),
                        MultiContentEntryPixmapAlphaTest(pos=(70,5), size=(50,40), png=2),
                        MultiContentEntryText(pos=(140,10), size=(600,45), font=0, flags=RT_HALIGN_LEFT, text=0)
                    ],
                    "fonts": [gFont("Regular", 35), gFont("Regular", 25)],
                    "itemHeight": 66}
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1235,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1235,1" zPosition="2" />
            
            <eLabel position="200,900" size="250,50" backgroundColor="#8B0000" zPosition="4" />
            <widget name="key_red" position="200,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Bold;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            <eLabel position="500,900" size="250,50" backgroundColor="#006400" zPosition="4" />
            <widget name="key_green" position="500,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Bold;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel position="800,900" size="250,50" backgroundColor="#C9A000" zPosition="4" />
            <widget name="key_yellow" position="800,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Bold;30" transparent="1" />
        </screen>""" % resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/background.png")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("Plugin Manager")
        self.selected_plugins = []
        
        self.checked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/checked.png"))
        self.unchecked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/unchecked.png"))
        self.plugin_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/plugins.png"))

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.installSelected,
            "yellow": self.toggleSelection,
        })

        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Install"))
        self["key_yellow"] = Label(_("Select") + " (0)")

        self.list = []
        self["menu"] = List(self.list)
        self.load_plugins_list()
        self.mList()

    def load_plugins_list(self):
        self.all_plugins = [
            "ArabicSavior",
            "Acherone",
            "Advanced-Screen-Shot",
            "Alajre",
            "Ansite",
            "Apod",
            "Astronomy",
            "Athan Times",
            "Atilehd",
            "automatic-fullbackup",
            "Azkar Almuslim",
            "Bitrate",
            "Bitrate-mod-ariad",
            "Bundesliga-Permanent-Clock",
            "CacheFlush",
            "CCcaminfo-py2",
            "CCcaminfo-py3",
            "CrondManager",
            "CFG_ZOOM_FINAL",
            "CiefpSatelliteXmlEditor",

"CiefpSettingsDownloader",

"CiefpBouquetUpdater",

"CiefpChannelManager",
   
   "CiefpIPTVBouquets",                  
            "CiefpsettingsMotor",
            "CiefpSelectSatellite",
            "CiefpE2Converter",
            "CiefpWhitelistStreamrelay",
            "CiefpSettingsStreamrela_PY3",
            "CiefpSettingsStreamrela_PY2",
            "CiefpSettingsT2miAbertis",
            "CiefpSettingsT2miAbertisOpenPLi",
            "chocholousek-picons",
            "CHLogoChanger",
            "CrashLogoViewer",
            "CrondManger",
            "enigma2readeradder",
            "Epg Grabber",
            "EPGImport",
            "EPGImport-99",
            "EPGTranslator",
            "Filmxy",
            "Footonsat",
            "Freearhey",
            "FreeCCcamServer",
            "hardwareinfo",
            "HasBahCa",
            "HistoryZapSelector",
            "horoscope",
            "HolidayCountdown",
            "Internet-Speedtest",

"Iptv-Org-Playlists",

            "iptvdream",
            
            "m3uconverter",
            "MoviesManager",
            "MyCam-Plugin",
            "MultiCamAdder",
            "Multi-Iptv-Adder",
            "NewVirtualkeyBoard",
            "ONEupdater",
            "Ozeta-Skins-Setup",
            "Plutotv",
            "Quran-karem",
            "Quran-karem_v2.2",
            "Radio-80-s",
            "Radiom",
            "Rakutentv",
            "RaedQuickSignal",
            "pluginmover",
            "pluginskinmover",
            "ScreenNames",
            "Screen-Recorder",
            "SetPicon",
            "scriptexecuter",
            "showclock",
            "Sherlockmod",
            "Simple-Zoom-Panel",
            "SubsSupport_1.5.8-r9",

"SubsSupport_by-m.nasr",
            "SubsSupport_2.1",
            "uninstaller-Plugins",
            "vavoo_1.15",
            "xtraevent_3.3",
            "xtraevent_4.2",
            "xtraevent_4.5",
            "Xtraevent_4.6",
            "xtraevent_6.798",
            "xtraevent_6.805",
            "xtraevent_6.820_All-Python",
            "WorldCam",
            "Zip2Pkg-Converter",
            "Zoom_1.1.2-Py3"
        ]

    def mList(self):
        self.list = [
            (plugin_name, plugin_name, self.plugin_icon, 
             self.checked_icon if plugin_name in self.selected_plugins else self.unchecked_icon)
            for plugin_name in self.all_plugins
        ]
        self["menu"].setList(self.list)
        self.update_selection_count()

    def toggleSelection(self):
        current = self["menu"].getCurrent()
        if current:
            index = self["menu"].getSelectedIndex()
            plugin_name = current[0]
            
            if plugin_name in self.selected_plugins:
                self.selected_plugins.remove(plugin_name)
                new_icon = self.unchecked_icon
            else:
                self.selected_plugins.append(plugin_name)
                new_icon = self.checked_icon
            
            self.list[index] = (
                plugin_name,
                plugin_name,
                current[2],
                new_icon
            )
            self["menu"].updateList(self.list)
            self.update_selection_count()

    def update_selection_count(self):
        self["key_yellow"].setText(_("Select") + f" ({len(self.selected_plugins)})")

    def installSelected(self):
        if not self.selected_plugins:
            self.showError(_("No plugins selected"))
            return

        self.install_scripts = []
        for plugin in self.selected_plugins:
            script = self.get_script(plugin)
            if not script:
                self.showError(_("Script not found for %s") % plugin)
                return
            self.install_scripts.append(script)

        self.session.openWithCallback(
            self.confirmInstallSelected,
            MessageBox,
            _("Install %d selected plugins?") % len(self.selected_plugins),
            MessageBox.TYPE_YESNO
        )

    def confirmInstallSelected(self, answer):
        if not answer or not hasattr(self, 'install_scripts'):
            return

        try:
            with open("/tmp/install_script.sh", "w") as f:
                f.write("#!/bin/sh\n")
                f.write("\n".join(self.install_scripts) + "\n")

            self.session.open(
                Console,
                title=_("Installing selected plugins"),
                cmdlist=[
                    "chmod +x /tmp/install_script.sh",
                    "/bin/sh /tmp/install_script.sh"
                ],
                closeOnSuccess=True
            )

            self.selected_plugins = []
            del self.install_scripts
            self.mList()
        except Exception as e:
            self.showError(str(e))

    def keyOK(self):
        current = self["menu"].getCurrent()
        if current:
            plugin_name = current[0]
            self.installPlugin(plugin_name)
        else:
            self.showError(_("No plugin selected"))

    def installPlugin(self, plugin_name):
        script = self.get_script(plugin_name)
        if script:
            self.session.openWithCallback(
                lambda answer: self.executeInstall(answer, plugin_name),
                MessageBox,
                _("Install %s?") % plugin_name,
                MessageBox.TYPE_YESNO
            )
        else:
            self.showError(_("Script not found"))

    def executeInstall(self, answer, plugin_name):
        if answer:
            try:
                with open("/tmp/install_script.sh", "w") as f:
                    f.write("#!/bin/sh\n%s\n" % self.get_script(plugin_name))

                self.session.open(
                    Console,
                    title=_("Installing %s") % plugin_name,
                    cmdlist=[
                        "chmod +x /tmp/install_script.sh",
                        "/bin/sh /tmp/install_script.sh"
                    ],
                    closeOnSuccess=True
                )
            except Exception as e:
                self.showError(str(e))

    def get_script(self, plugin_name):
        scripts = {
            "ArabicSavior": "wget http://dreambox4u.com/emilnabil237/plugins/ArabicSavior/installer.sh -O - | /bin/sh",
            "Acherone": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/acherone/installer.sh -O - | /bin/sh",
"Advanced-Screen-Shot": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/advancedscreenshot/advancedscreenshot.sh -O - | /bin/sh",
            "Alajre": "wget https://dreambox4u.com/emilnabil237/plugins/alajre/installer.sh -O - | /bin/sh",
            "Ansite": "wget https://raw.githubusercontent.com/emil237/ansite/refs/heads/main/installer.sh -O - | /bin/sh",
            "Apod": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/apod/installer.sh -O - | /bin/sh",
            "Astronomy": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/astronomy/installer.sh -O - | /bin/sh",
            "Athan Times": "wget https://dreambox4u.com/emilnabil237/plugins/athantimes/installer.sh -O - | /bin/sh",
            "Atilehd": "wget https://dreambox4u.com/emilnabil237/plugins/atilehd/installer.sh -O - | /bin/sh",
            "automatic-fullbackup": "wget https://dreambox4u.com/emilnabil237/plugins/automatic-fullbackup/installer.sh -O - | /bin/sh",
            "Azkar Almuslim": "wget https://dreambox4u.com/emilnabil237/plugins/azkar-almuslim/installer.sh -O - | /bin/sh",
            "Bitrate": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/bitrate/bitrate.sh -O - | /bin/sh",
            "Bitrate-mod-ariad": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/bitrate/bitrate-mod-ariad.sh -O - | /bin/sh",
            "Bundesliga-Permanent-Clock": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/bundesliga-permanent-clock/bundesliga-permanent-clock.sh -O - | /bin/sh",
            "CacheFlush": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/cacheflush/cacheflush.sh -O - | /bin/sh",
            "CCcaminfo-py2": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/cccaminfo/cccaminfo_py2.sh -O - | /bin/sh",
            "CCcaminfo-py3": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/cccaminfo/cccaminfo_py3.sh -O - | /bin/sh",
            "CrondManager": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/crondmanager/installer.sh -O - | /bin/sh",
            "CFG_ZOOM_FINAL": "wget https://dreambox4u.com/emilnabil237/plugins/cfg_Zoom_Final_FIX7x/installer.sh -O - | /bin/sh",
            "CiefpSatelliteXmlEditor": "wget https://raw.githubusercontent.com/ciefp/CiefpSatelliteXmlEditor/main/installer.sh -O - | /bin/sh",

"CiefpSettingsDownloader": "wget https://raw.githubusercontent.com/ciefp/CiefpSettingsDownloader/main/installer.sh -O - | /bin/sh",

"CiefpBouquetUpdater": "wget https://raw.githubusercontent.com/ciefp/CiefpBouquetUpdater/main/installer.sh -O - | /bin/sh",

"CiefpChannelManager": "wget https://raw.githubusercontent.com/ciefp/CiefpChannelManager/main/installer.sh -O - | /bin/sh",
            
  "CiefpIPTVBouquets": "wget https://raw.githubusercontent.com/ciefp/CiefpIPTVBouquets/main/installer.sh -O - | /bin/sh",          
            "CiefpsettingsMotor": "wget https://raw.githubusercontent.com/ciefp/CiefpsettingsMotor/main/installer.sh -O - | /bin/sh",
            "CiefpSelectSatellite": "wget https://raw.githubusercontent.com/ciefp/CiefpSelectSatellite/main/installer.sh -O - | /bin/sh",
            "CiefpE2Converter": "wget https://raw.githubusercontent.com/ciefp/CiefpE2Converter/main/installer.sh -O - | /bin/sh",
            "CiefpWhitelistStreamrelay": "wget https://raw.githubusercontent.com/ciefp/CiefpWhitelistStreamrelay/main/installer.sh -O - | /bin/sh",
            "CiefpSettingsStreamrela_PY3": "wget https://raw.githubusercontent.com/ciefp/CiefpSettingsStreamrelay/main/installer.sh -O - | /bin/sh",
            "CiefpSettingsStreamrela_PY2": "wget https://raw.githubusercontent.com/ciefp/CiefpSettingsStreamrelayPY2/main/installer.sh -O - | /bin/sh",
            "CiefpSettingsT2miAbertis": "wget https://raw.githubusercontent.com/ciefp/CiefpSettingsT2miAbertis/main/installer.sh -O - | /bin/sh",
            "CiefpSettingsT2miAbertisOpenPLi": "wget https://raw.githubusercontent.com/ciefp/CiefpSettingsT2miAbertisOpenPLi/main/installer.sh -O - | /bin/sh",
            "chocholousek-picons": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/chocholousek-picons.sh -O - | /bin/sh",
            "CHLogoChanger": "wget https://dreambox4u.com/emilnabil237/plugins/CHLogoChanger/ChLogoChanger.sh -O - | /bin/sh",
            "CrashLogoViewer": "wget https://dreambox4u.com/emilnabil237/plugins/crashlogviewer/install-CrashLogViewer.sh -O - | /bin/sh",
            "CrondManger": "wget https://github.com/emil237/download-plugins/raw/main/cronmanager.sh -O - | /bin/sh",
            "enigma2readeradder": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/enigma2readeradder/enigma2readeradder.sh -O - | /bin/sh",
            "Epg Grabber": "wget https://dreambox4u.com/emilnabil237/plugins/Epg-Grabber/installer.sh -O - | /bin/sh",
            "EPGImport": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/epgimport.sh -O - | /bin/sh",
            "EPGImport-99": "wget https://raw.githubusercontent.com/Belfagor2005/EPGImport-99/main/installer.sh -O - | /bin/sh",
            "EPGTranslator": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/epgtranslator.sh -O - | /bin/sh",
            "Filmxy": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/filmxy/filmxy.sh -O - | /bin/sh",
            "Footonsat": "wget https://dreambox4u.com/emilnabil237/plugins/FootOnsat/installer.sh -O - | /bin/sh",
            "Freearhey": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/freearhey/freearhey.sh -O - | /bin/sh",
            "FreeCCcamServer": "wget https://ia803104.us.archive.org/0/items/freecccamserver/installer.sh -O - | /bin/sh",
            "hardwareinfo": "wget https://dreambox4u.com/emilnabil237/plugins/hardwareinfo/installer.sh -O - | /bin/sh",
            "HasBahCa": "wget https://dreambox4u.com/emilnabil237/plugins/HasBahCa/installer.sh -O - | /bin/sh",
            "HistoryZapSelector": "wget https://dreambox4u.com/emilnabil237/plugins/historyzap/installer1.sh -O - | /bin/sh",
            "horoscope": "wget https://raw.githubusercontent.com/emilnabil/horoscope/refs/heads/main/horoscope.sh -O - | /bin/sh",
            "HolidayCountdown": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/HolidayCountdown/installer.sh -O - | /bin/sh",
            "Internet-Speedtest": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/internet-speedtest.sh -O - | /bin/sh",
"Iptv-Org-Playlists": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/iptv-org-playlists/iptv-org-playlists.sh -O - | /bin/sh",
            "iptvdream": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/main/iptvdream/iptvdream.sh -O - | /bin/sh",
            
            "m3uconverter": "wget https://raw.githubusercontent.com/Belfagor2005/Archimede-M3UConverter/main/installer.sh -O - | /bin/sh",
            "MoviesManager": "wget http://dreambox4u.com/emilnabil237/plugins/Transmission/MoviesManager.sh -O - | /bin/sh",
            "MyCam-Plugin": "wget https://dreambox4u.com/emilnabil237/plugins/mycam/installer.sh -O - | /bin/sh",
            "MultiCamAdder": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/MultiCamAdder/installer.sh -O - | /bin/sh",
            "Multi-Iptv-Adder": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/MultiIptvAdder/installer.sh -O - | /bin/sh",
            "NewVirtualkeyBoard": "wget https://dreambox4u.com/emilnabil237/plugins/NewVirtualKeyBoard/installer.sh -O - | /bin/sh",
            "ONEupdater": "wget https://raw.githubusercontent.com/Sat-Club/ONEupdaterE2/main/installer.sh -O - | /bin/sh",
            "Ozeta-Skins-Setup": "wget https://raw.githubusercontent.com/emil237/skins-enigma2/main/PLUGIN_Skin-ozeta.sh -O - | /bin/sh",
            "Plutotv": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/main/plutotv/plutotv.sh -O - | /bin/sh",
            "Quran-karem": "wget https://dreambox4u.com/emilnabil237/plugins/quran/installer.sh -O - | /bin/sh",
            "Quran-karem_v2.2": "wget https://raw.githubusercontent.com/emil237/quran/main/installer.sh -O - | /bin/sh",
            "Radio-80-s": "wget https://raw.githubusercontent.com/Belfagor2005/Radio-80-s/main/installer.sh -O - | /bin/sh",
            "Radiom": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/main/radiom/radiom.sh -O - | /bin/sh",
            "Rakutentv": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/main/rakutentv/rakutentv.sh -O - | /bin/sh",
            "RaedQuickSignal": "wget https://dreambox4u.com/emilnabil237/plugins/RaedQuickSignal/installer.sh -O - | /bin/sh",
            "pluginmover": "wget http://dreambox4u.com/emilnabil237/plugins/pluginmover/installer.sh -O - | /bin/sh",
            "pluginskinmover": "wget http://dreambox4u.com/emilnabil237/plugins/pluginskinmover/installer.sh -O - | /bin/sh",
            "ScreenNames": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/screennames/screennames.sh -O - | /bin/sh",
            "Screen-Recorder": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/screenrecorder/installer.sh -O - | /bin/sh",
            "SetPicon": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/setpicon/installer.sh -O - | /bin/sh",
            "scriptexecuter": "wget http://dreambox4u.com/emilnabil237/plugins/scriptexecuter/installer.sh -O - | /bin/sh",
            "showclock": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/showclock/showclock.sh -O - | /bin/sh",
            "Sherlockmod": "wget https://raw.githubusercontent.com/emil237/sherlockmod/main/installer.sh -O - | /bin/sh",
            "Simple-Zoom-Panel": "wget https://dreambox4u.com/emilnabil237/plugins/simple-zoom-panel/installer.sh -O - | /bin/sh",
            "SubsSupport_1.5.8-r9": "wget https://dreambox4u.com/emilnabil237/plugins/SubsSupport/installer1.sh -O - | /bin/sh",

"SubsSupport_by-m.nasr": "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh",
            "SubsSupport_2.1": "wget https://dreambox4u.com/emilnabil237/plugins/SubsSupport/subssupport_2.1.sh -O - | /bin/sh",
            "uninstaller-Plugins": "wget http://dreambox4u.com/emilnabil237/plugins/unstaller-plugins/installer.sh -O - | /bin/sh",
            "vavoo_1.15": "wget https://dreambox4u.com/emilnabil237/plugins/vavoo/installer.sh -O - | /bin/sh",
            "xtraevent_3.3": "wget https://raw.githubusercontent.com/emil237/download-plugins/main/xtraevent_3.3.sh -O - | /bin/sh",
            "xtraevent_4.2": "wget https://raw.githubusercontent.com/emil237/download-plugins/main/xtraEvent_4.2.sh -O - | /bin/sh",
            "xtraevent_4.5": "wget https://raw.githubusercontent.com/emil237/download-plugins/main/xtraEvent_4.5.sh -O - | /bin/sh",
            "Xtraevent_4.6": "wget https://github.com/emil237/download-plugins/raw/main/Xtraevent-v4.6.sh -O - | /bin/sh",
            "xtraevent_6.798": "wget https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent_6.798.sh -O - | /bin/sh",
            "xtraevent_6.805": "wget https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent-6.805.sh -O - | /bin/sh",
            "xtraevent_6.820_All-Python": "wget https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent-6.820.sh -O - | /bin/sh",
            "WorldCam": "wget https://raw.githubusercontent.com/Belfagor2005/WorldCam/main/installer.sh -O - | /bin/sh",
            "Zip2Pkg-Converter": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/Zip2Pkg/installer.sh -O - | /bin/sh",
            "Zoom_1.1.2-Py3": "wget https://dreambox4u.com/emilnabil237/plugins/zoom/installer.sh -O - | /bin/sh"
        }
        return scripts.get(plugin_name)

    def showError(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def exit(self):
        self.close()


