from __future__ import print_function
from __future__ import absolute_import
import sys
import os
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.MessageBox import MessageBox
from .Console import Console
from enigma import eLabel, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

def _(text):
    return text

def open_file(filename, mode='r'):
    if sys.version_info[0] >= 3:
        return open(filename, mode, encoding='utf-8', errors='ignore')
    else:
        return open(filename, mode)

class channels(Screen):
    skin = """
        <screen name="channels" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder">
            <ePixmap position="1305,400" size="550,500" pixmap="%s" zPosition="0" />
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryPixmapAlphaTest(pos=(25,5), size=(40,40), png=3),
                        MultiContentEntryPixmapAlphaTest(pos=(70,5), size=(50,40), png=2),
                        MultiContentEntryText(pos=(140,10), size=(600,45), font=0, flags=RT_HALIGN_LEFT, text=0)
                    ],
                    "fonts": [gFont("Regular", 35), gFont("Regular", 25)],
                    "itemHeight": 66}
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1235,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1235,1" zPosition="2" />
            
            <eLabel position="200,900" size="250,50" backgroundColor="#8B0000" zPosition="4" />
            <widget name="key_red" position="200,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            <eLabel position="500,900" size="250,50" backgroundColor="#006400" zPosition="4" />
            <widget name="key_green" position="500,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel position="800,900" size="250,50" backgroundColor="#C9A000" zPosition="4" />
           <eLabel backgroundColor="#00ffffff" position="1285,195" size="1,665" zPosition="2" /> 
            <widget name="key_yellow" position="800,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="black" font="Regular;30" transparent="1" />
        </screen>""" % resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/background.png")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle("Panel Manager")
        self.selected_plugins = []
        
        self.checked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/checked.png"))
        self.unchecked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/unchecked.png"))
        self.plugin_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/channels.png"))

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.installSelected,
            "yellow": self.toggleSelection,
        })

        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Install"))
        self["key_yellow"] = Label(_("Select") + " (0)")

        self.list = []
        self["menu"] = List(self.list)
        self.load_plugins_list()
        self.mList()

    def load_plugins_list(self):
        self.all_plugins = [
            _("Elsafty-Tv-Radio-Steaming"),
            _("Hazem-Wahba"),
            _("Khaled Ali"),
            _("Mohamed Goda"),
            _("Mohamed-Nasr"),
            _("Emil Nabil"),
            _("Tarek Ashry"),
            _("Tuner_Backup_By-Emil-Nabil"),
            _("Tuner_Backup_By-M-Goda")
        ]

    def mList(self):
        self.list = []
        for plugin_name in self.all_plugins:
            if plugin_name in self.selected_plugins:
                icon = self.checked_icon
            else:
                icon = self.unchecked_icon
            self.list.append((plugin_name, plugin_name, self.plugin_icon, icon))
        
        self["menu"].setList(self.list)
        self.update_selection_count()

    def toggleSelection(self):
        current = self["menu"].getCurrent()
        if current:
            index = self["menu"].getIndex()
            plugin_name = current[0]
            
            if plugin_name in self.selected_plugins:
                self.selected_plugins.remove(plugin_name)
                new_icon = self.unchecked_icon
            else:
                self.selected_plugins.append(plugin_name)
                new_icon = self.checked_icon
            
            self.list[index] = (
                plugin_name,
                plugin_name,
                current[2],
                new_icon
            )
            self["menu"].updateList(self.list)
            self.update_selection_count()

    def update_selection_count(self):
        self["key_yellow"].setText(_("Select") + " (" + str(len(self.selected_plugins)) + ")")

    def installSelected(self):
        if not self.selected_plugins:
            self.showError(_("No plugins selected"))
            return

        self.install_scripts = []
        for plugin in self.selected_plugins:
            script = self.get_script(plugin)
            if not script:
                self.showError(_("Script not found for %s") % plugin)
                return
            self.install_scripts.append(script)

        self.session.openWithCallback(
            self.confirmInstallSelected,
            MessageBox,
            _("Install %d selected plugins?") % len(self.selected_plugins),
            MessageBox.TYPE_YESNO
        )

    def confirmInstallSelected(self, answer):
        if not answer or not hasattr(self, 'install_scripts'):
            return

        try:
            with open_file("/tmp/install_script.sh", "w") as f:
                f.write("#!/bin/sh\n")
                f.write("\n".join(self.install_scripts) + "\n")

            self.session.open(
                Console,
                title=_("Installing selected plugins"),
                cmdlist=[
                    "chmod +x /tmp/install_script.sh",
                    "/bin/sh /tmp/install_script.sh"
                ],
                closeOnSuccess=True
            )

            self.selected_plugins = []
            if hasattr(self, 'install_scripts'):
                del self.install_scripts
            self.mList()
        except Exception as e:
            self.showError(str(e))

    def keyOK(self):
        current = self["menu"].getCurrent()
        if current:
            plugin_name = current[0]
            self.installPlugin(plugin_name)
        else:
            self.showError(_("No plugin selected"))

    def installPlugin(self, plugin_name):
        script = self.get_script(plugin_name)
        if script:
            self.session.openWithCallback(
                lambda answer: self.executeInstall(answer, plugin_name),
                MessageBox,
                _("Install %s?") % plugin_name,
                MessageBox.TYPE_YESNO
            )
        else:
            self.showError(_("Script not found"))

    def executeInstall(self, answer, plugin_name):
        if answer:
            try:
                with open_file("/tmp/install_script.sh", "w") as f:
                    f.write("#!/bin/sh\n" + self.get_script(plugin_name) + "\n")

                self.session.open(
                    Console,
                    title=_("Installing %s") % plugin_name,
                    cmdlist=[
                        "chmod +x /tmp/install_script.sh",
                        "/bin/sh /tmp/install_script.sh"
                    ],
                    closeOnSuccess=True
                )
            except Exception as e:
                self.showError(str(e))

    def get_script(self, plugin_name):
        scripts = {
            "Elsafty-Tv-Radio-Steaming": 'wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/settings/elsafty/installer.sh -O - | /bin/sh',
            "Hazem-Wahba": "wget https://raw.githubusercontent.com/emilnabil/channel-hazem-wahba/main/installer.sh -O - | /bin/sh",
            "Khaled Ali": "wget https://raw.githubusercontent.com/emilnabil/channel-khaled/main/installer.sh -O - | /bin/sh",
            "Mohamed Goda": "wget https://raw.githubusercontent.com/emilnabil/channel-mohamed-goda/main/installer.sh -O - | /bin/sh",
            "Mohamed-Nasr": "wget https://raw.githubusercontent.com/emilnabil/channel-mnasr/main/installer.sh -O - | /bin/sh",
            "Emil Nabil": "wget https://raw.githubusercontent.com/emilnabil/channel-emil-nabil/main/installer.sh -O - | /bin/sh",
            "Tarek Ashry": "wget https://raw.githubusercontent.com/emilnabil/channel-tarek-ashry/main/installer.sh -O - | /bin/sh",
            "Tuner_Backup_By-Emil-Nabil": "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/restore-tuner-emil.sh -O - | /bin/sh",
            "Tuner_Backup_By-M-Goda": "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/restore-tuner-goda.sh -O - | /bin/sh"
        }
        return scripts.get(plugin_name)

    def showError(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def exit(self):
        self.close()

