from __future__ import print_function
from __future__ import absolute_import
import sys
import os
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Screens.MessageBox import MessageBox
from .Console import Console
from enigma import eLabel, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

def _(text):
    return text

def open_file(filename, mode='r'):
    if sys.version_info[0] >= 3:
        return open(filename, mode, encoding='utf-8', errors='ignore')
    else:
        return open(filename, mode)

class mediamain(Screen):
    skin = """
        <screen name="mediamain" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder">
            <ePixmap position="1305,400" size="550,500" pixmap="%s" zPosition="0" />
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryPixmapAlphaTest(pos=(25,5), size=(40,40), png=3),
                        MultiContentEntryPixmapAlphaTest(pos=(70,5), size=(50,40), png=2),
                        MultiContentEntryText(pos=(140,10), size=(600,45), font=0, flags=RT_HALIGN_LEFT, text=0)
                    ],
                    "fonts": [gFont("Regular", 35), gFont("Regular", 25)],
                    "itemHeight": 66}
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1235,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1235,1" zPosition="2" />
            
            <eLabel position="200,900" size="250,50" backgroundColor="#8B0000" zPosition="4" />
            <widget name="key_red" position="200,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            <eLabel position="500,900" size="250,50" backgroundColor="#006400" zPosition="4" />
            <widget name="key_green" position="500,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="white" font="Regular;30" transparent="1" />
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel position="800,900" size="250,50" backgroundColor="#C9A000" zPosition="4" />
            <eLabel backgroundColor="#00ffffff" position="1285,195" size="1,665" zPosition="2" /> 
            <widget name="key_yellow" position="800,900" size="250,50" valign="center" halign="center" zPosition="5" foregroundColor="black" font="Regular;30" transparent="1" />
        </screen>""" % resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/background2.png")

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.setTitle("Panel Manager")
        self.selected_plugins = []
        
        self.checked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/checked.png"))
        self.unchecked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/unchecked.png"))
        self.plugin_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/media.png"))

        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"], {
            "ok": self.keyOK,
            "cancel": self.exit,
            "back": self.exit,
            "red": self.exit,
            "green": self.installSelected,
            "yellow": self.toggleSelection,
        })

        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Install"))
        self["key_yellow"] = Label(_("Select") + " (0)")

        self.list = []
        self["menu"] = List(self.list)
        self.load_plugins_list()
        self.mList()

    def load_plugins_list(self):
        self.all_plugins = [
            _("BouquetMakerXtream"),
            _("E2m3u2Bouquet"),
            _("E2Player-MAXBAMBY"),
            _("E2Player-ZADMARIO"),
            _("IptoSat"),
            _("IpAudio_6.7_py2"),
            _("IpAudio_7.4_py3"),
            
            _("IpAudio_8.02_All-Python"),
            _("IpAudioPro"), 
            _("JediEpgExtream"), 
            _("jedimakerxtream"), 
            _("multistalker"),
            _("MultiStalkerPro"), 
            _("Quarter pounder"), 
            _("Suptv"), 
            _("YouTube"), 
            _("xklass-iptv"), 
            _("Xtreamty"),
            _("Xcpluginforever")
        ]

    def mList(self):
        self.list = []
        for plugin_name in self.all_plugins:
            if plugin_name in self.selected_plugins:
                icon = self.checked_icon
            else:
                icon = self.unchecked_icon
            self.list.append((plugin_name, plugin_name, self.plugin_icon, icon))
        
        self["menu"].setList(self.list)
        self.update_selection_count()

    def toggleSelection(self):
        current = self["menu"].getCurrent()
        if current:
            index = self["menu"].getIndex()
            plugin_name = current[0]
            
            if plugin_name in self.selected_plugins:
                self.selected_plugins.remove(plugin_name)
                new_icon = self.unchecked_icon
            else:
                self.selected_plugins.append(plugin_name)
                new_icon = self.checked_icon
            
            self.list[index] = (
                plugin_name,
                plugin_name,
                current[2],
                new_icon
            )
            self["menu"].updateList(self.list)
            self.update_selection_count()

    def update_selection_count(self):
        self["key_yellow"].setText(_("Select") + " (" + str(len(self.selected_plugins)) + ")")

    def installSelected(self):
        if not self.selected_plugins:
            self.showError(_("No plugins selected"))
            return

        self.install_scripts = []
        for plugin in self.selected_plugins:
            script = self.get_script(plugin)
            if not script:
                self.showError(_("Script not found for %s") % plugin)
                return
            self.install_scripts.append(script)

        self.session.openWithCallback(
            self.confirmInstallSelected,
            MessageBox,
            _("Install %d selected plugins?") % len(self.selected_plugins),
            MessageBox.TYPE_YESNO
        )

    def confirmInstallSelected(self, answer):
        if not answer or not hasattr(self, 'install_scripts'):
            return

        try:
            with open_file("/tmp/install_script.sh", "w") as f:
                f.write("#!/bin/sh\n")
                f.write("\n".join(self.install_scripts) + "\n")

            self.session.open(
                Console,
                title=_("Installing selected plugins"),
                cmdlist=[
                    "chmod +x /tmp/install_script.sh",
                    "/bin/sh /tmp/install_script.sh"
                ],
                closeOnSuccess=True
            )

            self.selected_plugins = []
            if hasattr(self, 'install_scripts'):
                del self.install_scripts
            self.mList()
        except Exception as e:
            self.showError(str(e))

    def keyOK(self):
        current = self["menu"].getCurrent()
        if current:
            plugin_name = current[0]
            self.installPlugin(plugin_name)
        else:
            self.showError(_("No plugin selected"))

    def installPlugin(self, plugin_name):
        script = self.get_script(plugin_name)
        if script:
            self.session.openWithCallback(
                lambda answer: self.executeInstall(answer, plugin_name),
                MessageBox,
                _("Install %s?") % plugin_name,
                MessageBox.TYPE_YESNO
            )
        else:
            self.showError(_("Script not found"))

    def executeInstall(self, answer, plugin_name):
        if answer:
            try:
                with open_file("/tmp/install_script.sh", "w") as f:
                    f.write("#!/bin/sh\n" + self.get_script(plugin_name) + "\n")

                self.session.open(
                    Console,
                    title=_("Installing %s") % plugin_name,
                    cmdlist=[
                        "chmod +x /tmp/install_script.sh",
                        "/bin/sh /tmp/install_script.sh"
                    ],
                    closeOnSuccess=True
                )
            except Exception as e:
                self.showError(str(e))

    def get_script(self, plugin_name):
        scripts = {
            "BouquetMakerXtream": "wget -q --no-check-certificate http://dreambox4u.com/emilnabil237/plugins/BouquetMakerXtream/installer.sh -O - | /bin/sh",
            "E2m3u2Bouquet": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/e2m3u2bouquet/installer.sh -O - | /bin/sh",
            "E2Player-MAXBAMBY": "wget -q --no-check-certificate https://gitlab.com/maxbambi/e2iplayer/-/raw/master/install-e2iplayer.sh -O - | /bin/sh",
            "E2Player-ZADMARIO": "wget -q --no-check-certificate https://gitlab.com/zadmario/e2iplayer/-/raw/master/install-e2iplayer.sh -O - | /bin/sh",
            "IptoSat": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/iptosat/installer.sh -O - | /bin/sh",
            "IpAudio_6.7_py2": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudio/installer.sh -O - | /bin/sh",
            "IpAudio_7.4_py3": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudio/ipaudio-7.4-ffmpeg.sh -O - | /bin/sh",
            
            "IpAudio_8.02_All-Python": "wget -q --no-check-certificate https://github.com/emil237/ipaudio/raw/refs/heads/main/ipaudio_8.0.sh -O - | /bin/sh",
            "IpAudioPro": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/ipaudiopro/installer.sh -O - | /bin/sh",
            "JediEpgExtream": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/jediepgextream/installer.sh -O - | /bin/sh",
            "jedimakerxtream": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/jedimakerxtream/installer.sh -O - | /bin/sh",
            "multistalker": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/multistalker/installer.sh -O - | /bin/sh",
            "MultiStalkerPro": "wget -q --no-check-certificate https://raw.githubusercontent.com/emilnabil/multi-stalkerpro/main/installer.sh -O - | /bin/sh",
            "Quarter pounder": "wget -q --no-check-certificate http://dreambox4u.com/emilnabil237/script/quarterpounder.sh -O - | /bin/sh",
            "Suptv": "wget -q --no-check-certificate https://raw.githubusercontent.com/emil237/suptv/main/installer.sh -O - | /bin/sh",
            "YouTube": "wget -q --no-check-certificate https://raw.githubusercontent.com/fairbird/Youtube-Opensource-DreamOS/master/installer.sh -O - | /bin/sh",
            "xklass-iptv": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/xklass/installer.sh -O - | /bin/sh",
            "Xtreamty": "wget -q --no-check-certificate https://dreambox4u.com/emilnabil237/plugins/xtreamity/installer.sh -O - | /bin/sh",
            "Xcpluginforever": "wget -q --no-check-certificate https://raw.githubusercontent.com/Belfagor2005/xc_plugin_forever/main/installer.sh -O - | /bin/sh"
        }
        return scripts.get(plugin_name)

    def showError(self, message):
        self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)

    def exit(self):
        self.close()