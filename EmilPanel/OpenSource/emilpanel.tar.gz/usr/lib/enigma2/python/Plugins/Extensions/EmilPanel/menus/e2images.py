# -*- coding: utf-8 -*-
from __future__ import print_function
from __future__ import absolute_import
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sources.List import List
from Components.ProgressBar import ProgressBar
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from enigma import eTimer, gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, getDesktop
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists
import sys
import os
import re
import threading
import shutil
import time

PY3 = sys.version_info[0] == 3

if PY3:
    import urllib.request
    import urllib.parse
    import urllib.error
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
else:
    import urllib2
    from urllib2 import urlopen, Request
    from urllib2 import URLError, HTTPError

USER_AGENT = 'Enigma2-Image-Downloader/1.0'

FEEDS = {
    "OpenATV": "https://images.mynonpublic.com/openatv/json/{box}",
    "OpenBH": "https://images.openbh.net/json/{box}",
    "OpenDroid": "https://opendroid.org/json.php?box={box}",
    "TeamBlue": "https://images.teamblue.tech/json/{box}",
    "Pure2": "https://www.pur-e2.club/OU/images/json/{box}",
    "OpenViX": "https://www.openvix.co.uk/json/{box}",
    "OpenPLi": "https://downloads.openpli.org/json/{box}",
    "OpenSPA": "https://openspa.webhop.info/online/json.php?box={box}",
    "OpenVision": "https://images.openvision.dedyn.io/json/{box}",
    "Egami": "https://image.egami-image.com/json/{box}",
    "OpenHDF": "https://flash.hdfreaks.cc/openhdf/json/{box}",
    "Novaler": "https://novaler.com/downloads/enigma2/{box}"
}

GROUPS = [
    ["classm", "starsatlx", "genius", "evo", "galaxym6", "axodin", "axodinc", "odinm7"],
    ["geniuse3hd", "evoe3hd", "axase3", "axase3c", "e3hd"],
    ["maram9", "odinm9"],
    ["ventonhdx", "sezam5000hd", "mbtwin", "beyonwizt3", "inihdx"],
    ["sezam1000hd", "xpeedlx1", "xpeedlx2", "mbmini", "atemio5x00", "bwidowx", "inihde"],
    ["atemio6000", "atemio6100", "atemio6200", "mbminiplus", "mbhybrid", "bwidowx2", "beyonwizt2", "opticumtt", "evoslim", "xpeedlxpro", "inihde2"],
    ["xpeedlx3", "sezammarvel", "atemionemesis", "mbultra", "beyonwizt4", "inihdp"],
    ["xp1000mk", "xp1000max", "sf8", "xp1000plus", "xp1000"],
    ["mixoslumi", "eboxlumi"],
    ["mixosf7", "ebox7358"],
    ["mixosf5mini", "gi9196lite", "ebox5100"],
    ["mixosf5", "gi9196m", "ebox5000"],
    ["sogno8800hd", "uniboxhde", "blackbox7405"],
    ["enfinity", "marvel1", "ew7358"],
    ["mutant2400", "quadbox2400", "hd2400"],
    ["mutant11", "hd11"],
    ["mutant1100", "vizyonvita", "hd1100"],
    ["mutant1200", "hd1200"],
    ["mutant1265", "hd1265"],
    ["mutant1500", "hd1500"],
    ["mutant500c", "hd500c"],
    ["mutant530c", "hd530c"],
    ["vimastec1000", "vs1000"],
    ["enibox", "mago", "x1plus", "sf108", "vg5000"],
    ["t2cable", "jj7362"],
    ["x2plus", "ew7356"],
    ["bre2ze", "ew7362"],
    ["evomini", "ch62lc"],
    ["zgemmash1", "zgemmas2s", "zgemmass", "zgemmash2", "sh1"],
    ["zgemmahs", "zgemmah2s", "zgemmah2h", "novatwin", "novacombo", "zgemmah3ac", "zgemmah32tc", "zgemmah2splus", "h3"],
    ["zgemmaslc", "lc"],
    ["zgemmai55", "novaip", "i55"],
    ["zgemmai55plus", "i55plus"],
    ["zgemmai55se", "i55se"],
    ["zgemmah4", "h4"],
    ["zgemmah5", "zgemmah52s", "zgemmah5ac", "zgemmah52tc", "zgemmah52splus", "h5"],
    ["zgemmah6", "h6"],
    ["zgemmah7", "h7", "zgemmah7s", "multibox-4k-ultra-hd"],
    ["zgemmah17combo", "h17"],
    ["zgemmah82h", "h8"],
    ["zgemmah9s", "zgemmah9t", "zgemmah9splus", "zgemmah92s", "zgemmah92h", "h9"],
    ["zgemmah92hse", "zgemmah9sse", "h9se"],
    ["zgemmah9combose", "zgemmah9twinse", "h9combose"],
    ["zgemmah9combo", "zgemmah9twin", "h9combo"],
    ["zgemmah102s", "zgemmah102h", "zgemmah10combo", "h10"],
    ["zgemmah11s", "zgemmah112h", "h11"],
    ["zgemmahzeros", "hzero"],
    ["xcombo", "vg2000"],
    ["tyrant", "vg1000"],
    ["mbmicro", "e4hd", "e4hdhybrid", "7000s"],
    ["mbmicrov2", "7005s"],
    ["twinboxlcd", "singleboxlcd", "7100s"],
    ["twinboxlcdci5", "7105s"],
    ["sf208", "sf228", "7210s"],
    ["sf238", "7215s"],
    ["9910lx", "7220s"],
    ["9911lx", "e4hdcombo", "9920lx", "7225s"],
    ["odin2hybrid", "7300s"],
    ["odinplus", "7400s"],
    ["e4hdultra", "protek4k", "8100s"],
    ["xpeedlxcs2", "xpeedlxcc", "et7x00mini", "ultramini"],
    ["mbtwinplus", "sf3038", "alphatriple", "g300"],
    ["sf128", "sf138", "g100"],
    ["bre2zet2c", "g101"],
    ["osmega", "xc7346"],
    ["spycat", "osmini", "spycatmini", "osminiplus", "spycatminiplus", "xc7362"],
    ["spycat4kmini", "spycat4k", "spycat4kcombo", "xc7439"],
    ["dcube", "mkcube", "ultima", "cube"],
    ["amikomini", "dynaspark", "dynasparkplus", "amiko8900", "sognorevolution", "arguspingulux", "arguspinguluxmini", "arguspinguluxplus", "sparkreloaded", "sabsolo", "fulanspark1", "sparklx", "gis8120", "spark"],
    ["dynaspark7162", "amikoalien", "sognotriple", "sparktriplex", "sabtriple", "sparkone", "giavatar", "spark7162"],
    ["tm2t", "tmnano", "tmnano2t", "tmsingle", "tmtwin", "iqonios100hd", "iqonios300hd", "iqonios300hdv2", "optimussos1", "mediabox", "iqonios200hd", "roxxs200hd", "mediaart200hd", "optimussos2", "dags7335"],
    ["tmnano2super", "tmnano3t", "force1", "force1plus", "megaforce1plus", "worldvisionf1", "worldvisionf1plus", "optimussos1plus", "optimussos2plus", "optimussos3plus", "dags7356"],
    ["tmnanose", "tmnanosem2", "tmnanosem2plus", "tmnanosecombo", "force2plus", "force2", "megaforce2", "optimussos", "force2se", "fusionhd", "fusionhdse", "purehd", "force2nano", "tmnanom3", "valalinux", "dags7362"],
    ["force2plushv", "purehdse", "lunix", "lunixco", "dags73625"],
    ["revo4k", "force3uhd", "force3uhdplus", "tmtwin4k", "galaxy4k", "tm4ksuper", "lunix34k", "dags7252"],
    ["force4", "lunix4k", "dags72604"],
    ["gb800se", "gb800ue", "gb7325"],
    ["gb800seplus", "gb800ueplus", "gbipbox", "gb7358"],
    ["gbultrase", "gbultraue", "gbx1", "gbx3", "gb7362"],
    ["gbx2", "gbultraueh", "gbx3h", "gb73625"],
    ["gbquad", "gbquadplus", "gb7356"],
    ["gbquad4k", "gbue4k", "gbquad4kpro", "gb7252"],
    ["gbx34k", "gb72604"],
    ["gbtrio4k", "gbip4k", "gbtrio4kpro", "gbmv200"],
    ["sf98", "force2nano", "evoslimse", "yh7362"],
    ["evoslimt2c", "yh62tc"],
    ["vipert2c", "yh625tc"],
    ["vipercombo", "yh625dt"],
    ["vipercombohdd", "ch625dt"],
    ["viperslim", "yh73625"],
    ["mutant51", "ax51", "bre2ze4k", "hd51"],
    ["mutant60", "ax60", "hd60"],
    ["mutant61", "ax61", "hd61"],
    ["mutant66se", "hd66se"],
    ["vimastec1500", "vs1500"],
    ["gi11000", "viper4k51", "et1x000"],
    ["beyonwizu4", "et13000"],
    ["dinoboth265", "axashistwin", "u41"],
    ["spycatminiv2", "anadolprohd5", "iziboxecohd", "jdhdduo", "vipertwin", "vipersingle", "u42"],
    ["turing", "u43"],
    ["axashistwinplus", "u45"],
    ["dinobot4k", "mediabox4k", "anadol4k", "u5"],
    ["axashis4kcombo", "dinobot4kl", "anadol4kv2", "anadol4kcombo", "protek4kx1", "u51"],
    ["dinobot4kplus", "axashis4kcomboplus", "u52"],
    ["dinobot4kmini", "u53"],
    ["arivacombo", "u532"],
    ["arivatwin", "u533"],
    ["dinobot4kpro", "u54"],
    ["dinobotu55", "iziboxone4k", "hitube4k", "iziboxx3", "u55"],
    ["axashisc4k", "dinobot4kelite", "u56"],
    ["viper4kv20", "protek4kx2", "iziboxelite4k", "dinobot4ktwin", "hitube4kpro", "viper4kv30", "hitube4kplus", "iziboxx4", "u57"],
    ["iziboxone4kplus", "viper4kv40", "u571"],
    ["dinobot4kse", "ferguson4k", "u5pvr"],
    ["clap4k", "cc1"],
    ["maxytecmultise", "axmultiboxse", "anadolmultiboxse", "novaler4kse", "multiboxse", "multibox-4k-se-ultra-hd"],
    ["anadolmulti", "maxytecmulti", "anadolmultitwin", "axmulticombo", "axmultitwin", "novaler4k", "multibox", "multibox-4k-ultra-hd"],
    ["novaler4kpro", "multiboxpro", "multibox-4k-pro-ultra-hd"]
]

class DownloadProgressScreen(Screen):
    skin = """
    <screen name="DownloadProgressScreen" position="center,center" size="800,400" title="Download Progress">
        <widget name="title" position="20,20" size="760,40" font="Regular;30" halign="center" />
        <widget name="filename" position="20,70" size="760,30" font="Regular;24" halign="left" />
        <widget name="progress" position="20,110" size="760,30" />
        <widget name="percentage" position="20,150" size="380,30" font="Regular;24" halign="left" />
        <widget name="speed" position="400,150" size="380,30" font="Regular;24" halign="right" />
        <widget name="size" position="20,190" size="380,30" font="Regular;24" halign="left" />
        <widget name="time" position="400,190" size="380,30" font="Regular;24" halign="right" />
        <widget name="status" position="20,240" size="760,30" font="Regular;24" halign="center" />
        <widget name="key_red" position="20,290" size="360,60" font="Regular;28" valign="center" halign="center" backgroundColor="#9f1313" foregroundColor="white" transparent="0" />
        <widget name="key_green" position="420,290" size="360,60" font="Regular;28" valign="center" halign="center" backgroundColor="#1f771f" foregroundColor="white" transparent="0" />
    </screen>
    """

    def __init__(self, session, url, filename):
        Screen.__init__(self, session)
        self.session = session
        self.url = url
        self.filename = filename
        self.download_cancelled = False
        self.download_active = False
        self.download_thread = None
        
        self.total_size = 0
        self.downloaded_size = 0
        self.start_time = 0
        self.last_update_time = 0
        self.last_downloaded = 0
        
        self["title"] = Label("Downloading...")
        self["filename"] = Label(filename)
        self["progress"] = ProgressBar()
        self["percentage"] = Label("0%")
        self["speed"] = Label("0 KB/s")
        self["size"] = Label("0 MB / 0 MB")
        self["time"] = Label("Time: --:--")
        self["status"] = Label("Initializing...")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Background")
        
        self.update_timer = eTimer()
        self.update_timer.timeout.get().append(self.update_display)
        
        self["actions"] = ActionMap(["ColorActions"], {
            "red": self.cancel_download,
            "green": self.background_download,
        }, -1)
        
        self.onLayoutFinish.append(self.start_download)
    
    def format_size(self, bytes):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes < 1024.0:
                return "%.1f %s" % (bytes, unit)
            bytes /= 1024.0
        return "%.1f TB" % bytes
    
    def format_speed(self, bytes_per_sec):
        if bytes_per_sec < 1024:
            return "%.0f B/s" % bytes_per_sec
        elif bytes_per_sec < 1024 * 1024:
            return "%.1f KB/s" % (bytes_per_sec/1024)
        else:
            return "%.1f MB/s" % (bytes_per_sec/(1024*1024))
    
    def format_time(self, seconds):
        if seconds < 0:
            return "--:--"
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return "%02d:%02d" % (minutes, secs)
    
    def update_display(self):
        if not self.download_active:
            return
        
        if self.total_size > 0:
            percentage = (self.downloaded_size / self.total_size) * 100
            self["progress"].setValue(int(percentage))
            self["percentage"].setText("%.1f%%" % percentage)
            
            self["size"].setText("%s / %s" % (self.format_size(self.downloaded_size), self.format_size(self.total_size)))
            
            current_time = time.time()
            time_diff = current_time - self.last_update_time
            
            if time_diff >= 1.0:
                downloaded_diff = self.downloaded_size - self.last_downloaded
                speed = downloaded_diff / time_diff if time_diff > 0 else 0
                
                self["speed"].setText(self.format_speed(speed))
                
                if speed > 0:
                    remaining = (self.total_size - self.downloaded_size) / speed
                    self["time"].setText("Time: %s" % self.format_time(remaining))
                else:
                    self["time"].setText("Time: --:--")
                
                self.last_update_time = current_time
                self.last_downloaded = self.downloaded_size
    
    def start_download(self):
        self.download_active = True
        self.start_time = time.time()
        self.last_update_time = self.start_time
        self.last_downloaded = 0
        
        self.update_timer.start(100)
        self.download_thread = threading.Thread(target=self.download_file)
        self.download_thread.start()
    
    def download_file(self):
        try:
            download_paths = [
                "/media/hdd/images",
                "/media/usb/images",
                "/media/ba/images",
                "/tmp"
            ]
            
            target_dir = "/tmp"
            for path in download_paths:
                if os.path.exists(path):
                    target_dir = path
                    break
            
            if not os.path.exists(target_dir):
                os.makedirs(target_dir)
            
            clean_filename = re.sub(r'[<>:"/\\|?*]', '_', self.filename)
            target_path = os.path.join(target_dir, clean_filename)
            
            req = Request(self.url)
            req.add_header('User-Agent', USER_AGENT)
            
            try:
                if PY3:
                    response = urlopen(req, timeout=30)
                else:
                    response = urlopen(req, timeout=30)
                
                if PY3:
                    content_length = response.getheader('Content-Length')
                else:
                    content_length = response.headers.get('Content-Length')
                
                self.total_size = int(content_length) if content_length else 0
                
                chunk_size = 8192
                downloaded = 0
                
                with open(target_path, 'wb') as f:
                    while True:
                        if self.download_cancelled:
                            response.close()
                            if os.path.exists(target_path):
                                os.remove(target_path)
                            self.download_active = False
                            self.update_timer.stop()
                            self.close(False)
                            return
                        
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        
                        f.write(chunk)
                        downloaded += len(chunk)
                        self.downloaded_size = downloaded
                
                if not self.download_cancelled:
                    self.update_timer.stop()
                    self.download_active = False
                    
                    self.copy_to_backup_locations(target_path)
                    
                    self["status"].setText("Download completed successfully!")
                    self["key_green"].setText("OK")
                    
                    self.close(True)
                    
            except Exception as e:
                raise e
                
        except Exception as e:
            self.update_timer.stop()
            self.download_active = False
            self["status"].setText("Error: %s" % str(e))
            self["key_green"].setText("Close")
    
    def copy_to_backup_locations(self, source_path):
        backup_locations = [
            "/media/hdd/ImagesUpload",
            "/media/usb/ImagesUpload",
            "/media/hdd/open-multiboot-upload",
            "/media/usb/open-multiboot-upload",
            "/media/hdd/OPDBootUpload",
            "/media/usb/OPDBootUpload"
        ]
        
        for location in backup_locations:
            if os.path.exists(os.path.dirname(location)):
                if not os.path.exists(location):
                    try:
                        os.makedirs(location, 0o755)
                    except:
                        continue
                try:
                    dest = os.path.join(location, os.path.basename(source_path))
                    shutil.copy2(source_path, dest)
                except:
                    pass
    
    def cancel_download(self):
        if self.download_active:
            self.download_cancelled = True
            self["status"].setText("Cancelling download...")
            self["key_red"].setText("Cancelling...")
    
    def background_download(self):
        if self.download_active:
            self.session.open(
                MessageBox,
                "Download will continue in background. You can check status in main screen.",
                MessageBox.TYPE_INFO
            )
            self.close(True)
        else:
            self.close(True)
    
    def close(self, success=False):
        self.update_timer.stop()
        self.download_cancelled = True
        Screen.close(self, success)


class E2ImagesScreen(Screen):
    skin = """
    <screen name="E2ImagesScreen" position="center,center" size="1100,900" title="E2 Images Downloader">
        <widget name="title" position="20,20" size="1060,50" font="Regular;32" halign="left" />
        <widget name="logo" position="1000,20" size="80,50" transparent="1" />
        <widget source="list" render="Listbox" position="20,90" size="1060,700" scrollbarMode="showOnDemand">
            <convert type="TemplatedMultiContent">
                {"template": [
                    MultiContentEntryText(pos=(5,0), size=(1050,45), font=0, flags=RT_HALIGN_LEFT, text=0),
                ],
                "fonts": [gFont("Regular", 30)],
                "itemHeight": 55}
            </convert>
        </widget>
        <widget name="status" position="20,800" size="1060,40" font="Regular;35" halign="left" />
        <widget name="key_red" position="20,850" size="250,40" font="Regular;28" valign="center" halign="center" backgroundColor="#9f1313" foregroundColor="white" transparent="0" />
        <widget name="key_green" position="290,850" size="250,40" font="Regular;28" valign="center" halign="center" backgroundColor="#1f771f" foregroundColor="white" transparent="0" />
        <widget name="key_yellow" position="560,850" size="250,40" font="Regular;28" valign="center" halign="center" backgroundColor="#a08500" foregroundColor="white" transparent="0" />
        <widget name="key_blue" position="830,850" size="250,40" font="Regular;28" valign="center" halign="center" backgroundColor="#18188b" foregroundColor="white" transparent="0" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self.hostname = self._get_hostname()
        self.box_fallbacks = self._create_box_fallbacks()
        
        self.list_items = []
        self["list"] = List(self.list_items)
        self["logo"] = Pixmap()
        
        self["title"] = Label("E2 Images Downloader")
        self["status"] = Label("Ready")
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Select")
        self["key_yellow"] = Label("Refresh")
        self["key_blue"] = Label("Info")
        
        self.current_view = "feeds"
        self.current_feed = None
        self.feed_data = {}
        self.expanded_categories = []
        self.loading = False
        
        self.timer = eTimer()
        
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.ok_pressed,
            "cancel": self.cancel_pressed,
            "red": self.cancel_pressed,
            "green": self.select_pressed,
            "yellow": self.refresh_pressed,
            "blue": self.info_pressed,
        }, -1)
        
        self.onLayoutFinish.append(self._onLayoutFinish)
    
    def _onLayoutFinish(self):
        self.load_logo()
        self.load_feeds()
        if len(self.list_items) > 0:
            self["list"].setIndex(0)
    
    def _get_hostname(self):
        try:
            with open("/etc/hostname", "r") as f:
                return f.readline().strip()
        except:
            try:
                return os.uname().nodename.strip()
            except:
                return "unknown"
    
    def _create_box_fallbacks(self):
        box_fallbacks = {}
        for group in GROUPS:
            for hostname in group:
                box_fallbacks[hostname] = group
        return box_fallbacks
    
    def load_logo(self):
        priority_paths = [
            "/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/images/e2images.png",
            "/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/e2images.png",
            "/usr/share/enigma2/e2images.png",
            "/usr/share/enigma2/skin_default/e2images.png",
            "/usr/share/enigma2/skin_default/icons/e2images.png"
        ]
        
        for logo_path in priority_paths:
            if fileExists(logo_path):
                pixmap = LoadPixmap(logo_path)
                if pixmap:
                    self["logo"].instance.setPixmap(pixmap)
                    return
        
        logo_names = ["images.png"]
        logo_dirs = [
            "/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/images/",
            "/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/",
            "/usr/share/enigma2/",
            "/usr/share/enigma2/skin_default/",
            "/usr/share/enigma2/skin_default/icons/"
        ]
        
        for logo_name in logo_names:
            for logo_dir in logo_dirs:
                logo_path = os.path.join(logo_dir, logo_name)
                if fileExists(logo_path):
                    pixmap = LoadPixmap(logo_path)
                    if pixmap:
                        self["logo"].instance.setPixmap(pixmap)
                        return
    
    def get_box_list(self, feed_name):
        if self.hostname in self.box_fallbacks:
            return self.box_fallbacks[self.hostname]
        return [self.hostname]
    
    def load_feeds(self):
        self.current_view = "feeds"
        self.current_feed = None
        self.feed_data = {}
        self.expanded_categories = []
        self.list_items = []
        
        for feed_name in sorted(FEEDS.keys()):
            self.list_items.append(("▶ %s" % feed_name, feed_name, "feed"))
        
        self["list"].setList(self.list_items)
        if len(self.list_items) > 0:
            self["list"].setIndex(0)
        
        self["title"].setText("Select Image Feed")
        self["status"].setText("Device: %s" % self.hostname)
        self["key_red"].setText("Cancel")
    
    def load_feed_data(self, feed_name):
        self.loading = True
        self["status"].setText("Loading %s..." % feed_name)
        
        thread = threading.Thread(target=self.fetch_feed_thread, args=(feed_name,))
        thread.start()
        
        self.timer.callback.append(self.update_feed_display)
        self.timer.start(500, True)
    
    def fetch_feed_thread(self, feed_name):
        try:
            url_template = FEEDS[feed_name]
            box_list = self.get_box_list(feed_name)
            parsed = {}
            
            for box in box_list:
                try:
                    url = url_template.format(box=box)
                    req = Request(url)
                    req.add_header('User-Agent', USER_AGENT)
                    
                    try:
                        if PY3:
                            response = urlopen(req, timeout=15)
                        else:
                            response = urlopen(req, timeout=15)
                        
                        if PY3:
                            content = response.read().decode('utf-8')
                        else:
                            content = response.read()
                        
                        if feed_name == "Novaler":
                            matches = re.findall(r'/uploads[^"]*\.zip', content)
                            for href in matches:
                                parts = href.strip("/").split("/")
                                if len(parts) >= 2:
                                    category = parts[-2]
                                    file_name = parts[-1]
                                    full_link = "https://novaler.com" + href
                                    parsed.setdefault(str(category), {})[str(file_name)] = {
                                        "link": str(full_link),
                                        "name": str(file_name)
                                    }
                        
                        elif feed_name == "OpenSPA":
                            lines = content.splitlines()
                            current_version = ""
                            for line in lines:
                                line = line.strip()
                                if '"OPENSPA' in line:
                                    current_version = line.replace('{', '').replace('}', '').replace('"', '').replace(',', '').replace(':', '').strip()
                                    parsed.setdefault(str(current_version), {})
                                elif '"name"' in line and current_version:
                                    temp_name = line.replace('"', '').replace(',', '').replace('{', '').replace('}', '').replace('name:', '').strip()
                                    if temp_name:
                                        link = "https://openspa.webhop.info/online/images/%s/%s/%s.zip" % (box, current_version, temp_name)
                                        parsed[str(current_version)][str(temp_name)] = {
                                            "link": str(link),
                                            "name": str(temp_name)
                                        }
                        
                        else:
                            try:
                                import json
                                if PY3:
                                    data = json.loads(content)
                                else:
                                    data = json.loads(content)
                                if isinstance(data, dict):
                                    for category, images in data.items():
                                        if isinstance(images, dict):
                                            if str(category) not in parsed:
                                                parsed[str(category)] = {}
                                            for img_name, img_info in images.items():
                                                if isinstance(img_info, dict):
                                                    parsed[str(category)][str(img_name)] = img_info
                                                elif isinstance(img_info, str):
                                                    parsed[str(category)][str(img_name)] = {
                                                        "link": str(img_info),
                                                        "name": str(img_name)
                                                    }
                                                else:
                                                    parsed[str(category)][str(img_name)] = {
                                                        "link": str(img_info),
                                                        "name": str(img_name)
                                                    }
                            except:
                                pass
                    
                    except Exception as e:
                        continue
                
                except Exception as e:
                    continue
            
            if parsed:
                self.feed_data = parsed
            else:
                self.feed_data = {"Error": {"No Images": "No images found for this device"}}
            
            self.current_feed = feed_name
            self.current_view = "categories"
            
        except Exception as e:
            self.feed_data = {"Error": {"Error": str(e)}}
            self.current_feed = feed_name
            self.current_view = "categories"
        
        finally:
            self.loading = False
    
    def update_feed_display(self):
        if self.loading:
            self.timer.start(500, True)
            return
        
        if self.current_view == "categories":
            self.display_categories()
        else:
            self.load_feeds()
    
    def display_categories(self):
        self.list_items = []
        
        self.list_items.append(("◀ Back to Feeds", "back", "back"))
        
        if "Error" in self.feed_data:
            for error_key, error_msg in self.feed_data["Error"].items():
                self.list_items.append(("● %s: %s" % (str(error_key), str(error_msg)), "error", "error"))
        else:
            for category in sorted(self.feed_data.keys(), reverse=True):
                count = len(self.feed_data[category])
                symbol = "▼" if category in self.expanded_categories else "▶"
                self.list_items.append(("%s %s (%s images)" % (symbol, str(category), str(count)), str(category), "category"))
                
                if category in self.expanded_categories:
                    for img_name, img_info in sorted(self.feed_data[category].items(), reverse=True):
                        if isinstance(img_info, dict):
                            name = img_info.get('name', img_name)
                            self.list_items.append(("   • %s" % str(name), img_info, "image"))
        
        self["list"].setList(self.list_items)
        if len(self.list_items) > 0:
            self["list"].setIndex(0)
        
        self["title"].setText("%s Images" % self.current_feed)
        self["status"].setText("Categories: %s" % len(self.feed_data))
    
    def ok_pressed(self):
        selection = self["list"].getCurrent()
        if not selection:
            return
        
        item_type = selection[2]
        
        if item_type == "feed":
            feed_name = selection[1]
            self.load_feed_data(feed_name)
        
        elif item_type == "category":
            category = selection[1]
            if category in self.expanded_categories:
                self.expanded_categories.remove(category)
            else:
                self.expanded_categories.append(category)
            self.display_categories()
        
        elif item_type == "image":
            img_info = selection[1]
            self.download_image(img_info)
        
        elif item_type == "back":
            self.load_feeds()
        
        elif item_type == "error":
            self.load_feeds()
    
    def download_image(self, img_info):
        if not img_info or not isinstance(img_info, dict):
            self["status"].setText("Invalid image information")
            return
        
        url = img_info.get('link') or img_info.get('url')
        if not url:
            self["status"].setText("No download URL available")
            return
        
        name = img_info.get('name', 'image.zip')
        
        self.session.openWithCallback(
            lambda confirmed: self.confirm_download(confirmed, url, name),
            MessageBox,
            "Download %s?" % str(name),
            MessageBox.TYPE_YESNO
        )
    
    def confirm_download(self, confirmed, url, filename):
        if not confirmed:
            return
        
        self.session.openWithCallback(
            self.download_complete_callback,
            DownloadProgressScreen,
            str(url),
            str(filename)
        )
    
    def download_complete_callback(self, success):
        if success:
            self["status"].setText("Download completed successfully!")
        else:
            self["status"].setText("Download cancelled or failed")
    
    def cancel_pressed(self):
        self.close()
    
    def select_pressed(self):
        self.ok_pressed()
    
    def refresh_pressed(self):
        if self.current_view == "feeds":
            self.load_feeds()
            self["status"].setText("Feeds refreshed")
        elif self.current_view == "categories" and self.current_feed:
            self.load_feed_data(self.current_feed)
            self["status"].setText("Refreshing %s..." % self.current_feed)
    
    def info_pressed(self):
        selection = self["list"].getCurrent()
        if selection:
            item_type = selection[2]
            if item_type == "image":
                img_info = selection[1]
                info_text = "Image: %s\n" % str(img_info.get('name', 'Unknown'))
                info_text += "URL: %s\n" % str(img_info.get('link', 'N/A'))
                info_text += "Device: %s" % self.hostname
                self.session.open(MessageBox, info_text, MessageBox.TYPE_INFO)
            elif item_type == "feed":
                feed_name = selection[1]
                feed_url = FEEDS.get(feed_name, 'N/A')
                info_text = "Feed: %s\n" % str(feed_name)
                info_text += "URL: %s\n" % str(feed_url)
                info_text += "Device: %s" % self.hostname
                self.session.open(MessageBox, info_text, MessageBox.TYPE_INFO)
            else:
                self.session.open(MessageBox, "Selected: %s" % str(selection[0]), MessageBox.TYPE_INFO)


def main(session, **kwargs):
    return E2ImagesScreen(session)


def e2images(session, **kwargs):
    return main(session, **kwargs)
