# -*- coding: utf-8 -*-
from __future__ import print_function
from __future__ import absolute_import
import os
import sys
import socket
import json
import time
from enigma import *
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.Sources.List import List
from Components.ActionMap import ActionMap
from Components.Console import Console as iConsole
from Components.ProgressBar import ProgressBar
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap
from Plugins.Plugin import PluginDescriptor

PY3 = sys.version_info[0] >= 3

try:
    from urllib2 import urlopen, Request, URLError
except ImportError:
    from urllib.request import urlopen, Request
    from urllib.error import URLError

try:
    import urllib2 as urllib_request
except ImportError:
    import urllib.request as urllib_request

from .__init__ import Version

MENU_CONFIG = {
    "main": [
        {"title": "Update Dependencic", "section": "updated-dependencic", "icon": "tool.png"},
        {"title": "Panels", "section": "panels", "icon": "panel.png"},
        {"title": "Plugins", "section": "plugins", "icon": "plugins.png"},
        {"title": "Channels", "section": "channels", "icon": "channels.png"},
        {"title": "Feeds", "section": "feeds", "icon": "feeds.png"},
        {"title": "Bootlogos", "section": "bootlogos", "icon": "bootlogos.png"},
        {"title": "Spinners", "section": "spinners", "icon": "spinners.png"},
        {"title": "Tools", "section": "tools", "icon": "tools.png"},
        {"title": "System", "section": "system", "icon": "systemplugins.png"},
        {"title": "Media", "section": "media", "icon": "media.png"},
        {"title": "Multiboot", "section": "multiboot", "icon": "multiboot.png"},
        {"title": "Softcams", "section": "softcams", "icon": "emu.png"},
        {"title": "Backup", "section": "backup", "icon": "backup.png"},
        {"title": "Restore", "section": "restore", "icon": "backup.png"},
        {"title": "Skins", "section": "skins", "icon": "skins.png"},
        {"title": "Images", "section": "images", "icon": "images.png"},
        {"title": "Picons", "section": "picons", "icon": "picons.png"},
        {"title": "Remove", "section": "remove", "icon": "removed.png"}
    ]
}

def get_image_type():
    try:
        dreamos_indicators = ['/etc/dream', '/etc/dreamos', '/etc/dreambox', '/etc/enigma2/dreamos.conf', '/etc/enigma2/dreambox', '/var/lib/dpkg/status']
        for indicator in dreamos_indicators:
            if os.path.exists(indicator):
                return "dreamos"
        return "opensource"
    except:
        return "opensource"

def get_config_urls():
    image_type = get_image_type()
    if image_type == "dreamos":
        return [
            "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EmilPanel/dreamos/config.json",
            "https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanel/dreamos/config.json",
            "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EmilPanel/OpenSource/config.json",
            "https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanel/OpenSource/config.json"
        ]
    else:
        return [
            "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EmilPanel/OpenSource/config.json",
            "https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanel/OpenSource/config.json",
            "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EmilPanel/dreamos/config.json",
            "https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanel/dreamos/config.json"
        ]

_CONFIG_URLS = get_config_urls()

def open_file(filename, mode='r'):
    if PY3:
        return open(filename, mode, encoding='utf-8', errors='ignore')
    else:
        return open(filename, mode)

def download_url(url, timeout=10):
    try:
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        if not PY3:
            response = urlopen(req, timeout=timeout)
            data = response.read()
            if isinstance(data, str):
                return data
            else:
                return data.decode('utf-8', 'ignore')
        else:
            with urlopen(req, timeout=timeout) as response:
                return response.read().decode('utf-8', 'ignore')
    except Exception as e:
        print("[EmilPanel] Download error: " + str(e))
        return None

def load_json_from_url(url):
    data = download_url(url)
    if data:
        try:
            return json.loads(data)
        except Exception as e:
            print("[EmilPanel] JSON parse error from URL: " + str(e))
    return None

def load_json_from_file(filepath):
    try:
        if fileExists(filepath):
            with open_file(filepath, "r") as f:
                return json.load(f)
    except Exception as e:
        print("[EmilPanel] Error loading local JSON: " + str(e))
    return None

def save_json_to_file(data, filepath):
    try:
        with open_file(filepath, "w") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        print("[EmilPanel] Error saving JSON: " + str(e))
        return False

def safe_load_pixmap(path, cached=False):
    try:
        if not fileExists(path):
            print("[EmilPanel] Pixmap not found: " + path)
            return None
        print("[EmilPanel] Loading pixmap from: " + path)
        if not PY3:
            try:
                ptr = LoadPixmap(path, cached=cached)
                if ptr:
                    print("[EmilPanel] Successfully loaded with LoadPixmap (Python 2)")
                    return ptr
            except Exception as e1:
                try:
                    ptr = LoadPixmap(path)
                    if ptr:
                        print("[EmilPanel] Successfully loaded with LoadPixmap without cached param")
                        return ptr
                except Exception as e2:
                    try:
                        from enigma import ePixmap
                        ptr = ePixmap()
                        ptr.load(path)
                        print("[EmilPanel] Successfully loaded with ePixmap.load")
                        return ptr
                    except Exception as e3:
                        print("[EmilPanel] Method 3 failed: " + str(e3))
        else:
            try:
                ptr = LoadPixmap(path, desktop=getDesktop(0), cached=cached)
                if ptr:
                    getDesktop(0).makeCompatiblePixmap(ptr)
                    print("[EmilPanel] Successfully loaded with LoadPixmap (Python 3)")
                    return ptr
            except Exception as e:
                print("[EmilPanel] Python 3 loading failed: " + str(e))
        print("[EmilPanel] All loading methods failed for: " + path)
        return None
    except Exception as e:
        print("[EmilPanel] Error loading pixmap " + path + ": " + str(e))
        import traceback
        traceback.print_exc()
        return None

def load_icon(icon_name):
    if not icon_name:
        icon_name = "default.png"
    print("[EmilPanel] Attempting to load icon: " + icon_name)
    search_paths = [
        resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/" + icon_name),
        "/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/images/" + icon_name,
        "/usr/share/enigma2/EmilPanel/images/" + icon_name,
        resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/" + icon_name),
        "/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/" + icon_name
    ]
    for icon_path in search_paths:
        if fileExists(icon_path):
            print("[EmilPanel] Found icon at: " + icon_path)
            pixmap = safe_load_pixmap(icon_path)
            if pixmap:
                print("[EmilPanel] Successfully loaded: " + icon_name)
                return pixmap
            else:
                print("[EmilPanel] Failed to load pixmap from: " + icon_path)
    print("[EmilPanel] Icon not found in any path: " + icon_name)
    default_paths = [
        resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/default.png"),
        "/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/images/default.png"
    ]
    for default_path in default_paths:
        if fileExists(default_path):
            pixmap = safe_load_pixmap(default_path)
            if pixmap:
                print("[EmilPanel] Loaded default.png instead")
                return pixmap
    print("[EmilPanel] No icon loaded for: " + icon_name)
    return None

class DetailedInstallProgressScreen(Screen):
    def __init__(self, session, title, commands):
        Screen.__init__(self, session)
        self.commands = commands
        self.current_command_index = 0
        self.console = iConsole()
        self.console_output_text = ""
        self.is_running = True

        self.skin = """
        <screen name="DetailedInstallProgressScreen" position="center,center" size="1400,800" title="Installation Progress" backgroundColor="#000000" flags="wfNoBorder">
            <widget name="title" position="30,20" size="1340,70" font="Regular;40" halign="center" valign="center" backgroundColor="#1a1a1a" foregroundColor="#00BFFF" />
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/images/background1.png" position="30,40" size="400,400" zPosition="1" backgroundColor="#000000" />
            <widget name="progress" position="560,110" size="810,30" />
            <widget name="status" position="560,160" size="810,50" font="Regular;28" halign="center" valign="center" foregroundColor="#00FF00" />
            <widget name="console_output" position="30,420" size="1340,300" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#000000" />
            <widget name="key_red" position="200,750" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#990011" foregroundColor="white" />
            <widget name="key_green" position="1000,750" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#1F771F" foregroundColor="white" />
            <widget name="EmilLabel" position="500,760" size="400,40" font="Regular;28" halign="center" valign="center" foregroundColor="#888888" transparent="1" />
        </screen>"""

        self["title"] = Label(title)
        self["progress"] = ProgressBar()
        self["status"] = Label("Starting installation...")
        self["console_output"] = ScrollLabel()
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Close")
        self["EmilLabel"] = Label("Emil Panel Installer")

        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "red": self.cancel,
            "green": self.close,
            "cancel": self.close,
            "ok": self.close,
        })

        self.onShown.append(self.startInstallation)

    def startInstallation(self):
        if not self.commands:
            self.console_output_text = "No commands to execute.\n"
            self["console_output"].setText(self.console_output_text)
            self["status"].setText("Nothing to install")
            return
        self["progress"].setRange((0, len(self.commands)))
        self["progress"].setValue(0)
        self.executeNextCommand()

    def executeNextCommand(self):
        if self.current_command_index >= len(self.commands) or not self.is_running:
            if self.is_running:
                self.console_output_text += "\n\n========== INSTALLATION COMPLETED ==========\n"
                self["status"].setText("Installation finished successfully!")
                self["key_green"].setText("Exit")
                self["EmilLabel"].setText("Completed - You may restart GUI if needed")
            return

        command = self.commands[self.current_command_index]
        self["status"].setText("Executing command {} of {}...".format(self.current_command_index+1, len(self.commands)))
        self.console_output_text += "\n>>> Running: {}\n".format(command)
        self["console_output"].setText(self.console_output_text)
        self["console_output"].lastPage()

        self.console.ePopen(command, self.commandFinished)

    def commandFinished(self, result, retval, extra_args):
        if not self.is_running:
            return
        self.console_output_text += result
        self["console_output"].setText(self.console_output_text)
        self["console_output"].lastPage()
        self.current_command_index += 1
        self["progress"].setValue(self.current_command_index)
        if self.current_command_index < len(self.commands):
            self.executeNextCommand()
        else:
            self.console_output_text += "\n\n========== ALL COMMANDS FINISHED ==========\n"
            self["console_output"].setText(self.console_output_text)
            self["console_output"].lastPage()
            self["status"].setText("Installation completed successfully!")
            self["key_green"].setText("Exit")

    def cancel(self):
        self.is_running = False
        self.console_output_text += "\n>>> Installation cancelled by user.\n"
        self["console_output"].setText(self.console_output_text)
        self["console_output"].lastPage()
        self["status"].setText("Cancelled")
        self["key_green"].setText("Close")

class emilpanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """<screen name="emilpanel" position="0,0" size="1920,1080" backgroundColor="transparent" flags="wfNoBorder" title="Emil Panel">
            <widget name="Panel" position="160,105" size="270,50" font="Regular;45" halign="center" valign="center" transparent="1"/>
            <widget name="Version" position="410,110" size="150,50" font="Regular;35" halign="center" valign="center" transparent="1"/>
            <widget source="session.VideoPicture" render="Pig" position="1305,100" size="550,290" zPosition="1" backgroundColor="#ff000000" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1240,1" zPosition="2" />
            <widget source="menu" render="Listbox" position="48,200" size="1240,660" scrollbarMode="showOnDemand" transparent="1">
                <convert type="TemplatedMultiContent">
                    {"template": [
                        MultiContentEntryText(pos = (170, 10), size = (600, 45), font=0, flags = RT_HALIGN_LEFT, text = 0),
                        MultiContentEntryText(pos = (650, 19), size = (600, 35), font=1, flags = RT_HALIGN_LEFT, text = 2),
                        MultiContentEntryPixmap(pos = (25, 5), size = (50, 40), png = 3),
                        MultiContentEntryPixmap(pos = (85, 5), size = (50, 40), png = 4),
                    ],
                    "fonts": [gFont("Regular", 35),gFont("Regular", 25)],
                    "itemHeight": 66
                    }
                </convert>
            </widget>
            <eLabel backgroundColor="#00ffffff" position="45,860" size="1240,1" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="1285,195" size="1,665" zPosition="2" />
            <eLabel backgroundColor="#00ffffff" position="45,195" size="1,665" zPosition="2" />
            
            <widget name="key_red" position="200,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#990011" foregroundColor="white" transparent="0" />
            <widget name="key_green" position="520,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#1F771F" foregroundColor="white" transparent="0" />
            <widget name="key_blue" position="1160,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#13389F" foregroundColor="white" transparent="0" />
            <widget name="key_yellow" position="840,990" size="300,60" font="Regular;35" halign="center" valign="center" backgroundColor="#C58917" foregroundColor="white" transparent="0" />
            
            <widget name="EmilLabel" position="350,880" size="600,100" font="Regular;40" halign="center" valign="center" foregroundColor="#00BFFF" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,410" size="550,50" zPosition="-1" />
            <widget name="DeviceInfo" position="1305,410" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,470" size="550,80" zPosition="-1" />
            <widget name="RAMInfo" position="1305,470" size="550,80" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,560" size="550,100" zPosition="-1" />
            <widget name="StorageInfo" position="1305,560" size="550,100" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,670" size="550,50" zPosition="-1" />
            <widget name="CPUInfo" position="1305,670" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,730" size="550,50" zPosition="-1" />
            <widget name="ReceiverIP" position="1305,730" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,790" size="550,50" zPosition="-1" />
            <widget name="InternetStatus" position="1305,790" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <eLabel backgroundColor="#423C3D" position="1305,850" size="550,50" zPosition="-1" />
            <widget name="PythonVersion" position="1305,850" size="550,50" font="Regular;30" halign="center" valign="center" transparent="1"/>
            <widget name="ConfigSource" position="50,920" size="410,60" font="Regular;20" halign="left" valign="center" foregroundColor="#00FF00" transparent="1"/>
        </screen>"""
        self.setTitle("Emil Panel")
        self.iConsole = iConsole()
        self.config_data = None
        self.menu_stack = []
        self.current_menu = "main"
        self.selected_items = []
        self.multi_select_mode = False
        self.menu_positions = {}
        self.config_source = "Unknown"
        self.image_type = get_image_type()
        self.local_config_path = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/config.json")
        
        print("\n" + "="*60)
        print("[EmilPanel] Initializing on Python " + ("3" if PY3 else "2"))
        print("[EmilPanel] Image type detected: " + self.image_type)
        print("="*60)
        
        select_icon = load_icon("select.png")
        unchecked_icon = load_icon("unchecked.png")
        checked_icon = load_icon("checked.png")
        
        self.select_icon = select_icon
        self.unchecked_icon = unchecked_icon
        self.checked_icon = checked_icon
        
        print("[EmilPanel] Icons loaded status:")
        print("  - select.png: " + ("Loaded" if select_icon else "Failed"))
        print("  - unchecked.png: " + ("Loaded" if unchecked_icon else "Failed"))
        print("  - checked.png: " + ("Loaded" if checked_icon else "Failed"))
        
        if not select_icon or not unchecked_icon or not checked_icon:
            self.load_icons_alternative()
        
        self["key_red"] = Label("Close")
        self["key_green"] = Label("OK")
        self["key_blue"] = Label("Restart GUI")
        self["key_yellow"] = Label("Refresh")
        self["ConfigSource"] = Label("")
        
        self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions", "DirectionActions"], {
            "ok": self.keyOK,
            "cancel": self.exitOrBack,
            "back": self.exitOrBack,
            "red": self.exit,
            "green": self.keyGreen,
            "blue": self.restartGUI,
            "yellow": self.handleYellowButton
        })
        
        self.list = []
        self["menu"] = List(self.list)
        self["Version"] = Label("V" + Version)
        self["Panel"] = Label("Emil Panel")
        self["EmilLabel"] = Label("Welcome Emil Panel")
        self["DeviceInfo"] = Label(self.getDeviceInfo())
        self["RAMInfo"] = Label(self.getRAMInfo())
        self["StorageInfo"] = Label(self.getStorageInfo())
        self["CPUInfo"] = Label(self.getCPUInfo())
        self["ReceiverIP"] = Label(self.getReceiverIP())
        self["InternetStatus"] = Label(self.getInternetStatus())
        self["PythonVersion"] = Label(self.getPythonVersion())
        
        self.loadConfig()
        self.buildMainMenu()
        self.checkForUpdate()
    
    def load_icons_alternative(self):
        print("[EmilPanel] Using alternative icon loading method for Python 2")
        base_paths = [
            "/usr/lib/enigma2/python/Plugins/Extensions/EmilPanel/images/",
            resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/")
        ]
        for base_path in base_paths:
            if os.path.exists(base_path):
                print("[EmilPanel] Checking path: " + base_path)
                if not self.select_icon:
                    select_path = os.path.join(base_path, "select.png")
                    if os.path.exists(select_path):
                        print("[EmilPanel] Trying alternative load for select.png")
                        try:
                            if not PY3:
                                from Tools.LoadPixmap import LoadPixmap as LP
                                self.select_icon = LP(select_path)
                                if self.select_icon:
                                    print("[EmilPanel] Alternative select.png loaded")
                        except:
                            pass
                if not self.unchecked_icon:
                    unchecked_path = os.path.join(base_path, "unchecked.png")
                    if os.path.exists(unchecked_path):
                        print("[EmilPanel] Trying alternative load for unchecked.png")
                        try:
                            if not PY3:
                                from Tools.LoadPixmap import LoadPixmap as LP
                                self.unchecked_icon = LP(unchecked_path)
                                if self.unchecked_icon:
                                    print("[EmilPanel] Alternative unchecked.png loaded")
                        except:
                            pass
                if not self.checked_icon:
                    checked_path = os.path.join(base_path, "checked.png")
                    if os.path.exists(checked_path):
                        print("[EmilPanel] Trying alternative load for checked.png")
                        try:
                            if not PY3:
                                from Tools.LoadPixmap import LoadPixmap as LP
                                self.checked_icon = LP(checked_path)
                                if self.checked_icon:
                                    print("[EmilPanel] Alternative checked.png loaded")
                        except:
                            pass
    
    def storeCurrentPosition(self):
        current_index = self["menu"].getIndex()
        self.menu_positions[self.current_menu] = current_index
    
    def restorePosition(self, menu_name):
        if menu_name in self.menu_positions:
            stored_index = self.menu_positions[menu_name]
            current_list_length = len(self.list)
            if stored_index < current_list_length:
                self["menu"].setIndex(stored_index)
        else:
            self["menu"].setIndex(0)
    
    def loadConfig(self):
        self.config_source = "Unknown"
        self.config_data = None
        print("[EmilPanel] Using embedded menu configuration")
        self.config_data = MENU_CONFIG.copy()
        self.config_source = "Embedded Menu"
        for url in get_config_urls():
            print("[EmilPanel] Trying to load sub-menus from: " + url)
            online_data = load_json_from_url(url)
            if online_data:
                for key, value in online_data.items():
                    if key != "main":  
                        self.config_data[key] = value
                if "dreamos" in url:
                    config_type = "DreamOS: " + url.split('/')[-2]
                else:
                    config_type = "OpenSource: " + url.split('/')[-2]
                self.config_source = "Embedded + " + config_type
                print("[EmilPanel] Successfully loaded sub-menus from: " + url)
                save_json_to_file(self.config_data, self.local_config_path)
                break
        if not self.config_data:
            print("[EmilPanel] Trying to load config from local file")
            self.config_data = load_json_from_file(self.local_config_path)
            if self.config_data:
                self.config_source = "Local: config.json"
                print("[EmilPanel] Successfully loaded config from local file")
            else:
                self.config_data = MENU_CONFIG.copy()
                self.config_source = "Embedded Menu Only"
                print("[EmilPanel] Using only embedded menu configuration")
        self["ConfigSource"].setText("")
        return True
    
    def refreshConfig(self):
        old_source = self.config_source
        if self.loadConfig():
            if old_source != self.config_source:
                self.session.open(MessageBox, "Config updated from " + self.config_source, MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(MessageBox, "Config reloaded successfully", MessageBox.TYPE_INFO, timeout=2)
            if self.current_menu == "main":
                self.buildMainMenu()
            elif self.current_menu in ["channels", "skins"]:
                self.buildSubMenu(self.current_menu)
            else:
                self.buildSubSubMenu(self.current_menu)
        else:
            self.session.open(MessageBox, "Failed to refresh config!", MessageBox.TYPE_ERROR)
    
    def buildMainMenu(self):
        try:
            if not self.config_data or "main" not in self.config_data:
                self.session.open(MessageBox, "Main menu not found in config!", MessageBox.TYPE_ERROR)
                return
            print("[EmilPanel] Building main menu with Python " + ("3" if PY3 else "2"))
            self.list = []
            for item in self.config_data["main"]:
                title = item.get("title", "Unknown")
                section = item.get("section", "")
                icon_name = item.get("icon", "default.png")
                print("[EmilPanel] Menu item: " + title + ", icon: " + icon_name)
                icon = load_icon(icon_name)
                if not icon and not PY3:
                    print("[EmilPanel] Direct loading for Python 2: " + icon_name)
                    try:
                        icon_path = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanel/images/" + icon_name)
                        if fileExists(icon_path):
                            from Tools.LoadPixmap import LoadPixmap as LP
                            icon = LP(icon_path)
                    except:
                        pass
                description = ""
                check_icon = None
                self.list.append((str(title), str(section), str(description), icon, check_icon))
            self["menu"].setList(self.list)
            self.restorePosition("main")
            self["EmilLabel"].setText("Welcome Emil Panel")
            self.current_menu = "main"
            self.menu_stack = []
            self.updateButtonLabels()
            print("[EmilPanel] Main menu built with " + str(len(self.list)) + " items")
        except Exception as e:
            print("[EmilPanel] Error in buildMainMenu: " + str(e))
            import traceback
            traceback.print_exc()
            self.session.open(MessageBox, "Error building menu: " + str(e), MessageBox.TYPE_ERROR)
    
    def buildSubMenu(self, section_name):
        try:
            if not self.config_data or section_name not in self.config_data:
                self.session.open(MessageBox, "Section '" + section_name + "' not found!", MessageBox.TYPE_ERROR)
                return
            self.list = []
            if section_name == "channels":
                for item in self.config_data[section_name]:
                    title = item.get("title", "Unknown")
                    sub_section = item.get("section", "")
                    icon_name = item.get("icon", "default.png")
                    icon = load_icon(icon_name)
                    description = ""
                    check_icon = None
                    self.list.append((str(title), str(sub_section), str(description), icon, check_icon))
            elif section_name == "skins":
                for item in self.config_data[section_name]:
                    title = item.get("title", "Unknown")
                    sub_section = item.get("section", "")
                    icon_name = item.get("icon", "default.png")
                    icon = load_icon(icon_name)
                    description = ""
                    check_icon = None
                    self.list.append((str(title), str(sub_section), str(description), icon, check_icon))
            else:
                for item in self.config_data[section_name]:
                    name = item.get("name", "Unknown")
                    cmd = item.get("cmd", "")
                    description = ""
                    icon = self.select_icon
                    is_selected = any(selected[0] == name and selected[1] == cmd for selected in self.selected_items)
                    check_icon = self.checked_icon if is_selected else self.unchecked_icon
                    self.list.append((str(name), str(cmd), str(description), icon, check_icon))
            self["menu"].setList(self.list)
            self.restorePosition(section_name)
            self["EmilLabel"].setText("→ " + section_name.replace('_', ' ').title())
            self.updateButtonLabels()
        except Exception as e:
            print("[EmilPanel] Error in buildSubMenu: " + str(e))
    
    def buildSubSubMenu(self, section_name):
        try:
            if not self.config_data or section_name not in self.config_data:
                self.session.open(MessageBox, "Section '" + section_name + "' not found!", MessageBox.TYPE_ERROR)
                return
            self.list = []
            for item in self.config_data[section_name]:
                name = item.get("name", "Unknown")
                cmd = item.get("cmd", "")
                description = ""
                icon = self.select_icon
                is_selected = any(selected[0] == name and selected[1] == cmd for selected in self.selected_items)
                check_icon = self.checked_icon if is_selected else self.unchecked_icon
                self.list.append((str(name), str(cmd), str(description), icon, check_icon))
            self["menu"].setList(self.list)
            self.restorePosition(section_name)
            self["EmilLabel"].setText("→ " + section_name.replace('_', ' ').title())
            self.updateButtonLabels()
        except Exception as e:
            print("[EmilPanel] Error in buildSubSubMenu: " + str(e))
    
    def keyOK(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        name, action, description, icon, check_icon = current
        if self.multi_select_mode and self.current_menu not in ["main", "channels", "skins"]:
            self.toggleItemSelection()
            return
        self.storeCurrentPosition()
        if self.current_menu == "main":
            self.menu_stack.append("main")
            self.current_menu = action
            self.buildSubMenu(action)
        elif self.current_menu in ["channels", "skins"]:
            self.menu_stack.append(self.current_menu)
            self.current_menu = action
            self.buildSubSubMenu(action)
        else:
            if not self.multi_select_mode:
                self.multi_select_mode = True
                self.updateButtonLabels()
            self.toggleItemSelection()
    
    def keyGreen(self):
        if self.multi_select_mode:
            self.installSelected()
        else:
            if self.current_menu in ["main", "channels", "skins"]:
                self.keyOK()
            else:
                if not self.multi_select_mode:
                    self.multi_select_mode = True
                    self.updateButtonLabels()
                self.toggleItemSelection()
    
    def installSelected(self):
        if not self.selected_items:
            self.session.open(MessageBox, "No items selected!", MessageBox.TYPE_INFO)
            return
        title = self.current_menu.replace('_', ' ').title() + " - installing " + str(len(self.selected_items)) + " item(s)"
        commands = []
        for name, cmd in self.selected_items:
            if cmd:
                commands.append(cmd)
        if commands:
            self.session.open(DetailedInstallProgressScreen, title, commands)
            self.selected_items = []
            self.multi_select_mode = False
            self.updateButtonLabels()
            self.refreshCurrentMenu()
        else:
            self.session.open(MessageBox, "No valid commands to execute!", MessageBox.TYPE_INFO)
    
    def handleYellowButton(self):
        if self.current_menu == "main":
            self.refreshConfig()
        else:
            self.toggleMultiSelect()
    
    def toggleMultiSelect(self):
        if self.current_menu not in ["main", "channels", "skins"]:
            self.multi_select_mode = not self.multi_select_mode
            if not self.multi_select_mode:
                self.selected_items = []
            self.updateButtonLabels()
            self.refreshCurrentMenu()
    
    def toggleItemSelection(self):
        current = self["menu"].getCurrent()
        if not current:
            return
        name, cmd, description, icon, check_icon = current
        item_key = (name, cmd)
        if any(selected[0] == name and selected[1] == cmd for selected in self.selected_items):
            self.selected_items = [item for item in self.selected_items if item[0] != name or item[1] != cmd]
        else:
            self.selected_items.append(item_key)
        self.refreshCurrentMenu()
        self.updateButtonLabels()
    
    def refresh(self):
        self["DeviceInfo"].setText(self.getDeviceInfo())
        self["RAMInfo"].setText(self.getRAMInfo())
        self["StorageInfo"].setText(self.getStorageInfo())
        self["CPUInfo"].setText(self.getCPUInfo())
        self["ReceiverIP"].setText(self.getReceiverIP())
        self["InternetStatus"].setText(self.getInternetStatus())
        self["PythonVersion"].setText(self.getPythonVersion())
        if self.current_menu == "main":
            self.buildMainMenu()
        elif self.current_menu in ["channels", "skins"]:
            self.buildSubMenu(self.current_menu)
        else:
            self.buildSubSubMenu(self.current_menu)
        self["EmilLabel"].setText("System Refreshed!")
    
    def refreshCurrentMenu(self):
        current_index = self["menu"].getIndex()
        if self.current_menu == "main":
            self.buildMainMenu()
        elif self.current_menu in ["channels", "skins"]:
            self.buildSubMenu(self.current_menu)
        else:
            self.buildSubSubMenu(self.current_menu)
        list_length = len(self.list)
        if current_index < list_length:
            self["menu"].setIndex(current_index)
        elif list_length > 0:
            self["menu"].setIndex(0)
    
    def updateButtonLabels(self):
        if self.current_menu == "main":
            self["key_red"].setText("Close")
            self["key_green"].setText("OK")
            self["key_blue"].setText("Restart GUI")
            self["key_yellow"].setText("Refresh Config")
        else:
            if self.multi_select_mode:
                self["key_red"].setText("Back")
                self["key_green"].setText("Install (" + str(len(self.selected_items)) + ")")
                self["key_yellow"].setText("Cancel Select")
                self["key_blue"].setText("Restart GUI")
            else:
                self["key_red"].setText("Back")
                if self.current_menu in ["channels", "skins"]:
                    self["key_green"].setText("OK")
                else:
                    self["key_green"].setText("Select")
                self["key_yellow"].setText("Multi Select")
                self["key_blue"].setText("Restart GUI")
    
    def exitOrBack(self):
        if self.multi_select_mode:
            self.multi_select_mode = False
            self.selected_items = []
            self.updateButtonLabels()
            self.refreshCurrentMenu()
            return
        if self.menu_stack:
            self.storeCurrentPosition()
            prev_menu = self.menu_stack.pop()
            if prev_menu in ["channels", "skins"]:
                self.current_menu = "main"
                self.buildMainMenu()
            else:
                self.current_menu = prev_menu
                if prev_menu == "main":
                    self.buildMainMenu()
                else:
                    self.buildSubMenu(prev_menu)
        else:
            self.exit()
    
    def exit(self):
        self.close()
    
    def restartGUI(self):
        self.session.openWithCallback(self.restartConfirmed, MessageBox, "Are you sure you want to restart GUI?", MessageBox.TYPE_YESNO)
    
    def restartConfirmed(self, answer):
        if answer:
            self.iConsole.ePopen('if command -v systemctl > /dev/null 2>&1; then systemctl restart enigma2; else killall -9 enigma2; fi')
    
    def checkForUpdate(self):
        cmd = 'wget -q -O /tmp/emilpanel_version.txt "https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanel/version.txt"'
        self.iConsole.ePopen(cmd, self.versionDownloaded)
    
    def versionDownloaded(self, result, retval, extra_args):
        if retval == 0:
            try:
                with open_file("/tmp/emilpanel_version.txt", "r") as f:
                    online_version = f.read().strip()
                def parse_version(v):
                    return [int(x) for x in v.split('.')]
                if parse_version(online_version) > parse_version(Version):
                    self.session.openWithCallback(self.updateConfirmed, MessageBox, "New version " + online_version + " available. Update now?", MessageBox.TYPE_YESNO)
                os.remove("/tmp/emilpanel_version.txt")
            except Exception as e:
                print("Error checking version: " + str(e))
        else:
            print("Failed to download version file")
    
    def updateConfirmed(self, answer):
        if answer:
            self.doUpdate()
    
    def doUpdate(self):
        image_type = get_image_type()
        if image_type == "dreamos":
            download_url = "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EmilPanel/dreamos/EmilPanel.tar.gz"
        else:
            download_url = "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EmilPanel/OpenSource/EmilPanel.tar.gz"
        cmd = (
            'wget -q -O /tmp/emilpanel.tar.gz "' + download_url + '" && '
            'rm -rf /usr/lib/enigma2/python/Plugins/Extensions/EmilPanel && '
            'tar -xzf /tmp/emilpanel.tar.gz -C / && '
            'rm -f /tmp/emilpanel.tar.gz'
        )
        self.iConsole.ePopen(cmd, self.updateFinished)
    
    def updateFinished(self, result, retval, extra_args):
        if retval != 0:
            self.session.open(MessageBox, "Update failed. Check internet connection.", MessageBox.TYPE_ERROR)
        else:
            self.session.open(MessageBox, "Update completed! Please restart Emil Panel manually.", MessageBox.TYPE_INFO)
    
    def getDeviceInfo(self):
        model = "Unknown"
        image = "Unknown"
        version = "Unknown"
        try:
            model_paths = ["/etc/hostname", "/etc/hostname"]
            for path in model_paths:
                if os.path.exists(path):
                    with open_file(path) as f:
                        model = f.read().strip()
                    break
        except:
            pass
        try:
            if os.path.exists("/etc/image-version"):
                with open_file("/etc/image-version") as f:
                    for line in f:
                        if "creator" in line:
                            image = line.partition("=")[2].strip()
                        elif "version" in line:
                            version = line.partition("=")[2].strip()
        except:
            pass
        return model + ": " + image + " " + version
    
    def getRAMInfo(self):
        try:
            with open_file("/proc/meminfo") as f:
                mem = {}
                for line in f:
                    parts = line.split(':')
                    if len(parts) >= 2:
                        mem[parts[0]] = parts[1].strip()
            total = int(mem["MemTotal"].split()[0]) // 1024
            free = int(mem["MemAvailable"].split()[0]) // 1024
            used = total - free
            return "RAM: " + str(total) + "MB used: " + str(used) + "MB Free: " + str(free) + "MB"
        except:
            return "RAM: Not Available"
    
    def getStorageInfo(self):
        info = []
        mounts = {'HDD': '/media/hdd', 'USB': '/media/usb', 'MMC': '/media/mmc'}
        for name, path in mounts.items():
            if os.path.ismount(path):
                try:
                    stat = os.statvfs(path)
                    total = (stat.f_blocks * stat.f_frsize) / (1024**3)
                    free = (stat.f_bfree * stat.f_frsize) / (1024**3)
                    used = total - free
                    info.append(name + ": " + "{:.1f}".format(used) + "GB/" + "{:.1f}".format(total) + "GB")
                except:
                    info.append(name + ": Error")
            else:
                info.append(name + ": Not Available")
        return "\n".join(info)
    
    def getCPUInfo(self):
        try:
            with open_file("/proc/cpuinfo") as f:
                cores = 0
                for line in f:
                    if "processor" in line:
                        cores += 1
            with open_file("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq") as f:
                speed = int(f.read().strip()) // 1000
            return "CPU: ARMv7, " + str(speed) + " MHz (" + str(cores) + " cores)"
        except:
            return "CPU: Not Available"
    
    def getReceiverIP(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return "IP: " + ip
        except:
            return "IP: N/A"
    
    def getInternetStatus(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect(("8.8.8.8", 53))
            s.close()
            return "Internet: Connected"
        except:
            return "Internet: Not Connected"
    
    def getPythonVersion(self):
        return "Python: " + sys.version.split()[0]

def main(session, **kwargs):
    session.open(emilpanel)

def menuHook(menuid):
    if menuid == "mainmenu":
        return [(_("Emil Panel"), main, "emil_panel", None)]
    return []

def Plugins(**kwargs):
    return [
        PluginDescriptor(name="Emil Panel", description="Emil Addons Panel", where=PluginDescriptor.WHERE_PLUGINMENU, icon="icon.png", fnc=main),
        PluginDescriptor(name="Emil Panel", description="Emil Addons Panel", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
        PluginDescriptor(name="Emil Panel", description="Emil Addons Panel", where=PluginDescriptor.WHERE_MENU, fnc=menuHook)
    ]