#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  MOHAMED_OS >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"

killall -9 oscam
sleep 5
rm -rf /usr/bin/oscam
rm -rf /usr/script/oscam_em.sh
rm -rf /usr/uninstall/oscam_remove.sh

exit 0
