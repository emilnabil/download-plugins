#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  MOHAMED_OS >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"

/var/emuscript/oscam_em.sh stop

rm -rf /var/bin/oscam
rm -rf /var/emuscript/oscam_em.sh
rm -rf /var/uninstall/oscam_remove.sh

exit 0
