#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  MOHAMED_OS >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"

rm -f /etc/init.d/softcam.Oscam > /dev/null 2>&1
rm -f /etc/init.d/cardserver.Oscam > /dev/null 2>&1
rm -f /usr/bin/list_smargo > /dev/null 2>&1
rm -f /usr/bin/oscam > /dev/null 2>&1
rm -f /usr/uninstall/hdf_Softcamoscam_delfile_gz.sh
exit 0
