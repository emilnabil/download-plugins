from __future__ import absolute_import
from . import _
from Plugins.Plugin import PluginDescriptor
from .AutomaticVolumeAdjustmentSetup import AutomaticVolumeAdjustmentConfigScreen
from .AutomaticVolumeAdjustment import AutomaticVolumeAdjustment
from .AutomaticVolumeAdjustmentConfig import saveVolumeDict

try:
    from Components.SystemInfo import BoxInfo
    IMAGEDISTRO = BoxInfo.getItem('distro')
except:
    from boxbranding import getImageDistro
    IMAGEDISTRO = getImageDistro()

def autostart(reason, **kwargs):
    if 'session' in kwargs:
        session = kwargs['session']
        try:
            AutomaticVolumeAdjustment(session)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in autostart: %s' % str(e))

def autoend(reason, **kwargs):
    if reason == 1 and AutomaticVolumeAdjustment.instance and AutomaticVolumeAdjustment.instance.enabled and AutomaticVolumeAdjustment.instance.modus != '0':
        try:
            saveVolumeDict(AutomaticVolumeAdjustment.instance.serviceList)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in autoend: %s' % str(e))

def setupAVA(session, **kwargs):
    try:
        session.open(AutomaticVolumeAdjustmentConfigScreen)
    except Exception as e:
        print('[AutomaticVolumeAdjustment] Error in setupAVA: %s' % str(e))

def startSetup(menuid):
    try:
        if IMAGEDISTRO in ['openhdf', 'openatv'] and menuid != 'audio_menu':
            return []
        elif IMAGEDISTRO in ['openvix'] and menuid != 'av':
            return []
        elif menuid != 'system':
            return []
        
        return [(_('Automatic Volume Adjustment'), setupAVA, 'AutomaticVolumeAdjustment', 46)]
    except Exception as e:
        print('[AutomaticVolumeAdjustment] Error in startSetup: %s' % str(e))
        return []

def Plugins(**kwargs):
    return [
        PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart),
        PluginDescriptor(where=[PluginDescriptor.WHERE_AUTOSTART], fnc=autoend),
        PluginDescriptor(
            name='Automatic Volume Adjustment',
            description=_('Automatic Volume Adjustment'),
            where=PluginDescriptor.WHERE_MENU,
            fnc=startSetup
        )
    ]
