# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: '/usr/lib/enigma2/python/Plugins/SystemPlugins/AutomaticVolumeAdjustment/__init__.py'
# Bytecode version: 3.13.0rc3 (3571)
# Source timestamp: 1997-03-06 15:39:12 UTC (857662752)

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import gettext

PluginLanguageDomain = 'AutomaticVolumeAdjustment'
PluginLanguagePath = 'SystemPlugins/AutomaticVolumeAdjustment/locale'

def localeInit():
    """تهيئة ملفات الترجمة للغة المحددة"""
    gettext.bindtextdomain(PluginLanguageDomain, 
                          resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))

def _(txt):
    """دالة الترجمة المخصصة للقالب"""
    if not txt:
        return txt
        
    translated = gettext.dgettext(PluginLanguageDomain, txt)
    if translated:
        return translated
    else:
        print('[%s] fallback to default translation for: %s' % (PluginLanguageDomain, txt))
        return gettext.gettext(txt)

# تهيئة الترجمة عند بدء التشغيل
localeInit()

# إضافة دالة التهيئة كرد فعل لتغيير اللغة
language.addCallback(localeInit)
