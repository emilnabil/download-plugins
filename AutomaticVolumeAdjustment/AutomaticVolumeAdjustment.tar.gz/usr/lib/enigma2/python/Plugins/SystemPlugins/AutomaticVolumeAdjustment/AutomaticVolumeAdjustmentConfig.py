from __future__ import print_function
from . import _
from Components.config import ConfigSubsection, ConfigText, config, ConfigInteger, ConfigSubList, ConfigDirectory, NoSave, ConfigYesNo, ConfigSelectionNumber, ConfigSelection
from os import path as os_path
from pickle import load as pickle_load, dump as pickle_dump
from enigma import eEnv

CONFIG_FILE_VOLUME = eEnv.resolve('${sysconfdir}/enigma2/ava_volume.cfg')

def getVolumeDict():
    if os_path.exists(CONFIG_FILE_VOLUME):
        try:
            with open(CONFIG_FILE_VOLUME, 'rb') as pkl_file:
                return pickle_load(pkl_file)
        except Exception:
            return {}
    return {}

def saveVolumeDict(dict_data):
    try:
        with open(CONFIG_FILE_VOLUME, 'wb') as pkl_file:
            pickle_dump(dict_data, pkl_file)
    except Exception:
        pass

class AutomaticVolumeAdjustmentConfig:
    def __init__(self):
        self.CONFIG_FILE = eEnv.resolve('${sysconfdir}/enigma2/ava_setup.cfg')
        self.config = ConfigSubsection()
        self.loadConfigFile()

    def loadConfigFile(self):
        print('[AutomaticVolumeAdjustmentConfig] Loading config file...')
        
        self.config.enable = ConfigYesNo(default=False)
        self.config.modus = ConfigSelection(
            choices=[
                ('0', _('Automatic volume adjust')), 
                ('1', _('Remember service volume value'))
            ], 
            default='0'
        )
        self.config.adustvalue = ConfigSelectionNumber(-50, 50, 5, default=25)
        self.config.mpeg_max_volume = ConfigSelectionNumber(10, 100, 5, default=100)
        self.config.show_volumebar = ConfigYesNo(default=False)
        self.config.type_audio = ConfigYesNo(default=True)
        self.config.entriescount = ConfigInteger(0)
        self.config.Entries = ConfigSubList()
        
        if os_path.exists(self.CONFIG_FILE):
            try:
                self.config.loadFromFile(self.CONFIG_FILE)
                print('[AutomaticVolumeAdjustmentConfig] Config file loaded successfully')
            except Exception as e:
                print('[AutomaticVolumeAdjustmentConfig] Error loading config file:', e)
        else:
            print('[AutomaticVolumeAdjustmentConfig] No config file found, using defaults')
        
        self.initConfig()

    def initConfig(self):
        count = self.config.entriescount.value
        
        if count > 0:
            for i in range(count):
                self.initEntryConfig()
        
        print('[AutomaticVolumeAdjustmentConfig] Loaded %s entries from config file...' % count)

    def initEntryConfig(self):
        entry = ConfigSubsection()
        entry.servicereference = ConfigText(default='')
        entry.name = NoSave(ConfigDirectory(default=_('Press OK to select a service')))
        entry.adjustvalue = ConfigSelectionNumber(-50, 50, 5, default=25)
        
        self.config.Entries.append(entry)
        return entry

    def addEntry(self, servicereference='', name='', adjustvalue=25):
        entry = self.initEntryConfig()
        entry.servicereference.value = servicereference
        entry.name.value = name
        entry.adjustvalue.value = adjustvalue
        
        self.config.entriescount.value = len(self.config.Entries)
        self.config.entriescount.save()
        self.config.Entries.save()
        self.save()
        
        return entry

    def remove(self, configItem):
        if configItem in self.config.Entries:
            self.config.Entries.remove(configItem)
            self.config.entriescount.value = len(self.config.Entries)
            self.config.entriescount.save()
            self.config.Entries.save()
            self.save()
            print('[AutomaticVolumeAdjustmentConfig] Entry removed successfully')
            return True
        return False

    def save(self):
        print('[AutomaticVolumeAdjustmentConfig] Saving config file...')
        try:
            self.config.saveToFile(self.CONFIG_FILE)
            print('[AutomaticVolumeAdjustmentConfig] Config file saved successfully')
            return True
        except Exception as e:
            print('[AutomaticVolumeAdjustmentConfig] Error saving config file:', e)
            return False

    def getEntryByService(self, servicereference):
        for entry in self.config.Entries:
            if entry.servicereference.value == servicereference:
                return entry
        return None

    def getEntryCount(self):
        return len(self.config.Entries)

    def clearEntries(self):
        self.config.Entries = ConfigSubList()
        self.config.entriescount.value = 0
        self.config.entriescount.save()
        self.save()
        print('[AutomaticVolumeAdjustmentConfig] All entries cleared')
