from __future__ import absolute_import
from . import _
from enigma import eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, eServiceReference
from skin import parameters, fonts
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChannelSelection import SimpleChannelSelection
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, config
from ServiceReference import ServiceReference
from .AutomaticVolumeAdjustment import AutomaticVolumeAdjustment
from .AutomaticVolumeAdjustmentConfig import AutomaticVolumeAdjustmentConfig


class AutomaticVolumeAdjustmentConfigScreen(ConfigListScreen, Screen):
    skin = '''
        <screen name="AutomaticVolumeAdjustmentConfigScreen" position="center,center" size="550,400">
            <widget name="config" position="20,10" size="520,330" scrollbarMode="showOnDemand" />
            <ePixmap position="0,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
            <ePixmap position="140,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
            <ePixmap position="280,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
            <ePixmap position="420,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />

            <widget source="key_red" render="Label" position="0,350" zPosition="5" size="140,40" valign="center" halign="center" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
            <widget source="key_green" render="Label" position="140,350" zPosition="5" size="140,40" valign="center" halign="center" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
            <widget render="Label" source="key_blue" position="420,350" zPosition="5" size="140,40" valign="center" halign="center" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
        </screen>'''
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self["actions"] = ActionMap(['SetupActions', 'ColorActions'], 
                                   {'green': self.keySave, 
                                    'red': self.keyCancel, 
                                    'blue': self.blue, 
                                    'cancel': self.keyCancel}, -2)
        
        self.automaticVolumeAdjustmentInstance = AutomaticVolumeAdjustment.instance
        
        if not hasattr(self.automaticVolumeAdjustmentInstance, 'configVA'):
            self.automaticVolumeAdjustmentInstance.configVA = AutomaticVolumeAdjustmentConfig()
        
        self.config_enable = None
        self.config_modus = None
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session)
        self.createSetup('config')
        
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))
        self["key_blue"] = StaticText("")

    def createSetup(self, widget):
        self.list = []
        configVA = self.automaticVolumeAdjustmentInstance.configVA
        
        self.config_enable = getConfigListEntry(_("Enable"), configVA.config.enable)
        self.list.append(self.config_enable)
        
        if configVA.config.enable.value:
            self.config_modus = getConfigListEntry(_('Modus'), configVA.config.modus)
            self.list.append(self.config_modus)
            
            if configVA.config.modus.value == '0':
                self.list.append(getConfigListEntry(_('Default volume adjustment value for AC3/DTS'), 
                                                  configVA.config.adustvalue))
            else:
                self.list.append(getConfigListEntry(_('Max. volume for mpeg audio'), 
                                                  configVA.config.mpeg_max_volume))
            
            self.list.append(getConfigListEntry(_('Only AC3/DTS(HD)'), 
                                              configVA.config.type_audio))
            self.list.append(getConfigListEntry(_('Show volumebar when volume-value was changed'), 
                                              configVA.config.show_volumebar))
        else:
            self.config_modus = None
        
        self[widget].list = self.list
        self[widget].l.setList(self.list)

    def newConfig(self):
        current = self['config'].getCurrent()
        check_list = [self.config_enable]
        if self.config_modus is not None:
            check_list.append(self.config_modus)
        if current and current in check_list:
            self.createSetup('config')

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.newConfig()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.newConfig()

    def blue(self):
        try:
            configVA = self.automaticVolumeAdjustmentInstance.configVA
            if (configVA.config.enable.value and 
                configVA.config.modus.value == '0'):
                from .AutomaticVolumeAdjustmentSetup import AutomaticVolumeAdjustmentEntriesListConfigScreen
                self.session.open(AutomaticVolumeAdjustmentEntriesListConfigScreen, configVA)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in blue: %s' % str(e))

    def keySave(self):
        try:
            configVA = self.automaticVolumeAdjustmentInstance.configVA
            for x in self['config'].list:
                x[1].save()
            if self.automaticVolumeAdjustmentInstance is not None:
                self.automaticVolumeAdjustmentInstance.initializeConfigValues(configVA, True)
            self.close()
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in keySave: %s' % str(e))
            self.close()

    def keyCancel(self):
        try:
            ConfigListScreen.cancelConfirm(self, True)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in keyCancel: %s' % str(e))
            self.close()


class AutomaticVolumeAdjustmentEntriesListConfigScreen(Screen):
    skin = '''
        <screen position="center,center" size="550,400">
            <widget render="Label" source="name" position="5,0" size="350,50" font="Regular;20" halign="left"/>
            <widget render="Label" source="adjustvalue" position="355,0" size="200,50" font="Regular;20" halign="left"/>
            <widget name="entrylist" position="0,50" size="550,300" scrollbarMode="showOnDemand"/>
            <widget render="Label" source="key_red" position="0,350" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
            <widget source="key_green" render="Label" position="140,350" zPosition="5" size="140,40" valign="center" halign="center" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
            <widget render="Label" source="key_yellow" position="280,350" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="yellow" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
            <widget render="Label" source="key_blue" position="420,350" zPosition="5" size="140,40" valign="center" halign="center" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
            <ePixmap position="0,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
            <ePixmap position="140,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
            <ePixmap position="280,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
            <ePixmap position="420,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
        </screen>'''
    
    def __init__(self, session, configVA):
        Screen.__init__(self, session)
        self['entrylist'] = AutomaticVolumeAdjustmentEntryList([])
        self['actions'] = ActionMap(['WizardActions', 'MenuActions', 'ShortcutActions'], 
                                   {'ok': self.keyOK, 
                                    'back': self.keyClose, 
                                    'red': self.keyRed, 
                                    'green': self.keyClose, 
                                    'yellow': self.keyYellow, 
                                    'blue': self.keyDelete}, -1)
        
        self.automaticVolumeAdjustmentInstance = AutomaticVolumeAdjustment.instance
        self['entrylist'].setConfig(configVA)
        
        self["key_red"] = StaticText(_("Add"))
        self["key_green"] = StaticText(_("Close"))
        self["key_yellow"] = StaticText(_("Edit"))
        self["key_blue"] = StaticText(_("Delete"))
        self["name"] = StaticText(_("Service Name"))
        self["adjustvalue"] = StaticText(_("Adjust Value"))
        
        self.updateList()

    def updateList(self):
        try:
            self['entrylist'].buildList()
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in updateList: %s' % str(e))

    def keyClose(self):
        self.close()

    def keyRed(self):
        try:
            from .AutomaticVolumeAdjustmentSetup import AutomaticVolumeAdjustmentEntryConfigScreen
            self.session.openWithCallback(self.updateList, AutomaticVolumeAdjustmentEntryConfigScreen, 
                                         None, self['entrylist'].configVA)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in keyRed: %s' % str(e))

    def keyOK(self):
        sel = self['entrylist'].getCurrentSelection()
        if sel:
            self.close()

    def keyYellow(self):
        try:
            sel = self['entrylist'].l.getCurrentSelection()[0]
            if sel is not None:
                from .AutomaticVolumeAdjustmentSetup import AutomaticVolumeAdjustmentEntryConfigScreen
                self.session.openWithCallback(self.updateList, AutomaticVolumeAdjustmentEntryConfigScreen, 
                                             sel, self['entrylist'].configVA)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in keyYellow: %s' % str(e))

    def keyDelete(self):
        try:
            sel = self['entrylist'].l.getCurrentSelection()[0]
            if sel is not None:
                self.session.openWithCallback(self.deleteConfirm, MessageBox, 
                                            _('Do you really want to delete this entry?'), 
                                            type=MessageBox.TYPE_YESNO)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in keyDelete: %s' % str(e))

    def deleteConfirm(self, result):
        if result:
            try:
                sel = self['entrylist'].l.getCurrentSelection()[0]
                self['entrylist'].configVA.config.Entries.remove(sel)
                self['entrylist'].configVA.config.Entries.save()
                if self.automaticVolumeAdjustmentInstance is not None:
                    self.automaticVolumeAdjustmentInstance.initializeConfigValues(
                        self['entrylist'].configVA, True)
                self.updateList()
            except Exception as e:
                print('[AutomaticVolumeAdjustment] Error in deleteConfirm: %s' % str(e))


class AutomaticVolumeAdjustmentEntryList(MenuList):
    def __init__(self, list, enableWrapAround=True):
        MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
        self.parameters = parameters.get('AutomaticVolumeAdjustmentList', 
                                        (5, 0, 350, 20, 0, 355, 0, 200, 20, 1))
        self.configVA = None

    def postWidgetCreate(self, instance):
        MenuList.postWidgetCreate(self, instance)
        instance.setItemHeight(20)

    def getCurrentIndex(self):
        return self.instance.getCurrentIndex()
    
    def getCurrentSelection(self):
        try:
            return self.l.getCurrentSelection()[0]
        except:
            return None

    def setConfig(self, configVA):
        self.configVA = configVA

    def buildList(self):
        list = []
        if self.configVA and hasattr(self.configVA.config, 'Entries'):
            for c in self.configVA.config.Entries:
                res = [c, 
                      (eListboxPythonMultiContent.TYPE_TEXT, 
                       self.parameters[0], self.parameters[1], self.parameters[2], 
                       self.parameters[3], self.parameters[4], 
                       RT_HALIGN_LEFT | RT_VALIGN_CENTER, c.name.value),
                      (eListboxPythonMultiContent.TYPE_TEXT, 
                       self.parameters[5], self.parameters[6], self.parameters[7], 
                       self.parameters[8], self.parameters[9], 
                       RT_HALIGN_RIGHT | RT_VALIGN_CENTER, str(c.adjustvalue.value))]
                list.append(res)
        self.list = list
        self.l.setList(list)


class AutomaticVolumeAdjustmentEntryConfigScreen(ConfigListScreen, Screen):
    skin = '''
        <screen name="AutomaticVolumeAdjustmentEntryConfigScreen" position="center,center" size="550,400">
            <widget name="config" position="20,10" size="520,330" scrollbarMode="showOnDemand" />
            <ePixmap position="0,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
            <ePixmap position="140,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
            <ePixmap position="280,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
            <ePixmap position="420,350" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />

            <widget source="key_red" render="Label" position="0,350" zPosition="5" size="140,40" valign="center" halign="center" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
            <widget source="key_green" render="Label" position="140,350" zPosition="5" size="140,40" valign="center" halign="center" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
        </screen>'''
    
    def __init__(self, session, entry, configVA):
        Screen.__init__(self, session)
        self.session = session
        self.configVA = configVA
        
        if entry is None:
            self.newmode = 1
            self.current = self.configVA.initEntryConfig()
            self.currentref = None
            self.currentvalue = self.current.adjustvalue.value
        else:
            self.newmode = 0
            self.current = entry
            self.currentref = entry.servicereference.value
            self.currentvalue = entry.adjustvalue.value
        
        self.list = []
        self.service = getConfigListEntry(_('Servicename'), self.current.name)
        self.list.append(self.service)
        
        ConfigListScreen.__init__(self, self.list, session)
        self.automaticVolumeAdjustmentInstance = AutomaticVolumeAdjustment.instance
        
        self["actions"] = ActionMap(["SetupActions", "ColorActions"],
                                   {"red": self.keyCancel,
                                    "green": self.keySave,
                                    "save": self.keySave,
                                    "cancel": self.keyCancel}, -2)
        
        self["key_red"] = StaticText(_("Cancel"))
        self["key_green"] = StaticText(_("Save"))

    def keySelect(self):
        try:
            cur = self['config'].getCurrent()
            if cur == self.service:
                self.session.openWithCallback(self.channelSelected, SimpleChannelSelection, 
                                            _('Channel Selection'))
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in keySelect: %s' % str(e))

    def channelSelected(self, ref=None):
        try:
            if ref:
                self.current.name.value = ServiceReference(ref).getServiceName()
                self.current.servicereference.value = ref.toString()
                self.current.save()
                self.service = getConfigListEntry(_('Servicename'), self.current.name)
                self.list = [self.service]
                self["config"].list = self.list
                self["config"].l.setList(self.list)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in channelSelected: %s' % str(e))

    def keySave(self):
        try:
            if self.current.servicereference.value:
                if self.newmode == 1:
                    self.configVA.config.entriescount.value = self.configVA.config.entriescount.value + 1
                    self.configVA.config.Entries.append(self.current)
                
                for x in self['config'].list:
                    x[1].save()
                
                self.configVA.save()
                
                if self.automaticVolumeAdjustmentInstance is not None:
                    self.automaticVolumeAdjustmentInstance.initializeConfigValues(self.configVA, True)
                self.close()
            else:
                self.session.open(MessageBox, 
                                _('You must select a valid service!'), 
                                type=MessageBox.TYPE_INFO)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in keySave: %s' % str(e))
            self.close()

    def keyCancel(self):
        try:
            if self.newmode == 1:
                if hasattr(self.configVA.config, 'Entries') and self.current in self.configVA.config.Entries:
                    self.configVA.config.Entries.remove(self.current)
                    self.configVA.config.Entries.save()
            else:
                self.current.servicereference.value = self.currentref
                self.current.adjustvalue.value = self.currentvalue
                self.current.save()
            
            ConfigListScreen.cancelConfirm(self, True)
        except Exception as e:
            print('[AutomaticVolumeAdjustment] Error in keyCancel: %s' % str(e))
            self.close()
