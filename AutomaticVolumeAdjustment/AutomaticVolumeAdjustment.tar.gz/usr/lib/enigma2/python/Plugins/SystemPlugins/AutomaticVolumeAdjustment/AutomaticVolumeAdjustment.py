from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.config import config
from Components.ServiceEventTracker import ServiceEventTracker
from enigma import iPlayableService, iServiceInformation, eDVBVolumecontrol, eServiceCenter, eServiceReference
from ServiceReference import ServiceReference
from Components.VolumeControl import VolumeControl
from .AutomaticVolumeAdjustmentConfig import AutomaticVolumeAdjustmentConfig, getVolumeDict

# Compatibility fix for OpenPLi and other images without toggle_AV_session
if not hasattr(config.misc, 'toggle_AV_session'):
    from Components.config import ConfigYesNo
    config.misc.toggle_AV_session = ConfigYesNo(default=True)

class AutomaticVolumeAdjustment(Screen):
    instance = None
    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        print('[AutomaticVolumeAdjustment] Starting AutomaticVolumeAdjustment...')
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evUpdatedInfo: self.__evUpdatedInfo, iPlayableService.evStart: self.__evStart, iPlayableService.evEnd: self.__evEnd})
        self.newService = [False, None]
        self.pluginStarted = False
        self.lastAdjustedValue = 0
        self.currentVolume = 0
        self.enabled = False
        self.serviceList = {}
        configVA = AutomaticVolumeAdjustmentConfig()
        AutomaticVolumeAdjustment.instance = self
        self.volumeControlInstance = None
        self.currentAC3DTS = False
        self.initializeConfigValues(configVA, False)
        self.volctrl = eDVBVolumecontrol.getInstance()
        if not self.volctrl:
            print('[AutomaticVolumeAdjustment] Error: Failed to get volume control instance')
            self.enabled = False

    def initializeConfigValues(self, configVA, fromOutside):
        print('[AutomaticVolumeAdjustment] initialize config values...')
        self.serviceList = {}
        self.modus = configVA.config.modus.value
        if self.modus == '0':
            for c in configVA.config.Entries:
                self.serviceList[c.servicereference.value] = int(c.adjustvalue.value)
        else:
            self.serviceList = getVolumeDict()
        self.defaultValue = int(configVA.config.adustvalue.value)
        self.enabled = configVA.config.enable.value
        self.maxMPEGVolume = int(configVA.config.mpeg_max_volume.value)
        self.showVolumeBar = configVA.config.show_volumebar.value
        self.type_audio = configVA.config.type_audio.value
        if self.modus == '0':
            VolumeControlInit(self.enabled, self.maxMPEGVolume)
        if not self.pluginStarted and self.enabled and fromOutside:
                    self.newService = [True, None]
                    self.__evUpdatedInfo()

    def __evEnd(self):
        if self.pluginStarted and self.enabled and config.misc.toggle_AV_session.value:
                    if self.modus == '0':
                        if self.currentVolume and self.volctrl and self.volctrl.getVolume() != self.currentVolume:
                                self.lastAdjustedValue = self.newService[1] and self.serviceList.get(self.newService[1].toString(), self.defaultValue) or self.defaultValue
                    else:
                        ref = self.newService[1]
                        if ref and ref.valid() and self.volctrl:
                                self.serviceList[ref.toString()] = self.volctrl.getVolume()
                                print('[AutomaticVolumeAdjustment] save last value', ref.toString())
        self.newService = [False, None]

    def __evStart(self):
        self.newService = [True, None]
        if self.pluginStarted and self.enabled and config.misc.toggle_AV_session.value:
                    ref = self.session.nav.getCurrentlyPlayingServiceReference()
                    if ref and ref.toString().startswith('4097:'):
                            self.__evUpdatedInfo()

    def __evUpdatedInfo(self):
        if self.newService[0] and self.session.nav.getCurrentlyPlayingServiceReference() and self.enabled and config.misc.toggle_AV_session.value:
            print('[AutomaticVolumeAdjustment] service changed')
            self.newService = [False, self.session.nav.getCurrentlyPlayingServiceReference()]
            self.currentVolume = 0
            if self.modus == '0':
                self.currentAC3DTS = self.isCurrentAudioAC3DTS()
                if self.pluginStarted:
                    if self.currentAC3DTS:
                        if self.volctrl:
                            vol = self.volctrl.getVolume()
                            currentvol = vol
                            vol -= self.lastAdjustedValue
                            ref = self.getPlayingServiceReference()
                            ajvol = self.serviceList.get(ref.toString(), self.defaultValue)
                            if ajvol < 0:
                                if vol + ajvol < 0:
                                    ajvol = (-1) * vol
                            else:
                                if vol >= 100 - ajvol:
                                    ajvol = 100 - vol
                            self.lastAdjustedValue = ajvol
                            if vol + ajvol != currentvol:
                                if ajvol == 0:
                                    ajvol = vol - currentvol
                                self.setVolume(vol + self.lastAdjustedValue)
                                print('[AutomaticVolumeAdjustment] Change volume for service: %s (+%d) to %d' % (ServiceReference(ref).getServiceName().replace('Â', '').replace('Â', ''), ajvol, self.volctrl.getVolume() if self.volctrl else 0))
                            self.currentVolume = self.volctrl.getVolume() if self.volctrl else 0
                    else:
                        if self.lastAdjustedValue != 0 and self.volctrl:
                            vol = self.volctrl.getVolume()
                            ajvol = vol - self.lastAdjustedValue
                            if ajvol > self.maxMPEGVolume:
                                ajvol = self.maxMPEGVolume
                            self.setVolume(ajvol)
                            print('[AutomaticVolumeAdjustment] Change volume for service: %s (-%d) to %d' % (ServiceReference(self.session.nav.getCurrentlyPlayingServiceReference()).getServiceName().replace('Â', '').replace('Â', ''), vol - ajvol, self.volctrl.getVolume() if self.volctrl else 0))
                            self.lastAdjustedValue = 0
                    return None
            else:
                if self.pluginStarted:
                    ref = self.getPlayingServiceReference()
                    if ref and ref.valid() and self.volctrl:
                            lastvol = self.serviceList.get(ref.toString(), (-1))
                            if lastvol != (-1) and lastvol != self.volctrl.getVolume():
                                    self.setVolume(lastvol)
                                    print('[AutomaticVolumeAdjustment] Set last used volume value for service %s to %d' % (ServiceReference(ref).getServiceName().replace('Â', '').replace('Â', ''), self.volctrl.getVolume() if self.volctrl else 0))
                    return None
            if not self.pluginStarted:
                if self.modus == '0' and self.currentAC3DTS and self.volctrl:
                        self.lastAdjustedValue = self.serviceList.get(self.session.nav.getCurrentlyPlayingServiceReference().toString(), self.defaultValue)
                        self.currentVolume = self.volctrl.getVolume()
                try:
                    self.volumeControlInstance = VolumeControl.instance
                except:
                    print('[AutomaticVolumeAdjustment] VolumeControl.instance is None')
                self.pluginStarted = True

    def isCurrentAudioAC3DTS(self):
        service = self.session.nav.getCurrentService()
        audio = service and service.audioTracks()
        if audio:
            tracknr = audio.getCurrentTrack()
            i = audio.getTrackInfo(tracknr)
            description = i.getDescription()
            if self.type_audio:
                if 'AC3' in description or 'DTS' in description:
                    return True
                if description and description.split()[0] in ['AC3', 'AC-3', 'A_AC3', 'A_AC-3', 'A-AC-3', 'E-AC-3', 'A_EAC3', 'DTS', 'DTS-HD', 'AC4', 'AAC-HE']:
                    return True
                pass
                return False

    def getPlayingServiceReference(self):
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        if ref:
            refstr = ref.toString()
            if '%3a//' not in refstr and refstr.rsplit(':', 1)[1].startswith('/'):
                    self.serviceHandler = eServiceCenter.getInstance()
                    info = self.serviceHandler.info(ref)
                    if info:
                        ref = eServiceReference(info.getInfoString(ref, iServiceInformation.sServiceref))
        return ref

    def setVolume(self, value):
        if self.volctrl:
            self.volctrl.setVolume(value, value)
        else:
            print('[AutomaticVolumeAdjustment] Error: Cannot set volume, volctrl is None')
            return
        if self.volumeControlInstance is not None:
            self.volumeControlInstance.volumeDialog.setValue(value)
            if self.showVolumeBar:
                self.volumeControlInstance.volumeDialog.show()
                self.volumeControlInstance.hideVolTimer.start(3000, True)
        config.audio.volume.value = self.volctrl.getVolume() if self.volctrl else 50
        config.audio.volume.save()

baseVolumeControl_setVolume = None

def VolumeControlInit(enabled, maxVolume):
    global baseVolumeControl_setVolume
    if hasattr(VolumeControl, 'setVolume'):
        if baseVolumeControl_setVolume is None:
            baseVolumeControl_setVolume = VolumeControl.setVolume
        if enabled and maxVolume != 100:
            VolumeControl.setVolume = AVA_setVolume
            VolumeControl.maxVolume = maxVolume
        else:
            if baseVolumeControl_setVolume:
                VolumeControl.setVolume = baseVolumeControl_setVolume
            baseVolumeControl_setVolume = None
    else:
        print('[AutomaticVolumeAdjustment] Warning: VolumeControl.setVolume not found, disabling volume adjustment')
        enabled = False

def AVA_setVolume(self, direction):
    ok = True
    if direction > 0:
        oldvol = self.volctrl.getVolume()
        if not AutomaticVolumeAdjustment.instance.currentAC3DTS and oldvol + 1 > int(self.maxVolume):
                ok = False
                self.volumeDialog.setValue(oldvol)
                self.volumeDialog.show()
                self.hideVolTimer.start(3000, True)
    if ok:
        baseVolumeControl_setVolume(self, direction)
