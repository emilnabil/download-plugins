# -*- coding: utf-8 -*-
#
#  AutomaticVolumeAdjustment E2
#
#  $Id$
#
#  Coded by Dr.Best (c) 2010
#  Support: www.dreambox-tools.info
#
#  This plugin is licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#
from __future__ import print_function
from __future__ import absolute_import
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.config import config
from Components.ServiceEventTracker import ServiceEventTracker
from enigma import iPlayableService, iServiceInformation, eDVBVolumecontrol, eServiceCenter, eServiceReference
from ServiceReference import ServiceReference
from Components.VolumeControl import VolumeControl
from .AutomaticVolumeAdjustmentConfig import AutomaticVolumeAdjustmentConfig, getVolumeDict


class AutomaticVolumeAdjustment(Screen):
    instance = None

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        print("[AutomaticVolumeAdjustment] Starting AutomaticVolumeAdjustment...")
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={
                iPlayableService.evUpdatedInfo: self.__evUpdatedInfo,
                iPlayableService.evStart: self.__evStart,
                iPlayableService.evEnd: self.__evEnd
            })
        self.newService = [False, None]
        self.pluginStarted = False
        self.lastAdjustedValue = 0
        self.currentVolume = 0
        self.enabled = False
        self.serviceList = {}
        configVA = AutomaticVolumeAdjustmentConfig()
        assert not AutomaticVolumeAdjustment.instance, "only one AutomaticVolumeAdjustment instance is allowed!"
        AutomaticVolumeAdjustment.instance = self
        self.volumeControlInstance = None
        self.currentAC3DTS = False
        self.initializeConfigValues(configVA, False)
        self.volctrl = eDVBVolumecontrol.getInstance()

    def initializeConfigValues(self, configVA, fromOutside):
        print("[AutomaticVolumeAdjustment] initialize config values...")
        self.serviceList = {}
        self.modus = configVA.config.modus.value
        if self.modus == "0":
            for c in configVA.config.Entries:
                    self.serviceList[c.servicereference.value] = int(c.adjustvalue.value)
        else:
            self.serviceList = getVolumeDict()
        self.defaultValue = int(configVA.config.adustvalue.value)
        self.enabled = configVA.config.enable.value
        self.maxMPEGVolume = configVA.config.mpeg_max_volume.value
        self.showVolumeBar = configVA.config.show_volumebar.value
        self.type_audio = configVA.config.type_audio.value
        if self.modus == "0":
            VolumeControlInit(self.enabled, self.maxMPEGVolume)
        if not self.pluginStarted and self.enabled and fromOutside:
            self.newService = [True, None]
            self.__evUpdatedInfo()

    def __evEnd(self):
        if self.pluginStarted and self.enabled:
            if self.modus == "0":
                if self.currentVolume and self.volctrl.getVolume() != self.currentVolume:
                    self.lastAdjustedValue = self.newService[1] and self.serviceList.get(self.newService[1].toString(), self.defaultValue) or self.defaultValue
            else:
                ref = self.newService[1]
                if ref and ref.valid():
                    self.serviceList[ref.toString()] = self.volctrl.getVolume()
        self.newService = [False, None]

    def __evStart(self):
        self.newService = [True, None]

    def __evUpdatedInfo(self):
        if self.newService[0] and self.session.nav.getCurrentlyPlayingServiceReference() and self.enabled:
            print("[AutomaticVolumeAdjustment] service changed")
            self.newService = [False, self.session.nav.getCurrentlyPlayingServiceReference()]
            self.currentVolume = 0
            if self.modus == "0":
                self.currentAC3DTS = self.isCurrentAudioAC3DTS()
                if self.pluginStarted:
                    if self.currentAC3DTS:
                        vol = self.volctrl.getVolume()
                        currentvol = vol
                        vol -= self.lastAdjustedValue
                        ref = self.getPlayingServiceReference()
                        ajvol = self.serviceList.get(ref.toString(), self.defaultValue)
                        if ajvol < 0:
                            if vol + ajvol < 0:
                                ajvol = (-1) * vol
                        else:
                            if vol >= 100 - ajvol:
                                ajvol = 100 - vol
                        self.lastAdjustedValue = ajvol
                        if (vol + ajvol != currentvol):
                            if ajvol == 0:
                                ajvol = vol - currentvol
                            self.setVolume(vol + self.lastAdjustedValue)
                            print("[AutomaticVolumeAdjustment] Change volume for service: %s (+%d) to %d" % (ServiceReference(ref).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', ''), ajvol, self.volctrl.getVolume()))
                        self.currentVolume = self.volctrl.getVolume()
                    else:
                        if self.lastAdjustedValue != 0:
                            vol = self.volctrl.getVolume()
                            ajvol = vol - self.lastAdjustedValue
                            if ajvol > self.maxMPEGVolume:
                                    ajvol = self.maxMPEGVolume
                            self.setVolume(ajvol)
                            print("[AutomaticVolumeAdjustment] Change volume for service: %s (-%d) to %d" % (ServiceReference(self.session.nav.getCurrentlyPlayingServiceReference()).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', ''), vol - ajvol, self.volctrl.getVolume()))
                            self.lastAdjustedValue = 0
                    return
            else:
                if self.pluginStarted:
                    ref = self.getPlayingServiceReference()
                    if ref.valid():
                        lastvol = self.serviceList.get(ref.toString(), -1)
                        if lastvol != -1 and lastvol != self.volctrl.getVolume():
                            self.setVolume(lastvol)
                            print("[AutomaticVolumeAdjustment] Set last used volume value for service %s to %d" % (ServiceReference(ref).getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', ''), self.volctrl.getVolume()))
                    return
            if not self.pluginStarted:
                if self.modus == "0":
                    if self.currentAC3DTS:
                        self.lastAdjustedValue = self.serviceList.get(self.session.nav.getCurrentlyPlayingServiceReference().toString(), self.defaultValue)
                        self.currentVolume = self.volctrl.getVolume()
                try:
                    self.volumeControlInstance = VolumeControl.instance
                except:
                    print("[AutomaticVolumeAdjustment] VolumeControl.instance is None")
                self.pluginStarted = True

    def isCurrentAudioAC3DTS(self):
        service = self.session.nav.getCurrentService()
        audio = service.audioTracks()
        if audio:
            try:
                tracknr = audio.getCurrentTrack()
                i = audio.getTrackInfo(tracknr)
                description = i.getDescription()
                if self.type_audio:
                    if "AC3" in description or "DTS" in description:
                        return True
                else:
                    if description and description.split()[0] in ("AC3", "AC-3", "A_AC3", "A_AC-3", "A-AC-3", "E-AC-3", "A_EAC3", "DTS", "DTS-HD", "AC4", "AAC-HE"):
                        return True
            except:
                pass
        return False

    def getPlayingServiceReference(self):
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        if ref:
            refstr = ref.toString()
            if "%3a//" not in refstr and refstr.rsplit(":", 1)[1].startswith("/"):
                self.serviceHandler = eServiceCenter.getInstance()
                info = self.serviceHandler.info(ref)
                if info:
                    ref = eServiceReference(info.getInfoString(ref, iServiceInformation.sServiceref))
        return ref

    def setVolume(self, value):
        self.volctrl.setVolume(value, value)
        if self.volumeControlInstance is not None:
            self.volumeControlInstance.volumeDialog.setValue(value)
            if self.showVolumeBar:
                self.volumeControlInstance.volumeDialog.show()
                self.volumeControlInstance.hideVolTimer.start(3000, True)
        try:
            if hasattr(config, 'audio') and hasattr(config.audio, 'volume'):
                config.audio.volume.value = self.volctrl.getVolume()
                config.audio.volume.save()
        except:
            pass


baseVolumeControl_setVolume = None


def VolumeControlInit(enabled, maxVolume):
    global baseVolumeControl_setVolume
    if baseVolumeControl_setVolume is None:
        if hasattr(VolumeControl, 'setVolume'):
            baseVolumeControl_setVolume = VolumeControl.setVolume
        else:
            def dummy_setVolume(self, volume):
                pass
            baseVolumeControl_setVolume = dummy_setVolume
            print("[AutomaticVolumeAdjustment] VolumeControl.setVolume not found, using dummy function")
    if enabled and maxVolume != 100:
        VolumeControl.setVolume = AVA_setVolume
        VolumeControl.maxVolume = maxVolume
    else:
        VolumeControl.setVolume = baseVolumeControl_setVolume
        baseVolumeControl_setVolume = None


def AVA_setVolume(self, direction):
    ok = True
    if direction > 0:
        oldvol = self.volctrl.getVolume()
        if not AutomaticVolumeAdjustment.instance.currentAC3DTS:
            if oldvol + 1 > self.maxVolume:
                ok = False
                self.volumeDialog.setValue(oldvol)
                self.volumeDialog.show()
                self.hideVolTimer.start(3000, True)
    if ok:
        baseVolumeControl_setVolume(self, direction)
