import json
import hashlib
import time
from datetime import datetime
from .plugin import debugs

try:
    from urllib2 import Request, urlopen
    from urllib import urlencode
except ImportError:
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode


def generate_url_variants(original_url, host, saved_base_path):
    if debugs:
        print("*** generate_url_variants ***")
    """
    Generate a list of URL variants using the saved base path (e.g., /stalker_portal/api.php)
    and fall back to the original URL if needed.
    """
    if not original_url or not host:
        return []

    if saved_base_path != "/portal.php":
        query_part = ""
        if "portal.php" in original_url:
            query_part = original_url.split("portal.php", 1)[1]
        elif "load.php" in original_url:
            query_part = original_url.split("load.php", 1)[1]
        elif host in original_url:
            query_part = original_url.split(host, 1)[-1]

        if query_part:
            modified_url = host.rstrip("/") + saved_base_path + query_part
            return [modified_url, original_url]

    return [original_url]


def make_request(url, headers=None, legacy_params=None):
    try:
        if legacy_params:
            url += "?" + urlencode(legacy_params)

        req = Request(url)

        if headers:
            for key, value in headers.items():
                req.add_header(key, value)

        response = urlopen(req, timeout=10)
        content = response.read()

        try:
            content = content.decode("utf-8")
        except:
            pass

        data = json.loads(content)
        return data

    except Exception as e:
        print(e)
        return None


def get_profile_data(mac, token, random, profile_urls, headers, pythonVer, debugs=False):
    dt = datetime.now()
    timestamp = datetime.timestamp(dt) if pythonVer == 3 else time.mktime(dt.timetuple())

    md5_hash = hashlib.md5(mac.encode()).hexdigest().upper()[:13]

    metrics = {
        "mac": mac,
        "sn": md5_hash,
        "type": "STB",
        "model": "MAG250",
        "uid": "",
        "random": random or "null"
    }

    legacy_params = {
        'action': 'get_profile',
        'mac': mac,
        'type': 'stb',
        'hd': '1',
        'sn': md5_hash,
        'stb_type': "MAG250",
        'client_type': 'STB',
        'image_version': '218',
        'device_id': "",
        'hw_version': '1.7-BD-00',
        'hw_version_2': '1.7-BD-00',
        'auth_second_step': '1',
        'video_out': 'hdmi',
        'num_banks': '2',
        'ver': "ImageDescription: 0.2.18-r14-pub-250;ImageDate: Fri Jan 15 15:20:44 EET 2016;PORTAL version: 5.6.1;API Version: JS API version: 328;STB API version: 134;Player Engine version: 0x566",
        'not_valid_token': '0',
        'metrics': json.dumps(metrics),
        'timestamp': str(timestamp),
        'api_signature': '262'
    }

    profile_data = None
    profile_data2 = None
    xtream_creds = None
    play_token = None
    status = 0
    blocked = "0"
    playback_limit = None

    headers["Authorization"] = "Bearer " + token

    for profile_url in profile_urls:
        profile_data = make_request(profile_url, headers, legacy_params)
        if profile_data:
            break

    if profile_data:
        if debugs:
            print("*** profiledata ***", json.dumps(profile_data))
        js_data = profile_data.get("js", {})
        play_token = js_data.get("play_token", play_token)
        status = js_data.get("status", status)
        blocked = js_data.get("blocked", blocked)
        playback_limit = js_data.get("playback_limit", playback_limit)

        if js_data.get("login") and js_data.get("password"):
            xtream_creds = {
                "username": js_data["login"],
                "password": js_data["password"]
            }

    for profile_url in profile_urls:
        profile_data2 = make_request(profile_url, headers)
        if profile_data2:
            break

    if profile_data2:
        if debugs:
            print("*** profiledata2 ***", json.dumps(profile_data2))
        js_data = profile_data2.get("js", {})
        play_token = js_data.get("play_token", play_token)
        status = js_data.get("status", status)
        blocked = js_data.get("blocked", blocked)
        playback_limit = js_data.get("playback_limit", playback_limit)

        if js_data.get("login") and js_data.get("password"):
            xtream_creds = {
                "username": js_data["login"],
                "password": js_data["password"]
            }

    return {
        "xtream_creds": xtream_creds,
        "play_token": play_token,
        "status": status,
        "blocked": blocked,
        "playback_limit": playback_limit
    }
