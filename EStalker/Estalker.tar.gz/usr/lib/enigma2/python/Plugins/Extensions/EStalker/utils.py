import json
import os
import re

# Third-party imports
import requests
from requests.adapters import HTTPAdapter

try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode


try:
    from urlparse import urlparse, parse_qsl, urlunparse
except ImportError:
    from urllib.parse import urlparse, parse_qsl, urlunparse


PROTOCOL_PATTERN = re.compile(r"this\.portal_protocol\s*=\s*document\.URL\.replace\(pattern,\s*\"([^\"]+)\"\)")
IP_PATTERN = re.compile(r"this\.portal_ip\s*=\s*document\.URL\.replace\(pattern,\s*\"([^\"]+)\"\)")
PATH_PATTERN = re.compile(r"this\.portal_path\s*=\s*document\.URL\.replace\(pattern,\s*\"([^\"]+)\"\)")
LOADER_PATTERN = re.compile(r"this\.ajax_loader\s*=\s*(.*?\.php);")
URL_PATTERN = re.compile(r"(https?):\/\/([^\/]*)\/([^\/]*)")


def get_local_timezone():
    """Get local timezone from /etc/timezone or use Europe/London as fallback"""
    timezone_path = '/etc/timezone'
    default_tz = 'Europe/London'

    try:
        if os.path.exists(timezone_path):
            with open(timezone_path, 'r') as f:
                timezone = f.read().strip()
                # Validate it looks like a proper timezone (Area/City format)
                if '/' in timezone and not timezone.startswith('#'):
                    return timezone
    except (IOError, PermissionError):
        pass

    return default_tz


def make_request(url, headers=None, params=None, response_type=None):
    with requests.Session() as http:
        adapter = HTTPAdapter(max_retries=1)
        http.mount("http://", adapter)
        http.mount("https://", adapter)

        data = None

        try:
            if params:
                parsed_url = urlparse(url)
                existing_params = dict(parse_qsl(parsed_url.query))
                merged_params = existing_params.copy()
                merged_params.update(params)
                query_string = urlencode(merged_params)
                url = urlunparse(parsed_url._replace(query=query_string))

            r = http.get(url, headers=headers, timeout=5, verify=False)
            r.raise_for_status()

            if response_type == "json":
                try:
                    data = r.json()
                except ValueError:
                    try:
                        data = json.loads(r.text)
                    except:
                        data = None
            elif response_type == "javascript":
                data = r.text

            if data:
                print("*** final_url ***", url)

            return data

        except Exception as e:
            print("Request error:", e)
            return None


def xtream_request(url):
    response = None

    hdr = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0",
        "Accept-Encoding": "gzip, deflate",
    }

    with requests.Session() as http:
        adapter = HTTPAdapter(max_retries=1)
        http.mount("http://", adapter)
        http.mount("https://", adapter)

        try:
            r = http.get(url, headers=hdr, timeout=(10, 10), verify=False)
            r.raise_for_status()

            try:
                response = r.json()
            except ValueError:
                try:
                    response_text = r.text
                    # print("*** not json response ***", e)
                    response = json.loads(response_text)

                except json.JSONDecodeError as e:
                    print("Error decoding JSON from HTML content:", e, url)
                    return None

        except requests.exceptions.RequestException as e:
            print("Request error:", e)

        except Exception as e:
            print("Unexpected error:", e)

    return response
