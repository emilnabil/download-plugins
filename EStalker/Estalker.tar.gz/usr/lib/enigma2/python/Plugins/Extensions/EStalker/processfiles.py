#!/usr/bin/python
# -*- coding: utf-8 -*-

from collections import OrderedDict
import json
import os
import re

try:
    from urllib.parse import urlparse
except ImportError:
    from urlparse import urlparse

from .plugin import cfg

playlist_file = cfg.playlist_file.value
playlists_json = cfg.playlists_json.value


def process_files():
    if not os.path.isfile(playlist_file):
        with open(playlist_file, "a"):
            pass

    if not os.path.isfile(playlists_json):
        with open(playlists_json, "a"):
            pass

    try:
        with open(playlist_file, "r") as f:
            lines = f.readlines()
    except:
        return

    # validated_lines = []
    mac_regex = re.compile(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$')

    url_mac_lines = OrderedDict()
    current_url = None
    # mac_seen = set()

    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            continue

        is_url = line.startswith("http://") or line.startswith("https://")
        if is_url:
            line = line.rstrip('/')
            if line.lower().endswith('/c'):
                line = line[:-2]
            if line.lower().endswith('/stalker_portal'):
                line = line[:-15]
            if line.lower().endswith('/portal'):
                line = line[:-7]

            current_url = line
            if current_url not in url_mac_lines:
                url_mac_lines[current_url] = []
            continue

        if current_url is None:
            continue

        url_mac_lines[current_url].append(raw_line.rstrip())

    # Rebuild playlists.txt with grouped URLs and all MACs (including commented ones)
    try:
        with open(playlist_file, "w") as f:
            for url, mac_lines in url_mac_lines.items():
                f.write(url + "\n")
                for mac_line in mac_lines:
                    f.write(mac_line.rstrip() + "\n")
                f.write("\n")
    except:
        pass

    # Build JSON from uncommented and valid MACs only
    existing_entries = []
    try:
        with open(playlists_json, "r") as json_file:
            existing_entries = json.load(json_file)
    except:
        existing_entries = []

    existing_lookup = {}
    for entry in existing_entries:
        info = entry.get("playlist_info", {})
        key = (
            info.get("domain", ""),
            str(info.get("port", "")),
            info.get("mac", "").lower()
        )
        existing_lookup[key] = entry

    playlists_grouped = []
    valid_keys = set()
    index = 0

    livetype = cfg.livetype.value
    vodtype = cfg.vodtype.value

    for url, mac_lines in url_mac_lines.items():
        parsed_uri = urlparse(url)
        protocol = parsed_uri.scheme + "://"
        domain = parsed_uri.hostname.lower() if parsed_uri.hostname else ""
        port = parsed_uri.port or ""
        host = protocol + domain + (":" + str(port) if port else "")

        for mac_line in mac_lines:
            mac_stripped = mac_line.lstrip("#").strip().split()[0].lower()
            if not mac_regex.match(mac_stripped):
                continue

            if mac_line.strip().startswith("#"):
                continue  # Skip commented MACs for JSON

            key = (domain, str(port), mac_stripped)
            if key in valid_keys:
                continue
            valid_keys.add(key)

            if key in existing_lookup:
                existing_lookup[key]["playlist_info"]["index"] = index
                playlists_grouped.append(existing_lookup[key])
            else:
                playlists_grouped.append({
                    "playlist_info": {
                        "index": index,
                        "protocol": protocol,
                        "domain": domain,
                        "port": port,
                        "host": host,
                        "mac": mac_stripped,
                        "token": "",
                        "valid": True,
                        "expiry": "",
                        "version": ""
                    },
                    "player_info": OrderedDict([
                        ("livetype", livetype),
                        ("vodtype", vodtype),
                        ("livehidden", []),
                        ("channelshidden", []),
                        ("vodhidden", []),
                        ("vodstreamshidden", []),
                        ("serieshidden", []),
                        ("seriestitleshidden", []),
                        ("seriesseasonshidden", []),
                        ("seriesepisodeshidden", []),
                        ("catchuphidden", []),
                        ("catchupchannelshidden", []),
                        ("livefavourites", []),
                        ("vodfavourites", []),
                        ("seriesfavourites", []),
                        ("liverecents", []),
                        ("vodrecents", []),
                        ("vodwatched", []),
                        ("serieswatched", []),
                        ("showlive", True),
                        ("showvod", True),
                        ("showseries", True),
                        ("showcatchup", True),
                        ("showadult", False),
                        ("serveroffset", 0),
                        ("catchupoffset", 0),
                        ("epgoffset", 0)
                    ]),
                    "data": {
                        "live_categories": {},
                        "vod_categories": {},
                        "series_categories": {},
                        "live_streams": [],
                        "catchup": False,
                        "customsids": False,
                        "epg_date": "",
                        "data_downloaded": False,
                        "fail_count": 0
                    }
                })
            index += 1

    with open(playlists_json, "w") as json_file:
        json.dump(playlists_grouped, json_file, indent=4)

    return playlists_grouped
