#!/usr/bin/python
# -*- coding: utf-8 -*-

# Standard library imports
from __future__ import division

import json
import os
import re
import time


try:
    from http.client import HTTPConnection
    HTTPConnection.debuglevel = 0
except ImportError:
    from httplib import HTTPConnection
    HTTPConnection.debuglevel = 0

from datetime import datetime

try:
    from urllib.parse import urlparse
except ImportError:
    from urlparse import urlparse

# Third-party imports
import requests
from requests.adapters import HTTPAdapter

# Enigma2 components
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from enigma import eTimer
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap

# Local application/library-specific imports
from . import _
from . import estalker_globals as glob
from .plugin import skin_directory, cfg, common_path, version, hasConcurrent, hasMultiprocessing, debugs, pythonVer, base_headers, base_metrics, base_params
from .eStaticText import StaticText
from . import checkinternet
from .utils import get_local_timezone, make_request, xtream_request
from . import processfiles as loadfiles

# epgimporter = os.path.isdir("/usr/lib/enigma2/python/Plugins/Extensions/EPGImport")


playlist_file = cfg.playlist_file.value
playlists_json = cfg.playlists_json.value


class EStalker_Playlists(Screen):
    ALLOW_SUSPEND = True

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        skin_path = os.path.join(skin_directory, cfg.skin.value)
        skin = os.path.join(skin_path, "playlists.xml")
        with open(skin, "r") as f:
            self.skin = f.read()

        self.setup_title = _("Manage Playlists")

        self["key_red"] = StaticText(_("Back"))
        self["key_green"] = StaticText(_("OK"))
        self["key_yellow"] = StaticText(_("Delete"))
        self["key_blue"] = StaticText(_("Auto Delete"))
        self["version"] = StaticText(version)

        self.list = []
        self.drawList = []
        self["playlists"] = List(self.drawList, enableWrapAround=True)
        self["playlists"].onSelectionChanged.append(self.getCurrentEntry)
        self["splash"] = Pixmap()
        self["splash"].show()
        self["scroll_up"] = Pixmap()
        self["scroll_down"] = Pixmap()
        self["scroll_up"].hide()
        self["scroll_down"].hide()

        self["actions"] = ActionMap(["EStalkerActions"], {
            "red": self.quit,
            "green": self.getStreamTypes,
            "cancel": self.quit,
            "ok": self.getStreamTypes,
            "yellow": self.deleteServer,
            "blue": self.autoDeleteInvalid,  # Add this line
            "0": self.goTop
        }, -2)

        self.timezone = get_local_timezone()

        self.onFirstExecBegin.append(self.start)
        self.onLayoutFinish.append(self.__layoutFinished)

    def clear_caches(self):
        if debugs:
            print("*** clear_caches ***")
        try:
            with open("/proc/sys/vm/drop_caches", "w") as drop_caches:
                drop_caches.write("1\n2\n3\n")
        except IOError:
            pass

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def start(self):
        if debugs:
            print("*** start ***")
        loadfiles.process_files()

        self.checkinternet = checkinternet.check_internet()
        if not self.checkinternet:
            self.session.openWithCallback(self.quit, MessageBox, _("No internet."), type=MessageBox.TYPE_ERROR, timeout=5)

        self.playlists_all = []

        # check if playlists.json file exists in specified location
        if os.path.isfile(playlists_json):
            with open(playlists_json, "r") as f:
                try:
                    self.playlists_all = json.load(f)
                    self.playlists_all.sort(key=lambda e: e["playlist_info"]["index"], reverse=False)
                except:
                    os.remove(playlists_json)

        if self.playlists_all and os.path.isfile(playlist_file) and os.path.getsize(playlist_file) > 0:
            self.delayedDownload()
        else:
            self.close()

        self.clear_caches()

    def delayedDownload(self):
        if debugs:
            print("*** delayedDownload ***")
        self.timer = eTimer()
        try:
            self.timer_conn = self.timer.timeout.connect(self.makeUrlList)
        except:
            try:
                self.timer.callback.append(self.makeUrlList)
            except:
                self.makeUrlList()
        self.timer.start(10, True)

    def makeUrlList(self):
        if debugs:
            print("*** makeUrlList ***")

        self.url_list = []

        for index, playlist in enumerate(self.playlists_all):
            domain = str(playlist["playlist_info"].get("domain", ""))
            host = str(playlist["playlist_info"].get("host", "")).rstrip("/")
            mac = playlist["playlist_info"].get("mac", "")

            if host and mac:
                self.url_list.append((None, index, mac, host, domain, self.timezone))

        if self.url_list:
            self.process_downloads()

    def download_url(self, url_info):
        index = url_info[1]
        mac = url_info[2].upper()
        host = url_info[3]
        domain = url_info[4]
        timezone = url_info[5]

        # Initialize variables
        token = None
        play_token = None
        status = 0
        blocked = "0"
        expiry = ""
        portal_version = ""
        xtream_creds = None
        playback_limit = None
        username = ""
        password = ""
        active_cons = ""
        max_cons = ""
        random = None

        portal = self.playlists_all[index]["playlist_info"].get("portal", None)
        portal_version = self.playlists_all[index]["playlist_info"].get("version", "")

        with requests.Session() as http:
            # Configure session
            adapter = HTTPAdapter(max_retries=1)
            http.mount("http://", adapter)
            http.mount("https://", adapter)

            version_urls = [
                host.rstrip("/") + "/c/version.js",
                host.rstrip("/") + "/stalker_portal/c/version.js"
            ]

            if not portal:
                portal = str(host) + "/portal.php"
            # version number
            if not portal_version or not portal:
                for v_url in version_urls:
                    try:

                        vresponse = make_request(v_url, base_headers, None, "javascript")

                        # r = http.get(v_url, timeout=(4, 4), verify=False)
                        # r.raise_for_status()

                        if vresponse:
                            match = re.search(r"ver\s*=\s*['\"](\d+\.\d+\.\d+)['\"]", vresponse)

                            if match:
                                portal_version = match.group(1)
                            else:
                                portal_version = ""

                            if portal_version:
                                # print("*** portal_version ***", portal_version)
                                if "stalker_portal" in v_url:
                                    portal = str(host) + "/stalker_portal/server/load.php"
                                else:
                                    portal = str(host) + "/portal.php"
                                break
                    except Exception as e:
                        print(e)

                for playlist in self.playlists_all:
                    playlist_info = playlist.get("playlist_info", {})

                    host_url = playlist_info.get("host", "")
                    if not host_url:
                        continue

                    if host == host_url:
                        playlist_info["portal"] = portal

                with open(playlists_json, "w") as f:
                    json.dump(self.playlists_all, f, indent=4)

            # Base headers
            extra = ""
            if "/stalker_portal/" in portal:
                extra = "/stalker_portal"

            host_headers = {
                "Referer": "{}{}/c/".format(host, extra),
                "Host": domain,
                "Cookie": "mac={}; stb_lang=en; timezone={};".format(mac, timezone)
            }

            headers = dict(base_headers)
            headers.update(host_headers)

            # print("*** headers ***", headers)

            # 1. Handshake

            portal = self.playlists_all[index]["playlist_info"].get("portal", None)
            handshake_url = str(portal) + "?type=stb&action=handshake&JsHttpRequest=1-xml&mac={}".format(mac)

            if debugs:
                print("*** handshake_url ***", handshake_url)

            try:
                response = make_request(handshake_url, headers, None, "json")

                if not response:
                    if "/stalker_portal/" in portal:
                        portal = str(host) + "/portal.php"
                    else:
                        portal = str(host) + "/stalker_portal/server/load.php"

                handshake_url = str(portal) + "?type=stb&action=handshake&JsHttpRequest=1-xml&mac={}".format(mac)
                response = make_request(handshake_url, headers, None, "json")

                if not response:
                    return index, {"valid": False}

                # print("*** response ***", response)

                if isinstance(response, dict):
                    js_data = response.get("js", {})

                    if isinstance(js_data, dict):
                        token = js_data.get("token")

                        if token:
                            random = js_data.get("random")  # Optional
                            print("*** token ***", token)
                            if random:
                                print("*** random ***", random)
                        else:
                            print("Token missing in response: {}".format(js_data))
                    else:
                        print("Invalid 'js' block in response:", js_data)
                else:
                    print("Invalid response format (not a dict):", response)

            except Exception as e:
                print("Error during handshake with {}: {}".format(handshake_url, e))

            if not token:
                return index, {"valid": False}

            # Add Authorization header now that we have a token
            headers["Authorization"] = "Bearer " + token

            # print("*** headers 2 ***", headers)

            profile_url = str(portal) + "?type=stb&action=get_profile&JsHttpRequest=1-xml"

            # 2. Get Profiles
            dt = datetime.now()
            timestamp = datetime.timestamp(dt) if pythonVer == 3 else time.mktime(dt.timetuple())

            import hashlib

            md5_hash = hashlib.md5(mac.encode()).hexdigest().upper()[:13]

            if random:
                randomstring = random
            else:
                randomstring = ""

            host_metrics = {
                "mac": mac,
                "sn": md5_hash,
                "random": randomstring
            }

            metrics = dict(base_metrics)
            metrics.update(host_metrics)

            """
            # 2. Get Profiles first pass
            host_params1 = {
                'sn': md5_hash,
                'timestamp': str(timestamp),
                'metrics': json.dumps(metrics),
            }

            profile_params1 = dict(base_params)
            profile_params1.update(host_params1)
            """

            """
            profile_data = make_request(profile_url, headers, profile_params1, "json")

            if profile_data:
                if debugs:
                    print("*** profiledata ***", json.dumps(profile_data))
                js_data = profile_data.get("js", {})
                play_token = js_data.get("play_token", play_token)
                status = js_data.get("status", status)
                blocked = js_data.get("blocked", blocked)
                playback_limit = js_data.get("playback_limit", playback_limit)

                # Check for Xtream Codes credentials

                if js_data.get("login") and js_data.get("password"):
                    xtream_creds = {
                        "username": js_data["login"],
                        "password": js_data["password"]
                    }
                    """

            # 2. Get Profiles seconds pass
            if "/stalker_portal/" in portal:
                host_params2 = {
                    'var': "ver=ImageDescription: 0.2.18-r14-pub-250; ImageDate: Fri Jan 15 15:20:44 EET 2016; PORTAL version: 5.5.0; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566",
                    'sn': md5_hash,
                    'image_version': "218",
                    'timestamp': str(timestamp),
                    'metrics': json.dumps(metrics),
                    'device_id': "",
                    'device_id': "",
                }

                profile_params2 = dict(base_params)
                profile_params2.update(host_params2)

                profile_data2 = make_request(profile_url, headers, profile_params2, "json")

                if profile_data2:
                    if debugs:
                        print("*** profiledata2 ***", json.dumps(profile_data2))
                    js_data = profile_data2.get("js", {})
                    play_token = js_data.get("play_token", play_token)
                    status = js_data.get("status", status)
                    blocked = js_data.get("blocked", blocked)
                    playback_limit = js_data.get("playback_limit", playback_limit)

                    # Check for Xtream Codes credentials
                    if js_data.get("login") and js_data.get("password"):
                        xtream_creds = {
                            "username": js_data["login"],
                            "password": js_data["password"]
                        }
            else:
                profile_data2 = make_request(profile_url, headers, None, "json")

                if profile_data2:
                    if debugs:
                        print("*** profiledata2 ***", json.dumps(profile_data2))
                    js_data = profile_data2.get("js", {})
                    play_token = js_data.get("play_token", play_token)
                    status = js_data.get("status", status)
                    blocked = js_data.get("blocked", blocked)
                    playback_limit = js_data.get("playback_limit", playback_limit)

                    # Check for Xtream Codes credentials
                    if js_data.get("login") and js_data.get("password"):
                        xtream_creds = {
                            "username": js_data["login"],
                            "password": js_data["password"]
                        }

            # 3. Get Main Info with proper headers
            account_info_url = str(portal) + "?type=account_info&action=get_main_info&JsHttpRequest=1-xml"
            account_info = make_request(account_info_url, headers, None, "json")

            if account_info:
                if debugs:
                    print("*** account_info 2***", account_info)
                expiry = account_info.get("js", {}).get("phone", "")

            # 4. If no credentials found, try additional methods
            # Try VOD if still no credentials

            if not xtream_creds:

                vod_url = str(portal) + "?type=vod&action=get_ordered_list&genre=*&JsHttpRequest=1-xml"
                vod_data = make_request(vod_url, headers, None, "json")

                if vod_data:
                    js_data = vod_data.get("js", {})

                    if isinstance(js_data, dict) and js_data.get("data"):
                        first_vod = next((v for v in js_data["data"] if v.get("cmd")), None)
                        if first_vod:
                            create_link_url = str(portal) + "?type=vod&action=create_link&cmd={}&JsHttpRequest=1-xml".format(
                                first_vod["cmd"]
                            )

                            link_data = make_request(create_link_url, headers, None, "json")

                            if link_data and link_data.get("js", {}).get("cmd"):
                                # Extract URL from cmd field
                                stream_url = link_data["js"]["cmd"]

                                if isinstance(stream_url, str):
                                    parsed = urlparse(stream_url)
                                    if parsed.scheme in ["http", "https"]:
                                        stream_url = parsed.geturl()

                                # Parse username and password from URL
                                # import re
                                match = re.search(r'http://[^/]+/movie/([^/]+)/([^/]+)/', stream_url)
                                if match:
                                    username = match.group(1)
                                    password = match.group(2)
                                    xtream_creds = {
                                        "username": username,
                                        "password": password
                                    }

            # If credentials found, get Xtream API info
            if xtream_creds and len(password) != 32:
                api_url = host.rstrip("/") + "/player_api.php?username={}&password={}".format(xtream_creds["username"], xtream_creds["password"])
                time.sleep(2)
                api_data = xtream_request(api_url)

                if api_data:
                    if api_data and 'user_info' in api_data:
                        user_info = api_data['user_info']

                        # Process active connections
                        active_cons = str(user_info.get('active_cons', ""))
                        max_cons = str(user_info.get('max_connections', ""))

                        # Override status if auth=1 and status="Active"
                        if user_info.get('auth') == 1 and user_info.get('status') == "Active":
                            status = 0  # Your custom status code

                        # Process expiry date
                        if 'exp_date' in user_info:
                            try:
                                expiry_timestamp = int(user_info['exp_date'])
                                if expiry_timestamp > 0:
                                    expiry = datetime.utcfromtimestamp(expiry_timestamp).strftime('%Y-%m-%d')
                            except (ValueError, TypeError):
                                pass

            self.playlists_all[index]["playlist_info"]["version"] = portal_version

            valid = bool(token and blocked != "1")

            if debugs:
                print("*** token ***", token)
                print("*** valid ***", valid)
                print("*** expiry ***", expiry)
                print("*** status ***", status)
                print("*** blocked ***", blocked)
                print("*** playback_limit ***", playback_limit)
                print("*** xtream_creds ***", xtream_creds)
                print("*** temp_username ***", username)
                print("*** temp_password ***", password)
                print("*** active_connections ***", active_cons)
                print("*** max_connections ***", max_cons)

            return index, {
                "token": token or "",
                "valid": valid,
                "expiry": expiry or "",
                "play_token": play_token or "",
                "status": status,
                "blocked": blocked,
                "playback_limit": playback_limit,
                "xtream_creds": xtream_creds,
                "temp_username": username,
                "temp_password": password,
                "active_connections": active_cons,
                "max_connections": max_cons,
            }

    def process_downloads(self):
        if debugs:
            print("*** process_downloads ***")

        # Determine optimal thread count

        threads = min(len(self.url_list), 10)

        results = []

        if hasConcurrent:
            try:
                from concurrent.futures import ThreadPoolExecutor, as_completed

                # We need to maintain order, so we'll use a dictionary to track futures
                with ThreadPoolExecutor(max_workers=threads) as executor:
                    future_to_index = {
                        executor.submit(self.download_url, url_info): idx
                        for idx, url_info in enumerate(self.url_list)
                    }

                    # Initialize results list with None values
                    results = [None] * len(self.url_list)

                    for future in as_completed(future_to_index):
                        idx = future_to_index[future]
                        try:
                            result = future.result()
                            results[idx] = result
                        except Exception as e:
                            print("Error processing URL {}: {}".format(idx, e))
                            results[idx] = (idx, {"valid": False})

            except Exception as e:
                print("Concurrent execution error:", e)
                results = []
                for idx, url_info in enumerate(self.url_list):
                    try:
                        results.append(self.download_url(url_info))
                    except Exception as e:
                        print("2 Error processing URL {}: {} {}".format(idx, e, url_info))
                        results.append((idx, {"valid": False}))

        elif hasMultiprocessing:
            try:
                # Multiprocessing version that maintains order
                from multiprocessing.pool import ThreadPool

                pool = ThreadPool(threads)
                try:
                    # imap maintains order
                    results = list(pool.imap(self.download_url, self.url_list))
                finally:
                    pool.close()
                    pool.join()

            except Exception as e:
                print("Multiprocessing execution error:", e)
                results = []
                for url_info in self.url_list:
                    try:
                        results.append(self.download_url(url_info))
                    except Exception as e:
                        print("Error processing URL:", e)
                        results.append((0, {"valid": False}))
        else:
            # Fallback sequential processing
            results = []
            for url_info in self.url_list:
                try:
                    results.append(self.download_url(url_info))
                except Exception as e:
                    print("Error processing URL:", e)
                    results.append((0, {"valid": False}))

        # Update the playlist JSON
        self.update_results(results)

    def update_results(self, results):
        """Update playlist info with results"""
        for result in results:
            if not result:
                continue

            index, response = result
            if response:
                self.playlists_all[index]["playlist_info"].update({
                    "token": response.get("token", ""),
                    "valid": response.get("valid", False),
                    "expiry": response.get("expiry", ""),
                    "play_token": response.get("play_token", ""),
                    "status": response.get("status", 0),
                    "blocked": response.get("blocked", "0"),
                    "temp_username": response.get("temp_username", ""),
                    "temp_password": response.get("temp_password", ""),
                    "active_connections": response.get("active_connections", ""),
                    "max_connections": response.get("max_connections", "")
                })
            else:
                self.playlists_all[index]["playlist_info"].update({
                    "token": "",
                    "valid": False,
                    "expiry": "",
                    "play_token": "",
                    "status": 0,
                    "blocked": "0",
                    "temp_username": "",
                    "temp_password": "",
                    "active_connections": "",
                    "max_connections": ""
                })

        self.writeJsonFile()

    def writeJsonFile(self):
        if debugs:
            print("*** writeJsonFile ***")

        with open(playlists_json, "w") as f:
            json.dump(self.playlists_all, f, indent=4)
        self.createSetup()

    def createSetup(self):
        if debugs:
            print("*** createSetup ***")

        self["splash"].hide()

        self.list = []
        # fail_count_check = False
        index = 0

        for playlist in self.playlists_all:

            # valid = True

            # name = playlist["playlist_info"].get("name", playlist["playlist_info"].get("domain", ""))
            domain = playlist["playlist_info"].get("domain", "")
            url = playlist["playlist_info"].get("host", "")
            message = _("Active")

            mac = playlist["playlist_info"].get("mac", "")

            token = playlist["playlist_info"].get("token", "")
            expiry = playlist["playlist_info"].get("expiry", "")
            play_token = playlist["playlist_info"].get("play_token", "")
            status = playlist["playlist_info"].get("status", 0)
            blocked = playlist["playlist_info"].get("blocked", "0")
            valid = playlist["playlist_info"].get("valid", True)
            expires = _("Expires: ") + str(expiry)
            portal = playlist["playlist_info"].get("portal", "")

            active = str(_("Active Conn:"))
            activenum = playlist["playlist_info"].get("active_connections", "")
            maxc = str(_("Max Conn:"))
            maxnum = playlist["playlist_info"].get("max_connections", "")

            if not valid:
                message = _("Not active")

            elif blocked == "1":
                message = _("Blocked")
                # valid = False

            elif str(status) != "0":
                message = _("Unknown")

            elif "/stalker_portal/" not in portal and not play_token:
                message = _("No Play Token")

            portal_version = playlist["playlist_info"].get("version", "")

            self.list.append([index, domain, url, expires, message, mac, token, portal_version, valid, active, activenum, maxc, maxnum])
            index += 1

        self.drawList = [self.buildListEntry(x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8], x[9], x[10], x[11], x[12]) for x in self.list]
        self["playlists"].setList(self.drawList)

    def buildListEntry(self, index, domain, url, expires, message, mac, token, portal_version, valid, active, activenum, maxc, maxnum):

        if not valid:
            pixmap = LoadPixmap(cached=True, path=os.path.join(common_path, "led_red.png"))

        elif message == _("Active"):
            pixmap = LoadPixmap(cached=True, path=os.path.join(common_path, "led_green.png"))

            if activenum:
                try:
                    activenum = int(activenum)
                    maxnum = int(maxnum)
                    if int(activenum) >= int(maxnum) and int(maxnum) != 0:
                        pixmap = LoadPixmap(cached=True, path=os.path.join(common_path, "led_yellow.png"))
                except:
                    pass

        elif message == _("No Play Token"):
            pixmap = LoadPixmap(cached=True, path=os.path.join(common_path, "led_yellow.png"))
        elif message == _("Unknown"):
            pixmap = LoadPixmap(cached=True, path=os.path.join(common_path, "led_yellow.png"))
        else:
            pixmap = LoadPixmap(cached=True, path=os.path.join(common_path, "led_red.png"))

        return (index, str(domain), str(url), str(expires), str(message), pixmap, str(mac), str(portal_version), str(active), str(activenum), str(maxc), str(maxnum))

    def quit(self, answer=None):
        self.close()

    def deleteServer(self, answer=None):
        if self.list != []:
            self.currentplaylist = glob.active_playlist.copy()

            if answer is None:
                self.session.openWithCallback(self.deleteServer, MessageBox, _("Delete selected server (MAC) entry?"))
            elif answer:
                url_to_delete = str(self.currentplaylist["playlist_info"]["host"]).strip().rstrip('/')
                mac_to_delete = str(self.currentplaylist["playlist_info"]["mac"]).strip().lower()

                with open(playlist_file, "r") as f:
                    lines = f.readlines()

                new_lines = []
                inside_block = False
                block_start_index = None

                for idx, line in enumerate(lines):
                    stripped_line = line.strip()

                    if stripped_line.startswith("http://") or stripped_line.startswith("https://"):
                        inside_block = False
                        block_start_index = None

                        url_part = stripped_line.split(" #")[0].rstrip('/')

                        if url_part == url_to_delete:
                            inside_block = True
                            block_start_index = idx

                        new_lines.append(line)

                    elif inside_block:
                        if stripped_line.lower() == mac_to_delete:
                            if not line.lstrip().startswith("#"):
                                new_lines.append("#" + line)
                            else:
                                new_lines.append(line)
                        else:
                            new_lines.append(line)

                    else:
                        new_lines.append(line)

                # After looping: check if all MACs under that URL are commented
                if block_start_index is not None:
                    all_commented = True

                    for idx in range(block_start_index + 1, len(new_lines)):
                        mac_line = new_lines[idx].strip()

                        if mac_line.startswith("http://") or mac_line.startswith("https://"):
                            break  # End of this block

                        if mac_line and not mac_line.startswith("#"):
                            all_commented = False
                            break

                    if all_commented:
                        if not new_lines[block_start_index].lstrip().startswith("#"):
                            new_lines[block_start_index] = "#" + new_lines[block_start_index]

                with open(playlist_file, "w") as f:
                    f.writelines(new_lines)

                # Step 2: Update playlists.json
                x = 0
                for playlist in self.playlists_all:
                    playlist_url = playlist.get("playlist_info", {}).get("host", "").strip().rstrip('/')
                    playlist_mac = playlist.get("playlist_info", {}).get("mac", "").strip().lower()

                    if playlist_url == url_to_delete and playlist_mac == mac_to_delete:
                        del self.playlists_all[x]
                        break
                    x += 1

                self.writeJsonFile()
                # self.deleteEpgData()

    def getCurrentEntry(self):
        if self.list:
            glob.current_selection = self["playlists"].getIndex()
            glob.active_playlist = self.playlists_all[glob.current_selection]

            num_playlists = self["playlists"].count()
            if num_playlists > 5:
                self["scroll_up"].show()
                self["scroll_down"].show()

                if glob.current_selection < 5:
                    self["scroll_up"].hide()

                elif glob.current_selection + 1 > ((self["playlists"].count() // 5) * 5):
                    self["scroll_down"].hide()
        else:
            glob.current_selection = 0
            glob.active_playlist = {}

    def getStreamTypes(self):
        if glob.active_playlist["playlist_info"]["valid"] is True:
            from . import menu
            self.session.open(menu.EStalker_Menu)
            self.checkoneplaylist()

    def checkoneplaylist(self):
        if len(self.list) == 1 and cfg.skipplaylistsscreen.value is True:
            self.quit()

    def goTop(self):
        self["playlists"].setIndex(0)

    def autoDeleteInvalid(self, answer=None):
        """Remove all invalid playlists (blue button function)"""
        if answer is None:
            self.session.openWithCallback(
                self.autoDeleteInvalid,
                MessageBox,
                _("Delete ALL invalid playlists?\n(Those marked as Not Active/Blocked/Expired)"),
                MessageBox.TYPE_YESNO
            )
            return

        if not answer:
            return

        # Step 1: Process the playlists.txt file
        with open(playlist_file, "r") as f:
            lines = [line.strip() for line in f]

        new_lines = []
        current_url = None
        macs_to_keep = set()

        # First identify all valid MACs from JSON
        for playlist in self.playlists_all:
            if playlist["playlist_info"].get("valid", False):
                macs_to_keep.add(playlist["playlist_info"]["mac"].lower())

        # Now process the file
        for line in lines:
            if line.startswith(("http://", "https://")):
                current_url = line
                new_lines.append(line)
            elif line and current_url:
                # Only keep if MAC is in our valid set
                if line.lower() in macs_to_keep:
                    new_lines.append(line)
                else:
                    new_lines.append("#" + line)  # Comment out invalid
            else:
                new_lines.append(line)  # Keep comments/empty lines

        # Write back the cleaned file
        with open(playlist_file, "w") as f:
            f.write("\n".join(new_lines) + "\n")

        # Step 2: Clean the JSON data
        self.playlists_all = [
            playlist for playlist in self.playlists_all
            if playlist["playlist_info"].get("valid", False)
        ]

        # Reindex all remaining playlists
        for index, playlist in enumerate(self.playlists_all):
            playlist["playlist_info"]["index"] = index

        # Save the cleaned JSON
        self.writeJsonFile()

        # Refresh UI
        self.createSetup()

        self.session.open(
            MessageBox,
            _("Removed all invalid playlists"),
            MessageBox.TYPE_INFO,
            timeout=3
        )
