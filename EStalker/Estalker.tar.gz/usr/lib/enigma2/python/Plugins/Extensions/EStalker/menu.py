#!/usr/bin/python
# -*- coding: utf-8 -*-

# Standard library imports
import os
import json

try:
    from http.client import HTTPConnection
    HTTPConnection.debuglevel = 0
except:
    from httplib import HTTPConnection
    HTTPConnection.debuglevel = 0

# Enigma2 components
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from enigma import eTimer
# from requests.adapters import HTTPAdapter, Retry
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap

# Local application/library-specific imports
from . import _
from . import estalker_globals as glob
from .plugin import skin_directory, common_path, version, hasConcurrent, hasMultiprocessing, cfg, debugs, base_headers
from .eStaticText import StaticText
from .utils import get_local_timezone, make_request


playlists_json = cfg.playlists_json.value


class EStalker_Menu(Screen):
    ALLOW_SUSPEND = True

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        skin_path = os.path.join(skin_directory, cfg.skin.value)
        skin = os.path.join(skin_path, "menu.xml")
        with open(skin, "r") as f:
            self.skin = f.read()

        self.list = []
        self.drawList = []
        self["list"] = List(self.drawList, enableWrapAround=True)

        # self.setup_title = _("Playlist Menu") + " - " + str(glob.active_playlist["playlist_info"]["name"])
        self.setup_title = _("Playlist Menu")

        self["key_red"] = StaticText(_("Back"))
        self["key_green"] = StaticText(_("OK"))
        self["key_blue"] = StaticText("")
        self["version"] = StaticText()

        self["splash"] = Pixmap()
        self["splash"].show()

        self["actions"] = ActionMap(["EStalkerActions"], {
            "red": self.quit,
            "cancel": self.quit,
            "menu": self.settings,
            "green": self.__next__,
            "ok": self.__next__,
        }, -2)

        self["version"].setText(version)

        portal = glob.active_playlist["playlist_info"].get("portal", None)

        self.retry = False

        self.live_categories_url = portal + "?type=itv&action=get_genres&sortby=name&JsHttpRequest=1-xml"
        self.vod_categories_url = portal + "?type=vod&action=get_categories&sortby=name&JsHttpRequest=1-xml"
        self.series_categories_url = portal + "?type=series&action=get_categories&sortby=name&JsHttpRequest=1-xml"
        # self.live_streams_url = base_url + "?type=itv&action=get_all_channels"

        glob.active_playlist["data"]["live_streams"] = {}
        glob.active_playlist["data"]["data_downloaded"] = False

        if os.path.exists("/tmp/allchannels.json"):
            os.remove("/tmp/allchannels.json")

        self.onFirstExecBegin.append(self.start)
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def start(self, data=None):
        if debugs:
            print("*** start ***")
        # delay to allow splash screen to show

        # print("*** data_downloaded ***", glob.active_playlist["data"]["data_downloaded"])

        if glob.active_playlist["data"]["data_downloaded"] is False:
            self.timer = eTimer()
            try:
                self.timer_conn = self.timer.timeout.connect(self.makeUrlList)
            except:
                try:
                    self.timer.callback.append(self.makeUrlList)
                except:
                    self.makeUrlList()
            self.timer.start(10, True)
        else:
            self["splash"].hide()
            self.createSetup()

    def makeUrlList(self):
        if debugs:
            print("*** makeUrlList ***")
        self.url_list = [
            [self.live_categories_url, 0],
            [self.vod_categories_url, 1],
            [self.series_categories_url, 2]
        ]

        self.process_downloads()

    def download_url(self, url):
        if debugs:
            print("*** download_url ***", url)

        timezone = get_local_timezone()
        token = glob.active_playlist["playlist_info"]["token"]
        domain = str(glob.active_playlist["playlist_info"].get("domain", ""))
        host = str(glob.active_playlist["playlist_info"].get("host", "")).rstrip("/")
        mac = glob.active_playlist["playlist_info"].get("mac", "")
        portal = glob.active_playlist["playlist_info"].get("portal", None)

        extra = ""
        if "/stalker_portal/" in portal:
            extra = "/stalker_portal"

        host_headers = {
            "Referer": "{}{}/c/".format(host, extra),
            "Host": domain,
            "Cookie": "mac={}; stb_lang=en; timezone={};".format(mac, timezone)
        }

        headers = dict(base_headers)
        headers.update(host_headers)

        headers["Authorization"] = "Bearer " + token

        # Get the saved API base path
        category = url[1]
        response = ""

        response = make_request(url[0], headers, None, "json")

        if not response and self.retry is False:
            self.retry = True

            self.reauthorize(url)

        # print("*** response menu ***", response)

        return category, response

    def process_downloads(self):
        if debugs:
            print("*** process_downloads2 ***")
        self.retry = 0
        glob.active_playlist["data"]["live_categories"] = {}
        glob.active_playlist["data"]["vod_categories"] = {}
        glob.active_playlist["data"]["series_categories"] = {}

        threads = len(self.url_list)
        results = []

        def sort_categories(response):
            if debugs:
                print("*** response ***", response)

            if isinstance(response, dict) and "js" in response and isinstance(response["js"], list):
                response["js"] = sorted(response["js"], key=lambda g: g.get("title", "").lower())
            return response

        if hasConcurrent or hasMultiprocessing:
            if hasConcurrent:
                # print("******* trying concurrent futures ******")
                try:
                    from concurrent.futures import ThreadPoolExecutor
                    with ThreadPoolExecutor(max_workers=threads) as executor:
                        results = list(executor.map(self.download_url, self.url_list))
                except Exception as e:
                    print("Concurrent execution error:", e)

            elif hasMultiprocessing:
                try:
                    # print("*** trying multiprocessing ThreadPool ***")
                    from multiprocessing.pool import ThreadPool
                    pool = ThreadPool(threads)
                    results = pool.imap(self.download_url, self.url_list)

                    pool.close()
                    pool.join()

                except Exception as e:
                    print("multiprocessing execution error:", e)

            for category, response in results:
                if response:
                    # add categories to main json file
                    response = sort_categories(response)
                    if category == 0:
                        glob.active_playlist["data"]["live_categories"] = response
                    elif category == 1:
                        glob.active_playlist["data"]["vod_categories"] = response
                    elif category == 2:
                        glob.active_playlist["data"]["series_categories"] = response
                    elif category == 3:
                        glob.active_playlist["data"]["live_streams"] = response

        else:
            # print("*** trying sequential ***")
            for url in self.url_list:
                result = self.download_url(url)
                category = result[0]
                response = result[1]
                if response:
                    response = sort_categories(response)
                    # add categories to main json file
                    if category == 0:
                        glob.active_playlist["data"]["live_categories"] = response
                    elif category == 1:
                        glob.active_playlist["data"]["vod_categories"] = response
                    elif category == 2:
                        glob.active_playlist["data"]["series_categories"] = response
                    elif category == 3:
                        glob.active_playlist["data"]["live_streams"] = response

        self["splash"].hide()
        glob.active_playlist["data"]["data_downloaded"] = True
        self.createSetup()

    def writeJsonFile(self):
        if debugs:
            print("*** writeJsonFile ***")
        with open(playlists_json, "r") as f:
            playlists_all = json.load(f)

        playlists_all[glob.current_selection] = glob.active_playlist

        with open(playlists_json, "w") as f:
            json.dump(playlists_all, f, indent=4)

    def createSetup(self):
        if debugs:
            print("*** createSetup ***")
        self.list = []
        self.index = 0

        def add_category_to_list(title, category_type, index):
            if category_type in glob.active_playlist["data"] and glob.active_playlist["data"][category_type]:
                data = glob.active_playlist["data"][category_type]
                if isinstance(data, dict) and "js" in data:
                    data = data["js"]

                if isinstance(data, list) and data and "id" in data[0]:
                    self.index += 1
                    self.list.append([self.index, _(title), index, ""])

        show_live = glob.active_playlist["player_info"].get("showlive", False)
        show_vod = glob.active_playlist["player_info"].get("showvod", False)
        show_series = glob.active_playlist["player_info"].get("showseries", False)
        show_catchup = glob.active_playlist["player_info"].get("showcatchup", False)

        # content = glob.active_playlist["data"]["live_streams"]

        # print("*** content ***", content)

        # has_catchup = any(str(item.get("archive", "0")) == "1" for item in content.get('js', {}).get('data', []) if "archive" in item)
        # has_custom_sids = any(item.get("custom_sid", False) for item in content if "custom_sid" in item)

        glob.active_playlist["data"]["live_streams"] = {}

        """
        if has_custom_sids:
            glob.active_playlist["data"]["customsids"] = True
            """

        """
        if has_catchup:
            glob.active_playlist["data"]["catchup"] = True
            """

        if show_live:
            add_category_to_list("Live Streams", "live_categories", 0)

        if show_vod:
            add_category_to_list("Vod", "vod_categories", 1)

        """
        if show_series:
            add_category_to_list("TV Series", "series_categories", 2)
            """

        """
        if show_catchup and glob.active_playlist["data"]["catchup"]:
            self.index += 1
            self.list.append([self.index, _("Catch Up TV"), 3, ""])
            """
        """
        if show_catchup:
            self.index += 1
            self.list.append([self.index, _("Catch Up TV"), 3, ""])
            """

        self.index += 1
        self.list.append([self.index, _("Playlist Settings"), 4, ""])

        self.drawList = [buildListEntry(x[0], x[1], x[2], x[3]) for x in self.list]
        self["list"].setList(self.drawList)

        self.writeJsonFile()

        if not self.list:
            self.session.openWithCallback(self.close, MessageBox, (_("No data, blocked or playlist not compatible with EStalker plugin.")), MessageBox.TYPE_WARNING, timeout=5)

    def quit(self):
        self.close()

    def __next__(self):
        if debugs:
            print("*** next ***")
        current_item = self["list"].getCurrent()
        if current_item:
            category = current_item[2]
            if category == 0:
                from . import live
                self.session.openWithCallback(lambda: self.start, live.EStalker_Live_Categories)
            elif category == 1:
                from . import vod
                self.session.openWithCallback(lambda: self.start, vod.EStalker_Vod_Categories)
            elif category == 2:
                from . import series
                self.session.openWithCallback(lambda: self.start, series.EStalker_Series_Categories)
            elif category == 3:
                from . import catchup
                self.session.openWithCallback(lambda: self.start, catchup.EStalker_Catchup_Categories)
            elif category == 4:
                self.settings()

    def settings(self):
        if debugs:
            print("*** settings ***")
        from . import playsettings
        self.session.openWithCallback(self.start, playsettings.EStalker_Settings)

    def reauthorize(self, url):
        if debugs:
            print("*** reauthorize ***")
        token = None
        play_token = None
        status = 0
        blocked = "0"
        random = None

        with requests.Session() as http:
            # Configure session
            adapter = HTTPAdapter(max_retries=1)
            http.mount("http://", adapter)
            http.mount("https://", adapter)

            # Base headers
            extra = ""
            if "/stalker_portal/" in self.portal:
                extra = "/stalker_portal"

            host_headers = {
                "Referer": "{}{}/c/".format(self.host, extra),
                "Host": self.domain,
                "Cookie": "mac={}; stb_lang=en; timezone={};".format(self.mac, self.timezone)
            }

            headers = dict(base_headers)
            headers.update(host_headers)

            # print("*** headers ***", headers)

            # 1. Handshake

            portal = glob.active_playlist["playlist_info"].get("portal", None)
            handshake_url = str(portal) + "?type=stb&action=handshake&JsHttpRequest=1-xml&mac={}".format(self.mac)

            # print("*** handshake_url ***", handshake_url)

            try:
                response = make_request(handshake_url, headers, None, "json")

                # print("*** response ***", response)

                if isinstance(response, dict):
                    js_data = response.get("js", {})

                    if isinstance(js_data, dict):
                        token = js_data.get("token")

                        if token:
                            random = js_data.get("random")  # Optional
                            # print("*** token ***", token)
                            # if random:
                            #    print("*** random ***", random)
                        else:
                            print("Token missing in response: {}".format(js_data))
                    else:
                        print("Invalid 'js' block in response:", js_data)
                else:
                    print("Invalid response format (not a dict):", response)

            except Exception as e:
                print("Error during handshake with {}: {}".format(handshake_url, e))

            if not token:
                return

            glob.active_playlist["playlist_info"]["token"] = token
            self.token = token

            # Add Authorization header now that we have a token
            headers["Authorization"] = "Bearer " + token

            # print("*** headers 2 ***", headers)

            profile_url = str(portal) + "?type=stb&action=get_profile&JsHttpRequest=1-xml"

            # 2. Get Profiles
            dt = datetime.now()
            timestamp = datetime.timestamp(dt) if pythonVer == 3 else time.mktime(dt.timetuple())

            import hashlib

            md5_hash = hashlib.md5(self.mac.encode()).hexdigest().upper()[:13]

            if random:
                randomstring = random
            else:
                randomstring = ""

            host_metrics = {
                "mac": self.mac,
                "sn": md5_hash,
                "random": randomstring
            }

            metrics = dict(base_metrics)
            metrics.update(host_metrics)

            # 2. Get Profiles seconds pass
            if "/stalker_portal/" in portal:
                host_params2 = {
                    'var': "ver=ImageDescription: 0.2.18-r14-pub-250; ImageDate: Fri Jan 15 15:20:44 EET 2016; PORTAL version: 5.5.0; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566",
                    'sn': md5_hash,
                    'image_version': "218",
                    'timestamp': str(timestamp),
                    'metrics': json.dumps(metrics),
                    'device_id': "",
                    'device_id': "",
                }

                profile_params2 = dict(base_params)
                profile_params2.update(host_params2)

                profile_data2 = make_request(profile_url, headers, profile_params2, "json")

                if profile_data2:
                    # if debugs:
                    #    print("*** profiledata2 ***", json.dumps(profile_data2))
                    js_data = profile_data2.get("js", {})
                    play_token = js_data.get("play_token", play_token)
                    status = js_data.get("status", status)
                    blocked = js_data.get("blocked", blocked)

            else:
                profile_data2 = make_request(profile_url, headers, None, "json")

                if profile_data2:
                    # if debugs:
                    #    print("*** profiledata2 ***", json.dumps(profile_data2))
                    js_data = profile_data2.get("js", {})
                    play_token = js_data.get("play_token", play_token)
                    status = js_data.get("status", status)
                    blocked = js_data.get("blocked", blocked)

def buildListEntry(index, title, category_id, playlisturl):
    icon_mapping = {
        0: "live.png",
        1: "vod.png",
        2: "series.png",
        3: "catchup.png",
        4: "settings.png",
        5: "epg_download.png"
    }

    png = None
    icon_filename = icon_mapping.get(category_id)
    if icon_filename:
        png = LoadPixmap(os.path.join(common_path, icon_filename))

    return (index, str(title), category_id, str(playlisturl), png)
