#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import os
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Plugins.Plugin import PluginDescriptor
from Screens.Standby import TryQuitMainloop

PLUGIN_PATH = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanelPro")
PLUGIN_VERSION = "1.0"
PLUGIN_DESC = "Emil Panel Pro - Enigma2 Tools"

class EmilPanelMain(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.skin = """
        <screen position="center,center" size="1000,700" title="Emil Panel Pro v%s">
            <widget name="menu" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>""" % PLUGIN_VERSION
        
        self["menu"] = MenuList([])
        self["key_red"] = StaticText("Exit")
        self["key_green"] = StaticText("Install")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.openSelected,
            "cancel": self.close,
            "red": self.close,
            "green": self.installSelected,
            "blue": self.restartGUI
        }, -1)
        
        self.main_menu = [
            ("Panels", self.openPanels),
            ("Channels", self.openChannels),
            ("Plugins", self.openPlugins),
            ("System Tools", self.openTools),
            ("System Plugins", self.openSystemPlugins),
            ("Softcams", self.openSoftcams),
            ("Backup", self.openBackup),
            ("Restore", self.openRestore),
            ("Skins", self.openSkins)
        ]
        
        self["menu"].setList([item[0] for item in self.main_menu])
    
    def openSelected(self):
        idx = self["menu"].getSelectedIndex()
        if idx < len(self.main_menu):
            self.main_menu[idx][1]()
    
    def installSelected(self):
        current_panel = self["menu"].getCurrent()
        if current_panel == "Panels":
            self.session.open(PanelsPanel)
        elif current_panel == "Channels":
            self.session.open(ChannelsPanel)
        elif current_panel == "Plugins":
            self.session.open(PluginsPanel)
        elif current_panel == "System Plugins":
            self.session.open(SystemPluginsPanel)
        elif current_panel == "Softcams":
            self.session.open(SoftcamsPanel)
        elif current_panel == "Skins":
            self.session.open(SkinsPanel)
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)
    
    def openPanels(self):
        self.session.open(PanelsPanel)
    
    def openChannels(self):
        self.session.open(ChannelsPanel)
    
    def openPlugins(self):
        self.session.open(PluginsPanel)
    
    def openTools(self):
        self.session.open(ToolsPanel)
    
    def openSystemPlugins(self):
        self.session.open(SystemPluginsPanel)
    
    def openSoftcams(self):
        self.session.open(SoftcamsPanel)
    
    def openBackup(self):
        self.session.open(BackupPanel)
    
    def openRestore(self):
        self.session.open(RestorePanel)
    
    def openSkins(self):
        self.session.open(SkinsPanel)

class ChannelsPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="Channels Panel">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Install")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.installSelected,
            "cancel": self.close,
            "red": self.close,
            "green": self.installSelected,
            "blue": self.restartGUI
        }, -1)
        
        self.channels = [
            ("Emil Nabil", "https://raw.githubusercontent.com/emilnabil/channel-emil-nabil/main/installer.sh"),
                    ("Ahmed Romeh", "https://raw.githubusercontent.com/emilnabil/channel-romeh/main/installer.sh"),
                    ("Hazem-Wahba", "https://raw.githubusercontent.com/emilnabil/channel-hazem-wahba/main/installer.sh"),
                    ("Khaled Ali", "https://raw.githubusercontent.com/emilnabil/channel-khaled/main/installer.sh"),
                    ("Mohamed Goda", "https://raw.githubusercontent.com/emilnabil/channel-mohamed-goda/main/installer.sh"),
                    ("Mohamed-Nasr", "https://raw.githubusercontent.com/emilnabil/channel-mnasr/main/installer.sh"),
                    ("Tarek Ashry", "https://raw.githubusercontent.com/emilnabil/channel-tarek-ashry/main/installer.sh"),
                    ("Elsafty-Tv-Radio-Steaming", "https://dreambox4u.com/emilnabil237/settings/elsafty/installer.sh"),
                    ("ciefp-channels-e2-75e-34w", "https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-channels-e2-75e-34w.sh"),
                    ("Vhaninbal-Motor-70E-45W", "https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/vanenbal-channels/Vhannibal-Motor-70E-45W.sh"),
                    ("Tuner_Backup_By-Emil-Nabil", "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/restore-tuner-emil.sh"),
                    ("Tuner_Backup_By-M-Goda", "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/restore-tuner-goda.sh")
        ]
        
        self["list"].setList([name for name, url in self.channels])
    
    def installSelected(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.channels):
            url = self.channels[idx][1]
            self.session.open(Console, "Installing", ["wget -q %s -O - | /bin/sh" % url])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

class PanelsPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="Panels Panel">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Install")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.installSelected,
            "cancel": self.close,
            "red": self.close,
            "green": self.installSelected,
            "blue": self.restartGUI
        }, -1)
        
        self.panels = [
            ("Ajpanel", "wget http://dreambox4u.com/emilnabil237/plugins/ajpanel/installer1.sh -O - | /bin/sh"),
            ("AjPanel Custom Menu All Panels", "wget https://dreambox4u.com/emilnabil237/plugins/ajpanel/emil-panel-all.sh -O - | /bin/sh"),
            ("Panel Lite By Emil Nabil", "wget https://dreambox4u.com/emilnabil237/plugins/ajpanel/new/emil-panel-lite.sh -O - | /bin/sh"),
            ("dreamosat-downloader", "wget https://dreambox4u.com/emilnabil237/plugins/dreamosat-downloader/installer.sh -O - | /bin/sh"),
            ("EmilPanelpro", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/emilpanelpro.sh -O - | /bin/sh"),           
            ("Epanel", "wget https://dreambox4u.com/emilnabil237/plugins/epanel/installer.sh -O - | /bin/sh"),
            ("linuxsat-panel", "wget https://raw.githubusercontent.com/Belfagor2005/LinuxsatPanel/main/installer.sh -O - | /bin/sh"),
            ("levi45-AddonsManager", "wget https://dreambox4u.com/emilnabil237/plugins/levi45-addonsmanager/installer.sh -O - | /bin/sh"),
            ("Levi45MulticamManager", "wget https://dreambox4u.com/emilnabil237/plugins/levi45multicammanager/installer.sh -O - | /bin/sh"),
            ("SatVenusPanel", "wget https://dreambox4u.com/emilnabil237/plugins/satvenuspanel/installer.sh -O - | /bin/sh"),
            ("Tspanel", "wget https://dreambox4u.com/emilnabil237/plugins/tspanel/installer.sh -O - | /bin/sh"),
            ("TvAddon-Panel", "wget https://dreambox4u.com/emilnabil237/plugins/tvaddon/installer.sh -O - | /bin/sh")
        ]
        
        self["list"].setList([name for name, cmd in self.panels])  # Fixed: Changed from self.channels to self.panels
    
    def installSelected(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.panels):  # Fixed: Changed from self.channels to self.panels
            cmd = self.panels[idx][1]  # Fixed: Changed from self.channels to self.panels
            self.session.open(Console, "Installing Panel", [cmd])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

class PluginsPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="Plugins Panel">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Install")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.installSelected,
            "cancel": self.close,
            "red": self.close,
            "green": self.installSelected,
            "blue": self.restartGUI
        }, -1)
        
        self.plugins = [
    ("ArabicSavior", "wget http://dreambox4u.com/emilnabil237/plugins/ArabicSavior/installer.sh -O - | /bin/sh"),
    ("Acherone", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/acherone/installer.sh -O - | /bin/sh"),   
    ("Alajre", "wget https://dreambox4u.com/emilnabil237/plugins/alajre/installer.sh -O - | /bin/sh"),
    ("Ansite", "wget https://raw.githubusercontent.com/emil237/ansite/refs/heads/main/installer.sh -O - | /bin/sh"),
    ("Apod", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/apod/installer.sh -O - | /bin/sh"),
    ("Apsattv", "wget https://raw.githubusercontent.com/Belfagor2005/Apsattv/main/installer.sh -O - | /bin/sh"), 
    ("Astronomy", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/astronomy/installer.sh -O - | /bin/sh"),    
    ("Athan Times", "wget https://dreambox4u.com/emilnabil237/plugins/athantimes/installer.sh -O - | /bin/sh"), 
    ("Atilehd", "wget https://dreambox4u.com/emilnabil237/plugins/atilehd/installer.sh -O - | /bin/sh"), 
    ("Azkar Almuslim", "wget https://dreambox4u.com/emilnabil237/plugins/azkar-almuslim/installer.sh -O - | /bin/sh"),
    ("Backupflashe", "wget https://raw.githubusercontent.com/fairbird/backupflash/main/installer.sh -O - | /bin/sh"),
    ("BissFeedAutoKey", "wget https://raw.githubusercontent.com/emilnabil/bissfeed-autokey/main/installer.sh -O - | /bin/sh"),
    ("Bootvideo", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/Bootvideo.sh -O - | /bin/sh"),
    ("CacheFlush", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/cacheflush/cacheflush.sh -O - | /bin/sh"), 
    ("CCcaminfo", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/cccaminfo.sh -O - | /bin/sh"),
    ("CrondManager", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/crondmanager/installer.sh -O - | /bin/sh"), 
    ("chocholousek-picons", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/chocholousek-picons.sh -O - | /bin/sh"),
    ("CrashLogoViewer", "wget https://dreambox4u.com/emilnabil237/plugins/crashlogviewer/install-CrashLogViewer.sh -O - | /bin/sh"),
    ("CrondManger", "wget https://github.com/emil237/download-plugins/raw/main/cronmanager.sh -O - | /bin/sh"),
    ("DisplaySkin", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/displayskin.sh -O - | /bin/sh"),
    ("dreamxtream-dm-900-920", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/dreamxtream-dm-900-920.sh -O - | /bin/sh"),
    ("dreamxtream-dm-1-2", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/dreamxtream-dm-2.sh -O - | /bin/sh"),
    ("dreamxtream-dm-520", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/dreamxtream-dm-520.sh -O - | /bin/sh"),
    ("Easy-Cccam", "wget https://raw.githubusercontent.com/emil237/plugins/refs/heads/main/easy-cccam/easy-cccam.sh -O - | /bin/sh"),
    ("E2m3ubouquet", "wget https://dreambox4u.com/emilnabil237/plugins/e2m3u2bouquet/installer.sh -O - | /bin/sh"),
    ("enigma2readeradder", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/enigma2readeradder.sh -O - | /bin/sh"), 
    ("Epg Grabber", "wget https://dreambox4u.com/emilnabil237/plugins/Epg-Grabber/installer.sh -O - | /bin/sh"), 
    ("EPGImport", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/epgimport.sh -O - | /bin/sh"), 
    ("EPGImport-99", "wget https://raw.githubusercontent.com/Belfagor2005/EPGImport-99/main/installer.sh -O - | /bin/sh"), 
    ("EPGTranslator", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/epgtranslatorlite.sh -O - | /bin/sh"),
    ("Estalker", "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EStalker/EStalker.sh -O - | /bin/sh"),
    ("EstalkerWebControl", "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EstalkerWebControl/estalkerwebcontrol.sh -O - | /bin/sh"),
    ("Feeds-Finder", "wget https://dreambox4u.com/emilnabil237/plugins/feeds-finder/installer.sh -O - | /bin/sh"),
    ("Filmxy", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/filmxy/filmxy.sh -O - | /bin/sh"), 
    ("Footonsat", "wget https://dreambox4u.com/emilnabil237/plugins/FootOnsat/installer.sh -O - | /bin/sh"),
    ("Freearhey", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/freearhey/freearhey.sh -O - | /bin/sh"), 
    ("FreeCCcamServer", "wget https://ia803104.us.archive.org/0/items/freecccamserver/installer.sh -O - | /bin/sh"),  
    ("HasBahCa", "wget https://dreambox4u.com/emilnabil237/plugins/HasBahCa/installer.sh -O - | /bin/sh"), 
    ("HistoryZapSelector", "wget https://dreambox4u.com/emilnabil237/plugins/historyzap/installer1.sh -O - | /bin/sh"),  
    ("Internet-Speedtest", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/internet-speedtest.sh -O - | /bin/sh"),
    ("IP_Checker", "wget https://raw.githubusercontent.com/emil237/plugins/refs/heads/main/IP_Checker.sh -O - | /bin/sh"),
    ("Iptv-Org-Playlists", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/iptv-org-playlists/iptv-org-playlists.sh -O - | /bin/sh"),
    ("iptvdream", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/main/iptvdream/iptvdream.sh -O - | /bin/sh"),
    ("IptvPlayer", "wget https://raw.githubusercontent.com/emil237/iptvplayer/main/iptvinstaller.sh -O - | /bin/sh"),
    ("KeyAdder", "wget https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh -O - | /bin/sh"),
    ("levi45-freeserver", "wget https://raw.githubusercontent.com/emil237/plugins/refs/heads/main/levi45-freeserver/levi45-freeserver.sh -O - | /bin/sh"),
    ("levi45-settings", "wget https://dreambox4u.com/emilnabil237/plugins/levi45-settings/levi45-settings.sh -O - | /bin/sh"),
    ("M3uConverter", "wget https://raw.githubusercontent.com/Belfagor2005/Archimede-M3UConverter/main/installer.sh -O - | /bin/sh"),
    ("MmPicons", "wget https://raw.githubusercontent.com/Belfagor2005/mmPicons/main/installer.sh -O - | /bin/sh"),
    ("MoviesManager", "wget http://dreambox4u.com/emilnabil237/plugins/Transmission/MoviesManager.sh -O - | /bin/sh"),
    ("MyCam-Plugin", "wget https://dreambox4u.com/emilnabil237/plugins/mycam/installer.sh -O - | /bin/sh"),
    ("NewVirtualkeyBoard", "wget https://dreambox4u.com/emilnabil237/plugins/NewVirtualKeyBoard/installer.sh -O - | /bin/sh"),
    ("ONEupdater", "wget https://raw.githubusercontent.com/Sat-Club/ONEupdaterE2/main/installer.sh -O - | /bin/sh"),
    ("OrangeAudioPlugin", "wget https://raw.githubusercontent.com/popking159/OrangeAudio/refs/heads/main/installer.sh -O - | /bin/sh"),
    ("pauli", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/pauli.sh -O - | /bin/sh"),
    ("Quran-karem", "wget https://dreambox4u.com/emilnabil237/plugins/quran/installer.sh -O - | /bin/sh"),
    ("Quran-karem_v2.2", "wget https://raw.githubusercontent.com/emil237/quran/main/installer.sh -O - | /bin/sh"),
    ("Radio-80-s", "wget https://raw.githubusercontent.com/Belfagor2005/Radio-80-s/main/installer.sh -O - | /bin/sh"),
    ("RadioGit", "wget https://dreambox4u.com/emilnabil237/plugins/radiogit/radiogit.sh -O - | /bin/sh"),
    ("Radiom", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/main/radiom/radiom.sh -O - | /bin/sh"),
    ("Rakutentv", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/main/rakutentv/rakutentv.sh -O - | /bin/sh"),
    ("RaedQuickSignal", "wget https://dreambox4u.com/emilnabil237/plugins/RaedQuickSignal/installer.sh -O - | /bin/sh"), 
    ("Plutotv", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/main/plutotv/plutotv.sh -O - | /bin/sh"),
    ("scriptexecuter", "wget http://dreambox4u.com/emilnabil237/plugins/scriptexecuter/installer.sh -O - | /bin/sh"),
    ("Sherlockmod", "wget https://raw.githubusercontent.com/emil237/sherlockmod/main/installer.sh -O - | /bin/sh"),
    ("SimpleZoomPanel", "wget https://raw.githubusercontent.com/Belfagor2005/SimpleZooomPanel/main/installer.sh -O - | /bin/sh"),
    ("skincomponents-extmultilistselection", "curl -kL https://github.com/emilnabil/dreambox/raw/refs/heads/main/skincomponents-extmultilistselection.sh | bash"),
    ("StalkerPortalConverter", "wget https://raw.githubusercontent.com/Belfagor2005/StalkerPortalConverter/main/installer.sh -O - | /bin/sh"), 
    ("SubsSupport_1.5.8-r9", "wget https://dreambox4u.com/emilnabil237/plugins/SubsSupport/installer1.sh -O - | /bin/sh"),
    ("TheWeather", "wget https://raw.githubusercontent.com/biko-73/TheWeather/main/installer.sh -O - | /bin/sh"),
    ("TMBD", "wget https://raw.githubusercontent.com/biko-73/TMBD/main/installer.sh -O - | /bin/sh"),
    ("TvDream", "wget https://raw.githubusercontent.com/Belfagor2005/tvDream/main/installer.sh -O - | /bin/sh"),
    ("TvManager", "wget https://raw.githubusercontent.com/Belfagor2005/tvManager/main/installer.sh -O - | /bin/sh"),
    ("TvParsa", "wget https://raw.githubusercontent.com/Belfagor2005/tvParsa/main/installer.sh -O - | /bin/sh"),
    ("TvRaiPreview", "wget https://raw.githubusercontent.com/Belfagor2005/tvRaiPreview/main/installer.sh -O - | /bin/sh"),
    ("TvSettings", "wget https://raw.githubusercontent.com/Belfagor2005/tvSettings/main/installer.sh -O - | /bin/sh"),
    ("uninstaller", "curl -kL https://github.com/emilnabil/dreambox/raw/refs/heads/main/uninstaller.sh | bash"),
    ("userscripts", "curl -kL https://github.com/emilnabil/dreambox/raw/refs/heads/main/userscripts.sh | bash"), 
    ("vavoo_1.15", "wget https://dreambox4u.com/emilnabil237/plugins/vavoo/installer.sh -O - | /bin/sh"),
    ("WeatherPlugin", "wget https://raw.githubusercontent.com/fairbird/WeatherPlugin/master/installer.sh -O - | /bin/sh"),
    ("Wireguard-Vpn", "wget https://raw.githubusercontent.com/m4dhouse/Wireguard-Vpn/refs/heads/python-3.12/WireGuard.sh -O - | /bin/sh"),
    ("WorldCam", "wget https://raw.githubusercontent.com/Belfagor2005/WorldCam/main/installer.sh -O - | /bin/sh"),
    ("Youtube", "wget https://raw.githubusercontent.com/fairbird/Youtube-Opensource-DreamOS/master/installer.sh -O - | /bin/sh")
]
        
        self["list"].setList([name for name, url in self.plugins])
    
    def installSelected(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.plugins):
            url = self.plugins[idx][1]
            self.session.open(Console, "Installing Plugin", [url])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

class ToolsPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="System Tools">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Run")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.runTool,
            "cancel": self.close,
            "red": self.close,
            "green": self.runTool,
            "blue": self.restartGUI
        }, -1)
        
        self.tools = [
            ("Wget", "apt-get install wget"),
            ("Curl", "apt-get install curl"),
            ("Update Enigma2 All Python", "wget https://raw.githubusercontent.com/emil237/updates-enigma/main/update-all-python.sh -O - | /bin/sh"),
            ("Installer plugin from-tmp", "apt-get update && dpkg -i /tmp/*.deb && apt-get -f -y install"),
            ("Super Script", "wget https://dreambox4u.com/emilnabil237/script/Super_Script.sh -O - | /bin/sh"),
            ("Delete-password", "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/scripts-servise/delete-password.sh -O - | /bin/sh"),
            ("Change-Password-To-root", "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/scripts-servise/change-password-to-root.sh -O - | /bin/sh"),
            ("Epg-Khaled", "wget https://raw.githubusercontent.com/emilnabil/epg-khaled/main/EPG-khaled.sh -O - | /bin/sh"),
            ("dream-elite-panel", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/dream-elite-panel.sh -O - | /bin/sh"),
            ("feed-elite-extra_arm64", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/feed-elite-extra_arm64.sh -O - | /bin/sh"),
            ("feed-elite-extra_armhf", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/feed-elite-extra_armhf.sh -O - | /bin/sh"),
            ("feed-elite-extra_mipsel", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/feed-elite-extra_mipsel.sh -O - | /bin/sh"),
            ("FORMAT_HDD_TO-Ext4", "wget https://raw.githubusercontent.com/emil237/scripts/refs/heads/main/format-hdd.sh -O - | /bin/sh"),
            ("Repair-Inodes-From-Hdd", "wget https://raw.githubusercontent.com/emil237/scripts/refs/heads/main/repair-hdd.sh -O - | /bin/sh"),
            ("Fix-Xtraevent-Download", "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/fix-xtraevent-download.sh -O - | /bin/sh"),
            ("Set_Time_NTP-Google", "wget https://dreambox4u.com/emilnabil237/script/set_time.sh -O - | /bin/sh"), 
            ("UpdateSatellitesOealliance", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/Satellites-Oealliance.sh -O - | /bin/sh"), 
            ("UpdateSatellitesOpenPli", "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/satellites-openpli.sh -O - | /bin/sh")
        ]
        
        self["list"].setList([name for name, cmd in self.tools])
    
    def runTool(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.tools):
            cmd = self.tools[idx][1]
            self.session.open(Console, "Running Tool", [cmd])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

class SystemPluginsPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="System Plugins">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Install")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.installSelected,
            "cancel": self.close,
            "red": self.close,
            "green": self.installSelected,
            "blue": self.restartGUI
        }, -1)
        
        self.plugins = [
            ("AutomaticCleanup", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/AutomaticCleanup.sh -O - | /bin/sh"),
            ("AutoResolution", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/AutoResolution.sh -O - | /bin/sh"),
            ("extnumberzap", "wget https://dreambox4u.com/emilnabil237/plugins/extnumberzap/extnumberzap.sh -O - | /bin/sh"),
            ("CrashlogAutoSubmit", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/CrashlogAutoSubmit.sh -O - | /bin/sh"),
            ("DynamicDisplay", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/dynamicdisplay.sh -O - | /bin/sh"),
            ("Gemini Projekt for OE2.5", "apt update && wget -O /tmp/geminilocale_all.deb http://download.blue-panel.com/geminilocale_gp42.php && dpkg -i /tmp/geminilocale_all.deb"),
            ("Gemini Projekt for OE2.6", "apt update && wget -O /tmp/geminilocale_all.deb http://download.blue-panel.com/geminilocale_gp42.php && apt install -y /tmp/geminilocale_all.deb"),
            ("geminibluepanel", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/geminibluepanel.sh -O - | /bin/sh"),
            ("geminihwmanager", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/geminihwmanager.sh -O - | /bin/sh"),
            ("geminiimagebackup", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/geminiimagebackup.sh -O - | /bin/sh"),
            ("MenuSort", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/MenuSort.sh -O - | /bin/sh"),
            ("MerlinSkinThemes", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/MerlinSkinThemes.sh -O - | /bin/sh"),
            ("PluginHider", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/PluginHider.sh -O - | /bin/sh"),
            ("PluginSort", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/PluginSort.sh -O - | /bin/sh"),
            ("RemoteControlSelection", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/RemoteControlSelection.sh -O - | /bin/sh"),
            ("Satfinder", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/Satfinder.sh -O - | /bin/sh"),
            ("SetPasswd", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/SetPasswd.sh -O - | /bin/sh"),
            ("SkinSelector", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/SkinSelector.sh -O - | /bin/sh"),
            ("SoftwareManager", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/SoftwareManager.sh -O - | /bin/sh"),
            ("StartUpService", "wget https://github.com/emilnabil/dreambox/raw/refs/heads/main/StartUpService.sh -O - | /bin/sh")
        ]
        
        self["list"].setList([name for name, url in self.plugins])
    
    def installSelected(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.plugins):
            url = self.plugins[idx][1]
            self.session.open(Console, "Installing Plugin", [url])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

class SoftcamsPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="Softcams">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Install")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.installSelected,
            "cancel": self.close,
            "red": self.close,
            "green": self.installSelected,
            "blue": self.restartGUI
        }, -1)
        
        self.softcams = [
            ("Cccam", "wget https://dreambox4u.com/emilnabil237/emu/installer-cccam.sh -O - | /bin/sh"),
            ("gosatplus-ncam", "wget https://dreambox4u.com/emilnabil237/emu/installer-gosatplus-ncam.sh -O - | /bin/sh"),
            ("gosatplus-oscam", "wget https://dreambox4u.com/emilnabil237/emu/installer-gosatplus-oscam.sh -O - | /bin/sh"),
            ("gosatplus_v3_arm", "wget http://e2.gosatplus.com/Plugin/V3/arm-openpli-installer_py3_v3.sh -O - | /bin/sh"),
            ("gosatplus_v3_mips", "wget http://e2.gosatplus.com/Plugin/V3/mips-openpli-installer_py3_v3.sh -O - | /bin/sh"),
            ("gosatplus_v3_Fix", "wget http://e2.gosatplus.com/Plugin/V3/GosatPlusPluginFixPy.sh -O - | /bin/sh"),
            ("Hold-flag-ncam", "wget https://dreambox4u.com/emilnabil237/script/Hold-flag-ncam.sh -O - | /bin/sh"),
            ("Hold-flag-Oscam", "wget https://dreambox4u.com/emilnabil237/script/Hold-flag-Oscam.sh -O - | /bin/sh"),
            ("Ncam", "wget https://dreambox4u.com/emilnabil237/emu/installer-ncam.sh -O - | /bin/sh"),
            ("Oscam", "wget https://dreambox4u.com/emilnabil237/emu/installer-oscam.sh -O - | /bin/sh"),
            ("Oscam-11.726-by-lenuxsat", "wget https://dreambox4u.com/emilnabil237/emu/oscam-by-lenuxsat/installer.sh -O - | /bin/sh"),
            ("oscamicam", "wget https://dreambox4u.com/emilnabil237/emu/installer-oscamicam.sh -O - | /bin/sh"),
            ("powercam_v2-icam-arm", "wget https://dreambox4u.com/emilnabil237/emu/powercam/installer.sh -O - | /bin/sh"),
            ("powercam-Ncam", "wget https://dreambox4u.com/emilnabil237/emu/installer-powercam-ncam.sh -O - | /bin/sh"),
            ("powercam-Oscam", "wget https://dreambox4u.com/emilnabil237/emu/installer-powercam-oscam.sh -O - | /bin/sh"),
            ("Restore-flag-ncam", "wget https://dreambox4u.com/emilnabil237/script/Restore-flag-ncam.sh -O - | /bin/sh"),
            ("Restore-flag-oscam", "wget https://dreambox4u.com/emilnabil237/script/Restore-flag-Oscam.sh -O - | /bin/sh"),
            ("Revcam-Ncam", "wget https://dreambox4u.com/emilnabil237/emu/installer-revcam-ncam.sh -O - | /bin/sh"),
            ("Revcam-Oscam", "wget https://dreambox4u.com/emilnabil237/emu/installer-revcam-oscam.sh -O - | /bin/sh"),
            ("Revcam", "wget https://dreambox4u.com/emilnabil237/emu/installer-revcam.sh -O - | /bin/sh"),
            ("Supcam-Ncam", "wget https://dreambox4u.com/emilnabil237/emu/installer-supcam-ncam.sh -O - | /bin/sh"),
            ("Supcam-Oscam", "wget https://dreambox4u.com/emilnabil237/emu/installer-supcam-oscam.sh -O - | /bin/sh"),
            ("Ultracam-Ncam", "wget https://dreambox4u.com/emilnabil237/emu/installer-ultracam-ncam.sh -O - | /bin/sh"),
            ("Ultracam-Oscam", "wget https://dreambox4u.com/emilnabil237/emu/installer-ultracam-oscam.sh -O - | /bin/sh"),
            ("Ultracam", "wget https://dreambox4u.com/emilnabil237/emu/installer-ultracam.sh -O - | /bin/sh")
        ]
        
        self["list"].setList([name for name, url in self.softcams])
    
    def installSelected(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.softcams):
            url = self.softcams[idx][1]
            self.session.open(Console, "Installing Softcam", [url])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

class BackupPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="Backup">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Backup")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.runBackup,
            "cancel": self.close,
            "red": self.close,
            "green": self.runBackup,
            "blue": self.restartGUI
        }, -1)
        
        self.backups = [
            ("Backup-my-Channels", "wget http://dreambox4u.com/emilnabil237/script/Create-My-backup-shannels.sh -O - | /bin/sh"),   
         ("Backup-hotkey", "wget http://dreambox4u.com/emilnabil237/script/backup-hotkey.sh -O - | /bin/sh"),
         ("Backup-network", "wget http://dreambox4u.com/emilnabil237/script/backup-network.sh -O - | /bin/sh"),
         ("Backup-softcams", "wget http://dreambox4u.com/emilnabil237/script/backup-softcams.sh -O - | /bin/sh"),
        ("Backup-tuner", "wget http://dreambox4u.com/emilnabil237/script/backup-tuner.sh -O - | /bin/sh"),
        ("Backup-my-bouquetmakerxtream", "wget http://dreambox4u.com/emilnabil237/script/backup-my-bouquetmakerxtream.sh -O - | /bin/sh"),
        ("Backup-my-ip2sat-server", "wget http://dreambox4u.com/emilnabil237/script/backup-my-ip2sat-server.sh -O - | /bin/sh"),
("Backup-my-ipaudio-server", "wget http://dreambox4u.com/emilnabil237/script/backup-my-ipaudio-server.sh -O - | /bin/sh"),
("Backup-my-ipaudiopro-server", "wget http://dreambox4u.com/emilnabil237/script/backup-my-ipaudiopro-server.sh -O - | /bin/sh"),
        ("Backup-my-jediplaylists", "wget http://dreambox4u.com/emilnabil237/script/backup-my-jediplaylists.sh -O - | /bin/sh"),
        ("Backup-my-multistalkerpro", "wget http://dreambox4u.com/emilnabil237/script/backup-my-multistalkerpro.sh -O - | /bin/sh"),
        ("Backup-my-Subtitle-Setting", "wget http://dreambox4u.com/emilnabil237/script/backup_my-subtitle-setting.sh -O - | /bin/sh"),
        ("Backup-my-xstreamity-servers", "wget http://dreambox4u.com/emilnabil237/script/backup-my-xstreamity-servers.sh -O - | /bin/sh"),
        ("Backup-sittings-xtraevent", "wget http://dreambox4u.com/emilnabil237/script/backup-sittings-xtraevent.sh -O - | /bin/sh")
        ]
        
        self["list"].setList([name for name, cmd in self.backups])
    
    def runBackup(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.backups):
            cmd = self.backups[idx][1]
            self.session.open(Console, "Creating Backup", [cmd])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

class RestorePanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="Restore">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Restore")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.runRestore,
            "cancel": self.close,
            "red": self.close,
            "green": self.runRestore,
            "blue": self.restartGUI
        }, -1)
        
        self.restores = [
            ("Restore-my-Channels", "wget http://dreambox4u.com/emilnabil237/script/Restore-My-backup-shannels.sh -O - | /bin/sh"),   
         ("Restore-hotkey", "wget http://dreambox4u.com/emilnabil237/script/resore-hotkey.sh -O - | /bin/sh"),
         ("Restore-network", "wget http://dreambox4u.com/emilnabil237/script/restore-network.sh -O - | /bin/sh"),
         ("Restore-softcams", "wget http://dreambox4u.com/emilnabil237/script/restore-softcams.sh -O - | /bin/sh"),
        ("Restore-tuner", "wget http://dreambox4u.com/emilnabil237/script/restore-tuner.sh -O - | /bin/sh"),
        ("Restore-my-bouquetmakerxtream", "wget http://dreambox4u.com/emilnabil237/script/restore-my-bouquetmakerxtream.sh -O - | /bin/sh"),
        ("Restore-my-ip2sat-server", "wget http://dreambox4u.com/emilnabil237/script/restore-my-ip2sat-server.sh -O - | /bin/sh"),
  ("Restore-my-ipaudio-server", "wget http://dreambox4u.com/emilnabil237/script/restore-my-ipaudio-server.sh -O - | /bin/sh"),
("Restore-my-ipaudiopro-server", "wget http://dreambox4u.com/emilnabil237/script/restore-my-ipaudiopro-server.sh -O - | /bin/sh"),
        ("Restore-my-jediplaylists", "wget http://dreambox4u.com/emilnabil237/script/restore-my-jediplaylists.sh -O - | /bin/sh"),
        ("Restore-my-multistalkerpro", "wget http://dreambox4u.com/emilnabil237/script/restore-my-multistalkerpro.sh -O - | /bin/sh"),
        ("Restore-My-Subtitle-Setting", "wget http://dreambox4u.com/emilnabil237/script/Restore_my-subtitle-setting.sh -O - | /bin/sh"),
        ("Restore-my-xstreamity-servers", "wget http://dreambox4u.com/emilnabil237/script/restore-my-xstreamity-servers.sh -O - | /bin/sh"),
        ("Restore-sittings-xtraevent", "wget http://dreambox4u.com/emilnabil237/script/restore-sittings-xtraevent.sh -O - | /bin/sh")
        ]
        
        self["list"].setList([name for name, cmd in self.restores])
    
    def runRestore(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.restores):
            cmd = self.restores[idx][1]
            self.session.open(Console, "Restoring", [cmd])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

class SkinsPanel(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skin = """
        <screen position="center,center" size="1000,700" title="Skins">
            <widget name="list" position="50,50" size="900,500" itemHeight="50" transparent="1" scrollbarMode="showOnDemand" />
            <widget source="key_red" render="Label" position="50,600" size="250,60" backgroundColor="red" font="Regular;30" halign="center" valign="center" />
            <widget source="key_green" render="Label" position="375,600" size="250,60" backgroundColor="green" font="Regular;30" halign="center" valign="center" />
            <widget source="key_blue" render="Label" position="700,600" size="250,60" backgroundColor="blue" font="Regular;30" halign="center" valign="center" />
        </screen>"""
        
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Install")
        self["key_blue"] = StaticText("Restart")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"], {
            "ok": self.installSkin,
            "cancel": self.close,
            "red": self.close,
            "green": self.installSkin,
            "blue": self.restartGUI
        }, -1)
        
        self.skins = [
            ("metrix-hd-oe2.2", "wget -q https://github.com/emilnabil/download-plugins/raw/refs/heads/main/skins-for-dreambox/metrix-hd-oe2.2.sh -O - | /bin/sh"),
            ("gp4-skin-meridian-fhd", "curl -kL https://github.com/emilnabil/download-plugins/raw/refs/heads/main/skins-for-dreambox/gp4-skin-meridian-fhd.sh | bash"),
            ("hdsuisse.one4all.fhd", "curl -kL https://github.com/emilnabil/download-plugins/raw/refs/heads/main/skins-for-dreambox/hdsuisse.one4all.fhd.sh | bash"),
            ("My-Flow", "curl -kL https://github.com/emilnabil/download-plugins/raw/refs/heads/main/skins-for-dreambox/My-Flow.sh | bash"),
            ("Zombi-Shadow-FHD", "curl -kL https://github.com/emilnabil/download-plugins/raw/refs/heads/main/skins-for-dreambox/Zombi-Shadow-FHD.sh | bash"),
            ("ZSkin-FHD", "curl -kL https://github.com/emilnabil/download-plugins/raw/refs/heads/main/skins-for-dreambox/ZSkin-FHD.sh | bash")
        ]
        
        self["list"].setList([name for name, url in self.skins])
    
    def installSkin(self):
        idx = self["list"].getSelectedIndex()
        if idx < len(self.skins):
            url = self.skins[idx][1]
            self.session.open(Console, "Installing Skin", [url])
    
    def restartGUI(self):
        self.session.open(TryQuitMainloop, 3)

def main(session, **kwargs):
    session.open(EmilPanelMain)

def Plugins(**kwargs):
    icon_path = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanelPro/EmilPanel.png")
    return [PluginDescriptor(
        name="Emil Panel Pro",
        description=PLUGIN_DESC,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon=icon_path if os.path.exists(icon_path) else None,
        fnc=main
    )]




