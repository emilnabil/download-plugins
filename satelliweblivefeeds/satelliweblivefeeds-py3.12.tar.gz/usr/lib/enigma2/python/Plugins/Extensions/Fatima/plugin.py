#!/usr/bin/env python
# -*- coding: utf-8 -*-

from Plugins.Plugin import PluginDescriptor

PLUGIN_ICON = "icon.png"
PLUGIN_NAME = "Satelliweb Live Feeds"
PLUGIN_DESC = "Browse and scan live feeds & key in real time"

def main(session, **kwargs):
    from .Ostende import SatelliwebSplash
    session.open(SatelliwebSplash)

def kayadder(session, **kwargs):
    # open our tiny auto-writer that uses current SID/VPID
    from .SatelliwebScreen import keyadder
    session.open(keyadder)

def share_key(session, **kwargs):
    # open our share key screen
    from .SatelliwebScreen import ShareKeyScreen
    session.open(ShareKeyScreen)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name=PLUGIN_NAME,
            description=PLUGIN_DESC,
            where=[PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU],
            icon=PLUGIN_ICON,
            fnc=main
        ),
        PluginDescriptor(
            name="Add BISS Key (Satelliweb)",
            description="Write BISS for current service (SID+VPID)",
            where=[PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU, PluginDescriptor.WHERE_EXTENSIONSMENU, PluginDescriptor.WHERE_PLUGINMENU],
            icon=PLUGIN_ICON,
            fnc=kayadder
        ),
        PluginDescriptor(
            name="Share Key (Satelliweb)",
            description="Share local key for current service",
            where=[PluginDescriptor.WHERE_CHANNEL_CONTEXT_MENU],
            icon=PLUGIN_ICON,
            fnc=share_key
        )
    ]

