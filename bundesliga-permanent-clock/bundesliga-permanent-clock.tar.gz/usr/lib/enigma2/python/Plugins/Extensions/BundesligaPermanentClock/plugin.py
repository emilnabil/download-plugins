## Permanent Clock ## by AliAbdul ## mod by Maggy 
from Components.ActionMap import ActionMap
from Components.config import config, ConfigInteger, ConfigSubsection, ConfigYesNo, getConfigListEntry, ConfigSelection, KEY_LEFT, KEY_RIGHT
from Components.Language import language
from Components.MenuList import MenuList
from Components.ConfigList import ConfigList
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.Pixmap import Pixmap
from enigma import ePoint, eTimer, getDesktop
from GlobalActions import globalActionMap
from keymapparser import readKeymap, removeKeymap
from os import environ
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS
import gettext

##############################################################################

config.plugins.BundesligaPermanentClock = ConfigSubsection()
config.plugins.BundesligaPermanentClock.enabled = ConfigYesNo(default=False)
config.plugins.BundesligaPermanentClock.position_x = ConfigInteger(default=590)
config.plugins.BundesligaPermanentClock.position_y = ConfigInteger(default=35)
config.plugins.BundesligaPermanentClock.par1 = ConfigYesNo(default=False)
config.plugins.BundesligaPermanentClock.show_hide = ConfigYesNo(default=False)
config.plugins.BundesligaPermanentClock.color_analog = ConfigSelection([("1", _("HSV")),("2", _("BVB")),("3", _("FC Koeln")),("4", _("Bayer 04 Leverkusen")),("5", _("SV Darmstadt 98")),("6", _("FC Augsburg")),("7", _("Bayern Muenchen")),("8", _("SC Freiburg")),("9", _("Eintracht Frankfurt")),("10", _("Hertha BSC")),("11", _("FC Ingolstadt 04")),("12", _("FSV Mainz 05")),("13", _("RB Leipzig")),("14", _("FC Schalke 04")),("15", _("TSG Hoffenheim")),("16", _("Werder Bremen")),("17", _("VfL Wolfsburg")),("18", _("Bor. Moenchengladbach"))], default="1")


##############################################################################

def localeInit():
	lang = language.getLanguage()
	environ["LANGUAGE"] = lang[:2]
	gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
	gettext.textdomain("enigma2")
	gettext.bindtextdomain("BundesligaPermanentClock", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/BundesligaPermanentClock/locale/"))

def _(txt):
	t = gettext.dgettext("BundesligaPermanentClock", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)

##############################################################################

SKIN1 = """
  <screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
   <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/hsv.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")
	
##############################################################################

SKIN2 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
	 <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/bvb.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN3 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/1fck.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

	##############################################################################

SKIN4 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/bl1904.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")
	
##############################################################################

SKIN5 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/darmstadt.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN6 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/fca.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
 <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN7 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/fcb.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN8 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/freiburg.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN9 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/frankfurt.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN10 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/hertha bsc.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN11 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/ingolstadt.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN12 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/mainz05.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
 <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN13 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/rbl.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
 <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN14 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/s04.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN15 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/tsg.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN16 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/werder.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN17 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/wolfsburg.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
  <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN18 = """
	<screen position="5,5" size="200,200" zPosition="10" backgroundColor="transparent" title="%s" flags="wfNoBorder">
  <ePixmap position="0,0" zPosition="1" size="200,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/bmg.png" alphatest="blend" />
  <ePixmap position="95,95" size="8,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/clocks/dot.png" zPosition="5" alphatest="blend" />
 <widget source="global.CurrentTime" render="MaggyWatches" position="30,29" size="140,140" zPosition="4" alphatest="blend" foregroundColor="red">
    <convert type="MaggyExtraNumText">secHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="35,35" size="130,130" zPosition="3" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">minHand</convert>
  </widget>
  <widget source="global.CurrentTime" render="MaggyWatches" position="52,52" size="95,95" zPosition="2" foregroundColor="black" alphatest="blend">
    <convert type="MaggyExtraNumText">hourHand</convert>
  </widget>
</screen>""" % _("Bundesliga Permanent Clock")

##############################################################################

SKIN = """
	<screen position="0,0" size="135,50" zPosition="10" transparent="0" backgroundColor="transparent" title="%s" flags="wfNoBorder">
		<widget source="global.CurrentTime" render="Label" position="1,1" size="135,50" backgroundColor="transparent" transparent="1" zPosition="0" foregroundColor="white" font="Regular;35" valign="center" halign="center">
			<convert type="ClockToText">Default</convert>
		</widget>
	</screen>""" % _("Permanent Clock")

class BundesligaPermanentClockNewScreen(Screen):
	def __init__(self, session):
		if config.plugins.BundesligaPermanentClock.par1.value == True:
			if config.plugins.BundesligaPermanentClock.color_analog.value == "1":
				self.skin = SKIN1
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "2":
				self.skin = SKIN2
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "3":
				self.skin = SKIN3
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "4":
				self.skin = SKIN4
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "5":
				self.skin = SKIN5
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "6":
				self.skin = SKIN6
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "7":
				self.skin = SKIN7
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "8":
				self.skin = SKIN8
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "9":
				self.skin = SKIN9
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "10":
				self.skin = SKIN10
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "11":
				self.skin = SKIN11
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "12":
				self.skin = SKIN12
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "13":
				self.skin = SKIN13
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "14":
				self.skin = SKIN14
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "15":
				self.skin = SKIN15
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "16":
				self.skin = SKIN16
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "17":
				self.skin = SKIN17
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "18":
				self.skin = SKIN18
		if config.plugins.BundesligaPermanentClock.par1.value == False:
			self.skin = SKIN
		     
		Screen.__init__(self, session)
	    
		self.onShow.append(self.movePosition)

	def movePosition(self):
		if self.instance:
			self.instance.move(ePoint(config.plugins.BundesligaPermanentClock.position_x.value, config.plugins.BundesligaPermanentClock.position_y.value))

##############################################################################

class BundesligaPermanentClock():
	def __init__(self):
		self.dialog = None
		self.clockShown = False
		self.clockey = False
		
	def gotSession(self, session):
		self.dialog = session.instantiateDialog(BundesligaPermanentClockNewScreen)
		self.showHide()
		self.start_key()
		
	def start_key(self):
		global globalActionMap
		if config.plugins.BundesligaPermanentClock.show_hide.value and self.clockey == False:
			readKeymap("/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/keymap.xml")
			globalActionMap.actions['showClock'] = self.ShowHideKey
			self.clockey = True

	def unload_key(self):
		if not config.plugins.BundesligaPermanentClock.show_hide.value and self.clockey == True:
			removeKeymap("/usr/lib/enigma2/python/Plugins/Extensions/BundesligaPermanentClock/keymap.xml")
			if 'showClock' in globalActionMap.actions:
				del globalActionMap.actions['showClock']
			self.clockey = False
			
	def ShowHideKey(self):
		if config.plugins.BundesligaPermanentClock.enabled.value:
			if self.clockShown:
				self.clockShown = False
				self.dialog.show()
			else:
				self.clockShown = True
				self.dialog.hide()
	
	
	def changeVisibility(self):
		if config.plugins.BundesligaPermanentClock.enabled.value:
			config.plugins.BundesligaPermanentClock.enabled.value = False
		else:
			config.plugins.BundesligaPermanentClock.enabled.value = True
		config.plugins.BundesligaPermanentClock.enabled.save()
		self.showHide()

	def changeAnalog(self):
		if config.plugins.BundesligaPermanentClock.par1.value:
			config.plugins.BundesligaPermanentClock.par1.value = False
		else:
			config.plugins.BundesligaPermanentClock.par1.value = True
		config.plugins.BundesligaPermanentClock.par1.save()
		self.dialog = None
		
	def ColorAnalog(self):
		config.plugins.BundesligaPermanentClock.color_analog.save()
		self.dialog = None
		
	def changeKey(self):
		if config.plugins.BundesligaPermanentClock.show_hide.value:
			config.plugins.BundesligaPermanentClock.show_hide.value = False
		else:
			config.plugins.BundesligaPermanentClock.show_hide.value = True
		config.plugins.BundesligaPermanentClock.show_hide.save()	
		
	def showHide(self):
		if config.plugins.BundesligaPermanentClock.enabled.value:
			self.dialog.show()
		else:
			self.dialog.hide()

pClock = BundesligaPermanentClock()

##############################################################################

class BundesligaPermanentClockPositioner(Screen):
	def __init__(self, session):
		if config.plugins.BundesligaPermanentClock.par1.value == True:
			if config.plugins.BundesligaPermanentClock.color_analog.value == "1":
				self.skin = SKIN1
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "2":
				self.skin = SKIN2
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "3":
				self.skin = SKIN3
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "4":
				self.skin = SKIN4
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "5":
				self.skin = SKIN5
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "6":
				self.skin = SKIN6
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "7":
				self.skin = SKIN7
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "8":
				self.skin = SKIN8
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "9":
				self.skin = SKIN9
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "10":
				self.skin = SKIN10
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "11":
				self.skin = SKIN11
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "12":
				self.skin = SKIN12
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "13":
				self.skin = SKIN13
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "14":
				self.skin = SKIN14
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "15":
				self.skin = SKIN15
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "16":
				self.skin = SKIN16
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "17":
				self.skin = SKIN17
			elif config.plugins.BundesligaPermanentClock.color_analog.value == "18":
				self.skin = SKIN18
		if config.plugins.BundesligaPermanentClock.par1.value == False:
			self.skin = SKIN
		Screen.__init__(self, session)
	
		
		self["actions"] = ActionMap(["WizardActions"],
		{
			"left": self.left,
			"up": self.up,
			"right": self.right,
			"down": self.down,
			"ok": self.ok,
			"back": self.exit
		}, -1)
		
		desktop = getDesktop(0)
		self.desktopWidth = desktop.size().width()
		self.desktopHeight = desktop.size().height()
		
		self.moveTimer = eTimer()
		self.moveTimer.callback.append(self.movePosition)
		self.moveTimer.start(50, 1)

	def movePosition(self):
		self.instance.move(ePoint(config.plugins.BundesligaPermanentClock.position_x.value, config.plugins.BundesligaPermanentClock.position_y.value))
		self.moveTimer.start(50, 1)

	def left(self):
		value = config.plugins.BundesligaPermanentClock.position_x.value
		value -= 8
		if value < 0:
			value = 0
		config.plugins.BundesligaPermanentClock.position_x.value = value

	def up(self):
		value = config.plugins.BundesligaPermanentClock.position_y.value
		value -= 8
		if value < 0:
			value = 0
		config.plugins.BundesligaPermanentClock.position_y.value = value

	def right(self):
		value = config.plugins.BundesligaPermanentClock.position_x.value
		value += 8
		if value > self.desktopWidth:
			value = self.desktopWidth
		config.plugins.BundesligaPermanentClock.position_x.value = value

	def down(self):
		value = config.plugins.BundesligaPermanentClock.position_y.value
		value += 8
		if value > self.desktopHeight:
			value = self.desktopHeight
		config.plugins.BundesligaPermanentClock.position_y.value = value

	def ok(self):
		config.plugins.BundesligaPermanentClock.position_x.save()
		config.plugins.BundesligaPermanentClock.position_y.save()
		self.close()

	def exit(self):
		config.plugins.BundesligaPermanentClock.position_x.cancel()
		config.plugins.BundesligaPermanentClock.position_y.cancel()
		self.close()

##############################################################################

class BundesligaPermanentClockMenu(Screen):
	skin = """
		<screen position="center,center" size="750,235" title="Bundesliga Permanent Clock Setup">
			<widget name="list" itemHeight="40" font="Regular;30" position="10,10" size="730,215" />
		</screen>""" 

	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self["list"] = MenuList([])
		self.setTitle(_("Bundesliga Permanent Clock Setup"))
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.okClicked, "cancel": self.close}, -1)
		self.onLayoutFinish.append(self.showMenu)


	def showMenu(self):
		list = []
		if config.plugins.BundesligaPermanentClock.enabled.value:
			list.append(_("Deactivate bundesliga permanent clock"))
			list.append(_("Change bundesliga permanent clock position"))
		else:
			list.append(_("Activate bundesliga permanent clock"))
		if config.plugins.BundesligaPermanentClock.enabled.value:
			if config.plugins.BundesligaPermanentClock.par1.value:
				list.append(_("Show digital clock"))
				list.append(_("Change analog clock"))
			else:
				list.append(_("Show analog clock"))
		if config.plugins.BundesligaPermanentClock.enabled.value:
			if config.plugins.BundesligaPermanentClock.show_hide.value:
				list.append(_("Disable key 'long EXIT' show/nide"))
			else:
				list.append(_("Enable key 'long EXIT' show/nide"))
		self["list"].setList(list)



	def newConfig(self):
		pClock.dialog.hide()
		pClock.ColorAnalog()
		if pClock.dialog is None:
			pClock.gotSession(self.session)

					
	def okClicked(self):
		sel = self["list"].getCurrent()
		if pClock.dialog is None:
			pClock.gotSession(self.session)
		if sel == _("Deactivate bundesliga permanent clock") or sel == _("Activate bundesliga permanent clock"):
			pClock.changeVisibility()
			self.showMenu()
		if sel == _("Change bundesliga permanent clock position") :
			pClock.dialog.hide()
			self.session.openWithCallback(self.positionerCallback, BundesligaPermanentClockPositioner)
		if sel == _("Show analog clock") or sel == _("Show digital clock"):
			if pClock.dialog is not None:
				pClock.dialog.hide()
				pClock.changeAnalog()
				self.showMenu()
				if pClock.dialog is None:
					pClock.gotSession(self.session)
		if sel == _("Disable key 'long EXIT' show/nide"):
			if pClock.dialog is not None:
				pClock.changeKey()
				self.showMenu()
				pClock.unload_key()
		if sel == _("Enable key 'long EXIT' show/nide"):
			if pClock.dialog is not None:
				pClock.changeKey()
				self.showMenu()
				pClock.start_key()
		if sel == _("Change analog clock"):
			self.colorClock()
			
	def colorClock(self):
		list = [
			(_("HSV"), self.skins1),
			(_("BVB"), self.skins2),
			(_("FC Koeln"), self.skins3),
			(_("Bayer 04 Leverkusen"), self.skins4),
			(_("SV Darmstadt 98"), self.skins5),
			(_("FC Augsburg"), self.skins6),
			(_("Bayern Muenchen"), self.skins7),
			(_("SC Freiburg"), self.skins8),
			(_("Eintracht Frankfurt"), self.skins9),
			(_("Hertha BSC"), self.skins10),
			(_("FC Ingolstadt 04"), self.skins11),
			(_("FSV Mainz 05"), self.skins12),
			(_("RB Leipzig"), self.skins13),
			(_("FC Schalke 04"), self.skins14),
			(_("TSG Hoffenheim"), self.skins15),
			(_("Werder Bremen"), self.skins16),
			(_("VfL Wolfsburg"), self.skins17),
			(_("Bor. Moenchengladbach"), self.skins18),
		]
		self.session.openWithCallback(
			self.menuCallback,
			ChoiceBox,
			title= _("Choice clock color:"),
			list = list,
		)

	def menuCallback(self, ret = None):
		ret and ret[1]()

	def positionerCallback(self, callback=None):
		pClock.showHide()

	def skins1(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "1"
		self.newConfig()
		
	def skins2(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "2"
		self.newConfig()

	def skins3(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "3"
		self.newConfig()

	def skins4(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "4"
		self.newConfig()

	def skins5(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "5"
		self.newConfig()
		
	def skins6(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "6"
		self.newConfig()
		
	def skins7(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "7"
		self.newConfig()
		
	def skins8(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "8"
		self.newConfig()
		
	def skins9(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "9"
		self.newConfig()
		
	def skins10(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "10"
		self.newConfig()
	
	def skins11(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "11"
		self.newConfig()
	
	def skins12(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "12"
		self.newConfig()
		
	def skins13(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "13"
		self.newConfig()
		
	def skins14(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "14"
		self.newConfig()
		
	def skins15(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "15"
		self.newConfig()
	
	def skins16(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "16"
		self.newConfig()
		
	def skins17(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "17"
		self.newConfig()
		
	def skins18(self):
		config.plugins.BundesligaPermanentClock.color_analog.value = "18"
		self.newConfig()
##############################################################################

def sessionstart(reason, **kwargs):
	if reason == 0:
		pClock.gotSession(kwargs["session"])

def startConfig(session, **kwargs):
	session.open(BundesligaPermanentClockMenu)

def main(menuid):
	if menuid != "system": 
		return [ ]
	return [(_("Bundesliga Permanent Clock"), startConfig, "bundesliga permanent_clock", None)]

##############################################################################

def Plugins(**kwargs):
	return [
		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart),
		PluginDescriptor(name=_("Bundesliga Permanent Clock"), description=_("Shows the clock Bundesliga permanent on the screen"), where=PluginDescriptor.WHERE_MENU, fnc=main)]
