import json
import socket
import os
import sys
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Button import Button
from Components.Sources.List import List
from Components.ProgressBar import ProgressBar
from Components.config import config, ConfigSubsection
from enigma import eConsoleAppContainer, eTimer, ePixmap, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, fileExists
from Tools.LoadPixmap import LoadPixmap
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop

config.plugins.smartaddons = ConfigSubsection()

PLUGIN_PATH = resolveFilename(SCOPE_PLUGINS, "Extensions/SmartAddonspanel/")
PLUGIN_ICON = resolveFilename(SCOPE_PLUGINS, "Extensions/SmartAddonspanel/icon.png")
PLUGIN_VERSION = "5.0.3"
VERSION_URL = "https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/SmartAddonspanel/Py3/version.txt"
UPDATE_SCRIPT_URL = "https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/SmartAddonspanel/smart-Panel.sh"
CONFIG_URL = "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/SmartAddonspanel/Py3/config.json"
LOCAL_CONFIG_FILE = os.path.join(PLUGIN_PATH, "config.json")

class InstallProgressScreen(Screen):
    skin = """
    <screen name="InstallProgressScreen" position="center,center" size="700,200" title="Installing...">
        <widget name="progress" position="10,30" size="680,20" backgroundColor="#404040" />
        <widget name="status" position="10,60" size="680,100" font="Regular;22" transparent="1" />
        <widget name="percentage" position="10,150" size="680,20" font="Regular;24" halign="right" />
        <widget name="key_red" position="250,160" size="200,30" font="Bold;24" halign="center" backgroundColor="#C80000" foregroundColor="#FFFFFF" />
    </screen>
    """

    def __init__(self, session, selected_plugins, callback):
        Screen.__init__(self, session)
        self.selected_plugins = selected_plugins
        self.callback = callback
        self.container = eConsoleAppContainer()
        self.container.appClosed.append(self.command_finished)
        self.container.dataAvail.append(self.command_output)
        self.current_plugin_index = 0
        self.total_plugins = len(selected_plugins)
        self["progress"] = ProgressBar()
        self["status"] = Label("")
        self["percentage"] = Label("")
        self["key_red"] = Button("Cancel")
        self["actions"] = ActionMap(["ColorActions"], {"red": self.on_cancel}, -1)
        self.run_next_command()

    def run_next_command(self):
        if self.current_plugin_index < self.total_plugins:
            progress = int(((self.current_plugin_index + 1) / float(self.total_plugins)) * 100)
            self["progress"].setValue(progress)
            self["percentage"].setText(str(progress) + "%")
            name, cmd = self.selected_plugins[self.current_plugin_index]
            self["status"].setText("Installing: " + str(name) + " (" + str(self.current_plugin_index + 1) + "/" + str(self.total_plugins) + ")")
            self.container.execute(cmd)
        else:
            self.session.openWithCallback(self.restart_enigma2, MessageBox,
                "Successfully installed " + str(self.total_plugins) + " plugins. Restart Enigma2 now?",
                MessageBox.TYPE_YESNO)

    def command_output(self, data):
        pass

    def command_finished(self, retval):
        if retval != 0:
            self.session.openWithCallback(self.on_error, MessageBox,
                "Installation failed with error code " + str(retval) + ". Continue?",
                MessageBox.TYPE_YESNO)
        else:
            self.current_plugin_index += 1
            self.run_next_command()

    def on_error(self, answer):
        if answer:
            self.current_plugin_index += 1
            self.run_next_command()
        else:
            self.close()

    def on_cancel(self):
        if self.container.running:
            self.container.kill()
        self.session.open(MessageBox, "Installation cancelled.", MessageBox.TYPE_INFO)
        self.close()

    def restart_enigma2(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)
        self.close()

    def close(self):
        if hasattr(self, "container") and self.container.running:
            self.container.kill()
        if self.callback:
            self.callback()
        Screen.close(self)

class SmartAddonspanel(Screen):
    skin = """
    <screen name="SmartAddonspanel" position="left,center" size="1920,1080" title="Smart Addons Panel By Emil Nabil">
        <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SmartAddonspanel/icons/background.png" zPosition="-1" />
        <widget name="main_menu" position="30,60" size="500,900" scrollbarMode="showOnDemand" itemHeight="70" foregroundColor="#FFD700" font="Bold;40" flags="RT_HALIGN_LEFT" />
        <widget source="sub_menu" render="Listbox" position="560,50" size="650,900" scrollbarMode="showOnDemand" transparent="0">
            <convert type="TemplatedMultiContent">
                {"template": [
                    MultiContentEntryPixmapAlphaBlend(pos=(5,10), size=(50,50), png=2),
                    MultiContentEntryText(pos=(60,0), size=(580,35), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=0),
                    MultiContentEntryText(pos=(60,35), size=(580,35), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=1),
                ],
                "fonts": [gFont("Regular",24)],
                "itemHeight": 90
                }
            </convert>
        </widget>
        <widget name="status" position="30,965" size="1080,40" font="Regular;30" halign="center" backgroundColor="#303030" />
        <widget name="key_green" position="30,1010" size="376,55" font="Bold;28" halign="center" backgroundColor="#1F771F" />
        <widget name="key_yellow" position="427,1010" size="376,55" font="Bold;28" halign="center" backgroundColor="#FFC000" />
        <widget name="key_blue" position="824,1010" size="376,55" font="Bold;28" halign="center" backgroundColor="#13389F" />
        <widget name="python_version" position="1300,960" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget source="session.VideoPicture" render="Pig" position="1280,60" size="600,350" zPosition="1" backgroundColor="#ff000000" />
        <widget name="receiver_model" position="1300,420" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget name="image_type" position="1300,480" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget name="image_version" position="1300,540" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget name="cpu_info" position="1300,600" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget name="memory_info" position="1300,660" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget name="storage_info" position="1300,720" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget name="mount_info" position="1300,780" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget name="ip_address" position="1300,840" size="600,55" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
        <widget name="internet_status" position="1300,900" size="600,50" font="Regular;35" halign="center" backgroundColor="#423C3D" foregroundColor="#FFFFFF" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        if not os.path.exists(PLUGIN_PATH):
            try:
                os.makedirs(PLUGIN_PATH)
            except:
                pass
        
        self.load_config()
        
        if not hasattr(self, 'config_data') or not self.config_data:
            self.config_data = {}
            self.main_menu = []
            self.sub_menus = {}
        else:
            self.main_menu = []
            if isinstance(self.config_data, dict) and "main" in self.config_data:
                for item in self.config_data.get("main", []):
                    if isinstance(item, dict) and "title" in item:
                        title = item.get("title", "")
                        if title:
                            self.main_menu.append(str(title))
            
            if not self.main_menu:
                self.main_menu = ["Panels", "Plugins"]
            
            self.sub_menus = {}
            for item in self.config_data.get("main", []):
                if isinstance(item, dict):
                    title = item.get("title", "")
                    section = item.get("section", "")
                    if title and section and section in self.config_data:
                        self.sub_menus[title] = []
                        for plugin in self.config_data[section]:
                            if isinstance(plugin, dict) and "name" in plugin and "cmd" in plugin:
                                self.sub_menus[title].append((str(plugin["name"]), str(plugin["cmd"])))
        
        self.selected_plugins = []
        self.focus = "main_menu"

        self["main_menu"] = MenuList(self.main_menu)
        self["sub_menu"] = List([])
        self["status"] = Label("Select a category")
        self["key_green"] = Button("Install")
        self["key_yellow"] = Button("Update")
        self["key_blue"] = Button("Restart")
        self["python_version"] = Label(self.get_python_version())
        self["receiver_model"] = Label(self.get_receiver_model())
        self["image_type"] = Label(self.get_image_type())
        self["image_version"] = Label(self.get_image_version())
        self["cpu_info"] = Label(self.get_cpu_info())
        self["memory_info"] = Label(self.get_memory_info())
        self["storage_info"] = Label(self.get_storage_info())
        self["mount_info"] = Label(self.get_mount_info())
        self["ip_address"] = Label(self.get_router_ip())
        self["internet_status"] = Label(self.get_internet_status())

        self.checked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/SmartAddonspanel/icons/checked.png"))
        self.unchecked_icon = LoadPixmap(resolveFilename(SCOPE_PLUGINS, "Extensions/SmartAddonspanel/icons/unchecked.png"))

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.handle_ok,
                "left": self.focus_main_menu,
                "right": self.focus_sub_menu,
                "cancel": self.exit,
                "green": self.execute_all_selected_plugins,
                "yellow": self.update_plugin,
                "blue": self.restart_enigma2,
                "up": self.navigate_up,
                "down": self.navigate_down,
            },
            -1
        )

        self["main_menu"].onSelectionChanged.append(self.load_sub_menu)
        self.update_sub_menu_list()

        self.timer = eTimer()
        self.timer.timeout.get().append(self.update_time)
        self.timer.start(1000)
        self.version_check_in_progress = False
        self.check_for_updates()

    def load_config(self):
        try:
            config_data = None
            try:
                if sys.version_info[0] == 2:
                    import urllib2
                    response = urllib2.urlopen(CONFIG_URL, timeout=10)
                    data = response.read()
                    try:
                        config_data = json.loads(data)
                    except:
                        config_data = json.loads(data.decode('utf-8'))
                else:
                    import urllib.request
                    response = urllib.request.urlopen(CONFIG_URL, timeout=10)
                    data = response.read()
                    config_data = json.loads(data.decode('utf-8'))
            except:
                pass

            if config_data is None and fileExists(LOCAL_CONFIG_FILE):
                with open(LOCAL_CONFIG_FILE, 'r') as f:
                    data = f.read()
                    try:
                        config_data = json.loads(data)
                    except:
                        config_data = json.loads(data.decode('utf-8'))

            if config_data is None:
                config_data = self.get_default_config()
            else:
                if not isinstance(config_data, dict):
                    config_data = self.get_default_config()
                elif "main" not in config_data or not isinstance(config_data["main"], list):
                    config_data = self.get_default_config()

            self.config_data = config_data
            self.save_config()
        except:
            self.config_data = self.get_default_config()

    def get_default_config(self):
        return {
            "main": [
                {"title": "Panels", "section": "panels", "icon": "panels.png"},
                {"title": "Plugins", "section": "plugins", "icon": "plugins.png"}
            ],
            "panels": [
                {"name": "Ajpanel", "cmd": "wget http://dreambox4u.com/emilnabil237/plugins/ajpanel/installer.sh -O - | /bin/sh"},
                {"name": "EmilPanel", "cmd": "wget https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EmilPanel/emilpanel.sh -O - | /bin/sh"}
            ],
            "plugins": [
                {"name": "ArabicSavior", "cmd": "wget http://dreambox4u.com/emilnabil237/plugins/ArabicSavior/installer.sh -O - | /bin/sh"},
                {"name": "Acherone", "cmd": "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/acherone/installer.sh -O - | /bin/sh"}
            ]
        }

    def save_config(self):
        try:
            with open(LOCAL_CONFIG_FILE, 'w') as f:
                json.dump(self.config_data, f, indent=2)
        except:
            pass

    def split_name(self, name):
        if not isinstance(name, str):
            name = str(name)
        parts = name.split('-')
        if len(parts) <= 1:
            return (name, '')
        mid = len(parts) // 2
        return ('-'.join(parts[:mid]), '-'.join(parts[mid:]))

    def update_sub_menu_list(self):
        sel = self["main_menu"].getCurrent()
        items = []
        if sel and sel in self.sub_menus:
            for entry in self.sub_menus[sel]:
                name, cmd = entry
                line1, line2 = self.split_name(name)
                icon = self.checked_icon if any(p[0] == name for p in self.selected_plugins) else self.unchecked_icon
                items.append((line1, line2, icon, name))
        self["sub_menu"].setList(items)

    def load_sub_menu(self):
        current = self["main_menu"].getCurrent()
        if current:
            self["status"].setText("Category: " + str(current))
        self.update_sub_menu_list()

    def get_router_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return "IP: " + str(ip)
        except:
            return "IP not available"

    def get_python_version(self):
        return "Python: " + str(sys.version.split()[0])

    def get_receiver_model(self):
        try:
            return str(open("/etc/hostname").read().strip())
        except:
            return "Unknown Model"

    def get_image_type(self):
        try:
            with open("/etc/image-version") as f:
                for line in f:
                    if "creator" in line.lower():
                        return str(line.strip().replace("creator", "Image"))
            return "Unknown Image"
        except:
            return "Unknown Image"

    def get_image_version(self):
        try:
            with open("/etc/image-version") as f:
                for line in f:
                    if "version" in line.lower():
                        return str(line.strip())
            return "Unknown Version"
        except:
            return "Unknown Version"

    def get_cpu_info(self):
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if "Processor" in line or "model name" in line:
                        return str(line.split(":",1)[1].strip())
            return "Unknown CPU"
        except:
            return "Unknown CPU"

    def get_memory_info(self):
        try:
            total = free = 0
            with open("/proc/meminfo") as f:
                for line in f:
                    if "MemTotal" in line:
                        total = int(line.split()[1]) // 1024
                    elif "MemFree" in line:
                        free = int(line.split()[1]) // 1024
            return "RAM: " + str(total) + "MB Free: " + str(free) + "MB"
        except:
            return "Unknown Memory"

    def get_storage_info(self):
        try:
            st = os.statvfs("/")
            total = st.f_blocks * st.f_frsize
            free = st.f_bfree * st.f_frsize
            total_gb = total / (1024 ** 3)
            free_gb = free / (1024 ** 3)
            used_gb = total_gb - free_gb
            return "HDD: " + str(round(used_gb, 2)) + "GB/" + str(round(total_gb, 2)) + "GB"
        except:
            return "HDD: N/A"

    def get_mount_info(self):
        return "Mount: /media/hdd" if os.path.ismount("/media/hdd") else "Mount: Not Found"

    def get_internet_status(self):
        return "Internet: Connected" if os.system("ping -c 1 8.8.8.8 >/dev/null 2>&1") == 0 else "Internet: Offline"

    def focus_main_menu(self):
        self.focus = "main_menu"
        self["main_menu"].selectionEnabled(1)
        self["sub_menu"].setIndex(0)

    def focus_sub_menu(self):
        self.focus = "sub_menu"
        self["main_menu"].selectionEnabled(0)
        if len(self["sub_menu"].list):
            self["sub_menu"].setIndex(0)

    def navigate_up(self):
        if self.focus == "main_menu":
            self["main_menu"].up()
        else:
            self["sub_menu"].up()

    def navigate_down(self):
        if self.focus == "main_menu":
            self["main_menu"].down()
        else:
            self["sub_menu"].down()

    def handle_ok(self):
        category = self["main_menu"].getCurrent()
        entry = self["sub_menu"].getCurrent()
        if not entry or not category:
            return
        original_name = entry[3]
        cmd = None
        if category in self.sub_menus:
            for n, c in self.sub_menus[category]:
                if n == original_name:
                    cmd = c
                    break
        if cmd:
            if any(p[0] == original_name for p in self.selected_plugins):
                self.selected_plugins = [p for p in self.selected_plugins if p[0] != original_name]
            else:
                self.selected_plugins.append((original_name, cmd))
            self.update_sub_menu_list()

    def execute_all_selected_plugins(self):
        if self.selected_plugins:
            self.session.openWithCallback(self.installation_finished,
                InstallProgressScreen, self.selected_plugins, self.installation_finished)
        else:
            self.session.open(MessageBox, "No plugins selected.", MessageBox.TYPE_INFO)

    def installation_finished(self, *args):
        self.selected_plugins = []
        self.update_sub_menu_list()

    def update_plugin(self):
        self.check_for_updates()

    def restart_enigma2(self):
        self.session.openWithCallback(self.confirm_restart, MessageBox,
            "Restart Enigma2 now?", MessageBox.TYPE_YESNO)

    def confirm_restart(self, answer):
        if answer:
            self.session.open(TryQuitMainloop, 3)

    def exit(self):
        self.close()

    def update_time(self):
        pass

    def check_for_updates(self):
        if getattr(self, "version_check_in_progress", False):
            return
        self.version_check_in_progress = True
        self["status"].setText("Checking for updates...")
        self.version_buffer = b""
        self.update_container = eConsoleAppContainer()
        self.update_container.dataAvail.append(self.version_data_avail)
        self.update_container.appClosed.append(self.version_check_closed)
        self.update_container.execute("wget -q -O - " + str(VERSION_URL))

    def version_data_avail(self, data):
        self.version_buffer += data

    def version_check_closed(self, retval):
        self.version_check_in_progress = False
        if retval == 0:
            remote = ""
            try:
                remote = self.version_buffer.decode().strip()
            except:
                remote = self.version_buffer.strip()
            if remote != PLUGIN_VERSION:
                self.session.openWithCallback(self.start_update, MessageBox,
                    "Update available (" + str(remote) + "). Install now?",
                    MessageBox.TYPE_YESNO)
            else:
                self["status"].setText("Plugin is up to date.")
        else:
            self["status"].setText("Update check failed.")

    def start_update(self, answer):
        if not answer:
            return
        self["status"].setText("Updating plugin...")
        self.update_container = eConsoleAppContainer()
        self.update_container.appClosed.append(self.update_completed)
        self.update_container.execute(
            "wget -q -O /tmp/smart-Panel.sh " + str(UPDATE_SCRIPT_URL) + " && chmod +x /tmp/smart-Panel.sh && /tmp/smart-Panel.sh"
        )

    def update_completed(self, retval):
        if retval == 0:
            self["status"].setText("Update successful. Restarting...")
            self.session.open(TryQuitMainloop, 3)
        else:
            self["status"].setText("Update failed.")

def Plugins(**kwargs):
    return [PluginDescriptor(
        name="Smart Addons Panel",
        description="Manage plugins and tools",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon=PLUGIN_ICON,
        fnc=lambda session: session.open(SmartAddonspanel)
    )]
