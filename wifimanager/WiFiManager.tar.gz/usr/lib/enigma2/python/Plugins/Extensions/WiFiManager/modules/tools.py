from __future__ import division
from __future__ import print_function

import errno
import io
import sys
import time
import subprocess
from json import load, dump
from re import search, findall, DOTALL
from os.path import exists

from .. import _


def verify_connection(interface, essid):
    
    try:
        process = subprocess.Popen("iwconfig " + interface, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        if 'ESSID:"' + essid + '"' in stdout:
            ip_process = subprocess.Popen("ip addr show " + interface, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            ip_stdout, ip_stderr = ip_process.communicate()
            return 'inet ' in ip_stdout
        return False
    except:
        return False


def is_interface_up(interface):
    
    try:
        process = subprocess.Popen(['ip', 'link', 'show', interface], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        return 'state UP' in stdout
    except:
        return False


def ensure_interface_up(interface):
    
    if not interface:
        return False

    try:
        
        process = subprocess.Popen("ip link show " + interface, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        if process.returncode != 0:
            print("[DEBUG] Interface " + interface + " not found")
            return False

        
        process = subprocess.Popen("ip link set " + interface + " up", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()

        if process.returncode == 0:
            print("[DEBUG] Interface " + interface + " brought up successfully")
            time.sleep(1)  
            return True
        else:
            print("[DEBUG] Failed to bring interface up: " + stderr)
            
            process2 = subprocess.Popen("ifconfig " + interface + " up", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout2, stderr2 = process2.communicate()
            return process2.returncode == 0

    except Exception as e:
        print("[DEBUG] Error ensuring interface up: " + str(e))
        return False


def get_wifi_interfaces():
    
    wifi_interfaces = []

    try:
        
        try:
            with open('/proc/net/wireless', 'r') as f:
                lines = f.readlines()
            for line in lines[2:]:  
                parts = line.split(':')
                if len(parts) > 0:
                    ifname = parts[0].strip()
                    if ifname and ifname not in wifi_interfaces:
                        wifi_interfaces.append(ifname)
        except Exception as e:
            print("[get_wifi_interfaces] Error reading /proc/net/wireless: " + str(e))

        
        try:
            process = subprocess.Popen(['iwconfig'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout, stderr = process.communicate()
            if process.returncode == 0:
                for line in stdout.split('\n'):
                    if 'IEEE 802.11' in line or 'ESSID:' in line:
                        if 'no wireless extensions' not in line:
                            ifname_match = search(r'^(\w+)\s+', line)
                            if ifname_match:
                                ifname = ifname_match.group(1)
                                if ifname and ifname not in wifi_interfaces:
                                    wifi_interfaces.append(ifname)
        except Exception as e:
            print("[get_wifi_interfaces] Error with iwconfig: " + str(e))

        
        try:
            process = subprocess.Popen(['ip', 'link', 'show'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout, stderr = process.communicate()
            if process.returncode == 0:
                for line in stdout.split('\n'):
                    if any(name in line for name in ['wlan', 'wlp', 'wifi', 'ath', 'ra']):
                        ifname_match = search(r'^\d+:\s+(\w+):', line)
                        if ifname_match:
                            ifname = ifname_match.group(1)
                            if ifname and ifname not in wifi_interfaces:
                                
                                try:
                                    iw_process = subprocess.Popen(['iw', 'dev', ifname, 'info'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
                                    iw_stdout, iw_stderr = iw_process.communicate()
                                    if iw_process.returncode == 0:
                                        wifi_interfaces.append(ifname)
                                except:
                                    pass
        except Exception as e:
            print("[get_wifi_interfaces] Error with ip link: " + str(e))

        
        common_names = ['wlan0', 'wlan1', 'wlan2', 'wlp2s0', 'wlp3s0', 'wifi0', 'ath0', 'ra0']
        for ifname in common_names:
            try:
                process = subprocess.Popen(['ip', 'link', 'show', ifname], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
                stdout, stderr = process.communicate()
                if process.returncode == 0:
                    
                    iw_process = subprocess.Popen(['iw', 'dev', ifname, 'info'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
                    iw_stdout, iw_stderr = iw_process.communicate()
                    if iw_process.returncode == 0 and ifname not in wifi_interfaces:
                        wifi_interfaces.append(ifname)
            except:
                pass

        
        try:
            import os
            if os.path.exists('/sys/class/net'):
                for ifname in os.listdir('/sys/class/net'):
                    wireless_path = '/sys/class/net/' + ifname + '/wireless'
                    if os.path.exists(wireless_path) and ifname not in wifi_interfaces:
                        wifi_interfaces.append(ifname)
        except Exception as e:
            print("[get_wifi_interfaces] Error checking sysfs: " + str(e))

    except Exception as e:
        print("[get_wifi_interfaces] General error: " + str(e))

    return wifi_interfaces


def get_current_connected_essid(interface):
    
    try:
        process = subprocess.Popen("iwconfig " + interface, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        if process.returncode == 0:
            essid_match = search(r'ESSID:"([^"]*)"', stdout)
            if essid_match and essid_match.group(1):
                return essid_match.group(1)
    except:
        pass
    return None


def get_ip_address(interface):
    
    try:
        process = subprocess.Popen("ip addr show " + interface, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        ip_match = search(r'inet (\d+\.\d+\.\d+\.\d+)', stdout)
        return ip_match.group(1) if ip_match else None
    except:
        return None


def get_interface_info(ifname):
    
    try:
        info = {'name': ifname}

        
        process = subprocess.Popen(['iwconfig', ifname], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        if process.returncode != 0:
            info['error'] = _("Interface {} not available").format(ifname)
            return info

        output = stdout
        print("[DEBUG] iwconfig output for " + ifname + ":\n" + output)

        
        essid_match = search(r'ESSID:"([^"]*)"', output)
        info['essid'] = essid_match.group(1) if essid_match else _("Not connected")

        
        ap_match = search(r'Access Point: ([0-9A-Fa-f:]{17})', output)
        info['ap_addr'] = ap_match.group(1) if ap_match else _("Unknown")

        
        mode_match = search(r'Mode:(\w+)', output)
        info['mode'] = mode_match.group(1) if mode_match else _("Unknown")

        
        freq_match = search(r'Frequency:([0-9.]+) GHz', output)
        channel_match = search(r'Channel[=:](\d+)', output)

        if freq_match:
            info['frequency'] = _("{} GHz").format(freq_match.group(1))
        elif channel_match:
            info['frequency'] = _("Channel {}").format(channel_match.group(1))
        else:
            info['frequency'] = _("Unknown")

        
        rate_match = search(r'Bit Rate[=:]([0-9.]+) Mb/s', output)
        info['bitrate'] = _("{} Mb/s").format(rate_match.group(1)) if rate_match else _("Unknown")

        
        quality_match = search(r'Link Quality=(\d+)/(\d+)', output)
        signal_match = search(r'Signal level=(-?\d+) dBm', output)

        
        if not signal_match:
            signal_match = search(r'Signal[=\s:]*(-?\d+)', output)

        
        if not signal_match:
            try:
                iw_process = subprocess.Popen(['iw', 'dev', ifname, 'link'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
                iw_stdout, iw_stderr = iw_process.communicate()
                if iw_process.returncode == 0:
                    iw_signal_match = search(r'signal: (-?\d+)', iw_stdout)
                    if iw_signal_match:
                        info['signal_dbm'] = int(iw_signal_match.group(1))
            except:
                pass

        if quality_match:
            quality = int(quality_match.group(1))
            max_quality = int(quality_match.group(2))
            if max_quality > 0:
                percentage = (quality / max_quality) * 100
                info['quality'] = _("{:.1f}%").format(percentage)
            else:
                info['quality'] = _("0%")
        elif signal_match:
            signal_dbm = int(signal_match.group(1))
            info['quality'] = _("{} dBm").format(signal_dbm)
            info['signal_dbm'] = signal_dbm
        else:
            info['quality'] = _("Unknown")

        
        if 'signal_dbm' in info:
            info['signal'] = info['signal_dbm']

        
        power_match = search(r'Tx-Power[=:](-?\d+) dBm', output)
        info['txpower'] = _("{} dBm").format(power_match.group(1)) if power_match else _("Unknown")

        
        try:
            ethtool_process = subprocess.Popen(['ethtool', '-i', ifname], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            ethtool_stdout, ethtool_stderr = ethtool_process.communicate()

            if ethtool_process.returncode == 0:
                ethtool_output = ethtool_stdout
                print("[DEBUG] ethtool output for " + ifname + ":\n" + ethtool_output)

                driver_match = search(r'driver:\s*(\S+)', ethtool_output)
                if driver_match:
                    info['protocol'] = driver_match.group(1)
                    print("[DEBUG] Found driver: " + info['protocol'])
                else:
                    info['protocol'] = _("Unknown")
                    print("[DEBUG] Driver not found in ethtool output")

              
                if info['protocol'] == _("Unknown"):
                    version_match = search(r'version:\s*(\S+)', ethtool_output)
                    if version_match:
                        info['protocol'] = version_match.group(1)

            else:
                info['protocol'] = _("Unknown")
                print("[DEBUG] ethtool failed with returncode: " + str(ethtool_process.returncode))

        except Exception as e:
            info['protocol'] = _("Error")
            print("[DEBUG] ethtool exception: " + str(e))

        print("[DEBUG] Final interface info: " + str(info))
        return info

    except Exception as e:
        print("[DEBUG] Error in get_interface_info: " + str(e))
        return {'name': ifname, 'error': str(e)}


def parse_wpa_supplicant(wpa_file, interface):
    
    networks = {}
    try:
        with open(wpa_file, 'r') as f:
            content = f.read()

        network_blocks = findall(r'network=\{([^}]+)\}', content, DOTALL)

        for block in network_blocks:
            ssid_match = search(r'ssid="([^"]+)"', block)
            psk_match = search(r'psk="([^"]+)"', block)

            if ssid_match and psk_match:
                essid = ssid_match.group(1)
                password = psk_match.group(1)
                networks[essid] = {
                    'password': password,
                    'encryption': 'WPA/WPA2',
                    'timestamp': time.time(),
                    'interface': interface
                }
    except Exception as e:
        print("Error parsing wpa_supplicant: " + str(e))

    return networks


def parse_iw_scan(scan_output):
    
    networks = []
    current_bss = {}

    for line in scan_output.split('\n'):
        line = line.strip()

        if line.startswith('BSS'):
            if current_bss:
                networks.append(current_bss)
            current_bss = {}
            bss_match = search(r'BSS ([0-9a-f:]{17})', line)
            if bss_match:
                current_bss['bssid'] = bss_match.group(1).lower()

        elif 'SSID:' in line:
            ssid_match = search(r'SSID: (.+)', line)
            if ssid_match:
                current_bss['essid'] = ssid_match.group(1).strip()

        elif 'signal:' in line:
            signal_match = search(r'signal: (-?\d+\.\d+) dBm', line)
            if signal_match:
                current_bss['signal'] = float(signal_match.group(1))

        elif 'freq:' in line:
            freq_match = search(r'freq: (\d+)', line)
            if freq_match:
                current_bss['frequency'] = int(freq_match.group(1))

    if current_bss:
        networks.append(current_bss)

    return networks


def parse_iwlist_scan(scan_output):
    
    networks = []
    current_network = {}

    for line in scan_output.split('\n'):
        line = line.strip()

        
        if 'Cell' in line and 'Address' in line:
            if current_network:
                networks.append(current_network)
            current_network = {}
            mac_match = search(r'Address: ([0-9A-Fa-f:]{17})', line)
            if mac_match:
                current_network['bssid'] = mac_match.group(1)

        
        elif 'ESSID:' in line:
            essid_match = search(r'ESSID:"([^"]*)"', line)
            if essid_match:
                current_network['essid'] = essid_match.group(1)

        
        elif 'Quality=' in line:
            quality_match = search(r'Quality=(\d+)/(\d+)', line)
            signal_match = search(r'Signal level=(-?\d+) dBm', line)

            if quality_match:
                quality = int(quality_match.group(1))
                max_quality = int(quality_match.group(2))
                if max_quality > 0:
                    percentage = (quality / max_quality) * 100
                    current_network['quality'] = percentage
                else:
                    current_network['quality'] = 0
            if signal_match:
                current_network['signal'] = int(signal_match.group(1))

        
        elif 'Channel:' in line or 'Frequency:' in line:
            channel_match = search(r'Channel:(\d+)', line)
            freq_match = search(r'Frequency:([0-9.]+) GHz', line)

            if channel_match:
                current_network['channel'] = int(channel_match.group(1))
            if freq_match:
                current_network['frequency'] = float(freq_match.group(1))

        
        elif 'Encryption key:' in line:
            encrypt_match = search(r'Encryption key:(\w+)', line)
            if encrypt_match:
                current_network['encryption'] = encrypt_match.group(1) == 'on'

        
        elif 'Mode:' in line:
            mode_match = search(r'Mode:(\w+)', line)
            if mode_match:
                current_network['mode'] = mode_match.group(1)

    
    if current_network:
        networks.append(current_network)

    return networks


def parse_iwlist_detailed(scan_output):
    
    networks = []
    current_net = {}

    for line in scan_output.split('\n'):
        line = line.strip()

        
        if 'Cell' in line and 'Address' in line:
            if current_net and current_net.get('essid'):
                networks.append(current_net)
            current_net = {'encryption': False}

            
            mac_match = search(r'Address: ([0-9A-Fa-f:]{17})', line)
            if mac_match:
                current_net['bssid'] = mac_match.group(1)

        
        elif 'ESSID:' in line:
            essid_match = search(r'ESSID:\s*"([^"]*)"', line)
            if essid_match:
                current_net['essid'] = essid_match.group(1).strip()

        
        elif 'Encryption key:' in line:
            current_net['encryption'] = 'on' in line.lower()

        
        elif 'Signal level=' in line:
            
            signal_match = search(r'Signal level=(-?\d+)\s*dBm?', line)
            if signal_match:
                current_net['signal'] = int(signal_match.group(1))
            else:
                
                signal_match2 = search(r'Signal[=\s:]*(-?\d+)', line)
                if signal_match2:
                    current_net['signal'] = int(signal_match2.group(1))

        
        elif 'Quality=' in line:
            quality_match = search(r'Quality=(\d+)/(\d+)', line)
            if quality_match:
                quality = int(quality_match.group(1))
                max_quality = int(quality_match.group(2))
                
                if max_quality > 0:
                    percentage = (quality / max_quality) * 100
                    current_net['quality_percent'] = percentage
                else:
                    current_net['quality_percent'] = 0

        
        elif 'Channel:' in line:
            channel_match = search(r'Channel:(\d+)', line)
            if channel_match:
                current_net['channel'] = int(channel_match.group(1))

        
        elif 'Mode:' in line:
            mode_match = search(r'Mode:(\w+)', line)
            if mode_match:
                current_net['mode'] = mode_match.group(1)

    
    if current_net and current_net.get('essid'):
        networks.append(current_net)

    return networks


def scan_networks_simple(ifname):
    
    try:
        process = subprocess.Popen(['iw', 'dev', ifname, 'scan'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()

        if process.returncode != 0:
            raise Exception("iw scan failed: " + stderr.strip())

        return parse_iw_scan(stdout)

    except Exception as e:
        raise Exception("Scan failed on " + ifname + ": " + str(e))


def scan_networks(ifname, detailed=False):
    
    try:
        cmd = "iwlist " + ifname + " scan"
        process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()

        if process.returncode != 0:
            raise Exception("Scan failed: " + stderr.strip())

        networks = parse_iwlist_scan(stdout)
        return networks

    except Exception as e:
        raise Exception("Scan failed on " + ifname + ": " + str(e))


def format_signal_quality(quality_data):
    
    if not quality_data:
        return _("No data")

    
    if isinstance(quality_data, (int, float)):
        quality = quality_data
    elif isinstance(quality_data, dict) and hasattr(quality_data, 'quality'):
        quality = quality_data.quality
    else:
        return _("Unknown")

    levels = [
        (90, _("Excellent")),
        (70, _("Good")),
        (50, _("Fair")),
        (30, _("Poor")),
        (0, _("Very Poor"))
    ]

    for threshold, description in levels:
        if quality >= threshold:
            return _("{} ({:.0f}%)").format(description, quality)

    return _("{} ({:.0f}%)").format(_('Very Poor'), quality)


def load_saved_networks(config_file=None, interface=None):
    
    try:
        
        if config_file is None:
            config_file = "/etc/wifi_saved_networks.json"

        if exists(config_file):
            with open(config_file, 'r') as f:
                networks = load(f)
                if networks:
                    return networks

        
        if interface:
            wpa_file = "/etc/wpa_supplicant." + interface + ".conf"
            if exists(wpa_file):
                networks = parse_wpa_supplicant(wpa_file, interface)
                if networks:
                    with open(config_file, 'w') as f:
                        dump(networks, f, indent=2)
                    return networks
    except Exception as e:
        print("Error loading saved networks: " + str(e))
    return {}


def test_ping(host="8.8.8.8", count=3, timeout=5, debug=False):
    
    try:
        ping_commands = [
            ["ping", "-c", str(count), "-W", str(timeout), host],
            ["ping6", "-c", str(count), "-W", str(timeout), host],
            ["ping", "-c", str(count), host],  # Senza timeout
            ["busybox", "ping", "-c", str(count), host],
            ["ping", "-4", "-c", str(count), host]  # Forza IPv4
        ]

        ping_result = None
        last_error = None
        used_command = None

        for cmd in ping_commands:
            try:
                if debug:
                    print("[PING] Trying command: " + ' '.join(cmd))

                process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
                stdout, stderr = process.communicate()

                if process.returncode == 0:
                    ping_result = type('obj', (object,), {'returncode': process.returncode, 'stdout': stdout, 'stderr': stderr})
                    used_command = ' '.join(cmd)  
                    break
                else:
                    last_error = stderr
                    if debug:
                        print("[PING] Command failed (code " + str(process.returncode) + "): " + last_error)

            except Exception as e:
                last_error = str(e)
                if debug:
                    print("[PING] Command error: " + str(e))
                continue

        if ping_result is None or ping_result.returncode != 0:
            error_msg = _("Ping not available")
            if last_error and "Name or service not known" in last_error:
                error_msg = _("Host not found")
            elif last_error and "Network is unreachable" in last_error:
                error_msg = _("Network unreachable")
            return error_msg

        if debug:
            print("[PING] Success with: " + used_command)
            print("[PING] Output:\n" + ping_result.stdout)
            if ping_result.stderr:
                print("[PING] Error:\n" + ping_result.stderr)

        
        output = ping_result.stdout

        
        time_lines = []
        for line in output.split('\n'):
            if 'time=' in line or 'ms' in line:
                time_lines.append(line)
                if debug:
                    print("[PING] Time line: " + line)

        
        times = []
        time_patterns = [
            r'time=([\d.]+)\s*ms',      
            r'time=([\d.]+)ms',         
            r'([\d.]+)\s*ms',           
            r'icmp_seq=\d+.+?([\d.]+)\s*ms'  
        ]

        for line in time_lines:
            for pattern in time_patterns:
                time_matches = findall(pattern, line)
                for match in time_matches:
                    try:
                        times.append(float(match))
                        if debug:
                            print("[PING] Found time: " + match + " ms")
                        break  
                    except ValueError:
                        continue

        if debug:
            print("[PING] Found individual times: " + str(times))

        if times:
          
            avg_time = sum(times) / len(times)
            if debug:
                print("[PING] Calculated average: " + str(avg_time) + " ms")
            return _("{:.1f} ms").format(avg_time)

        
        stats_lines = [line for line in output.split('\n')
                       if 'min/avg/max' in line.lower() or 'rtt' in line.lower()]

        if stats_lines:
            stats_line = stats_lines[-1]
            if debug:
                print("[PING] Stats line: " + stats_line)

            
            stats_patterns = [
                r'([\d.]+)/([\d.]+)/([\d.]+)',  # min/avg/max
                r'=\s*([\d.]+)/([\d.]+)/([\d.]+)',  
                r'avg\s*[=:]\s*([\d.]+)',  
            ]

            for pattern in stats_patterns:
                match = search(pattern, stats_line)
                if match:
                    try:
                        
                        if len(match.groups()) >= 3:
                            avg_ping = float(match.group(2))
                        else:
                            avg_ping = float(match.group(1))
                        if debug:
                            print("[PING] Found average from stats: " + str(avg_ping) + " ms")
                        return _("{:.1f} ms").format(avg_ping)
                    except (ValueError, IndexError):
                        continue

        
        if "bytes from" in output or "icmp_seq" in output:
            return _("Connected but no timing data")

        return _("No ping data")

    except Exception as e:
        if debug:
            print("[PING] Exception: " + str(e))
        return _("Error: {}").format(str(e))