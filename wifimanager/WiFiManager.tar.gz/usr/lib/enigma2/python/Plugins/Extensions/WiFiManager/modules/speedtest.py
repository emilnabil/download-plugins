import time
import subprocess
from re import search

try:
    from json import loads
except ImportError:
    pass

try:
    from six.moves.urllib.request import urlopen
except ImportError:
    pass

from .. import _


def test_download_speed(interface=None, timeout=10):
    
    try:
        test_servers = [
            "http://ipv4.download.thinkbroadband.com/5MB.zip",
            "http://speedtest.tele2.net/5MB.zip",
            "http://proof.ovh.net/files/10Mb.dat",
        ]

        
        try:
            process = subprocess.Popen(['ping', '-c', '1', '-W', '2', '8.8.8.8'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout, stderr = process.communicate()
            if process.returncode != 0:
                return _("No internet connection")
        except Exception:
            return _("Connection timeout")

        for test_url in test_servers:
            try:
                print("Testing download from: " + test_url)
                start_time = time.time()

              
                process = subprocess.Popen(['wget', '-O', '/dev/null', '--timeout=8', '--tries=1', test_url], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
                stdout, stderr = process.communicate()

                end_time = time.time()

                if process.returncode == 0:
                    duration = end_time - start_time
                    
                    if "10Mb" in test_url:
                        file_size_mb = 10 / 8
                    elif "5MB" in test_url:
                        file_size_mb = 5
                    else:
                        file_size_mb = 1

                    speed_mbps = (file_size_mb * 8) / duration
                    return str(speed_mbps)[:5] + " Mbps"

            except Exception as e:
                print("Error with server " + test_url + ": " + str(e))
                continue

        return "All download servers failed"

    except Exception as e:
        return _("Error: {error}").format(error=str(e))


def test_upload_speed(interface=None, timeout=10):
    
    try:
        test_file = "/tmp/upload_test.bin"
        test_data = '0' * 1024 * 100  

        with open(test_file, 'w') as f:
            f.write(test_data)

        start_time = time.time()
        process = subprocess.Popen(['curl', '-X', 'POST', '--data-binary', '@' + test_file, 'http://httpbin.org/post', '--max-time', '10'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        end_time = time.time()

        
        subprocess.Popen(['rm', '-f', test_file], stdout=subprocess.PIPE, stderr=subprocess.PIPE).communicate()

        if process.returncode == 0:
            duration = end_time - start_time
            file_size_mb = 0.1  
            speed_mbps = (file_size_mb * 8) / duration
            return _("{speed:.2f} Mbps").format(speed=speed_mbps)
        else:
            return _("Upload test not available")

    except Exception as e:
        return _("Upload test failed: {error}").format(error=str(e))


def test_ping(host="8.8.8.8", count=3):
    
    try:
        process = subprocess.Popen(["ping", "-c", str(count), "-W", "3", host], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()

        if process.returncode == 0:
            for line in stdout.split('\n'):
                if 'min/avg/max' in line or 'rtt min/avg/max' in line:
                    stats_match = search(r'([0-9.]+)/([0-9.]+)/([0-9.]+)', line)
                    if stats_match:
                        ping_time = float(stats_match.group(2))
                        return "{:.1f} ms".format(ping_time)

            
            stats_match = search(r'([0-9.]+)/([0-9.]+)/([0-9.]+)', stdout)
            if stats_match:
                ping_time = float(stats_match.group(2))
                return "{:.1f} ms".format(ping_time)

        return _("Ping failed")

    except Exception as e:
        return _("Error: {}").format(str(e))


def extended_ping_test():
    
    hosts = [
        (_("Google DNS"), "8.8.8.8"),
        (_("Cloudflare"), "1.1.1.1"),
        (_("OpenDNS"), "208.67.222.222")
    ]

    results = []
    for name, host in hosts:
        ping_result = test_ping(host, 2)
        results.append(_("{name} ({host}): {ping}").format(name=name, host=host, ping=ping_result))

    return "\n".join(results)


def get_public_ip_info():
    
    try:
        response = urlopen('http://ipinfo.io/json', timeout=10)
        data = loads(response.read().decode())
        return data
    except:
        return None


def get_network_interfaces():
    
    try:
        process = subprocess.Popen(['ip', 'addr', 'show'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        stdout, stderr = process.communicate()
        interfaces = []
        current_interface = None

        for line in stdout.split('\n'):
            if line and not line.startswith(' '):
                current_interface = line.split()[1].rstrip(':')
                interfaces.append(current_interface)

        return interfaces
    except:
        return []


def multi_server_download_test(interface=None):
    
    servers = [
        ("Otenet Greece", "http://speedtest.ftp.otenet.gr/files/test1Mb.db"),
        ("Linode Frankfurt", "http://speedtest.frankfurt.linode.com/100MB-frankfurt.bin"),
    ]

    results = []
    for name, url in servers:
        try:
            start_time = time.time()
            process = subprocess.Popen(['wget', '-O', '/dev/null', url], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout, stderr = process.communicate()
            end_time = time.time()

            if process.returncode == 0:
                duration = end_time - start_time
                
                if "100MB" in url:
                    size_mb = 100
                else:
                    size_mb = 1
                speed = (size_mb * 8) / duration
                results.append(_("{name}: {speed:.2f} Mbps").format(name=name, speed=speed))
            else:
                results.append(_("{name}: Failed").format(name=name))

        except Exception as e:
            results.append(_("{name}: Error {error}").format(name=name, error=e))

    return "\n".join(results)


def multi_server_upload_test(interface=None):
    
    upload_result = test_upload_speed(interface)
    return _("Upload test: {result}").format(result=upload_result)


def connection_stability_test(interface=None, duration=5):
    
    try:
        start_time = time.time()
        packets_sent = 0
        packets_lost = 0
        max_packets = 5

        while time.time() - start_time < duration and packets_sent < max_packets:
            try:
                process = subprocess.Popen(['ping', '-c', '1', '-W', '2', '8.8.8.8'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
                stdout, stderr = process.communicate()
                packets_sent += 1
                if process.returncode != 0:
                    packets_lost += 1
                time.sleep(1)
            except Exception:
                packets_lost += 1
                packets_sent += 1
                continue

        if packets_sent > 0:
            loss_percentage = (packets_lost / packets_sent) * 100
            stability = _("Stable") if loss_percentage < 10 else _("Unstable")
            return _("Packets: {sent}, Lost: {lost} ({percentage:.1f}%) - {stability}").format(
                sent=packets_sent, lost=packets_lost, percentage=loss_percentage, stability=stability)
        else:
            return _("No packets sent")

    except Exception as e:
        return _("Stability test error: {error}").format(error=str(e))


def format_speed_result(speed_value):
    
    if isinstance(speed_value, (int, float)):
        if speed_value >= 1000:
            return str(speed_value / 1000)[:5] + " Gbps"
        else:
            return str(speed_value)[:5] + " Mbps"
    return speed_value


def test_connectivity():
    
    return test_ping()


def quick_speed_test(interface=None):
    
    download = test_download_speed(interface, timeout=15)
    upload = test_upload_speed(interface, timeout=15)
    ping = test_ping()

    return {
        'download': download,
        'upload': upload,
        'ping': ping
    }