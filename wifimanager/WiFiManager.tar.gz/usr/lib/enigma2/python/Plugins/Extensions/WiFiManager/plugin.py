from Plugins.Plugin import PluginDescriptor


def main(session, **kwargs):
    from .WiFiManager import WiFiManagerMain
    return session.open(WiFiManagerMain)


def Plugins(**kwargs):
    return PluginDescriptor(
        name="WiFi Manager",
        description="Advanced WiFi diagnostic tools",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="plugin.png",
        fnc=main,
        needsRestart=True,
    )


    
