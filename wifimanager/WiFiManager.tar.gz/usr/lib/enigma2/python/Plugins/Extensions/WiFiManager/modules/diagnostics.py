# -*- coding: utf-8 -*-
from __future__ import print_function
import subprocess
import sys
from re import search, IGNORECASE, findall

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.ScrollLabel import ScrollLabel
from os.path import basename, realpath
from .tools import get_wifi_interfaces
from . import _


def run_command(cmd, shell=False, timeout=None):
    try:
        if hasattr(subprocess, 'run'):
            result = subprocess.run(cmd, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, timeout=timeout)
            return result.returncode, result.stdout, result.stderr
        else:
            process = subprocess.Popen(cmd, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout, stderr = process.communicate(timeout=timeout)
            return process.returncode, stdout, stderr
    except Exception as e:
        return -1, "", str(e)


class WiFiDiagnostics(Screen):
    skin = """
    <screen position="center,center" size="800,700" title="WiFi Diagnostics">
        <widget name="diagnostics_output" position="10,10" size="773,579" font="Regular;18" />
        <widget name="key_red" position="10,635" size="180,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="red" transparent="1" />
        <widget name="key_green" position="210,635" size="180,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="green" transparent="1" />
        <widget name="key_yellow" position="410,635" size="180,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="yellow" transparent="1" />
        <widget name="key_blue" position="600,635" size="180,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="blue" transparent="1" />
        <eLabel name="" position="9,677" size="180,8" zPosition="3" backgroundColor="#fe0000" />
        <eLabel name="" position="209,677" size="180,8" zPosition="3" backgroundColor="#fe00" />
        <eLabel name="" position="409,677" size="180,8" zPosition="3" backgroundColor="#cccc40" />
        <eLabel name="" position="599,677" size="180,8" zPosition="3" backgroundColor="#1a27408b" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["diagnostics_output"] = ScrollLabel()
        self["key_red"] = Button(_("Full Test"))
        self["key_green"] = Button(_("Quick Test"))
        self["key_yellow"] = Button(_("Clear"))
        self["key_blue"] = Button(_("Exit"))
        self["actions"] = ActionMap(
            ["ColorActions", "OkCancelActions", "DirectionActions"],
            {
                "red": lambda: self.run_diagnostics(full_test=True),
                "green": lambda: self.run_diagnostics(full_test=False),
                "yellow": self.clear_output,
                "blue": self.close,
                "cancel": self.close,
                "pageUp": self.pageUp,
                "pageDown": self.pageDown,
                "up": self.pageUp,
                "down": self.pageDown,
                "left": self.pageUp,
                "right": self.pageDown,
            }
        )
        self.setTitle(_("WiFi Diagnostics"))
        self.interfaces = get_wifi_interfaces()
        self.run_diagnostics(full_test=False)

    def pageUp(self):
        self["diagnostics_output"].pageUp()

    def pageDown(self):
        self["diagnostics_output"].pageDown()

    def run_diagnostics(self, full_test=True):
        diagnostics = [_("=== WiFi Diagnostics (System Commands Only) ===\n")]
        diagnostics.append(_("Test Type: {test_type}\n\n").format(
            test_type=_('Full Comprehensive Test') if full_test else _('Quick System Check')))

        try:
            diagnostics.append(_("SYSTEM LEVEL DIAGNOSTICS\n"))
            diagnostics.append("=" * 50 + "\n")

            kernel_modules = self.check_kernel_modules()
            diagnostics.extend(kernel_modules)

            usb_wifi = self.check_usb_wifi_devices()
            diagnostics.extend(usb_wifi)

            commands_check = self.check_system_commands()
            diagnostics.extend(commands_check)

            diagnostics.append("\nNETWORK INTERFACE DIAGNOSTICS\n")
            diagnostics.append("=" * 50 + "\n")

            wifi_interfaces = get_wifi_interfaces()
            all_interfaces = self.get_all_interfaces()

            diagnostics.append(_("All Network Interfaces: {interfaces}\n").format(
                interfaces=', '.join(all_interfaces) if all_interfaces else _('None found')))
            diagnostics.append(_("Wireless Interfaces: {interfaces}\n\n").format(
                interfaces=', '.join(wifi_interfaces) if wifi_interfaces else _('None found')))

            if not wifi_interfaces:
                diagnostics.append(_("CRITICAL: No WiFi interfaces detected!\n"))
                solutions = self.suggest_solutions(no_interfaces=True)
                diagnostics.extend(solutions)
                self.display_results(diagnostics)
                return

            for ifname in wifi_interfaces:
                diagnostics.append(_("\nDETAILED ANALYSIS: {interface}\n").format(interface=ifname))
                diagnostics.append("-" * 40 + "\n")

                iface_status = self.check_interface_status(ifname)
                diagnostics.extend(iface_status)

                driver_info = self.check_driver_info(ifname)
                diagnostics.extend(driver_info)

                basic_tests = self.run_basic_wireless_tests(ifname)
                diagnostics.extend(basic_tests)

                if full_test:
                    advanced_tests = self.run_advanced_tests(ifname)
                    diagnostics.extend(advanced_tests)

                perf_tests = self.run_performance_tests(ifname)
                diagnostics.extend(perf_tests)

            diagnostics.append(_("\nSUMMARY & RECOMMENDATIONS\n"))
            diagnostics.append("=" * 50 + "\n")
            summary = self.generate_summary(wifi_interfaces)
            diagnostics.extend(summary)

        except Exception as e:
            error_msg = _("\nDIAGNOSTIC ERROR: {error}\n").format(error=str(e))
            diagnostics.append(error_msg)

        self.display_results(diagnostics)

    def get_all_interfaces(self):
        interfaces = []
        try:
            returncode, stdout, stderr = run_command(['ip', 'link', 'show'])
            for line in stdout.split('\n'):
                if ': ' in line and 'LOOPBACK' not in line:
                    parts = line.split(': ')
                    if len(parts) > 1:
                        ifname = parts[1].strip()
                        if ifname and ifname not in interfaces:
                            interfaces.append(ifname)
        except:
            pass
        return interfaces

    def check_kernel_modules(self):
        results = []
        try:
            returncode, stdout, stderr = run_command(["lsmod"])
            wifi_modules = []
            for module in ["rtl", "ath", "brcm", "wl", "iwl", "mt", "rt", "zd"]:
                if module in stdout.lower():
                    matches = findall(r"({}\w*)\s+\d".format(module), stdout)
                    wifi_modules.extend(matches)

            if wifi_modules:
                results.append(_("Loaded WiFi modules: {modules}\n").format(modules=', '.join(set(wifi_modules))))
            else:
                results.append(_("No WiFi kernel modules detected\n"))
        except Exception as e:
            results.append(_("Kernel module check failed: {error}\n").format(error=e))
        return results

    def check_usb_wifi_devices(self):
        results = []
        try:
            returncode, stdout, stderr = run_command(["lsusb"])
            wifi_adapters = []
            for vendor in ["Realtek", "Ralink", "Atheros", "Broadcom", "Intel", "MediaTek"]:
                if vendor.lower() in stdout.lower():
                    matches = findall(r".*{}.*".format(vendor), stdout, IGNORECASE)
                    wifi_adapters.extend(matches)

            if wifi_adapters:
                results.append(_("USB WiFi adapters detected:\n"))
                for adapter in set(wifi_adapters):
                    results.append(_("   - {adapter}\n").format(adapter=adapter.strip()))
            else:
                results.append(_("No USB WiFi adapters found\n"))
        except Exception as e:
            results.append(_("USB device check failed: {error}\n").format(error=e))
        return results

    def check_system_commands(self):
        results = []
        essential_cmds = ["iwconfig", "iw", "ip", "ifconfig", "wpa_supplicant"]
        available_cmds = []
        missing_cmds = []
        for cmd in essential_cmds:
            try:
                run_command([cmd, "--help"], timeout=2)
                available_cmds.append(cmd)
            except:
                missing_cmds.append(cmd)

        if available_cmds:
            results.append(_("Available commands: {commands}\n").format(commands=', '.join(available_cmds)))
        if missing_cmds:
            results.append(_("Missing commands: {commands}\n").format(commands=', '.join(missing_cmds)))

        return results

    def check_interface_status(self, ifname):
        results = []
        try:
            returncode, stdout, stderr = run_command(["ip", "link", "show", ifname])
            if "state UP" in stdout:
                results.append(_("Interface {interface}: UP and active\n").format(interface=ifname))
            elif "state DOWN" in stdout:
                results.append(_("Interface {interface}: DOWN (needs activation)\n").format(interface=ifname))
            else:
                results.append(_("Interface {interface}: UNKNOWN STATE\n").format(interface=ifname))

            mac_match = search(r"link/ether (([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2}))", stdout)
            if mac_match:
                results.append(_("   MAC Address: {mac}\n").format(mac=mac_match.group(1)))

        except Exception as e:
            results.append(_("Interface {interface}: NOT FOUND\n").format(interface=ifname))
        return results

    def check_driver_info(self, ifname):
        results = []
        try:
            driver_path = "/sys/class/net/" + ifname + "/device/driver"
            if sys.version_info[0] < 3:
                import os
                if os.path.isdir(driver_path):
                    driver_link = realpath(driver_path)
                    driver_name = basename(driver_link)
                    results.append(_("   Driver: {driver}\n").format(driver=driver_name))
                else:
                    results.append(_("   Driver: Unknown\n"))
            else:
                returncode, stdout, stderr = run_command(["test", "-d", driver_path])
                if returncode == 0:
                    driver_link = realpath(driver_path)
                    driver_name = basename(driver_link)
                    results.append(_("   Driver: {driver}\n").format(driver=driver_name))
                else:
                    results.append(_("   Driver: Unknown\n"))
        except Exception as e:
            results.append(_("   Driver check failed: {error}\n").format(error=str(e)))
        return results

    def run_basic_wireless_tests(self, ifname):
        results = []

        try:
            returncode, stdout, stderr = run_command(["iwconfig", ifname], timeout=5)

            essid_match = search(r'ESSID:"([^"]*)"', stdout)
            if essid_match:
                results.append(_("ESSID: {essid}\n").format(essid=essid_match.group(1)))
            else:
                results.append(_("ESSID: Not connected\n"))
        except Exception as e:
            error_msg = _("ESSID check: {error}\n").format(error=e)
            results.append(error_msg)

        try:
            returncode, stdout, stderr = run_command(["iwconfig", ifname], timeout=5)
            quality_match = search(r'Link Quality=(\d+)/(\d+)', stdout)
            signal_match = search(r'Signal level=(-?\d+)', stdout)

            if quality_match:
                current = int(quality_match.group(1))
                max_val = int(quality_match.group(2))
                quality_percent = int((current / max_val) * 100)
                signal_dbm = signal_match.group(1) if signal_match else _("N/A")
                results.append(_("Signal: {quality}% quality, {signal} dBm\n").format(
                    quality=quality_percent, signal=signal_dbm))
            else:
                results.append(_("Signal: No quality data available\n"))
        except Exception as e:
            results.append(_("Signal check: {error}\n").format(error=e))

        try:
            returncode, stdout, stderr = run_command(["iwconfig", ifname], timeout=5)
            mode_match = search(r'Mode:(\w+)', stdout)
            if mode_match:
                results.append(_("Mode: {mode}\n").format(mode=mode_match.group(1)))
            else:
                results.append(_("Mode: Unknown\n"))
        except Exception as e:
            results.append(_("Mode check: {error}\n").format(error=e))

        return results

    def run_advanced_tests(self, ifname):
        results = []
        results.append(_("\n   ADVANCED TESTS:\n"))

        advanced_tests = [
            (_("Frequency/Channel"), "iwconfig " + ifname + " | grep Frequency"),
            (_("Bitrate"), "iwconfig " + ifname + " | grep BitRate"),
            (_("Encryption"), "iwconfig " + ifname + " | grep Encryption"),
            (_("Access Point"), "iwconfig " + ifname + " | grep 'Access Point'"),
        ]

        for test_name, cmd in advanced_tests:
            try:
                returncode, stdout, stderr = run_command(cmd, shell=True, timeout=5)
                if stdout.strip():
                    results.append(_("   {test}: {output}\n").format(test=test_name, output=stdout.strip()))
                else:
                    results.append(_("   {test}: No data\n").format(test=test_name))
            except Exception as e:
                results.append(_("   {test}: Failed\nError: {error}").format(test=test_name, error=e))

        return results

    def run_performance_tests(self, ifname):
        results = []
        results.append(_("\n   PERFORMANCE TESTS:\n"))

        try:
            returncode, stdout, stderr = run_command(["iwlist", ifname, "scan"], timeout=10)
            cell_count = stdout.count("Cell ")
            results.append(_("   Scan: Found {count} networks\n").format(count=cell_count))
        except Exception as e:
            if "Device or resource busy" in stderr:
                results.append(_("   Scan: Interface busy (connected to network)\n"))
            else:
                results.append(_("   Scan test: {error}\n").format(error=stderr.strip()))

        try:
            from Components.Network import iNetwork
            ip = iNetwork.getAdapterAttribute(ifname, "ip")
            if ip and ip != [0, 0, 0, 0]:
                results.append(_("   Connectivity: IP {ip} - ONLINE\n").format(ip='.'.join(map(str, ip))))
            else:
                results.append(_("   Connectivity: No IP address - OFFLINE\n"))
        except:
            results.append(_("   Connectivity: Unknown status\n"))

        return results

    def suggest_solutions(self, no_interfaces=False):
        suggestions = []
        suggestions.append(_("\nPOSSIBLE SOLUTIONS:\n"))

        if no_interfaces:
            suggestions.append(_("1. Check if WiFi adapter is properly connected\n"))
            suggestions.append(_("2. Verify WiFi adapter is supported by your receiver\n"))
            suggestions.append(_("3. Try different USB port for USB WiFi adapters\n"))
            suggestions.append(_("4. Check if WiFi drivers are installed\n"))
            suggestions.append(_("5. Restart the receiver and try again\n"))

        else:
            suggestions.append(_("All systems operational\n"))
            suggestions.append(_("Tips:\n"))
            suggestions.append(_("   - Monitor signal strength for best performance\n"))
            suggestions.append(_("   - Keep drivers updated\n"))
            suggestions.append(_("   - Use 5GHz band for less interference\n"))

        return suggestions

    def generate_summary(self, wifi_interfaces):
        summary = []
        if wifi_interfaces:
            summary.append(_("SYSTEM STATUS: WiFi hardware detected and functional\n"))
            summary.append(_("METHOD: Using system commands (no root required)\n"))
            summary.append(_("All basic diagnostics available\n"))
        else:
            summary.append(_("SYSTEM STATUS: No WiFi interfaces detected\n"))
            summary.append(_("Check hardware connection and drivers\n"))
        return summary

    def display_results(self, results):
        if isinstance(results, list):
            self["diagnostics_output"].setText("".join(results))
        else:
            self["diagnostics_output"].setText(results)

    def clear_output(self):
        self["diagnostics_output"].setText("")

    def test_wireless_protocol(self, wireless):
        try:
            protocol = wireless.getWirelessName()
            return True, protocol
        except Exception as e:
            return False, str(e)

    def test_essid(self, wireless):
        try:
            essid = wireless.getEssid()
            return True, essid if essid else "Not connected"
        except Exception as e:
            return False, str(e)

    def test_ap_address(self, wireless):
        try:
            ap_addr = wireless.getAPaddr()
            return True, ap_addr
        except Exception as e:
            return False, str(e)

    def test_operation_mode(self, wireless):
        try:
            mode = wireless.getMode()
            return True, mode
        except Exception as e:
            return False, str(e)

    def test_frequency(self, wireless):
        try:
            freq = wireless.getFrequency()
            return True, freq
        except Exception as e:
            return False, str(e)

    def test_bitrate(self, wireless):
        try:
            bitrate = wireless.getBitrate()
            return True, bitrate
        except Exception as e:
            return False, str(e)

    def test_signal_quality(self, wireless):
        try:
            quality = wireless.getQualityAvg()
            if quality:
                return True, "Quality: {}%, Signal: {} dBm".format(quality.quality, quality.siglevel)
            return False, "No quality data"
        except Exception as e:
            return False, str(e)

    def test_tx_power(self, wireless):
        try:
            txpower = wireless.getTXPower()
            return True, txpower
        except Exception as e:
            return False, str(e)

    def test_scan_capability(self, wireless):
        try:
            scan_results = wireless.scan()
            return True, "Found {} networks".format(len(scan_results))
        except Exception as e:
            return False, str(e)

    def test_iwconfig_compatibility(self, wireless):
        try:
            from .iwconfig import getBitrate, getTXPower, getEncryption
            bitrate_info = getBitrate(wireless)
            txpower_info = getTXPower(wireless)
            encryption_info = getEncryption(wireless)

            result = "iwconfig functions available - "
            if bitrate_info:
                result += "Bitrate OK "
            if txpower_info:
                result += "TXPower OK "
            if encryption_info:
                result += "Encryption OK"

            return True, result.strip()
        except Exception as e:
            return False, "iwconfig error: {}".format(str(e))