from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from enigma import eTimer, getDesktop, eListboxPythonMultiContent, gFont
import time
import datetime
import os
import shutil

FONTS_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/HolidayCountdown/fonts/"
SYSTEM_FONTS_PATH = "/usr/share/fonts/"

def install_fonts():
    if not os.path.exists(SYSTEM_FONTS_PATH):
        os.makedirs(SYSTEM_FONTS_PATH)
    
    font_files = [f for f in os.listdir(FONTS_PATH) if f.endswith(('.ttf', '.otf'))]
    for font_file in font_files:
        src_path = os.path.join(FONTS_PATH, font_file)
        dest_path = os.path.join(SYSTEM_FONTS_PATH, font_file)
        if not os.path.exists(dest_path):
            try:
                shutil.copy(src_path, dest_path)
                print(f"[HolidayCountdown] Installed font: {font_file}")
            except Exception as e:
                print(f"[HolidayCountdown] Failed to install font {font_file}: {str(e)}")
    try:
        os.system("fc-cache -f -v")
        print("[HolidayCountdown] Font cache updated.")
    except:
        print("[HolidayCountdown] Could not update font cache, manual update may be required.")

class MainMenu(Screen):
    skin = """
    <screen name="HolidayCountdown" position="center,center" size="720,720" title="Holiday Countdown" backgroundColor="#1A2526" zPosition="0">
        <widget name="menu" position="center,center" size="700,600" scrollbarMode="showOnDemand" transparent="0" backgroundColor="#1A2526" zPosition="1"/>
    </screen>"""
    
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        install_fonts()
        
        self.menu_list = [
            ("Ramadan Countdown", "icons/ramadan_icon.png", self.showRamadan),
            ("Eid al-Fitr Countdown", "icons/eid_icon.png", self.showEidAlFitr),
            ("Halloween Countdown", "icons/halloween_icon.png", self.showHalloween),
            ("Christmas Countdown", "icons/christmas_icon.png", self.showChristmas),
            ("New Year Countdown", "icons/newyear_icon.png", self.showNewYear),
            ("Autumn Countdown", "icons/autumn_icon.png", self.showAutumn),
            ("Winter Countdown", "icons/winter_icon.png", self.showWinter),
            ("Spring Countdown", "icons/spring_icon.png", self.showSpring),
            ("Summer Countdown", "icons/summer_icon.png", self.showSummer),
            ("Eid al-Adha Countdown", "icons/eid_adha_icon.png", self.showEidAlAdha),
            ("Christ's Birth Countdown", "icons/christ_birth_icon.png", self.showChristBirth),
            ("Easter Countdown", "icons/easter_icon.png", self.showEaster)
        ]
        
        self["menu"] = CustomMenuList(self.menu_list)
        
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"],
        {
            "ok": self.selectItem,
            "cancel": self.close,
            "up": self.up,
            "down": self.down
        }, -1)
        
    def selectItem(self):
        current = self["menu"].getCurrent()
        if current:
            callback = current[2]
            callback()
            
    def up(self):
        self["menu"].up()
        
    def down(self):
        self["menu"].down()
        
    def showChristmas(self):
        self.session.open(ChristmasCountdownScreen)
        
    def showHalloween(self):
        self.session.open(HalloweenCountdownScreen)
        
    def showNewYear(self):
        self.session.open(NewYearCountdownScreen)
        
    def showEidAlFitr(self):
        self.session.open(EidAlFitrCountdownScreen)
        
    def showRamadan(self):
        self.session.open(RamadanCountdownScreen)
        
    def showAutumn(self):
        self.session.open(AutumnCountdownScreen)
        
    def showWinter(self):
        self.session.open(WinterCountdownScreen)
        
    def showSpring(self):
        self.session.open(SpringCountdownScreen)
        
    def showSummer(self):
        self.session.open(SummerCountdownScreen)
        
    def showEidAlAdha(self):
        self.session.open(EidAlAdhaCountdownScreen)
        
    def showChristBirth(self):
        self.session.open(ChristBirthCountdownScreen)
        
    def showEaster(self):
        self.session.open(EasterCountdownScreen)

class CustomMenuList(MenuList):
    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont("Regular", 32))
        self.l.setItemHeight(120)
        self.buildList()
        
    def buildList(self):
        list_items = []
        base_path = "/usr/lib/enigma2/python/Plugins/Extensions/HolidayCountdown/"
        from Tools.LoadPixmap import LoadPixmap
        
        for entry in self.list:
            name, icon, callback = entry
            icon_path = os.path.join(base_path, icon)
            vertical_offset = 40
            
            if not os.path.exists(icon_path):
                item = [
                    entry,
                    (eListboxPythonMultiContent.TYPE_TEXT, 250, vertical_offset, 650, 40, 0, 0, name)  # تغيير الإحداثي X من 50 إلى 250
                ]
            else:
                pixmap = LoadPixmap(cached=True, path=icon_path)
                if pixmap:
                    text_width = 490
                    text_x = 700 - text_width - 10
                    item = [
                        entry,
                        (eListboxPythonMultiContent.TYPE_TEXT, 250, vertical_offset, text_width, 40, 0, 0, name),  # تغيير الإحداثي X من text_x إلى 250
                        (eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 5, 10, 200, 100, pixmap)
                    ]
                else:
                    item = [
                        entry,
                        (eListboxPythonMultiContent.TYPE_TEXT, 250, vertical_offset, 650, 40, 0, 0, name) 
                    ]
            list_items.append(item)
        self.l.setList(list_items)
        self.l.setList(list_items)
        
    def getCurrent(self):
        current = self.l.getCurrentSelection()
        if current:
            return current[0]
        return None

class CountdownScreen(Screen):
    def __init__(self, session, title, target_date, background, 
                 font_file, num_font_size=80, label_font_size=30, 
                 title_font_file="DefaultFont.ttf", title_font_size=50, title_font_color="#FFFFFF", 
                 is_recurring=False):
        
        font_name = os.path.splitext(font_file)[0]
        title_font_name = os.path.splitext(title_font_file)[0]
        
        self.skin = f"""
        <screen name="{title}Screen" position="0,0" size="1920,1080" flags="wfNoBorder" zPosition="0" backgroundColor="#000000">
            <ePixmap position="0,0" zPosition="1" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/HolidayCountdown/{background}"/>
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/HolidayCountdown/icons/rectangle.png" position="340,400" size="1200,170" zPosition="2" alphatest="blend"/>
            <widget name="title" position="center,280" size="1000,400" font="{title_font_name};{title_font_size}" halign="center" zPosition="15" transparent="1" foregroundColor="{title_font_color}"/>
            <widget name="days_num"   position="340,410"  size="300,100" font="{font_name};{num_font_size}"   halign="center" zPosition="15" transparent="1" foregroundColor="#FFFFFF"/>
            <widget name="hours_num"  position="640,410"  size="300,100" font="{font_name};{num_font_size}"   halign="center" zPosition="15" transparent="1" foregroundColor="#FFFFFF"/>
            <widget name="mins_num"   position="940,410"  size="300,100" font="{font_name};{num_font_size}"   halign="center" zPosition="15" transparent="1" foregroundColor="#FFFFFF"/>
            <widget name="secs_num"   position="1240,410" size="300,100" font="{font_name};{num_font_size}"   halign="center" zPosition="15" transparent="1" foregroundColor="#FFFFFF"/>
            <widget name="days_label" position="340,510"  size="300,60"  font="{font_name};{label_font_size}" halign="center" zPosition="15" transparent="1" foregroundColor="#FFFFFF"/>
            <widget name="hours_label" position="640,510" size="300,60"  font="{font_name};{label_font_size}" halign="center" zPosition="15" transparent="1" foregroundColor="#FFFFFF"/>
            <widget name="mins_label" position="940,510"  size="300,60"  font="{font_name};{label_font_size}" halign="center" zPosition="15" transparent="1" foregroundColor="#FFFFFF"/>
            <widget name="secs_label" position="1240,510" size="300,60"  font="{font_name};{label_font_size}" halign="center" zPosition="15" transparent="1" foregroundColor="#FFFFFF"/>
        </screen>"""
        
        Screen.__init__(self, session)
        
        self["title"] = Label(title)
        self["days_num"] = Label("0")
        self["hours_num"] = Label("00")
        self["mins_num"] = Label("00")
        self["secs_num"] = Label("00")
        self["days_label"] = Label("Days")
        self["hours_label"] = Label("Hours")
        self["mins_label"] = Label("Minutes")
        self["secs_label"] = Label("Seconds")
        
        self["actions"] = ActionMap(["OkCancelActions"],
        {
            "cancel": self.close
        }, -1)
        
        self.is_recurring = is_recurring
        self.target_date = self.calculate_target_date(target_date)
        
        self.timer = eTimer()
        self.timer.callback.append(self.updateCounter)
        self.timer.start(1000, False)
        
    def calculate_target_date(self, base_date):
        now = datetime.datetime.now()
        current_year = now.year
        target = base_date.replace(year=current_year)
        if target < now:
            target = target.replace(year=current_year + 1)
        return target
        
    def updateCounter(self):
        now = datetime.datetime.now()
        remaining = self.target_date - now
        
        if remaining.total_seconds() <= 0:
            if self.is_recurring:
                self.target_date = self.calculate_target_date(self.target_date)
                remaining = self.target_date - now
            else:
                self["days_num"].setText("0")
                self["hours_num"].setText("00")
                self["mins_num"].setText("00")
                self["secs_num"].setText("00")
                self.timer.stop()
                return
            
        days = remaining.days
        hours, remainder = divmod(remaining.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        self["days_num"].setText(str(days))
        self["hours_num"].setText(f"{hours:02d}")
        self["mins_num"].setText(f"{minutes:02d}")
        self["secs_num"].setText(f"{seconds:02d}")
        
    def close(self):
        if self.timer.isActive():
            self.timer.stop()
        Screen.close(self)

class ChristmasCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "Christmas Countdown", 
                                datetime.datetime(2025, 12, 25), 
                                "icons/christmas_bg.png",
                                font_file="ChristmasFont.otf", 
                                num_font_size=90, 
                                label_font_size=50, 
                                title_font_file="ChristmasTitleFont.otf", 
                                title_font_size=70, 
                                title_font_color="#FFFFFF",
                                is_recurring=True)

class HalloweenCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "Halloween Countdown", 
                                datetime.datetime(2025, 10, 31), 
                                "icons/halloween_bg.png",
                                font_file="HalloweenFont.ttf", 
                                num_font_size=50, 
                                label_font_size=25, 
                                title_font_file="HalloweenTitleFont.ttf", 
                                title_font_size=60, 
                                title_font_color="#FFFFFF",
                                is_recurring=True)

class NewYearCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "New Year Countdown", 
                                datetime.datetime(2026, 1, 1), 
                                "icons/newyear_bg.png",
                                font_file="NewYearFont.otf", 
                                num_font_size=85, 
                                label_font_size=32, 
                                title_font_file="NewYearTitleFont.otf", 
                                title_font_size=80, 
                                title_font_color="#FFD700",
                                is_recurring=True)

class EidAlFitrCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "Eid al-Fitr Countdown", 
                                datetime.datetime(2025, 4, 1), 
                                "icons/eid_bg.png",
                                font_file="EidFont.ttf", 
                                num_font_size=80, 
                                label_font_size=30, 
                                title_font_file="EidTitleFont.ttf", 
                                title_font_size=80, 
                                title_font_color="#000000",
                                is_recurring=True)

class RamadanCountdownScreen(CountdownScreen):
    def __init__(self, session):
        base_date = datetime.datetime(2025, 2, 28)
        CountdownScreen.__init__(self, session, 
                                "Ramadan Countdown", 
                                base_date, 
                                "icons/ramadan_bg.png",
                                font_file="RamadanFont.ttf", 
                                num_font_size=78, 
                                label_font_size=29, 
                                title_font_file="RamadanTitleFont.ttf", 
                                title_font_size=80, 
                                title_font_color="#FFD700",
                                is_recurring=True)
        
    def calculate_target_date(self, base_date):
        now = datetime.datetime.now()
        current_year = now.year
        years_diff = current_year - 2025
        days_shift = years_diff * 11
        target = base_date - datetime.timedelta(days=days_shift)
        
        if target < now:
            target = target.replace(year=target.year + 1)
            target = target - datetime.timedelta(days=11)
        
        return target

class AutumnCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "Autumn Countdown", 
                                datetime.datetime(2025, 9, 22), 
                                "icons/autumn_bg.png",
                                font_file="AutumnFont.ttf", 
                                num_font_size=80, 
                                label_font_size=30, 
                                title_font_file="AutumnTitleFont.ttf", 
                                title_font_size=80, 
                                title_font_color="#000000",
                                is_recurring=True)

class WinterCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "Winter Countdown", 
                                datetime.datetime(2025, 12, 21), 
                                "icons/winter_bg.png",
                                font_file="WinterFont.otf", 
                                num_font_size=82, 
                                label_font_size=31, 
                                title_font_file="WinterTitleFont.otf", 
                                title_font_size=80, 
                                title_font_color="#000000",
                                is_recurring=True)

class SpringCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "Spring Countdown", 
                                datetime.datetime(2025, 3, 20), 
                                "icons/spring_bg.png",
                                font_file="SpringFont.ttf", 
                                num_font_size=80, 
                                label_font_size=30, 
                                title_font_file="SpringTitleFont.ttf", 
                                title_font_size=80, 
                                title_font_color="#000000",
                                is_recurring=True)

class SummerCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "Summer Countdown", 
                                datetime.datetime(2025, 6, 20), 
                                "icons/summer_bg.png",
                                font_file="SummerFont.ttf", 
                                num_font_size=80, 
                                label_font_size=30, 
                                title_font_file="SummerTitleFont.ttf", 
                                title_font_size=80, 
                                title_font_color="#FFFF00",
                                is_recurring=True)

class EidAlAdhaCountdownScreen(CountdownScreen):
    def __init__(self, session):
        base_date = datetime.datetime(2025, 6, 6)
        CountdownScreen.__init__(self, session, 
                                "Eid al-Adha Countdown", 
                                base_date, 
                                "icons/eid_adha_bg.png",
                                font_file="EidAdhaFont.ttf", 
                                num_font_size=80, 
                                label_font_size=30, 
                                title_font_file="EidAdhaTitleFont.ttf", 
                                title_font_size=80, 
                                title_font_color="#FFFFFF",
                                is_recurring=True)
        
    def calculate_target_date(self, base_date):
        now = datetime.datetime.now()
        current_year = now.year
        years_diff = current_year - 2025
        days_shift = years_diff * 11
        target = base_date - datetime.timedelta(days=days_shift)
        
        if target < now:
            target = target.replace(year=target.year + 1)
            target = target - datetime.timedelta(days=11)
        
        return target

class ChristBirthCountdownScreen(CountdownScreen):
    def __init__(self, session):
        CountdownScreen.__init__(self, session, 
                                "Christ's Birth Countdown", 
                                datetime.datetime(2025, 1, 7), 
                                "icons/christ_birth_bg.png",
                                font_file="ChristmasFont.otf", 
                                num_font_size=90, 
                                label_font_size=50, 
                                title_font_file="ChristmasTitleFont.otf", 
                                title_font_size=70, 
                                title_font_color="#FFFFFF",
                                is_recurring=True)

class EasterCountdownScreen(CountdownScreen):
    def __init__(self, session):
        easter_date = self.calculate_easter(datetime.datetime.now().year)
        CountdownScreen.__init__(self, session, 
                                "Easter Countdown", 
                                easter_date, 
                                "icons/easter_bg.png",
                                font_file="EasterFont.ttf", 
                                num_font_size=80, 
                                label_font_size=30, 
                                title_font_file="EasterTitleFont.ttf", 
                                title_font_size=80, 
                                title_font_color="#FFD700",
                                is_recurring=True)
    
    def calculate_easter(self, year):
        a = year % 19
        b = year // 100
        c = year % 100
        d = b // 4
        e = b % 4
        f = (b + 8) // 25
        g = (b - f + 1) // 3
        h = (19 * a + b - d - g + 15) % 30
        i = c // 4
        k = c % 4
        l = (32 + 2 * e + 2 * i - h - k) % 7
        m = (a + 11 * h + 22 * l) // 451
        month = (h + l - 7 * m + 114) // 31
        day = ((h + l - 7 * m + 114) % 31) + 1
        return datetime.datetime(year, month, day)
    
    def calculate_target_date(self, base_date):
        now = datetime.datetime.now()
        if now > base_date:
            return self.calculate_easter(now.year + 1)
        return base_date

def main(session, **kwargs):
    session.open(MainMenu)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Holiday Countdown",
        description="Countdown for Holidays and Seasons",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="icons/icon.png",
        fnc=main
    )

install_fonts()
