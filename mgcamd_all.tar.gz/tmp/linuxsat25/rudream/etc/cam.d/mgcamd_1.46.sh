#!/bin/sh

#profile for mgcamd_1.46

usage()
{
	echo "Usage: $0 {start|stop|status|restart|reload}"
}

if [ $# -lt 1 ] ; then usage ; break ; fi
action=$1

case "$action" in

start)
	echo -n "Start cam daemon: mgcamd_1.46"
	/usr/bin/mgcamd_1.46
	echo " mgcamd_1.46."
		;;

stop)
	echo -n "Stopping cam daemon: mgcamd_1.46"
	while [ -n "`pidof mgcamd_1.46`" ] ; do
		kill -9 `pidof mgcamd_1.46`
	done
	rm -f /tmp/*.info /tmp/camd.socket /tmp/*.list /tmp/*.pid
	echo "."
	;;

status)
	;;

restart|reload)
	$0 stop
	sleep 2
	$0 start
	;;

*)
	usage
	;;

esac

exit 0
