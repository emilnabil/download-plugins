#!/bin/sh
########################################
######      Edited by LINUXSAT25  ######
########################################

/var/emuscript/mgcamd_1.46_em.sh stop

rm -rf /var/bin/mgcamd_1.46
rm -rf /var/emuscript/mgcamd_1.46_em.sh
rm -rf /var/uninstall/mgcamd_1.46_remove.sh

exit 0
