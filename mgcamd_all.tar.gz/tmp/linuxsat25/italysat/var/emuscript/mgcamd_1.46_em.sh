#!/bin/sh
########################################
######      Edited by LINUXSAT25  ######
########################################

remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/pid.info /tmp/cardinfo /tmp/mg* /tmp/mgcamd_1.46*
}

case "$1" in
	start)
	remove_tmp
	/var/bin/mgcamd_1.46 &
	sleep 3
	;;
	stop)
	killall -9 mgcamd_1.46
	remove_tmp
	sleep 2
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0
