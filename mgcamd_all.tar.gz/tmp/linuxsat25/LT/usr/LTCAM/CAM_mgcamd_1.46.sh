#!/bin/sh
########################################
######      Edited by LINUXSAT25  ######
########################################

CAMNAME="mgcamd_1.46"

usage()
{
	echo "Usage: $0 {start|stop|restart|reload}"
}

if [ $# -lt 1 ] ; then usage ; break ; fi
action=$1

case "$action" in
start)
	echo "[SCRIPT] $1: $CAMNAME"
	/usr/bin/mgcamd_1.46 &
	;;
stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 mgcamd_1.46
	;;
restart|reload)
	$0 stop
	$0 start
	;;
*)
	usage
	;;
esac

exit 0
