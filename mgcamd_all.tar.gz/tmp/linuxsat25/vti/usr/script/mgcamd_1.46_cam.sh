#!/bin/sh
########################################
######     Powered by LINUXSAT25  ######
########################################

CAMNAME="mgcamd_1.46"


remove_tmp () {
  rm -rf /tmp/cainfo.* /tmp/camd.* /tmp/sc.* /tmp/*.info* /tmp/*.tmp*
        [ -e /tmp/.emu.info ] && rm -rf /tmp/.emu.info
        [ -e /tmp/mgcamd_1.46.mem ] && rm -rf /tmp/mgcamd_1.46.mem
        [ -e /tmp/oscam.mem ] && rm -rf /tmp/oscam.mem
}

case "$1" in
  start)
  echo "[SCRIPT] $1: $CAMNAME"
  remove_tmp
  touch /tmp/.emu.info
  echo $CAMNAME > /tmp/.emu.info
  /usr/bin/mgcamd_1.46 &
  ;;
  stop)
  echo "[SCRIPT] $1: $CAMNAME"
  kill `pidof mgcamd_1.46`
  remove_tmp
  ;;
  restart)
  $0 stop
  sleep 2
  $0 start
  exit
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
