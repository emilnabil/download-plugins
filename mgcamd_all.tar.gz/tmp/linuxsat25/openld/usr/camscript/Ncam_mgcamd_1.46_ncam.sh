#!/bin/sh
########################################
######       EDit By LINUXSAT25   ######
########################################

CAMNAME="mgcamd_1.46"


remove_tmp () {
    rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*mgcamd_1.46*
}
    echo "[SCRIPT] $1: $CAMNAME"
    start_cam () 
    { 
    remove_tmp
	sleep 2
	/usr/bin/mgcamd_1.46 &
    }
	echo "[SCRIPT] $1: $CAMNAME"
	stop_cam () 
    {
	remove_tmp
    killall -9 mgcamd_1.46 2>/dev/null
	    }
case "$1" in  
    start) 
        start_cam 
        ;; 
    stop) 
        stop_cam 
        ;; 
    restart) 
        $0 stop 
        $0 start 
        ;; 
    *)
 
    esac


exit 0
