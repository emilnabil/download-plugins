#!/bin/sh
dpkg -r enigma2-plugin-softcams-mgcamd_1.46-osdreambox
exit 0
