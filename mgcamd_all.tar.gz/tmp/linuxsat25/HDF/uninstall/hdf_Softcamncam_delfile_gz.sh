#!/bin/sh

rm -f /etc/init.d/softcam.mgcamd_1.46 > /dev/null 2>&1
rm -f /etc/init.d/cardserver.mgcamd_1.46 > /dev/null 2>&1
rm -f /usr/bin/list_smargo > /dev/null 2>&1
rm -f /usr/bin/mgcamd_1.46 > /dev/null 2>&1
rm -f /usr/uninstall/hdf_Softcammgcamd_1.46_delfile_gz.sh
exit 0
