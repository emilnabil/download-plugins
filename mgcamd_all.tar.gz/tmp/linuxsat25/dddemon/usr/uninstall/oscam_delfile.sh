#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
# Type: Cam

killall -9 mgcamd_1.46 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/mgcamd_1.46
rm -rf /usr/script/mgcamd_1.46_cam.sh
rm -rf /usr/uninstall/mgcamd_1.46_delfile.sh

exit 0

