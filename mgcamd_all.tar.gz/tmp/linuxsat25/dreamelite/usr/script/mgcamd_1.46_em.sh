#!/bin/sh
########################################
######      Edited by LINUXSAT25  ######
########################################

CAMNAME="mgcamd_1.46"
BINARY="mgcamd_1.46"

remove_tmp () {
	rm -rf  /tmp/*.info /tmp/cardinfo 
}

case "$1" in
	start)
	remove_tmp
	sleep 1
	/usr/bin/mgcamd_1.46 &
	sleep 5
	;;
	stop)
	touch /tmp/mgcamd_1.46.kill
	sleep 3
	killall -9 mgcamd_1.46 2>/dev/null
	sleep 2
	remove_tmp
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0


