#!/bin/sh

########################################
######      Edited by LINUXSAT25  ######
########################################

killall -9 mgcamd_1.46
sleep 5
rm -rf /usr/bin/mgcamd_1.46
rm -rf /usr/script/mgcamd_1.46_1.6_em.sh
rm -rf /usr/uninstall/mgcamd_1.46_1.6_remove.sh

exit 0
