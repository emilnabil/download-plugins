#!/usr/bin/env python3
import os
import sys
import zipfile
import tarfile
import subprocess
import shutil
import argparse

def get_package_info(control_path):
    info = {}
    with open(control_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line.startswith('Package:'):
                info['name'] = line.split(':', 1)[1].strip()
            elif line.startswith('Version:'):
                info['version'] = line.split(':', 1)[1].strip()
            elif line.startswith('Architecture:'):
                info['arch'] = line.split(':', 1)[1].strip()
    
    missing = [k for k in ['name', 'version', 'arch'] if k not in info]
    if missing:
        print(f"Missing fields: {', '.join(missing)}", file=sys.stderr)
        sys.exit(1)
    return info

def create_ar_archive(ipk_path, files):
    try:
        cmd = f"ar rcs '{ipk_path}' {' '.join(files)}"
        subprocess.run(cmd, shell=True, check=True, stderr=subprocess.PIPE)
        if not os.path.exists(ipk_path):
            raise RuntimeError("AR command failed to create file")
    except Exception as e:
        print(f"AR Error: {str(e)}", file=sys.stderr)
        raise

def zip_to_ipk(zip_path, output_dir=None):
    temp_dir = None
    try:
        if not zipfile.is_zipfile(zip_path):
            raise ValueError("Invalid ZIP file format")
        
        base_name = os.path.splitext(os.path.basename(zip_path))[0]
        output_dir = output_dir or os.path.dirname(zip_path)
        temp_dir = os.path.join(output_dir, f"temp_{base_name}")
        
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(temp_dir)
        
        control_file = os.path.join(temp_dir, 'CONTROL', 'control')
        if not os.path.exists(control_file):
            raise FileNotFoundError("CONTROL/control file missing")
        
        pkg_info = get_package_info(control_file)
        
        debian = os.path.join(temp_dir, 'debian-binary')
        with open(debian, 'w') as f:
            f.write("2.0\n")
        
        # Create control.tar.gz with 755 permissions for all files
        control_tar = os.path.join(temp_dir, 'control.tar.gz')
        control_dir = os.path.join(temp_dir, 'CONTROL')
        with tarfile.open(control_tar, 'w:gz') as tar:
            for root, dirs, files in os.walk(control_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, control_dir)
                    arcname = os.path.join('.', rel_path)
                    tar_info = tar.gettarinfo(full_path, arcname)
                    tar_info.mode = 0o755  # Force 755 permissions
                    tar.addfile(tar_info, open(full_path, 'rb'))
        
        # Create data.tar.gz with 755 permissions for all files
        data_dir = os.path.join(temp_dir, 'DATA')
        if not os.path.exists(data_dir):
            raise NotADirectoryError("DATA directory missing")
        
        data_tar = os.path.join(temp_dir, 'data.tar.gz')
        with tarfile.open(data_tar, 'w:gz') as tar:
            for root, dirs, files in os.walk(data_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, data_dir)
                    arcname = os.path.join('.', rel_path)
                    tar_info = tar.gettarinfo(full_path, arcname)
                    tar_info.mode = 0o755  # Force 755 permissions
                    tar.addfile(tar_info, open(full_path, 'rb'))
        
        ipk_name = f"{pkg_info['name']}_{pkg_info['version']}_{pkg_info['arch']}.ipk"
        ipk_path = os.path.join(output_dir, ipk_name)
        
        create_ar_archive(ipk_path, [debian, control_tar, data_tar])
        return ipk_path
        
    finally:
        if temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Convert ZIP to IPK')
    parser.add_argument('input', help='Input ZIP file path')
    parser.add_argument('--output', help='Output directory', default=None)
    args = parser.parse_args()

    try:
        result = zip_to_ipk(args.input, args.output)
        print(result)
    except Exception as e:
        print(f"Fatal Error: {str(e)}", file=sys.stderr)
        sys.exit(1)

