from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.LocationBox import LocationBox
from Components.ActionMap import ActionMap
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigText, getConfigListEntry, ConfigDirectory
from Components.ConfigList import ConfigListScreen
from Components.Button import Button
import os
import subprocess
import shlex
import traceback

config.plugins.Zip2IPK = ConfigSubsection()
config.plugins.Zip2IPK.auto_clean = ConfigYesNo(default=True)
config.plugins.Zip2IPK.output_path = ConfigDirectory(default="/tmp/")

class Zip2IPKSettings(Screen, ConfigListScreen):
    skin = """
        <screen name="Zip2IPKSettings" position="center,center" size="600,400" title="Zip2IPK By Emil Nabil">
            <widget name="config" position="10,10" size="580,300" scrollbarMode="showOnDemand" />
            <eLabel text="Convert" position="10,350" size="280,40" font="Bold;28" halign="center" backgroundColor="green" />
            <eLabel text="Exit" position="300,350" size="280,40" font="Bold;28" halign="center" backgroundColor="red" />
        </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("Zip2IPK By Emil Nabil")

        self.list = [
            getConfigListEntry("Auto Clean", config.plugins.Zip2IPK.auto_clean),
            getConfigListEntry("Output Path", config.plugins.Zip2IPK.output_path)
        ]

        ConfigListScreen.__init__(self, self.list, session=session)
        self["actions"] = ActionMap(["ColorActions", "CancelActions", "OkCancelActions"], {
            "green": self.convert,
            "red": self.close,
            "cancel": self.close,
            "ok": self.openLocationBox
        }, -1)

    def openLocationBox(self):
        sel = self["config"].getCurrent()[1]
        if sel == config.plugins.Zip2IPK.output_path:
            self.session.openWithCallback(self.locationSelected, LocationBox, text="Select Output Folder", currDir=config.plugins.Zip2IPK.output_path.value, minFree=0)

    def locationSelected(self, path):
        if path and os.path.isdir(path):
            config.plugins.Zip2IPK.output_path.value = path
            config.plugins.Zip2IPK.output_path.save()
            self["config"].setList(self.list)

    def convert(self):
        try:
            zip_path = "/tmp/package.zip"
            output_dir = config.plugins.Zip2IPK.output_path.value.strip()

            if not os.path.exists(zip_path):
                self.session.open(MessageBox, "Error: package.zip not found in /tmp", MessageBox.TYPE_ERROR)
                return

            script_path = os.path.join(os.path.dirname(__file__), "zip2ipk.py")
            cmd = f'python3 {shlex.quote(script_path)} {shlex.quote(zip_path)} --output {shlex.quote(output_dir)}'

            result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True).strip()

            if config.plugins.Zip2IPK.auto_clean.value and os.path.exists(zip_path):
                os.remove(zip_path)

            if os.path.exists(result):
                self.session.open(MessageBox, f"Success!\n{result}", MessageBox.TYPE_INFO)
            else:
                self.session.open(MessageBox, "Conversion failed: No output file", MessageBox.TYPE_ERROR)

        except subprocess.CalledProcessError as e:
            self.session.open(MessageBox, f"Error {e.returncode}:\n{e.output}", MessageBox.TYPE_ERROR)
        except Exception as e:
            error_msg = f"Critical Error:\n{str(e)}"
            print(traceback.format_exc())
            self.session.open(MessageBox, error_msg, MessageBox.TYPE_ERROR)

def main(session, **kwargs):
    session.open(Zip2IPKSettings)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Zip2IPK Converter",
            description="Convert ZIP to IPK with settings",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=os.path.join(os.path.dirname(__file__), "plugin.png"),
            fnc=main
        )
    ]

