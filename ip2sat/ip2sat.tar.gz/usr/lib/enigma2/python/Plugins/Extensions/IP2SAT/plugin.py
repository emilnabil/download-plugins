# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import sys
import traceback
import time

try:
    from urllib2 import Request, urlopen
    from urllib import quote
except ImportError:
    from urllib.request import Request, urlopen
    from urllib.parse import quote

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.ConfigList import ConfigListScreen
from Components.Sources.StaticText import StaticText
from Components.config import (
    config,
    ConfigSubsection,
    ConfigSelection,
    ConfigText,
    ConfigYesNo,
    ConfigInteger,
    getConfigListEntry,
    configfile,
)
from enigma import (
    eServiceCenter,
    eServiceReference,
    eTimer,
    eConsoleAppContainer,
    iFrontendInformation,
    eListboxPythonMultiContent,
    RT_HALIGN_LEFT,
    RT_VALIGN_CENTER,
    gRGB,
)

try:
    from enigma import gFont
except Exception:
    gFont = None

try:
    from ServiceReference import ServiceReference
except Exception:
    ServiceReference = None

try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    try:
        from Screens.VirtualKeyboard import VirtualKeyBoard
    except Exception:
        VirtualKeyBoard = None

try:
    text_type = unicode
    binary_type = str
except NameError:
    text_type = str
    binary_type = bytes

PLUGIN_NAME = "IP2SAT"
PLUGIN_VERSION = "1.9.1"
PLUGIN_DESC = "IPTV on Satellite Services by mosad"
PLUGIN_PATH = os.path.dirname(__file__)
BUTTONS_PATH = os.path.join(PLUGIN_PATH, "Buttons")
WHATSAPP_QR = os.path.join(PLUGIN_PATH, "whatsapp-qr.png")
PAYPAL_QR = os.path.join(PLUGIN_PATH, "paypal-qr.png")
PLUGIN_ICON = os.path.join(PLUGIN_PATH, "plugin.png")
IP2SAT_JSON = "/etc/enigma2/ip2sat.json"
IP2SAT_LOG = "/tmp/ip2sat.log"

PANEL_BG = "#050505"
HEADER_BG = "#000000"
LIST_BG = "#000000"
FOOTER_BG = "#000000"
TEXT_MAIN = "#ffffff"
TEXT_DIM = "#d5d5d5"
TEXT_MUTED = "#a9a9a9"
TEXT_RED = "#ff5b5b"
TEXT_GREEN = "#4fe06a"
TEXT_BLUE = "#4aa3ff"
SELECT_BG = "#1f6fa8"
SELECT_BG_ACTIVE = "#d8c021"
SELECT_TEXT_ACTIVE = "#000000"

FONT_TITLE = 38
FONT_SECTION = 38
FONT_TEXT = 38
FONT_LIST = 38
FONT_FOOTER = 38
FONT_STATUS = 38
ROW_MAIN = 80
ROW_LIST = 80

PY3 = sys.version_info[0] >= 3

BRIDGE_INSTANCE = None


def log(msg):
    try:
        with open(IP2SAT_LOG, "a") as f:
            f.write("%s\n" % msg)
    except Exception:
        pass


def ensure_text(value):
    try:
        if isinstance(value, text_type):
            return value
        if isinstance(value, binary_type):
            return value.decode("utf-8", "ignore")
    except Exception:
        pass
    try:
        return text_type(value)
    except Exception:
        try:
            return str(value)
        except Exception:
            return ""


def parse_color(value, fallback="#ffffff"):
    """Return a plain integer color for MultiContent on Py2/Py3/OpenBH/DreamOS.

    Some images accept gRGB on older builds, but newer Python 3 images raise:
    TypeError: 'gRGB' object cannot be interpreted as an integer.
    """
    try:
        value = ensure_text(value or fallback).strip()
        if value.startswith("#"):
            value = value[1:]
        elif fallback.startswith("#"):
            value = fallback[1:]
        if len(value) not in (6, 8):
            value = fallback[1:] if fallback.startswith("#") else "ffffff"
        return int(value, 16)
    except Exception:
        try:
            fb = fallback[1:] if ensure_text(fallback).startswith("#") else "ffffff"
            return int(fb, 16)
        except Exception:
            return 0xffffff




def color_label(label, color=None):
    try:
        color = ensure_text(color or TEXT_RED).replace("#", "")
        return "\\c00%s%s" % (color, ensure_text(label))
    except Exception:
        return ensure_text(label)

if not hasattr(config.plugins, "ip2sat"):
    config.plugins.ip2sat = ConfigSubsection()

config.plugins.ip2sat.enabled = ConfigSelection(
    default="disable",
    choices=[("enable", "Enable"), ("disable", "Disable")],
)
DEFAULT_PLAYER = "gstplayer"
if not PY3 and os.path.exists("/usr/bin/gst-play-1.0"):
    DEFAULT_PLAYER = "gst-play-1.0"
config.plugins.ip2sat.player = ConfigSelection(
    default=DEFAULT_PLAYER,
    choices=[("gstplayer", "gstplayer"), ("gst-play-1.0", "gst-play-1.0"), ("exteplayer3", "exteplayer3")],
)

STREAM_TYPE_CHOICES = [
    ("1", "DVB 1"),
]
config.plugins.ip2sat.stream_type = ConfigSelection(default="1", choices=STREAM_TYPE_CHOICES)
config.plugins.ip2sat.hostname = ConfigText(default="", fixed_size=False)
config.plugins.ip2sat.port = ConfigText(default="80", fixed_size=False)
config.plugins.ip2sat.username = ConfigText(default="", fixed_size=False)
config.plugins.ip2sat.password = ConfigText(default="", fixed_size=False)
config.plugins.ip2sat.keep_sat_lock = ConfigYesNo(default=True)
config.plugins.ip2sat.signal_threshold = ConfigInteger(default=10, limits=(0, 100))
config.plugins.ip2sat.assign_action = ConfigSelection(default="open", choices=[("open", "")])
config.plugins.ip2sat.manage_action = ConfigSelection(default="open", choices=[("open", "")])
config.plugins.ip2sat.info_action = ConfigSelection(default="open", choices=[("open", "")])
config.plugins.ip2sat.config_header = ConfigSelection(default="header", choices=[("header", "")])

TEXT_FIELD_IDS = ["hostname", "port", "username", "password"]


def is_enabled():
    try:
        return config.plugins.ip2sat.enabled.value == "enable"
    except Exception:
        return False


def is_player_available(player_name):
    return os.path.exists("/usr/bin/%s" % player_name)


def normalize_sref(sref):
    try:
        if hasattr(sref, "toString"):
            sref = sref.toString()
        if not sref:
            return ""
        sref = ensure_text(sref).strip()
        parts = sref.split(":")
        if len(parts) >= 10:
            return ":".join(parts[:10]) + ":"
        return sref
    except Exception:
        return ""


def ensure_json_dir():
    folder = os.path.dirname(IP2SAT_JSON)
    if folder and not os.path.exists(folder):
        os.makedirs(folder)


def _normalize_mapping_item(item):
    if not isinstance(item, dict):
        return None
    ref = normalize_sref(item.get("ref") or item.get("sref") or "")
    channel = ensure_text(item.get("channel") or item.get("name") or "").strip()
    url = ensure_text(item.get("url") or "").strip()
    if not ref or not url:
        return None
    return {"ref": ref, "channel": channel, "url": url}


def load_mappings():
    try:
        if not os.path.exists(IP2SAT_JSON):
            return []
        with open(IP2SAT_JSON, "r") as f:
            data = json.load(f)
        items = []
        if isinstance(data, dict) and isinstance(data.get("playlist"), list):
            items = data.get("playlist", [])
        elif isinstance(data, list):
            items = data
        out = []
        for item in items:
            row = _normalize_mapping_item(item)
            if row:
                out.append(row)
        return out
    except Exception as e:
        log("load_mappings error: %s" % e)
        return []


def save_mappings(items):
    try:
        ensure_json_dir()
        cleaned = []
        for item in items:
            row = _normalize_mapping_item(item)
            if row:
                cleaned.append(row)
        with open(IP2SAT_JSON, "w") as f:
            json.dump({"playlist": cleaned}, f, indent=4)
        return True
    except Exception as e:
        log("save_mappings error: %s" % e)
        return False


def set_mapping(ref, channel, url):
    ref = normalize_sref(ref)
    channel = ensure_text(channel or "").strip()
    url = ensure_text(url or "").strip()
    if not ref or not url:
        return False
    items = load_mappings()
    found = False
    for item in items:
        if normalize_sref(item.get("ref")) == ref:
            item["channel"] = channel
            item["url"] = url
            found = True
            break
    if not found:
        items.append({"ref": ref, "channel": channel, "url": url})
    return save_mappings(items)


def remove_mapping(ref):
    ref = normalize_sref(ref)
    return save_mappings([x for x in load_mappings() if normalize_sref(x.get("ref")) != ref])


def reset_mappings():
    return save_mappings([])


def get_mapping_for_ref(ref):
    nref = normalize_sref(ref)
    for item in load_mappings():
        if normalize_sref(item.get("ref")) == nref:
            return item
    return None


def get_base_url():
    host = ensure_text(config.plugins.ip2sat.hostname.value).strip()
    port = ensure_text(config.plugins.ip2sat.port.value).strip()
    if not host:
        return ""
    scheme = "http"
    host_only = host
    if host.startswith("http://"):
        host_only = host[7:]
    elif host.startswith("https://"):
        scheme = "https"
        host_only = host[8:]
    host_only = host_only.split("/")[0]
    if ":" in host_only:
        return "%s://%s" % (scheme, host_only)
    return "%s://%s:%s" % (scheme, host_only, port or "80")


def fetch_json(url):
    req = Request(url, headers={"User-Agent": "IP2SAT/%s" % PLUGIN_VERSION})
    data = urlopen(req, timeout=10).read()
    try:
        data = data.decode("utf-8", "ignore")
    except Exception:
        pass
    return json.loads(data)


def build_stream_url(stream_id):
    base = get_base_url()
    username = ensure_text(config.plugins.ip2sat.username.value).strip()
    password = ensure_text(config.plugins.ip2sat.password.value).strip()
    if not (base and username and password and stream_id):
        return ""
    return "%s/%s/%s/%s" % (base, username, password, stream_id)


def to_service_ref_string(ref):
    try:
        if ref is None:
            return ""
        if hasattr(ref, "toString"):
            return ensure_text(ref.toString()).strip()
        return ensure_text(ref).strip()
    except Exception:
        return ""


def quote_for_service(value, safe="/"):
    value = ensure_text(value or "")
    try:
        out = quote(value, safe=safe)
    except Exception:
        try:
            out = quote(value.encode("utf-8"), safe=safe)
        except Exception:
            out = value
    return ensure_text(out)


def get_selected_stream_type():
    try:
        return ensure_text(config.plugins.ip2sat.stream_type.value or "").strip()
    except Exception:
        return ""


def get_service_type_candidates(player_name):
    selected = get_selected_stream_type()
    if selected == "1":
        return ["1"]
    return ["1"]


def replace_service_type(base_ref, service_type):
    try:
        parts = ensure_text(base_ref or "").strip(':').split(':')
        while len(parts) < 10:
            parts.append('0')
        parts = parts[:10]
        parts[0] = ensure_text(service_type)
        return ':'.join(parts)
    except Exception:
        return '%s:0:1:0:0:0:0:0:0:0' % ensure_text(service_type)


def build_iptv_service_refs(url, title, player_name, sat_ref):
    refs = []
    url_part = quote_for_service(url, safe="/@?&=._-~%+,")
    name_part = quote_for_service(title or "IP2SAT", safe="")
    sat_ref = normalize_sref(sat_ref)
    for service_type in get_service_type_candidates(player_name):
        base_part = replace_service_type(sat_ref, service_type)
        ref_string = "%s:%s:%s" % (base_part, url_part, name_part)
        refs.append((service_type, eServiceReference(ref_string)))
    return refs


def get_live_categories():
    username = ensure_text(config.plugins.ip2sat.username.value).strip()
    password = ensure_text(config.plugins.ip2sat.password.value).strip()
    base = get_base_url()
    if not (base and username and password):
        return [{"category_id": "0", "category_name": "All"}]
    url = "%s/player_api.php?username=%s&password=%s&action=get_live_categories" % (base, quote(username), quote(password))
    try:
        data = fetch_json(url)
        rows = [{"category_id": "0", "category_name": "All"}]
        if isinstance(data, list):
            rows.extend(data)
        return rows
    except Exception as e:
        log("get_live_categories error: %s" % e)
        return [{"category_id": "0", "category_name": "All"}]


def get_live_streams():
    username = ensure_text(config.plugins.ip2sat.username.value).strip()
    password = ensure_text(config.plugins.ip2sat.password.value).strip()
    base = get_base_url()
    if not (base and username and password):
        return []
    url = "%s/player_api.php?username=%s&password=%s&action=get_live_streams" % (base, quote(username), quote(password))
    try:
        data = fetch_json(url)
        out = []
        if isinstance(data, list):
            for item in data:
                sid = item.get("stream_id")
                if sid is None:
                    continue
                out.append({
                    "name": ensure_text(item.get("name", "Unknown IPTV Channel")),
                    "stream_id": ensure_text(sid),
                    "category_id": ensure_text(item.get("category_id", "0")),
                    "url": build_stream_url(sid),
                })
        return out
    except Exception as e:
        log("get_live_streams error: %s" % e)
        return []


def get_tv_bouquets():
    bouquets = []
    try:
        service_handler = eServiceCenter.getInstance()
        root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
        bouquet_list = service_handler.list(root)
        if bouquet_list is None:
            return bouquets
        while True:
            bouquet = bouquet_list.getNext()
            if not bouquet.valid():
                break
            if bouquet.flags & eServiceReference.isDirectory:
                info = service_handler.info(bouquet)
                name = info and info.getName(bouquet) or bouquet.toString()
                bouquets.append({"name": ensure_text(name), "ref": bouquet.toString()})
    except Exception as e:
        log("get_tv_bouquets error: %s" % e)
    return bouquets


def get_services_from_ref(ref_string):
    channels = []
    try:
        service_handler = eServiceCenter.getInstance()
        root = eServiceReference(ref_string)
        service_list = service_handler.list(root)
        if service_list is None:
            return channels
        while True:
            service = service_list.getNext()
            if not service.valid():
                break
            if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker):
                continue
            info = service_handler.info(service)
            if info is not None:
                name = info.getName(service)
            elif ServiceReference is not None:
                name = ServiceReference(service).getServiceName()
            else:
                name = service.toString()
            channels.append({"name": ensure_text(name), "ref": normalize_sref(service.toString())})
    except Exception as e:
        log("get_services_from_ref error: %s" % e)
    return channels


def get_services_from_bouquet(bouquet_ref):
    return get_services_from_ref(bouquet_ref)


def get_satellite_directories():
    satellites = []
    try:
        service_handler = eServiceCenter.getInstance()
        root = eServiceReference('1:7:1:0:0:0:0:0:0:0:FROM SATELLITES ORDER BY satellitePosition')
        sat_list = service_handler.list(root)
        if sat_list is None:
            return satellites
        while True:
            sat = sat_list.getNext()
            if not sat.valid():
                break
            if not (sat.flags & eServiceReference.isDirectory):
                continue
            info = service_handler.info(sat)
            name = info and info.getName(sat) or sat.toString()
            satellites.append({"name": ensure_text(name), "ref": sat.toString()})
    except Exception as e:
        log("get_satellite_directories error: %s" % e)
    return satellites


def save_all_config():
    for cfg in (
        config.plugins.ip2sat.enabled,
        config.plugins.ip2sat.player,
        config.plugins.ip2sat.stream_type,
        config.plugins.ip2sat.hostname,
        config.plugins.ip2sat.port,
        config.plugins.ip2sat.username,
        config.plugins.ip2sat.password,
        config.plugins.ip2sat.keep_sat_lock,
        config.plugins.ip2sat.signal_threshold,
    ):
        cfg.save()
    configfile.save()


class IP2SATBridge(object):
    def __init__(self, session):
        self.session = session
        self.container = eConsoleAppContainer()
        self.timer = eTimer()
        self.ip_sat = False
        self.play_mode = ""
        self.active_ref = ""
        self.active_url = ""
        self.active_stream_ref = ""
        self.last_sat_signal = 0
        self._nav_shadow_installed = False
        self._orig_get_ref = None
        self._orig_get_group = None
        self.install_nav_shadow()
        try:
            self.timer.callback.append(self.poll)
        except Exception:
            try:
                self.timer_conn = self.timer.timeout.connect(self.poll)
            except Exception:
                self.timer_conn = None
        try:
            self.timer.start(1500, False)
        except Exception:
            self.timer.start(1500)

    def clear_state(self):
        self.ip_sat = False
        self.play_mode = ""
        self.active_ref = ""
        self.active_url = ""
        self.active_stream_ref = ""

    def shadow_ref_enabled(self):
        try:
            return bool(self.ip_sat and self.active_ref)
        except Exception:
            return False

    def shadow_group_enabled(self):
        try:
            return bool(config.plugins.ip2sat.keep_sat_lock.value and self.ip_sat and self.active_ref)
        except Exception:
            return False

    def install_nav_shadow(self):
        if self._nav_shadow_installed or self.session is None or not hasattr(self.session, "nav"):
            return
        nav = self.session.nav
        if callable(getattr(nav, "getCurrentlyPlayingServiceReference", None)):
            self._orig_get_ref = nav.getCurrentlyPlayingServiceReference

            def _shadow_get_ref():
                if self.shadow_ref_enabled():
                    try:
                        return eServiceReference(self.active_ref)
                    except Exception:
                        pass
                return self._orig_get_ref()

            try:
                nav.getCurrentlyPlayingServiceReference = _shadow_get_ref
            except Exception as e:
                log("install_nav_shadow ref error: %s" % e)
        if callable(getattr(nav, "getCurrentlyPlayingServiceOrGroup", None)):
            self._orig_get_group = nav.getCurrentlyPlayingServiceOrGroup

            def _shadow_get_group():
                if self.shadow_group_enabled():
                    try:
                        return eServiceReference(self.active_ref)
                    except Exception:
                        pass
                return self._orig_get_group()

            try:
                nav.getCurrentlyPlayingServiceOrGroup = _shadow_get_group
            except Exception as e:
                log("install_nav_shadow group error: %s" % e)
        self._nav_shadow_installed = True

    def get_real_current_service_reference(self):
        try:
            if callable(self._orig_get_ref):
                return self._orig_get_ref()
        except Exception:
            pass
        try:
            return self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            return None

    def get_real_current_ref_string(self):
        return to_service_ref_string(self.get_real_current_service_reference())

    def get_signal_percent(self):
        try:
            service = self.session.nav.getCurrentService()
            if service is None:
                return 0
            fe_info = service.frontendInfo()
            if fe_info is None:
                return 0
            raw = int(fe_info.getFrontendInfo(iFrontendInformation.signalQuality) or 0)
            if raw > 100:
                return int(raw / 655)
            return raw
        except Exception:
            return 0

    def stop_active(self, restore_sat=False):
        if not self.ip_sat:
            return
        current_full = self.get_real_current_ref_string()
        if self.play_mode == "external":
            try:
                self.container.sendCtrlC()
            except Exception:
                pass
        elif self.play_mode == "service_ref":
            if restore_sat and self.active_ref and current_full == self.active_stream_ref:
                try:
                    self.session.nav.stopService()
                except Exception:
                    pass
                try:
                    self.session.nav.playService(eServiceReference(self.active_ref))
                except Exception as e:
                    log("restore satellite service error: %s" % e)
        self.clear_state()

    def wait_for_service(self, ref_obj, timeout=2.5):
        target = to_service_ref_string(ref_obj)
        if not target:
            return False
        end_time = time.time() + timeout
        while time.time() < end_time:
            current = self.get_real_current_ref_string()
            if current == target:
                return True
            time.sleep(0.20)
        return False

    def start_service_ref(self, sat_ref, mapping):
        player = config.plugins.ip2sat.player.value
        url = ensure_text(mapping.get("url") or "").strip()
        name = ensure_text(mapping.get("channel") or "IP2SAT").strip()
        if not url:
            return False
        for service_type, ref_obj in build_iptv_service_refs(url, name, player, sat_ref):
            try:
                self.session.nav.stopService()
            except Exception:
                pass
            try:
                try:
                    self.session.nav.playService(ref_obj, adjust=False)
                except TypeError:
                    self.session.nav.playService(ref_obj)
            except Exception as e:
                log("playService service type %s error: %s" % (service_type, e))
                continue
            if self.wait_for_service(ref_obj):
                self.ip_sat = True
                self.play_mode = "service_ref"
                self.active_ref = normalize_sref(sat_ref)
                self.active_url = url
                self.active_stream_ref = to_service_ref_string(ref_obj)
                log("IP2SAT playback started with service type %s for %s" % (service_type, self.active_ref))
                return True
            log("IP2SAT service type %s did not start stream, trying fallback" % service_type)
        return False

    def start_external(self, sat_ref, mapping):
        player = config.plugins.ip2sat.player.value
        player_bin = player
        if not player_bin.startswith("/"):
            player_bin = "/usr/bin/%s" % player_bin
        if not os.path.exists(player_bin):
            log("IP2SAT player not found: %s" % player_bin)
            return False
        url = ensure_text(mapping.get("url") or "").strip()
        if not url:
            return False
        cmd = '%s "%s"' % (player_bin, url.replace('"', '\"'))
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            self.container.execute(cmd)
        except Exception as e:
            log("container.execute error: %s" % e)
            return False
        try:
            self.session.nav.playService(eServiceReference(normalize_sref(sat_ref)))
        except Exception as e:
            log("restore satellite service error: %s" % e)
        self.ip_sat = True
        self.play_mode = "external"
        self.active_ref = normalize_sref(sat_ref)
        self.active_url = url
        self.active_stream_ref = ""
        log("IP2SAT playback started with external player for %s" % self.active_ref)
        return True

    def start_playback(self, sat_ref, mapping):
        """Prefer the selected stream type first, especially on OpenBH.

        The user can choose an explicit Enigma2 service type from the main page.
        We try that service-ref based playback first so images like OpenBH can
        use 4097/5001/5002/8193/8739/4114 as requested, then fall back to the
        external IPtoSAT-style bridge if needed.
        """
        self.stop_active(restore_sat=False)
        if self.start_service_ref(sat_ref, mapping):
            return True
        return self.start_external(sat_ref, mapping)

    def poll(self):
        try:
            self._poll()
        except Exception:
            log(traceback.format_exc())

    def _poll(self):
        if self.session is None:
            return

        current_ref = self.get_real_current_service_reference()
        current_full = to_service_ref_string(current_ref)
        current_norm = normalize_sref(current_full)

        # IPtoSAT-style behavior: when the user leaves the current satellite
        # service, stop the external IPTV player as well.
        if self.ip_sat and self.play_mode == "external":
            if current_norm != normalize_sref(self.active_ref):
                self.stop_active(restore_sat=False)
        elif self.ip_sat and self.play_mode == "service_ref":
            if current_full != self.active_stream_ref:
                self.clear_state()

        effective_ref = normalize_sref(self.get_real_current_ref_string())
        if self.ip_sat and self.play_mode == "external":
            effective_ref = normalize_sref(self.active_ref)

        signal = self.get_signal_percent()
        if signal > 0:
            self.last_sat_signal = signal
        else:
            signal = self.last_sat_signal

        if not is_enabled() or not effective_ref:
            self.stop_active(restore_sat=True)
            return

        mapping = get_mapping_for_ref(effective_ref)
        if mapping is None:
            self.stop_active(restore_sat=True)
            return

        url = ensure_text(mapping.get("url") or "").strip()
        if not url:
            self.stop_active(restore_sat=True)
            return

        try:
            threshold = int(config.plugins.ip2sat.signal_threshold.value)
        except Exception:
            threshold = 0
        if not self.ip_sat and threshold > 0 and signal < threshold:
            return

        if self.ip_sat and normalize_sref(self.active_ref) == effective_ref and self.active_url == url:
            return

        self.start_playback(effective_ref, mapping)


class ThemedScreen(Screen):
    def safeClose(self, *args, **kwargs):
        try:
            self.close()
        except Exception as e:
            log("safeClose error: %s" % e)

    def applyListFonts(self, names, size_main=FONT_LIST, size_alt=FONT_LIST, item_height=None):
        if gFont is None:
            return
        for name in names:
            try:
                widget = self[name]
            except Exception:
                continue
            try:
                if hasattr(widget, "l"):
                    try:
                        widget.l.setFont(0, gFont("Regular", size_main))
                    except Exception:
                        pass
                    try:
                        widget.l.setFont(1, gFont("Regular", size_alt))
                    except Exception:
                        pass
                    if item_height is not None:
                        try:
                            widget.l.setItemHeight(item_height)
                        except Exception:
                            pass
            except Exception:
                pass


class ColorMenuList(MenuList):
    def __init__(self, entries=None, width=1000, font_size=FONT_LIST, item_height=ROW_LIST, selected_bg=SELECT_BG, selected_fg=TEXT_MAIN):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        self.row_width = width
        self.item_height = item_height
        self.font_size = font_size
        self.selected_bg = selected_bg
        self.selected_fg = selected_fg
        self._entries = []
        if gFont is not None:
            try:
                self.l.setFont(0, gFont("Regular", font_size))
            except Exception:
                pass
        try:
            self.l.setItemHeight(item_height)
        except Exception:
            pass
        self.setEntries(entries or [])

    def buildEntry(self, label, color=None):
        label = ensure_text(label)
        return [
            label,
            MultiContentEntryText(
                pos=(14, 0),
                size=(self.row_width - 28, self.item_height),
                font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=label,
                color=parse_color(color or TEXT_MAIN),
                color_sel=parse_color(self.selected_fg or TEXT_MAIN),
                backcolor=parse_color(LIST_BG),
                backcolor_sel=parse_color(self.selected_bg or SELECT_BG),
            ),
        ]

    def setSelectionColors(self, selected_bg=None, selected_fg=None):
        if selected_bg is not None:
            self.selected_bg = selected_bg
        if selected_fg is not None:
            self.selected_fg = selected_fg
        self.setEntries(self._entries)

    def setEntries(self, entries):
        self._entries = list(entries or [])
        rows = []
        for item in self._entries:
            if isinstance(item, dict):
                rows.append(self.buildEntry(item.get("text", ""), item.get("color", TEXT_MAIN)))
            else:
                rows.append(self.buildEntry(item, TEXT_MAIN))
        self.setList(rows)



MAIN_SKIN = """
<screen name="IP2SATMain" position="center,center" size="1920,1080" title="IP2SAT" backgroundColor="#00000000" flags="wfNoBorder">
    <eLabel position="50,35" size="1820,1010" backgroundColor="%s" zPosition="0" />
    <eLabel position="50,35" size="1820,78" backgroundColor="%s" zPosition="1" />
    <eLabel position="62,105" size="1796,830" backgroundColor="%s" zPosition="1" />
    <eLabel position="62,968" size="1796,94" backgroundColor="%s" zPosition="1" />

    <widget source="screen_title" render="Label" position="78,52" size="900,56" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget name="config" position="78,114" size="1772,806" itemHeight="%d" foregroundColor="%s" foregroundColorSelected="%s" backgroundColor="%s" backgroundColorSelected="%s" transparent="0" scrollbarMode="showNever" zPosition="3" />
    <widget source="status" render="Label" position="350,946" size="1220,52" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="0" halign="center" zPosition="3" />

    <ePixmap position="94,1032" size="36,36" pixmap="%s/key_exit.png" alphatest="blend" zPosition="3" />
    <widget source="key_red" render="Label" position="142,1024" size="220,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="440,1032" size="36,36" pixmap="%s/key_green.png" alphatest="blend" zPosition="3" />
    <widget source="key_green" render="Label" position="488,1024" size="220,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="785,1032" size="36,36" pixmap="%s/key_ok.png" alphatest="blend" zPosition="3" />
    <widget source="key_ok" render="Label" position="833,1024" size="320,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="1160,1032" size="36,36" pixmap="%s/key_arrows_h.png" alphatest="blend" zPosition="3" />
    <widget source="key_arrows" render="Label" position="1208,1024" size="330,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="1545,1032" size="36,36" pixmap="%s/key_help.png" alphatest="blend" zPosition="3" />
    <widget source="key_info" render="Label" position="1593,1024" size="170,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
</screen>
""" % (
    PANEL_BG, HEADER_BG, LIST_BG, FOOTER_BG,
    FONT_TITLE, TEXT_BLUE, HEADER_BG,
    ROW_MAIN, TEXT_MAIN, TEXT_MAIN, LIST_BG, SELECT_BG,
    FONT_STATUS, TEXT_BLUE, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
)


class IP2SATMain(ThemedScreen, ConfigListScreen):
    skin = MAIN_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("IP2SAT")
        self["screen_title"] = StaticText("IP2SAT")
        self["status"] = StaticText("")
        self["key_red"] = StaticText("Exit")
        self["key_green"] = StaticText("Save")
        self["key_ok"] = StaticText("Select / Edit")
        self["key_arrows"] = StaticText("Change value")
        self["key_info"] = StaticText("Help")
        ConfigListScreen.__init__(self, [], session=session)
        self.entry_meta = []
        self.pending_text_id = None
        self["actions"] = ActionMap([
            "SetupActions",
            "ColorActions",
            "OkCancelActions",
            "InfobarEPGActions",
            "InfobarAudioSelectionActions",
            "InfobarActions",
            "HelpActions",
        ], {
            "cancel": self.safeClose,
            "red": self.safeClose,
            "green": self.keySave,
            "save": self.keySave,
            "ok": self.keyOK,
            "left": self.keyLeft,
            "right": self.keyRight,
            "showEPGList": self.openInfo,
            "audioSelection": self.openInfo,
            "showEventInfo": self.openInfo,
            "showEventInfoPlugin": self.openInfo,
            "help": self.openInfo,
            "displayHelp": self.openInfo,
        }, -1)
        self.onLayoutFinish.append(self.onReady)
        try:
            self["config"].onSelectionChanged.append(self.updateStatus)
        except Exception:
            pass

    def onReady(self):
        self.applyListFonts(["config"], size_main=FONT_LIST, size_alt=FONT_LIST, item_height=ROW_MAIN)
        self.buildList()

    def buildList(self):
        self.entry_meta = [
            {"id": "enabled", "type": "config", "cfg": config.plugins.ip2sat.enabled, "label": "IP2SAT"},
            {"id": "player", "type": "config", "cfg": config.plugins.ip2sat.player, "label": "IP2SAT Player"},
            {"id": "stream_type", "type": "config", "cfg": config.plugins.ip2sat.stream_type, "label": "Stream type"},
            {"id": "hostname", "type": "config", "cfg": config.plugins.ip2sat.hostname, "label": "Hostname"},
            {"id": "port", "type": "config", "cfg": config.plugins.ip2sat.port, "label": "Port"},
            {"id": "username", "type": "config", "cfg": config.plugins.ip2sat.username, "label": "Username"},
            {"id": "password", "type": "config", "cfg": config.plugins.ip2sat.password, "label": "Password"},
            {"id": "assign", "type": "action", "cfg": config.plugins.ip2sat.assign_action, "label": "Assign service to IPTV Links"},
            {"id": "manage", "type": "action", "cfg": config.plugins.ip2sat.manage_action, "label": "Reset or Remove channels from playlist"},
            {"id": "keep_sat_lock", "type": "config", "cfg": config.plugins.ip2sat.keep_sat_lock, "label": "Keep Satellite lock / signal"},
            {"id": "signal_threshold", "type": "config", "cfg": config.plugins.ip2sat.signal_threshold, "label": "Signal threshold"},
            {"id": "info", "type": "action", "cfg": config.plugins.ip2sat.info_action, "label": "Info"},
        ]
        cfg_list = [getConfigListEntry(item["label"], item["cfg"]) for item in self.entry_meta]
        self["config"].list = cfg_list
        self["config"].setList(cfg_list)
        self.updateStatus()

    def getCurrentMeta(self):
        try:
            idx = self["config"].getCurrentIndex()
        except Exception:
            idx = self["config"].getSelectionIndex()
        if idx < 0 or idx >= len(self.entry_meta):
            return None
        return self.entry_meta[idx]

    def updateStatus(self):
        item = self.getCurrentMeta()
        if not item:
            self["status"].setText("IP2SAT")
            return
        text = {
            "enabled": "Enable or disable IP2SAT signal mode",
            "player": "Choose the IPTV player",
            "stream_type": "Keep only DVB 1 stream type",
            "assign": "Open channel assignment page",
            "manage": "Reset or remove saved mappings",
                        "hostname": "Enter IPTV host name or full server address",
            "port": "Enter server port",
            "username": "Enter IPTV username",
            "password": "Enter IPTV password",
            "keep_sat_lock": "Keep satellite lock and signal before IPTV playback",
            "signal_threshold": "Minimum signal level before IPTV playback starts",
            "info": "Open support and contact information",
        }.get(item["id"], "IP2SAT")
        self["status"].setText(text)

    def keyLeft(self):
        item = self.getCurrentMeta()
        if item and item["type"] == "config":
            ConfigListScreen.keyLeft(self)
            self.updateStatus()

    def keyRight(self):
        item = self.getCurrentMeta()
        if item and item["type"] == "config":
            ConfigListScreen.keyRight(self)
            self.updateStatus()

    def keySave(self):
        save_all_config()
        self.session.open(MessageBox, "IP2SAT settings saved", MessageBox.TYPE_INFO, timeout=3)

    def keyOK(self):
        item = self.getCurrentMeta()
        if not item:
            return
        if item["type"] == "action":
            if item["id"] == "assign":
                self.session.open(IP2SATAssignScreen)
            elif item["id"] == "manage":
                self.session.open(IP2SATManageScreen)
            elif item["id"] == "info":
                self.openInfo()
            return
        if item["id"] in TEXT_FIELD_IDS and VirtualKeyBoard is not None:
            self.pending_text_id = item["id"]
            current = item["cfg"].value
            self.session.openWithCallback(self.onKeyboardDone, VirtualKeyBoard, title=item["label"], text=current)

    def onKeyboardDone(self, value=None):
        if value is None or self.pending_text_id is None:
            self.pending_text_id = None
            return
        try:
            getattr(config.plugins.ip2sat, self.pending_text_id).value = ensure_text(value)
        except Exception:
            pass
        self.pending_text_id = None
        self.buildList()

    def openInfo(self):
        self.session.open(IP2SATInfoScreen)


CHOICE_SKIN = """
<screen name="IP2SATChoiceScreen" position="center,center" size="1920,1080" title="IP2SAT" backgroundColor="#00000000" flags="wfNoBorder">
    <eLabel position="330,150" size="1260,780" backgroundColor="%s" zPosition="0" />
    <eLabel position="330,150" size="1260,76" backgroundColor="%s" zPosition="1" />
    <eLabel position="365,245" size="1190,610" backgroundColor="%s" zPosition="1" />
    <eLabel position="365,852" size="1190,58" backgroundColor="%s" zPosition="1" />

    <widget source="title" render="Label" position="388,166" size="980,46" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget name="list" position="390,262" size="1140,565" itemHeight="%d" backgroundColor="%s" transparent="0" scrollbarMode="showOnDemand" zPosition="3" />
    <ePixmap position="420,872" size="36,36" pixmap="%s/key_exit.png" alphatest="blend" zPosition="3" />
    <widget source="key_red" render="Label" position="468,869" size="150,38" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="760,872" size="36,36" pixmap="%s/key_ok.png" alphatest="blend" zPosition="3" />
    <widget source="key_ok" render="Label" position="808,869" size="150,38" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
</screen>
""" % (
    PANEL_BG, HEADER_BG, LIST_BG, FOOTER_BG,
    FONT_TITLE, TEXT_MAIN, HEADER_BG,
    ROW_LIST, LIST_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
)


class IP2SATChoiceScreen(ThemedScreen):
    skin = CHOICE_SKIN

    def __init__(self, session, title="Select", choices=None, current_index=0):
        Screen.__init__(self, session)
        self.setTitle(ensure_text(title))
        self["title"] = StaticText(ensure_text(title))
        self["list"] = ColorMenuList([], width=1120, font_size=FONT_LIST, item_height=ROW_LIST)
        self["key_red"] = StaticText("Exit")
        self["key_ok"] = StaticText("Select")
        self.choices = choices or []
        self.current_index = int(current_index or 0)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.doCancel,
            "red": self.doCancel,
            "ok": self.doSelect,
            "green": self.doSelect,
        }, -1)
        self.onLayoutFinish.append(self.onReady)

    def onReady(self):
        rows = []
        for item in self.choices:
            try:
                rows.append({"text": ensure_text(item[0]), "color": TEXT_MAIN})
            except Exception:
                rows.append({"text": ensure_text(item), "color": TEXT_MAIN})
        self["list"].setEntries(rows)
        self.moveTo(self.current_index)

    def moveTo(self, index):
        try:
            self["list"].moveToIndex(index)
            return
        except Exception:
            pass
        try:
            self["list"].instance.moveSelectionTo(index)
        except Exception:
            pass

    def doCancel(self):
        self.close(None)

    def doSelect(self):
        idx = self["list"].getSelectionIndex()
        if idx < 0 or idx >= len(self.choices):
            self.close(None)
            return
        self.close(self.choices[idx])


def move_menu_to_index(menu_widget, index):
    try:
        menu_widget.moveToIndex(index)
        return
    except Exception:
        pass
    try:
        menu_widget.instance.moveSelectionTo(index)
    except Exception:
        pass


ASSIGN_SKIN = """
<screen name="IP2SATAssignScreen" position="center,center" size="1920,1080" title="Assign service to IPTV Links" backgroundColor="#00000000" flags="wfNoBorder">
    <eLabel position="50,35" size="1820,1010" backgroundColor="%s" zPosition="0" />
    <eLabel position="50,35" size="1820,78" backgroundColor="%s" zPosition="1" />
    <eLabel position="80,120" size="860,840" backgroundColor="%s" zPosition="1" />
    <eLabel position="980,120" size="860,840" backgroundColor="%s" zPosition="1" />
    <eLabel position="80,968" size="1760,94" backgroundColor="%s" zPosition="1" />

    <widget source="screen_title" render="Label" position="78,52" size="1200,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget source="sat_header" render="Label" position="100,80" size="820,50" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget source="iptv_header" render="Label" position="1000,80" size="820,50" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget source="sat_info" render="Label" position="100,126" size="820,46" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget source="iptv_info" render="Label" position="1000,126" size="820,46" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget name="sat_list" position="100,188" size="820,726" itemHeight="%d" backgroundColor="%s" transparent="0" scrollbarMode="showOnDemand" zPosition="3" />
    <widget name="iptv_list" position="1000,188" size="820,726" itemHeight="%d" backgroundColor="%s" transparent="0" scrollbarMode="showOnDemand" zPosition="3" />

    <ePixmap position="100,1032" size="36,36" pixmap="%s/key_exit.png" alphatest="blend" zPosition="3" />
    <widget source="key_red" render="Label" position="146,1024" size="220,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="470,1032" size="36,36" pixmap="%s/key_green.png" alphatest="blend" zPosition="3" />
    <widget source="key_green" render="Label" position="516,1024" size="230,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="800,1032" size="36,36" pixmap="%s/key_yellow.png" alphatest="blend" zPosition="3" />
    <widget source="key_yellow" render="Label" position="846,1024" size="230,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="1135,1032" size="36,36" pixmap="%s/key_arrows_h.png" alphatest="blend" zPosition="3" />
    <widget source="key_arrows" render="Label" position="1181,1024" size="330,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="1520,1032" size="36,36" pixmap="%s/key_menu.png" alphatest="blend" zPosition="3" />
    <widget source="key_menu" render="Label" position="1566,1024" size="220,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
</screen>
""" % (
    PANEL_BG, HEADER_BG, LIST_BG, LIST_BG, FOOTER_BG,
    FONT_TITLE, TEXT_MAIN, HEADER_BG,
    FONT_SECTION, TEXT_BLUE, LIST_BG,
    FONT_SECTION, TEXT_BLUE, LIST_BG,
    FONT_TEXT, TEXT_BLUE, LIST_BG,
    FONT_TEXT, TEXT_BLUE, LIST_BG,
    ROW_LIST, LIST_BG,
    ROW_LIST, LIST_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
)


class IP2SATAssignScreen(ThemedScreen):
    skin = ASSIGN_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("Assign service to IPTV Links")
        self["screen_title"] = StaticText("Assign service to IPTV Links")
        self["sat_header"] = StaticText("Satellite Channels")
        self["iptv_header"] = StaticText("IPTV Channels")
        self["sat_info"] = StaticText("Bouquet: loading...")
        self["iptv_info"] = StaticText("Category: loading...")
        self["sat_list"] = ColorMenuList([], width=800, font_size=FONT_LIST, item_height=ROW_LIST, selected_bg=SELECT_BG, selected_fg=TEXT_MAIN)
        self["iptv_list"] = ColorMenuList([], width=800, font_size=FONT_LIST, item_height=ROW_LIST, selected_bg=SELECT_BG, selected_fg=TEXT_MAIN)
        self["key_red"] = StaticText("Exit")
        self["key_green"] = StaticText("Assign")
        self["key_yellow"] = StaticText("Remove")
        self["key_arrows"] = StaticText("Switch focus")
        self["key_menu"] = StaticText("Menu")
        self.active_list = "sat"
        self.updateFocusColors()
        self.bouquets = []
        self.satellites = []
        self.sat_items = []
        self.categories = []
        self.iptv_all = []
        self.iptv_items = []
        self.current_bouquet_idx = 0
        self.current_satellite_idx = 0
        self.current_satellite_ref = ""
        self.current_satellite_name = ""
        self.sat_source = "bouquet"
        self.current_category_id = "0"
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "cancel": self.safeClose,
            "red": self.safeClose,
            "green": self.assignCurrent,
            "yellow": self.removeCurrentMapping,
            "left": self.keyLeft,
            "right": self.keyRight,
            "up": self.keyUp,
            "down": self.keyDown,
            "ok": self.assignCurrent,
            "menu": self.openMenu,
        }, -1)
        self.onLayoutFinish.append(self.onReady)

    def onReady(self):
        self.applyListFonts(["sat_list", "iptv_list"], size_main=FONT_LIST, size_alt=FONT_LIST, item_height=ROW_LIST)
        self.loadData()
        self.updateFocusColors()

    def updateFocusColors(self):
        try:
            if self.active_list == "sat":
                self["sat_list"].setSelectionColors(SELECT_BG_ACTIVE, SELECT_TEXT_ACTIVE)
                self["iptv_list"].setSelectionColors(SELECT_BG, TEXT_MAIN)
            else:
                self["sat_list"].setSelectionColors(SELECT_BG, TEXT_MAIN)
                self["iptv_list"].setSelectionColors(SELECT_BG_ACTIVE, SELECT_TEXT_ACTIVE)
        except Exception as e:
            log("updateFocusColors error: %s" % e)

    def loadData(self):
        self.bouquets = get_tv_bouquets()
        self.satellites = get_satellite_directories()
        self.categories = get_live_categories()
        self.iptv_all = get_live_streams()
        self.current_bouquet_idx = 0
        self.current_satellite_idx = 0
        self.current_satellite_ref = ""
        self.current_satellite_name = ""
        self.sat_source = "bouquet"
        self.current_category_id = "0"
        self.reloadSatList()
        self.reloadIptvList()

    def keyLeft(self):
        self.active_list = "sat"
        self.updateFocusColors()

    def keyRight(self):
        self.active_list = "iptv"
        self.updateFocusColors()

    def keyUp(self):
        if self.active_list == "sat":
            self["sat_list"].up()
        else:
            self["iptv_list"].up()

    def keyDown(self):
        if self.active_list == "sat":
            self["sat_list"].down()
        else:
            self["iptv_list"].down()

    def reloadSatList(self):
        assigned_refs = set([normalize_sref(x.get("ref", "")) for x in load_mappings()])
        sat_rows = []
        if self.sat_source == "satellite" and self.current_satellite_ref:
            self.sat_items = get_services_from_ref(self.current_satellite_ref)
            info_text = "Satellite: %s" % ensure_text(self.current_satellite_name or "Unknown")
        else:
            self.sat_source = "bouquet"
            if not self.bouquets:
                self.sat_items = []
                self["sat_list"].setList([])
                self["sat_info"].setText("Bouquet: no bouquets found")
                return
            if self.current_bouquet_idx >= len(self.bouquets):
                self.current_bouquet_idx = 0
            current = self.bouquets[self.current_bouquet_idx]
            self.sat_items = get_services_from_bouquet(current["ref"])
            info_text = "Bouquet: %s" % ensure_text(current["name"])
        for row in self.sat_items:
            color = TEXT_GREEN if normalize_sref(row.get("ref", "")) in assigned_refs else TEXT_MAIN
            sat_rows.append({"text": ensure_text(row.get("name", "")), "color": color})
        self["sat_list"].setEntries(sat_rows)
        self["sat_info"].setText(info_text)
        self.updateFocusColors()

    def reloadIptvList(self):
        cid = ensure_text(self.current_category_id)
        if cid == "0":
            self.iptv_items = self.iptv_all[:]
        else:
            self.iptv_items = [x for x in self.iptv_all if ensure_text(x.get("category_id", "0")) == cid]
        cat_name = "All"
        for cat in self.categories:
            if ensure_text(cat.get("category_id", "0")) == cid:
                cat_name = ensure_text(cat.get("category_name", "All"))
                break
        assigned_urls = set([ensure_text(x.get("url", "")).strip() for x in load_mappings()])
        iptv_rows = []
        for row in self.iptv_items:
            url = ensure_text(row.get("url", "")).strip()
            color = TEXT_GREEN if url in assigned_urls else TEXT_RED
            iptv_rows.append({"text": ensure_text(row.get("name", "")), "color": color})
        self["iptv_list"].setEntries(iptv_rows)
        self["iptv_info"].setText("Category: %s" % cat_name)
        self.updateFocusColors()

    def openChoice(self, title, choices, callback, current_index=0):
        self.session.openWithCallback(callback, IP2SATChoiceScreen, title=title, choices=choices, current_index=current_index)

    def openMenu(self):
        choices = [
            ("Choose Satellite Bouquet", "bouquet"),
            ("Choose IPTV Category", "category"),
            ("Reload Lists", "reload"),
        ]
        self.openChoice("Assign Menu", choices, self.onMenuSelected, 0)

    def onMenuSelected(self, choice):
        if not choice:
            return
        action = choice[1]
        if action == "bouquet":
            self.chooseBouquet()
        elif action == "category":
            self.chooseCategory()
        elif action == "reload":
            self.loadData()

    def chooseBouquet(self):
        if not self.bouquets:
            self.session.open(MessageBox, "No satellite bouquets found", MessageBox.TYPE_ERROR, timeout=4)
            return
        choices = [(ensure_text(x["name"]), idx) for idx, x in enumerate(self.bouquets)]
        self.openChoice("Choose Satellite Bouquet", choices, self.onBouquetSelected, self.current_bouquet_idx)

    def onBouquetSelected(self, choice):
        if choice is None:
            return
        self.current_bouquet_idx = int(choice[1])
        self.sat_source = "bouquet"
        self.current_satellite_ref = ""
        self.current_satellite_name = ""
        self.reloadSatList()
        self.active_list = "sat"
        self.updateFocusColors()

    def chooseCategory(self):
        if not self.categories:
            self.session.open(MessageBox, "No IPTV categories found", MessageBox.TYPE_ERROR, timeout=4)
            return
        choices = [(ensure_text(x.get("category_name", "All")), ensure_text(x.get("category_id", "0"))) for x in self.categories]
        current_index = 0
        for idx, row in enumerate(self.categories):
            if ensure_text(row.get("category_id", "0")) == ensure_text(self.current_category_id):
                current_index = idx
                break
        self.openChoice("Choose IPTV Category", choices, self.onCategorySelected, current_index)

    def onCategorySelected(self, choice):
        if choice is None:
            return
        self.current_category_id = ensure_text(choice[1])
        self.reloadIptvList()
        self.active_list = "iptv"
        self.updateFocusColors()

    def chooseSatelliteChannelSearch(self):
        if not self.satellites:
            self.satellites = get_satellite_directories()
        if not self.satellites:
            self.session.open(MessageBox, "No satellites found", MessageBox.TYPE_ERROR, timeout=4)
            return
        choices = [(ensure_text(x["name"]), idx) for idx, x in enumerate(self.satellites)]
        self.openChoice("Choose Satellite", choices, self.onSatelliteSearchSatelliteSelected, self.current_satellite_idx)

    def onSatelliteSearchSatelliteSelected(self, choice):
        if not choice:
            return
        idx = int(choice[1])
        if idx < 0 or idx >= len(self.satellites):
            return
        sat = self.satellites[idx]
        self.current_satellite_idx = idx
        self.current_satellite_ref = ensure_text(sat.get("ref", ""))
        self.current_satellite_name = ensure_text(sat.get("name", ""))
        self.sat_source = "satellite"
        self.reloadSatList()
        if not self.sat_items:
            self.session.open(MessageBox, "No channels found on this satellite", MessageBox.TYPE_ERROR, timeout=4)
            return
        matches = [(ensure_text(item.get("name", "")), pos) for pos, item in enumerate(self.sat_items)]
        self.openChoice("Choose Channel from Satellite", matches, self.onSatelliteChannelSelected, self["sat_list"].getSelectionIndex())

    def onSatelliteChannelSelected(self, choice):
        if not choice:
            return
        idx = int(choice[1])
        self.active_list = "sat"
        move_menu_to_index(self["sat_list"], idx)

    def getCurrentSat(self):
        idx = self["sat_list"].getSelectionIndex()
        if idx < 0 or idx >= len(self.sat_items):
            return None
        return self.sat_items[idx]

    def getCurrentIptv(self):
        idx = self["iptv_list"].getSelectionIndex()
        if idx < 0 or idx >= len(self.iptv_items):
            return None
        return self.iptv_items[idx]

    def assignCurrent(self):
        sat = self.getCurrentSat()
        iptv = self.getCurrentIptv()
        if not sat:
            self.session.open(MessageBox, "Select a satellite channel first", MessageBox.TYPE_ERROR, timeout=3)
            return
        if not iptv:
            self.session.open(MessageBox, "Select an IPTV channel first", MessageBox.TYPE_ERROR, timeout=3)
            return
        if set_mapping(sat["ref"], sat["name"], iptv["url"]):
            self.reloadSatList()
            self.reloadIptvList()
            self.session.open(MessageBox, "Assigned\n%s\n=>\n%s" % (ensure_text(sat["name"]), ensure_text(iptv["name"])), MessageBox.TYPE_INFO, timeout=4)
        else:
            self.session.open(MessageBox, "Failed to save mapping", MessageBox.TYPE_ERROR, timeout=4)

    def removeCurrentMapping(self):
        sat = self.getCurrentSat()
        if not sat:
            self.session.open(MessageBox, "Select a satellite channel first", MessageBox.TYPE_ERROR, timeout=3)
            return
        ref = normalize_sref(sat.get("ref", ""))
        if not ref:
            self.session.open(MessageBox, "Invalid satellite service reference", MessageBox.TYPE_ERROR, timeout=3)
            return
        if remove_mapping(ref):
            self.reloadSatList()
            self.reloadIptvList()
            self.session.open(MessageBox, "Removed mapping for\n%s" % ensure_text(sat.get("name", "Unknown")), MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, "No saved mapping for this channel", MessageBox.TYPE_INFO, timeout=3)


MANAGE_SKIN = """
<screen name="IP2SATManageScreen" position="center,center" size="1920,1080" title="Reset or Remove channels from playlist" backgroundColor="#00000000" flags="wfNoBorder">
    <eLabel position="50,35" size="1820,1010" backgroundColor="%s" zPosition="0" />
    <eLabel position="50,35" size="1820,78" backgroundColor="%s" zPosition="1" />
    <eLabel position="80,120" size="1760,840" backgroundColor="%s" zPosition="1" />
    <eLabel position="80,968" size="1760,94" backgroundColor="%s" zPosition="1" />

    <widget source="screen_title" render="Label" position="78,52" size="1400,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget name="list" position="100,140" size="1720,800" itemHeight="%d" backgroundColor="%s" transparent="0" scrollbarMode="showOnDemand" zPosition="3" />

    <ePixmap position="100,1032" size="36,36" pixmap="%s/key_exit.png" alphatest="blend" zPosition="3" />
    <widget source="key_exit" render="Label" position="146,1024" size="200,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="420,1032" size="36,36" pixmap="%s/key_red.png" alphatest="blend" zPosition="3" />
    <widget source="key_red" render="Label" position="466,1024" size="260,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="880,1032" size="36,36" pixmap="%s/key_green.png" alphatest="blend" zPosition="3" />
    <widget source="key_green" render="Label" position="926,1024" size="280,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <ePixmap position="1430,1032" size="36,36" pixmap="%s/key_yellow.png" alphatest="blend" zPosition="3" />
    <widget source="key_yellow" render="Label" position="1476,1024" size="220,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
</screen>
""" % (
    PANEL_BG, HEADER_BG, LIST_BG, FOOTER_BG,
    FONT_TITLE, TEXT_MAIN, HEADER_BG,
    ROW_LIST, LIST_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
)


class IP2SATManageScreen(ThemedScreen):
    skin = MANAGE_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("Reset or Remove channels from playlist")
        self["screen_title"] = StaticText("Reset or Remove channels from playlist")
        self["list"] = ColorMenuList([], width=1680, font_size=FONT_LIST, item_height=ROW_LIST)
        self["key_exit"] = StaticText("Exit")
        self["key_red"] = StaticText("Reset All")
        self["key_green"] = StaticText("Remove")
        self["key_yellow"] = StaticText("Reload")
        self.mapping_items = []
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.safeClose,
            "red": self.askResetAll,
            "green": self.askRemoveCurrent,
            "yellow": self.reload,
            "ok": self.askRemoveCurrent,
        }, -1)
        self.onLayoutFinish.append(self.onReady)

    def onReady(self):
        self.applyListFonts(["list"], size_main=FONT_LIST, size_alt=FONT_LIST, item_height=ROW_LIST)
        self.reload()

    def reload(self):
        self.mapping_items = load_mappings()
        rows = [{"text": "%s   =>   %s" % (ensure_text(x.get("channel", "Unknown")), ensure_text(x.get("url", ""))), "color": TEXT_GREEN} for x in self.mapping_items]
        if not rows:
            rows = [{"text": "No channel mappings found in %s" % IP2SAT_JSON, "color": TEXT_MAIN}]
        self["list"].setEntries(rows)

    def askResetAll(self):
        self.session.openWithCallback(self.doResetAll, MessageBox, "Delete all channel mappings?", MessageBox.TYPE_YESNO)

    def doResetAll(self, answer):
        if answer:
            reset_mappings()
            self.reload()
            self.session.open(MessageBox, "All mappings were removed", MessageBox.TYPE_INFO, timeout=3)

    def getCurrentItem(self):
        idx = self["list"].getSelectionIndex()
        if idx < 0 or idx >= len(self.mapping_items):
            return None
        return self.mapping_items[idx]

    def askRemoveCurrent(self):
        item = self.getCurrentItem()
        if not item:
            return
        self.session.openWithCallback(self.doRemoveCurrent, MessageBox, "Remove mapping for channel:\n%s" % ensure_text(item.get("channel", "Unknown")), MessageBox.TYPE_YESNO)

    def doRemoveCurrent(self, answer):
        if not answer:
            return
        item = self.getCurrentItem()
        if not item:
            return
        remove_mapping(item.get("ref", ""))
        self.reload()
        self.session.open(MessageBox, "Selected mapping removed", MessageBox.TYPE_INFO, timeout=3)


INFO_SKIN = """
<screen name="IP2SATInfoScreen" position="center,center" size="1920,1080" title="IP2SAT Info" backgroundColor="#00000000" flags="wfNoBorder">
    <eLabel position="50,35" size="1820,1010" backgroundColor="%s" zPosition="0" />
    <eLabel position="50,35" size="1820,78" backgroundColor="%s" zPosition="1" />
    <eLabel position="80,120" size="640,840" backgroundColor="%s" zPosition="1" />
    <eLabel position="760,120" size="510,840" backgroundColor="%s" zPosition="1" />
    <eLabel position="1310,120" size="510,840" backgroundColor="%s" zPosition="1" />
    <eLabel position="80,968" size="1740,54" backgroundColor="%s" zPosition="1" />

    <widget source="screen_title" render="Label" position="78,52" size="980,56" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget source="title" render="Label" position="100,142" size="560,50" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
    <widget source="support" render="Label" position="100,188" size="580,700" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />

    <widget source="left_qr_title" render="Label" position="790,142" size="450,50" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" halign="center" transparent="1" zPosition="3" />
    <widget name="whatsapp_qr" position="840,250" size="350,350" zPosition="3" />
    <widget source="left_qr_text" render="Label" position="790,650" size="450,96" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" halign="center" valign="center" transparent="1" zPosition="3" />

    <widget source="right_qr_title" render="Label" position="1340,142" size="450,50" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" halign="center" transparent="1" zPosition="3" />
    <widget name="paypal_qr" position="1390,250" size="350,350" zPosition="3" />
    <widget source="right_qr_text" render="Label" position="1340,650" size="450,96" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" halign="center" valign="center" transparent="1" zPosition="3" />

    <ePixmap position="100,972" size="36,36" pixmap="%s/key_exit.png" alphatest="blend" zPosition="3" />
    <widget source="key_exit" render="Label" position="146,968" size="200,48" font="Regular;%d" foregroundColor="%s" backgroundColor="%s" transparent="1" zPosition="3" />
</screen>
""" % (
    PANEL_BG, HEADER_BG, LIST_BG, LIST_BG, LIST_BG, FOOTER_BG,
    FONT_TITLE, TEXT_MAIN, HEADER_BG,
    FONT_SECTION, TEXT_MAIN, LIST_BG,
    FONT_TEXT, TEXT_DIM, LIST_BG,
    FONT_SECTION, TEXT_MAIN, LIST_BG,
    FONT_TEXT, TEXT_DIM, LIST_BG,
    FONT_SECTION, TEXT_MAIN, LIST_BG,
    FONT_TEXT, TEXT_DIM, LIST_BG,
    BUTTONS_PATH, FONT_FOOTER, TEXT_MAIN, FOOTER_BG,
)


class IP2SATInfoScreen(ThemedScreen):
    skin = INFO_SKIN

    def __init__(self, session):
        from Components.Pixmap import Pixmap
        from Tools.LoadPixmap import LoadPixmap
        Screen.__init__(self, session)
        self.setTitle("IP2SAT Info")
        self["screen_title"] = StaticText("IP2SAT Info")
        self["title"] = StaticText("Support and Contact")
        self["support"] = StaticText(
            "Plugin: IP2SAT\n"
            "By: mosad\n"
            "Mode: Signal mode IPTV on Satellite services\n"
            "Compatibility: Python 2 / Python 3 / DreamOS\n"
            "Playlist: /etc/enigma2/ip2sat.json"
        )
        self["left_qr_title"] = StaticText("WhatsApp")
        self["left_qr_text"] = StaticText("Scan to open WhatsApp")
        self["right_qr_title"] = StaticText("PayPal")
        self["right_qr_text"] = StaticText("Scan to open PayPal")
        self["key_exit"] = StaticText("Exit")
        self["whatsapp_qr"] = Pixmap()
        self["paypal_qr"] = Pixmap()
        self.whatsapp_pix = LoadPixmap(path=WHATSAPP_QR) if os.path.exists(WHATSAPP_QR) else None
        self.paypal_pix = LoadPixmap(path=PAYPAL_QR) if os.path.exists(PAYPAL_QR) else None
        self["actions"] = ActionMap(["OkCancelActions"], {"cancel": self.safeClose, "ok": self.safeClose}, -1)
        self.onLayoutFinish.append(self.applyPixmaps)

    def applyPixmaps(self):
        try:
            if self.whatsapp_pix is not None:
                self["whatsapp_qr"].instance.setPixmap(self.whatsapp_pix)
            if self.paypal_pix is not None:
                self["paypal_qr"].instance.setPixmap(self.paypal_pix)
        except Exception as e:
            log("applyPixmaps error: %s" % e)


def main(session, **kwargs):
    session.open(IP2SATMain)


def sessionStart(reason, **kwargs):
    global BRIDGE_INSTANCE
    if reason == 0 and "session" in kwargs and BRIDGE_INSTANCE is None:
        try:
            BRIDGE_INSTANCE = IP2SATBridge(kwargs["session"])
        except Exception as e:
            log("sessionStart error: %s" % e)
            log(traceback.format_exc())


def Plugins(path=None, **kwargs):
    return [
        PluginDescriptor(name=PLUGIN_NAME, description=PLUGIN_DESC, where=[PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main, icon="plugin.png"),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionStart),
    ]
