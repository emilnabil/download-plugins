#!/bin/sh

CONFIG_FILE="/usr/lib/enigma2/python/Plugins/Extensions/EmilMultiCamManager/config.txt"
NCAM_CONFIG_PATH="/etc/tuxbox/config/ncam.server"
OSCAM_CONFIG_PATH="/etc/tuxbox/config/oscam.server"
CCCAM_CONFIG_PATH="/etc/tuxbox/config/CCcam.cfg"
CCCAM_MAIN_CONFIG="/etc/CCcam.cfg"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: Config file not found!"
    exit 1
fi

SERVER_HOST=$(grep "SERVER_HOST=" "$CONFIG_FILE" | cut -d'=' -f2)
SERVER_PORT=$(grep "SERVER_PORT=" "$CONFIG_FILE" | cut -d'=' -f2)
SERVER_USER=$(grep "SERVER_USER=" "$CONFIG_FILE" | cut -d'=' -f2)
SERVER_PASS=$(grep "SERVER_PASS=" "$CONFIG_FILE" | cut -d'=' -f2)

if [ -z "$SERVER_HOST" ] || [ -z "$SERVER_PORT" ] || [ -z "$SERVER_USER" ] || [ -z "$SERVER_PASS" ]; then
    echo "Error: Missing server details!"
    exit 1
fi

echo "Adding server: $SERVER_HOST:$SERVER_PORT"

if [ ! -d "/etc/tuxbox/config" ]; then
    mkdir -p "/etc/tuxbox/config"
fi

for FILE in "$CCCAM_CONFIG_PATH" "$CCCAM_MAIN_CONFIG"; do
    if [ ! -f "$FILE" ]; then
        touch "$FILE"
    fi
done

chmod 666 "$NCAM_CONFIG_PATH" "$OSCAM_CONFIG_PATH" "$CCCAM_CONFIG_PATH" "$CCCAM_MAIN_CONFIG" 2>/dev/null

if ! grep -q "$SERVER_HOST,$SERVER_PORT" "$NCAM_CONFIG_PATH" 2>/dev/null; then
    echo "[Adding to NCam]"
    cat >> "$NCAM_CONFIG_PATH" <<EOL

[reader]
label = ncam_server_$(date +%s)
protocol = cccam
device = $SERVER_HOST,$SERVER_PORT
user = $SERVER_USER
password = $SERVER_PASS
EOL
fi

if ! grep -q "$SERVER_HOST,$SERVER_PORT" "$OSCAM_CONFIG_PATH" 2>/dev/null; then
    echo "[Adding to OScam]"
    cat >> "$OSCAM_CONFIG_PATH" <<EOL

[reader]
label = oscam_server_$(date +%s)
protocol = cccam
device = $SERVER_HOST,$SERVER_PORT
user = $SERVER_USER
password = $SERVER_PASS
EOL
fi

for FILE in "$CCCAM_CONFIG_PATH" "$CCCAM_MAIN_CONFIG"; do
    if ! grep -q "C: $SERVER_HOST $SERVER_PORT $SERVER_USER $SERVER_PASS" "$FILE" 2>/dev/null; then
        echo "[Adding to $FILE]"
        echo "C: $SERVER_HOST $SERVER_PORT $SERVER_USER $SERVER_PASS" >> "$FILE"
    fi
done

chmod 644 "$NCAM_CONFIG_PATH" "$OSCAM_CONFIG_PATH" "$CCCAM_CONFIG_PATH" "$CCCAM_MAIN_CONFIG"

for CAM in ncam oscam CCcam; do
    if command -v "$CAM" >/dev/null 2>&1; then
        killall -9 "$CAM" 2>/dev/null
        "$CAM" &
    else
        echo "Warning: $CAM not found!"
    fi
done

echo "Servers added successfully!"



