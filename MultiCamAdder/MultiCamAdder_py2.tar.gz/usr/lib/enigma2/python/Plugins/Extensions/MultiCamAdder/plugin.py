from __future__ import print_function
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigInteger, getConfigListEntry
from Components.Console import Console

class MultiCamAdderScreen(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="800,600" title="MultiCamAdder">
            <widget name="config" position="30,30" size="740,500"
itemHeight="90" scrollbarMode="showOnDemand"/>
            <eLabel text="Cancel" position="50,550" size="174,40" font="Bold;30" halign="center" valign="center" backgroundColor="red" foregroundColor="white"/>
            <eLabel text="Cccam" position="313,550" size="174,40" font="Bold;30" halign="center" valign="center" backgroundColor="#006400" foregroundColor="white"/>
            <eLabel text="Newcamd" position="576,550" size="174,40" font="Bold;30" halign="center" valign="center" backgroundColor="#B8860B" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.exit,
            "red": self.exit,
            "green": self.saveSettings,
            "yellow": self.convertToNewcamd
        }, -2)

        self.server_host = ConfigText(default="server.example.com", fixed_size=False)
        self.server_port = ConfigInteger(default=12345, limits=(1, 65535))
        self.server_user = ConfigText(default="username", fixed_size=False)
        self.server_pass = ConfigText(default="password", fixed_size=False)

        ConfigListScreen.__init__(self, [
            getConfigListEntry("Server Host:", self.server_host),
            getConfigListEntry("Server Port:", self.server_port),
            getConfigListEntry("Username:", self.server_user),
            getConfigListEntry("Password:", self.server_pass),
        ])

    def saveSettings(self):
        data = {
            "SERVER_HOST": self.server_host.value,
            "SERVER_PORT": str(self.server_port.value),
            "SERVER_USER": self.server_user.value,
            "SERVER_PASS": self.server_pass.value
        }
        self.writeConfigFile(data, "cccam")
        self.session.open(MessageBox, "Server Added Successfully!", MessageBox.TYPE_INFO, timeout=3)
        Console().ePopen("/usr/lib/enigma2/python/Plugins/Extensions/MultiCamAdder/script.sh")

    def convertToNewcamd(self):
        data = {
            "SERVER_HOST": self.server_host.value,
            "SERVER_PORT": str(self.server_port.value),
            "SERVER_USER": self.server_user.value,
            "SERVER_PASS": self.server_pass.value
        }
        self.writeConfigFile(data, "newcamd")
        self.session.open(MessageBox, "Converted to Newcamd Successfully!", MessageBox.TYPE_INFO, timeout=3)

    def writeConfigFile(self, data, protocol):
        config_paths = {
            "cccam": [
                "/etc/tuxbox/config/ncam.server",
                "/etc/tuxbox/config/oscam.server",
                "/etc/tuxbox/config/cccam.cfg",
                "/etc/CCcam.cfg",
                "/etc/tuxbox/config/CCcam.cfg"
            ],
            "newcamd": [
                "/etc/tuxbox/config/ncam.server",
                "/etc/tuxbox/config/oscam.server",
                "/etc/tuxbox/config/cccam.cfg",
                "/etc/CCcam.cfg",
                "/etc/tuxbox/config/CCcam.cfg"
            ]
        }

        for path in config_paths[protocol]:
            if protocol == "cccam":
                if "CCcam.cfg" in path or "cccam.cfg" in path:
                    content = "C: {} {} {} {}\n".format(data["SERVER_HOST"], data["SERVER_PORT"], data["SERVER_USER"], data["SERVER_PASS"])
                else:
                    content = """
[reader]
label = my_server
protocol = cccam
device = {},{}
user = {}
password = {}
""".format(data["SERVER_HOST"], data["SERVER_PORT"], data["SERVER_USER"], data["SERVER_PASS"])
            else:
                if "CCcam.cfg" in path or "cccam.cfg" in path:
                    content = "N: {} {} {} {} 01 02 03 04 05 06 07 08 09 10 11 12 13 14\n".format(data["SERVER_HOST"], data["SERVER_PORT"], data["SERVER_USER"], data["SERVER_PASS"])
                else:
                    content = """
[reader]
label = my_server
protocol = newcamd
device = {},{}
key = 01 02 03 04 05 06 07 08 09 10 11 12 13 14
user = {}
password = {}
""".format(data["SERVER_HOST"], data["SERVER_PORT"], data["SERVER_USER"], data["SERVER_PASS"])

            try:
                f = open(path, "a")
                f.write(content)
                f.close()
            except IOError:
                print("Error writing to file:", path)

    def exit(self):
        self.close()

def Plugins(**kwargs):
    return [PluginDescriptor(name="MultiCamAdder",
                             description="Add NCam, OScam, and CCcam servers",
                             where=PluginDescriptor.WHERE_PLUGINMENU,
                             icon="/usr/lib/enigma2/python/Plugins/Extensions/MultiCamAdder/icon.png",
                             fnc=lambda session, **kwargs: session.open(MultiCamAdderScreen))]




