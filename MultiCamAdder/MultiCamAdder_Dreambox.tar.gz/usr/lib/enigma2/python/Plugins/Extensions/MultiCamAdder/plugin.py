# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigInteger, getConfigListEntry
from Components.Console import Console

class PortConfigInteger(ConfigInteger):
    def __init__(self, default=0):
        ConfigInteger.__init__(self, default=default, limits=(0, 65535))

    def getText(self):
        return str(int(self.value)) if self.value != 0 else "0"

class MultiCamAdderScreen(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="800,600" title="MultiCamAdder">
            <widget name="config" position="30,30" size="740,500"
                itemHeight="90" font="Regular;35" scrollbarMode="showOnDemand"/>
            <eLabel text="Cancel" position="50,550" size="174,40" font="Regular;30" 
                halign="center" valign="center" backgroundColor="red" foregroundColor="white"/>
            <eLabel text="Cccam" position="313,550" size="174,40" font="Regular;30" 
                halign="center" valign="center" backgroundColor="#006400" foregroundColor="white"/>
            <eLabel text="Newcamd" position="576,550" size="174,40" font="Regular;30" 
                halign="center" valign="center" backgroundColor="#B8860B" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "cancel": self.exit,
            "red": self.exit,
            "green": self.saveSettings,
            "yellow": self.convertToNewcamd,
            "ok": self.openKeyboard
        }, -2)

        self.server_host = ConfigText(default="server.example.com", fixed_size=False)
        self.server_port = PortConfigInteger(default=12345)
        self.server_user = ConfigText(default="username", fixed_size=False)
        self.server_pass = ConfigText(default="password", fixed_size=False)

        self.list = [
            getConfigListEntry("Server Host:", self.server_host),
            getConfigListEntry("Server Port:", self.server_port),
            getConfigListEntry("Username:", self.server_user),
            getConfigListEntry("Password:", self.server_pass),
        ]

        ConfigListScreen.__init__(self, self.list)

    def openKeyboard(self):
        current_item = self["config"].getCurrent()
        if current_item:
            current_config = current_item[1]
            if isinstance(current_config, PortConfigInteger):
                current_value = str(int(current_config.value))
            else:
                current_value = str(current_config.value)

            self.session.openWithCallback(
                lambda text: self.keyboardCallback(text, current_config),
                VirtualKeyBoard,
                title="Enter {0}".format(current_item[0]),
                text=current_value
            )

    def keyboardCallback(self, text, config_item):
        if text is not None:
            try:
                if isinstance(config_item, PortConfigInteger):
                    # Remove leading zeros while preserving zero value
                    cleaned_text = text.lstrip('0')
                    config_item.value = int(cleaned_text) if cleaned_text else 0
                else:
                    config_item.value = text
                self["config"].invalidateCurrent()
            except ValueError:
                self.session.open(MessageBox, "Invalid input! Please enter a valid number.", MessageBox.TYPE_ERROR, timeout=3)

    def saveSettings(self):
        try:
            port_value = int(self.server_port.value)
            if not (0 <= port_value <= 65535):
                raise ValueError("Port out of range")
        except ValueError:
            self.session.open(MessageBox, "Invalid port value! Please enter a number between 0 and 65535.", MessageBox.TYPE_ERROR, timeout=3)
            return

        self.writeConfigFile("cccam")
        self.session.open(MessageBox, "Server Added Successfully!", MessageBox.TYPE_INFO, timeout=3)
        
        # Run script to restart softcam
        Console().ePopen("/usr/lib/enigma2/python/Plugins/Extensions/MultiCamAdder/script.sh")

    def convertToNewcamd(self):
        try:
            port_value = int(self.server_port.value)
            if not (0 <= port_value <= 65535):
                raise ValueError("Port out of range")
        except ValueError:
            self.session.open(MessageBox, "Invalid port value! Please enter a number between 0 and 65535.", MessageBox.TYPE_ERROR, timeout=3)
            return

        self.writeConfigFile("newcamd")
        self.session.open(MessageBox, "Converted to Newcamd Successfully!", MessageBox.TYPE_INFO, timeout=3)

    def writeConfigFile(self, protocol):
        data = {
            "SERVER_HOST": self.server_host.value,
            "SERVER_PORT": str(int(self.server_port.value)),
            "SERVER_USER": self.server_user.value,
            "SERVER_PASS": self.server_pass.value
        }

        config_paths = {
            "cccam": [
                "/etc/tuxbox/config/ncam.server",
                "/etc/tuxbox/config/oscam.server",
                "/etc/tuxbox/config/CCcam.cfg",
                "/etc/CCcam.cfg"
            ],
            "newcamd": [
                "/etc/tuxbox/config/ncam.server",
                "/etc/tuxbox/config/oscam.server",
                "/etc/tuxbox/config/CCcam.cfg",
                "/etc/CCcam.cfg"
            ]
        }

        for path in config_paths[protocol]:
            try:
                if "CCcam.cfg" in path or "cccam.cfg" in path:
                    if protocol == "cccam":
                        content = "C: {SERVER_HOST} {SERVER_PORT} {SERVER_USER} {SERVER_PASS}\n".format(**data)
                    else:
                        content = "N: {SERVER_HOST} {SERVER_PORT} {SERVER_USER} {SERVER_PASS} 01 02 03 04 05 06 07 08 09 10 11 12 13 14\n".format(**data)
                else:
                    if protocol == "cccam":
                        content = """
[reader]
label                         = My_Server
protocol                      = cccam
device                        = {SERVER_HOST},{SERVER_PORT}
user                          = {SERVER_USER}
password                      = {SERVER_PASS}
group                         = 1,2,3,4,5,6,7,8,9,10,64
emmcache                      = 2,1,2,1
cccversion                    = 2.0.11
ccckeepalive                  = 1
cccmaxhops                    = 2 # dont use higher than 3 !!!
disablecrccws                 = 1
cccwantemu                    = 1
blockemm-unknown              = 1
blockemm-u                    = 1
blockemm-s                    = 1
blockemm-g                    = 1
audisabled                    = 1
services                      = !powervu_fake,!tandberg_fake,!biss_fake,!afn_fake,1708:000000
disablecrccws_only_for        = 1709:000000;1708:000000;1811:003311,003315;09C4:000000;0500:030B00,042820;0604:000000;1819:00006D;0100:00006D;1810:000000;1884:000000;0E00:000000
""".format(**data)
                    else:
                        content = """
[reader]
label                         = newcamd_server
enable                        = 1
protocol                      = newcamd
device                        = {SERVER_HOST},{SERVER_PORT}
key                           = 0102030405060708091011121314
user                          = {SERVER_USER}
password                      = {SERVER_PASS}
services                      = !powervu_fake,!tandberg_fake,!biss_fake,!afn_fake,1708:000000
fallback                      = 1
group                         = 1,2,3,4,5,6,7,8,9,10,64
disablecrccws                 = 1
audisabled                    = 1
disablecrccws_only_for        = 1709:000000;1708:000000;1811:003311,003315;09C4:000000;0500:030B00,042820;0604:000000;1819:00006D;0100:00006D;1810:000000;1884:000000;0E00:000000
""".format(**data)

                # Write to file
                with open(path, "a") as f:
                    f.write(content)
            except IOError as e:
                print "Error writing to {0}: {1}".format(path, e)

    def exit(self):
        self.close()

def main(session, **kwargs):
    session.open(MultiCamAdderScreen)

def Plugins(**kwargs):
    return [PluginDescriptor(
        name="MultiCamAdder",
        description="Add NCam, OScam, and CCcam servers",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="/usr/lib/enigma2/python/Plugins/Extensions/MultiCamAdder/icon.png",
        fnc=main
    )]

