#!/bin/sh
#### "*******************************************"
#### "*  ..::   Edit BY RAED - Fairbird   ::..  *"
#### "*******************************************"

CAMNAME="CCcam 2.3.9"
BINARY="CCcam_2.3.9"


remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/pid.info /tmp/cardinfo /tmp/mg*
}

case "$1" in
	start)
	remove_tmp
	/var/bin/$BINARY &
	sleep 3
	;;
	stop)
	killall -9 $BINARY
	remove_tmp
	sleep 2
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0
