#!/bin/sh
########################################
######      Edited by RAED        ######
########################################

/usr/emuscript/CCcam239_em.sh stop

rm -rf /var/bin/CCcam_2.3.9
rm -rf /var/emuscript/CCcam239_em.sh
rm -rf /var/uninstall/CCcam239_remove.sh

exit 0
