#!/bin/sh
#### "*******************************************"
#### "*  ..::   Edit BY RAED - Fairbird   ::..  *"
#### "*******************************************"

CAMNAME="CCcam 2.3.9"
BINARY="CCcam_2.3.9"

remove_tmp () {
  rm -rf /tmp/*.tmp* /tmp/*.info*
}

case "$1" in
  start)
  remove_tmp
  /usr/bin/$BINARY &
  ;;
  stop)
  killall -9 $BINARY 2>/dev/null
  sleep 2
  remove_tmp
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
