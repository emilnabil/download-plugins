#!/bin/sh
#### "*******************************************"
#### "*  ..::   Edit BY RAED - Fairbird   ::..  *"
#### "*******************************************"

CAMNAME="CCcam 2.3.9"
BINARY="CCcam_2.3.9"

usage()
{
	echo "Usage: $0 {start|stop|restart|reload}"
}

if [ $# -lt 1 ] ; then usage ; break ; fi
action=$1

case "$action" in
start)
	echo "[SCRIPT] $1: $CAMNAME"
	/usr/bin/$BINARY &
	;;
stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 $BINARY
	;;
restart|reload)
	$0 stop
	$0 start
	;;
*)
	usage
	;;
esac

exit 0
