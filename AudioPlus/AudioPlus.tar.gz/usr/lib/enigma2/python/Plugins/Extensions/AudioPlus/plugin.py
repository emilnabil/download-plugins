# -*- coding: utf-8 -*-

from Plugins.Plugin import PluginDescriptor
from enigma import addFont

addFont("/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/fonts/digicon.ttf", "di", 100, 1)
addFont("/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/fonts/arial.ttf", "Regular", 100, 1)

try:
	from . import apx
	version = getattr(apx, "version", "")
except Exception:
	apx = None
	version = ""


def _log(err):
	try:
		import sys
		from time import localtime
		nt = localtime()
		tm = "{:02d}:{:02d}:{:02d}".format(nt.tm_hour, nt.tm_min, nt.tm_sec)
		line = "N/A"
		try:
			line = sys.exc_info()[2].tb_lineno
		except Exception:
			pass
		with open("/tmp/AudioPlus.log", "a+") as f:
			f.write("[{}]plugin, {}, line:{}\n".format(tm, err, line))
	except Exception:
		pass


def _get_apx():
	global apx, version
	if apx is None:
		from . import apx as apx_module
		apx = apx_module
		version = getattr(apx, "version", version)
	return apx


def load_audioplus(force=False):
	module = _get_apx().load_audioplus(force=force)
	return module


def install_audioselection_patch():
	try:
		from . import audioselection_hooks
		audioselection_hooks.install()
	except Exception as err:
		_log(err)


# Install only the hook early. audioplus.py itself is loaded lazily from apx.py
# when AudioPlus is opened or when the native Select Audio Track list needs it.
install_audioselection_patch()


def _open_audioplus(session, force=True):
	module = load_audioplus(force=force)
	screen = getattr(module, "audioplus", None)
	if screen is None:
		raise AttributeError("audioplus screen class not found")
	session.open(screen)


def main(session, **kwargs):
	try:
		install_audioselection_patch()
		_open_audioplus(session, force=True)
	except Exception as err:
		_log(err)
		try:
			session.open(_get_apx().apx)
		except Exception as err2:
			_log(err2)


def audiomenu(session, **kwargs):
	try:
		install_audioselection_patch()
		_open_audioplus(session, force=True)
	except Exception as err:
		_log(err)
		try:
			session.open(_get_apx().apx)
		except Exception as err2:
			_log(err2)


def sessionstart(reason, session=None, **kwargs):
	try:
		install_audioselection_patch()
	except Exception as err:
		_log(err)


def Plugins(**kwargs):
	install_audioselection_patch()
	plugins = []
	plugins.append(PluginDescriptor(name="AudioPlus {}".format(version), description="background audio playback...", where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main))
	plugins.append(PluginDescriptor(name="AudioPlus {}".format(version), description="background audio playback...", where=PluginDescriptor.WHERE_AUDIOMENU, fnc=audiomenu))
	try:
		plugins.append(PluginDescriptor(name="AudioPlus AudioSelection Patch", where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart))
	except Exception:
		pass
	return plugins
