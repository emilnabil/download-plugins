# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from enigma import getDesktop
version="vXXXX"
desktop_size = getDesktop(0).size().width()
if desktop_size <= 1280:
	blue = """
		<screen name="ap" position="center,center" size="1280,720" title="..." flags="wfNoBorder">
			<ePixmap position="0,0" size="1280,720" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/BlueHD.png" />
			<ePixmap position="1102,680" size="169,38" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/infomenu_HD.png" alphatest="blend" />
			<widget name="list" position="20,120" size="610,510" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#183e51" backgroundColorSelected="#0a566d" foregroundColorSelected="#ffffff" />
			<widget name="status" osition="20,120" size="613,720" transparent="1" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#183e51" halign="center" valign="center" zPosition="1" />
			<widget name="curCh" position="830,300" size="430,30" transparent="1" font="Regular; 20" foregroundColor="#ffffff" backgroundColor="#183e51" halign="left" valign="center" />
			<widget name="now_evnt" position="830,330" size="430,30" transparent="1" font="Regular; 20" noWrap="1" foregroundColor="#ffffff" backgroundColor="#3478c1" halign="left" valign="center" />
			<widget name="next_evnt" position="830,360" size="430,30" transparent="1" font="Regular; 20" noWrap="1" foregroundColor="#ffffff" backgroundColor="#3478c1" halign="left" valign="center" />
			<widget name="desc" position="830,402" size="430,230" transparent="1" font="Regular; 20" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="top" zPosition="1" />
			<widget name="audioSource" position="25,60" size="600,30" transparent="1" font="Regular; 22" foregroundColor="#00eeff" backgroundColor="#183e51" halign="left" zPosition="2" />
			<widget name="info" position="25,90" size="600,30" transparent="1" font="Regular; 22" foregroundColor="#00eeff" backgroundColor="#183e51" halign="left" zPosition="2" />
			<widget source="session.VideoPicture" render="Pig" position="770,76" size="366,206" backgroundColor="#ff000000" zPosition="11" />
			<widget name="picon" position="675,300" size="146,88" transparent="1" alphatest="blend" zPosition="11" />

			<widget source="global.CurrentTime" render="Label" position="1200,14" size="80,26" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#0f7c9d" valign="center" halign="center" transparent="1">
				<convert type="ClockToText">Format:%H:%M</convert>
			</widget>
			<!-- <widget name="int_statu" position="1220,6" size="53,40" transparent="1" alphatest="blend" zPosition="2" /> -->
			<eLabel text="Close" backgroundColor="#183e51" position="60,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
			<eLabel text="Server 1" backgroundColor="#183e51" position="320,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
			<eLabel text="Server 2" backgroundColor="#183e51" position="590,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
			<eLabel text="Reset" backgroundColor="#183e51" position="855,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		</screen>"""
	blue_setup = """
<screen name="MenuSetup" position="center,center" size="1280,720" title="..." backgroundColor="#183e51" flags="wfNoBorder">
		<widget name="config" position="13,76" size="613,200" itemHeight="26" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#183e51" backgroundColorSelected="#0a566d" foregroundColorSelected="#ffffff" />
		<ePixmap position="0,0" size="1280,720" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/BlueHD.png" />
		<ePixmap position="824,366" size="266,213" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/setup_HD.png" alphatest="blend" />
		<widget source="session.VideoPicture" render="Pig" position="770,76" size="366,206" backgroundColor="#ff000000" zPosition="11" />
		<widget name="status" position="726,13" size="443,26" transparent="1" font="Regular; 20" foregroundColor="#ffffff" backgroundColor="#0a566d" halign="center" valign="center" />
		<widget name="info" position="740,604" size="500,40" transparent="1" font="Regular; 22" foregroundColor="#00e5ff" backgroundColor="#183e51" halign="center" valign="center" zPosition="1" />
		<eLabel text="Close" backgroundColor="#183e51" position="60,685" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Save" backgroundColor="#183e51" position="320,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Update" backgroundColor="#183e51" position="590,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Keyboard" backgroundColor="#183e51" position="855,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<widget name="Picture" position="120,350" size="440,247" transparent="1" alphatest="off" zPosition="11" />
</screen>
"""
	darkBlue="""
	<screen name="ap" position="center,center" size="1280,720" title="..." flags="wfNoBorder">
		<ePixmap position="0,0" size="1280,720" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/DarkBlueHD.png" />
		<ePixmap position="1102,680" size="169,38" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/infomenu_HD.png" alphatest="blend" />
		<widget name="list" position="656,120" size="613,510" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#141e28" backgroundColorSelected="#0a566d" foregroundColorSelected="#00ffff" />
		<widget name="status" position="656,120" size="613,550" transparent="1" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#141e28" halign="center" valign="center" />
		<widget source="session.VideoPicture" render="Pig" position="130,76" size="366,206" backgroundColor="#ff000000" zPosition="11" />
		<widget name="picon" position="13,303" size="146,88" transparent="1" alphatest="blend" zPosition="11" />
		<widget source="global.CurrentTime" render="Label" position="1200,14" size="80,26" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#143447" valign="center" halign="center" transparent="1">
			<convert type="ClockToText">Format:%H:%M</convert>
		</widget>
		<!-- <widget name="int_statu" position="1220,6" size="53,40" transparent="1" alphatest="blend" zPosition="2" /> -->
		<widget name="curCh" position="175,300" size="430,30" transparent="1" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#183e51" halign="left" valign="center" />
		<widget name="now_evnt" position="180,330" size="430,26" transparent="1" font="Regular; 22" noWrap="1" foregroundColor="#ffffff" backgroundColor="#3478c1" halign="left" valign="center" />
		<widget name="next_evnt" position="180,360" size="430,26" transparent="1" font="Regular; 22" noWrap="1" foregroundColor="#ffffff" backgroundColor="#3478c1" halign="left" valign="center" />
		<widget name="audioSource" position="656,60" size="613,30" transparent="1" font="Regular; 22" foregroundColor="#00eeff" backgroundColor="#183e51" halign="left" zPosition="2" />
		<widget name="info" position="656,90" size="613,30" transparent="1" font="Regular; 22" foregroundColor="#00eeff" backgroundColor="#183e51" halign="left" zPosition="2" />
		<widget name="desc" position="20,412" size="610,232" transparent="1" font="Regular; 20" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="top" zPosition="1" />
		<eLabel text="Close" backgroundColor="#183e51" position="60,685" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Server 1" backgroundColor="#183e51" position="320,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Server 2" backgroundColor="#183e51" position="590,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Reset" backgroundColor="#183e51" position="855,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
	</screen>"""
	darkBlue_setup="""
<screen name="MenuSetup" position="center,center" size="1280,720" title="..." backgroundColor="#141e28" flags="wfNoBorder">
		<widget name="config" position="655,75" size="613,200" itemHeight="26" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#141e28" backgroundColorSelected="#0a566d" foregroundColorSelected="#ffffff" />
		<ePixmap position="0,0" size="1280,720" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/DarkBlueHD.png" />
		<ePixmap position="182,375" size="266,213" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/setup_HD.png" alphatest="blend" />
		<widget source="session.VideoPicture" render="Pig" position="130,76" size="366,206" backgroundColor="#ff000000" zPosition="11" />
		<widget name="status" position="726,13" size="443,26" transparent="1" font="Regular; 20" foregroundColor="white" backgroundColor="#0a566d" halign="center" valign="center" />
		<widget name="info" position="40,615" size="600,40" transparent="1" font="Regular; 22" foregroundColor="#00e5ff" backgroundColor="#141e28" halign="center" valign="center" zPosition="1" />
		<eLabel text="Close" backgroundColor="#183e51" position="60,685" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Save" backgroundColor="#183e51" position="320,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Update" backgroundColor="#183e51" position="590,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<eLabel text="Keyboard " backgroundColor="#183e51" position="855,687" size="200,26" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />
		<widget name="Picture" position="769,359" size="440,247" transparent="1" alphatest="off" zPosition="11" />
	</screen>"""

	dark="""
	<screen name="ap" position="center,center" size="640,600" title="..." backgroundColor="#222230" flags="wfNoBorder">
		<eLabel name="" position="0,0" size="640,40" transparent="0" backgroundColor="#454556" zPosition="0" />
		<widget name="title" position="20,0" size="640,40" transparent="1" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#454556"  zPosition="1" halign="left" valign="center" />
		<widget name="curCh" position="15,50" size="600,26" transparent="1" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#454556" halign="left" valign="center" />
		<widget name="now_evnt" position="15,80" size="600,26" transparent="1" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#454556" halign="left" valign="center" />
		<widget name="audioSource" position="20,120" size="600,30" transparent="1" font="Regular; 22" foregroundColor="#8bc1a2" backgroundColor="#183e51" halign="left" zPosition="2" />
		<widget name="info" position="20,150" size="600,30" transparent="1" font="Regular; 22" foregroundColor="#8bc1a2" backgroundColor="#00000000" halign="left" valign="center" zPosition="2" />

		<widget name="list" position="20,190" size="610,330" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" zPosition="2" backgroundColor="#222230" backgroundColorSelected="#454556" foregroundColorSelected="#ffffff" />
		<widget name="status" position="20,190" size="600,350" transparent="1" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#222230" halign="center" valign="center" zPosition="2" />
		<eLabel name="" text=" " position="580,10" size="40,20" transparent="1" font="di; 18" halign="center" valign="center" backgroundColor="#454556" zPosition="2" />
		<!-- <eLabel name="" text="z" position="515,10" size="60,20" transparent="0" font="di; 18" halign="center" valign="center" backgroundColor="#222222" zPosition="2" /> -->
		<!-- <widget name="int_statu" position="557,10" size="16,16" transparent="1" alphatest="blend" zPosition="2" backgroundColor="#454556" /> -->
		<eLabel text="Close" backgroundColor="#222222" position="0,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Server 1" backgroundColor="#222222" position="160,555" size="160,30"  transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Server 2" backgroundColor="#222222" position="320,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Reset" backgroundColor="#222222" position="480,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" /> -->
		<eLabel name="r" position="0,590" size="160,10" transparent="0" backgroundColor="#ef4c4c" />
		<eLabel name="g" position="160,590" size="160,10" transparent="0" backgroundColor="#4cef83" />
		<eLabel name="y" position="320,590" size="160,10" transparent="0" backgroundColor="#efcf4c" />
		<eLabel name="b" position="480,590" size="160,10" transparent="0" backgroundColor="#4cc1ef" />
	</screen>"""

	dark_setup="""
	<screen name="MenuSetup" position="center,center" size="640,600" title="..." backgroundColor="#222230" flags="wfNoBorder">
		<eLabel name="" text=" SETUP" position="0,0" size="640,40" transparent="0" font="di; 22" halign="center" valign="center" backgroundColor="#454556" zPosition="2" />
		<widget name="config" position="20,60" size="600,200" itemHeight="30" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#222230" backgroundColorSelected="#454556" foregroundColorSelected="#ffffff" />
		<widget name="info" position="20,510" size="600,40" transparent="1" font="Regular; 22" foregroundColor="#00e5ff" backgroundColor="#222230" halign="left" valign="center" zPosition="1" />
		<eLabel text="Close" backgroundColor="#222222" position="0,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" />
		<eLabel text="Save" backgroundColor="#222222" position="160,555" size="160,30"  transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" />
		<eLabel text="Update" backgroundColor="#222222" position="320,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" />
		<eLabel text="Keyboard" backgroundColor="#222222" position="480,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" />
		<eLabel name="r" position="0,590" size="160,10" transparent="0" backgroundColor="#ef4c4c" />
		<eLabel name="g" position="160,590" size="160,10" transparent="0" backgroundColor="#4cef83" />
		<eLabel name="y" position="320,590" size="160,10" transparent="0" backgroundColor="#efcf4c" />
		<eLabel name="b" position="480,590" size="160,10" transparent="0" backgroundColor="#4cc1ef" />
		<widget name="Picture" position="123,274" size="440,247" transparent="1" alphatest="off" zPosition="11" />
	</screen>"""
	black="""
	<screen name="ap" position="center,center" size="640,600" title="..." backgroundColor="#40000000" flags="wfNoBorder">
		<eLabel name="" position="0,0" size="640,40" transparent="0" backgroundColor="#303478c1" zPosition="0" />
		<widget name="title" position="20,0" size="640,40" transparent="1" font="Regular; 22" foregroundColor="#cccccc" backgroundColor="#3478c1" zPosition="1" halign="left" valign="center" />
		<widget name="curCh" position="15,50" size="600,26" transparent="1" font="Regular; 22" foregroundColor="#cccccc" backgroundColor="#40000000" halign="left" valign="center" />
		<widget name="now_evnt" position="15,80" size="600,26" transparent="1" font="Regular; 22" foregroundColor="#cccccc" backgroundColor="#40000000" halign="left" valign="center" />
		<widget name="audioSource" position="20,120" size="600,30" transparent="1" font="Regular; 22" foregroundColor="#eeff" backgroundColor="#40000000" halign="left" zPosition="2" />
		<widget name="info" position="20,150" size="600,30" transparent="1" font="Regular; 22" foregroundColor="#00eeee" backgroundColor="#40000000" halign="left" valign="center" zPosition="99" />
		<widget name="list" position="20,190" size="610,330" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" zPosition="2" backgroundColor="#40000000" backgroundColorSelected="#30005090" foregroundColorSelected="#ffffff" />
		<widget name="status" position="20,190" size="600,350" transparent="1" font="Regular; 22" foregroundColor="#ffffff" backgroundColor="#40000000" halign="center" valign="center" zPosition="2"  />
		<eLabel name="" text=" " position="580,10" size="40,20" transparent="1" font="di; 18" halign="center" valign="center" backgroundColor="#3478c1" zPosition="2" />
		<!-- <eLabel name="" text="z" position="515,10" size="60,20" transparent="0" font="di; 18" halign="center" valign="center" backgroundColor="#222222" zPosition="2" /> -->
		<!-- <widget name="int_statu" position="557,10" size="16,16" transparent="1" alphatest="blend" zPosition="2" backgroundColor="#3478c1" /> -->
		<eLabel text="Close" backgroundColor="#222222" position="0,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Server 1" backgroundColor="#222222" position="160,555" size="160,30"  transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Server 2" backgroundColor="#222222" position="320,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Reset" backgroundColor="#222222" position="480,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" /> -->
		<eLabel name="r" position="0,590" size="160,10" transparent="0" backgroundColor="#ef4c4c" />
		<eLabel name="g" position="160,590" size="160,10" transparent="0" backgroundColor="#4cef83" />
		<eLabel name="y" position="320,590" size="160,10" transparent="0" backgroundColor="#efcf4c" />
		<eLabel name="b" position="480,590" size="160,10" transparent="0" backgroundColor="#4cc1ef" />
	</screen>"""
	black_setup="""
	<screen name="MenuSetup" position="center,center" size="640,600" title="..." backgroundColor="#40000000" flags="wfNoBorder">
		<eLabel name="" position="0,0" size="640,40" transparent="0" backgroundColor="#303478c1" zPosition="0" />
		<eLabel name="" text=" SETUP" position="0,0" size="640,40" transparent="1" font="di; 22" halign="center" valign="center" backgroundColor="#3478c1" zPosition="2" />
		<widget name="config" position="20,60" size="600,200" itemHeight="30" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#40000000" backgroundColorSelected="#30005090" foregroundColorSelected="#ffffff" />
		<widget name="info" position="20,510" size="600,40" transparent="1" font="Regular; 22" foregroundColor="#00e5ff" backgroundColor="#40000000" halign="left" valign="center" zPosition="1" />
		<eLabel text="Close" backgroundColor="#222222" position="0,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" />
		<eLabel text="Save" backgroundColor="#222222" position="160,555" size="160,30"  transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" />
		<eLabel text="Update" backgroundColor="#222222" position="320,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" />
		<eLabel text="Keyboard" backgroundColor="#222222" position="480,555" size="160,30" transparent="1" font="Regular; 22" zPosition="1" halign="center" valign="center" />
		<eLabel name="r" position="0,590" size="160,10" transparent="0" backgroundColor="#ef4c4c" />
		<eLabel name="g" position="160,590" size="160,10" transparent="0" backgroundColor="#4cef83" />
		<eLabel name="y" position="320,590" size="160,10" transparent="0" backgroundColor="#efcf4c" />
		<eLabel name="b" position="480,590" size="160,10" transparent="0" backgroundColor="#4cc1ef" />
		<widget name="Picture" position="123,274" size="440,247" transparent="1" alphatest="off" zPosition="11" />
	</screen>"""
	pastel="""
	<screen name="ap" position="center,center" size="640,560" title="..." backgroundColor="transparent" flags="wfNoBorder">
		<ePixmap position="0,0" size="640,560" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/skin-pastel_HD.png" />
		<eLabel name="" text=" " position="561,16" size="53,26" transparent="1" font="di; 20" halign="center" valign="center" backgroundColor="#145ba8" zPosition="2" />

		<widget name="list" position="6,80" size="626,373" foregroundColor="#c5c5c5"
		scrollbarMode="showOnDemand" scrollbarWidth="10" scrollbarSliderBorderWidth="0"
		scrollbarSliderForegroundColor="#f7b9e0"
		selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/sel_back_green.png"
		transparent="1" backgroundColor="#374146"
		foregroundColorSelected="#ffffff" />

		<widget name="status" position="6,80" size="626,373" transparent="1" font="Regular; 22" foregroundColor="white" backgroundColor="#374146" halign="center" valign="center" zPosition="2" />
		<widget name="info" position="481,485" size="133,20" transparent="1" font="Regular; 16" foregroundColor="#8bc1a2" backgroundColor="#374146" halign="right" valign="center" zPosition="99" />
		<widget name="audioSource" position="20,486" size="433,20" transparent="1" font="Regular; 16" foregroundColor="#00a5d6e3" backgroundColor="#374146" halign="left" zPosition="2" />
		<eLabel text="Close" backgroundColor="#374146" position="20,518" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" /> --&gt;
		<eLabel text="Server 1" backgroundColor="#374146" position="179,518" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" /> --&gt;
		<eLabel text="Server 2" backgroundColor="#374146" position="338,518" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" /> --&gt;
		<eLabel text="Reset" backgroundColor="#374146" position="492,518" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" /> --&gt;
		<widget name="title" position="20,16" size="400,26" transparent="1" font="Regular; 20" foregroundColor="#ffffff" backgroundColor="#415259" zPosition="3" halign="left" valign="center" />

	</screen>"""

	pastel_setup="""
  <screen name="MenuSetup" position="center,center" size="640,560" title="..." backgroundColor="transparent" flags="wfNoBorder">
    <ePixmap position="0,0" size="640,560" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/skin-pastel_HD.png" />
    <eLabel name="" text=" SETUP" position="0,6" size="640,40" transparent="1" font="di; 22" halign="center" valign="center" backgroundColor="#3478c1" zPosition="2" />
    <widget name="config" position="13,80" size="600,165" itemHeight="33" foregroundColor="#c5c5c5"
	scrollbarMode="showOnDemand" scrollbarWidth="10" scrollbarSliderBorderWidth="0"
	scrollbarSliderForegroundColor="#f7b9e0"
	selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/sel_back_green.png"
	transparent="1" backgroundColor="#374146"
	foregroundColorSelected="#ffffff" />

	<widget name="info" position="69,486" size="513,20" transparent="1" font="Regular; 16" foregroundColor="#00e5ff" backgroundColor="#374146" halign="center" valign="center" zPosition="99" />
    <eLabel text="Close" backgroundColor="#374146" position="20,518" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" />
    <eLabel text="Save" backgroundColor="#374146" position="179,518" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" />
    <eLabel text="Update" backgroundColor="#374146" position="338,518" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" />
	<eLabel text="Keyboard" backgroundColor="#374146" position="492,518" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" /> --&gt;
    <!-- <eLabel text="" backgroundColor="#374146" position="402,430" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="center" valign="center" /> -->
    <!-- <eLabel text="" backgroundColor="#50000000" position="422,440" size="120,22" transparent="1" font="Regular; 16" zPosition="1" halign="left" valign="center" />-->
    <widget name="Picture" position="110,253" size="440,247" transparent="1" alphatest="off" zPosition="88" />
	</screen>"""
else:
	blue="""
	<screen name="ap" position="0,0" size="1920,1080" title="..." flags="wfNoBorder">
		<ePixmap position="0,0" size="1920,1080" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/BlueFHD.png" />
		<ePixmap position="1653,1020" size="254,58" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/infomenu_FHD.png" alphatest="blend" />
		<widget name="list" position="980,180" size="940,750" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#141e28" backgroundColorSelected="#0a566d" foregroundColorSelected="#ffffff" zPosition="1" />
		<widget name="status" position="980,0" size="940,1080" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#141e28" halign="center" valign="center" zPosition="1" />
		<widget name="curCh" position="270,455" size="665,40" transparent="1" font="Regular; 33" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="bottom" />
		<widget name="now_evnt" position="270,495" size="665,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="center" />
		<widget name="next_evnt" position="270,535" size="665,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="center" />
		<widget name="desc" position="20,625" size="915,348" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="top" zPosition="1" />
		<!-- <eLabel name="" text=" Audio Sources" position="985,210" size="900,40" transparent="1" font="Regular; 26" halign="left" foregroundColor="#eeff" /> -->
		<widget source="session.VideoPicture" render="Pig" position="195,115" size="550,310" backgroundColor="#ff000000" zPosition="11" />
		<widget name="picon" position="20,455" size="220,132" transparent="1" alphatest="blend" zPosition="11" />
		<widget source="global.CurrentTime" render="Label" position="1750,25" size="200,40" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#143447" valign="center" halign="center" transparent="1">
			<convert type="ClockToText">Format:%H:%M</convert>
		</widget>
		<!-- <widget name="int_statu" position="1800,10" size="80,60" transparent="1" alphatest="blend" zPosition="9" /> -->
		<widget name="audioSource" position="995,100" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#00eeff" backgroundColor="#141e28" halign="left" zPosition="2" />
		<widget name="info" position="995,140" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#00eeff" backgroundColor="#141e28" halign="left" zPosition="2" />
		<eLabel text="Close" backgroundColor="#183e51" position="78,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Server 1" backgroundColor="#183e51" position="475,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Server 2" backgroundColor="#183e51" position="875,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Reset" backgroundColor="#183e51" position="1275,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
	</screen>"""
	blue_setup="""
<screen name="MenuSetup" position="center,center" size="1920,1080" title="..." backgroundColor="#141e28" flags="wfNoBorder">
		<widget name="config" position="985,115" size="920,400" itemHeight="40" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#141e28" backgroundColorSelected="#0a566d" foregroundColorSelected="#ffffff" />
		<ePixmap position="0,0" size="1920,1080" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/BlueFHD.png" />
		<ePixmap position="273,563" size="400,320" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/setup_FHD.png" alphatest="blend" />
		<widget source="session.VideoPicture" render="Pig" position="195,115" size="550,310" backgroundColor="#ff000000" zPosition="11" />
		<!-- <widget name="status" position="1090,20" size="665,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#0a566d" halign="center" valign="center" /> -->
		<widget name="info" position="14,936" size="915,40" transparent="1" font="Regular; 30" foregroundColor="#00e5ff" backgroundColor="#141e28" halign="center" valign="center" zPosition="1" />
		<widget source="global.CurrentTime" render="Label" position="1750,25" size="200,40" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#143447" valign="center" halign="center" transparent="1">
			<convert type="ClockToText">Format:%H:%M</convert>
		</widget>
		<eLabel text="Close" backgroundColor="#183e51" position="78,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Save" backgroundColor="#183e51" position="475,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Update" backgroundColor="#183e51" position="875,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Keyboard" backgroundColor="#183e51" position="1275,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<widget name="Picture" position="1136,546" size="660,390" transparent="1" alphatest="off" zPosition="11" />
	</screen>"""
	darkBlue="""
	<screen name="ap" position="0,0" size="1920,1080" title="..." flags="wfNoBorder">
		<ePixmap position="0,0" size="1920,1080" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/DarkBlueFHD.png" />
		<ePixmap position="1653,1020" size="254,58" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/infomenu_FHD.png" alphatest="blend" />
		<widget name="list" position="980,180" size="940,750" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#141e28" backgroundColorSelected="#0a566d" foregroundColorSelected="#ffffff" zPosition="1" />
		<widget name="status" position="980,0" size="940,1080" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#141e28" halign="center" valign="center" zPosition="1" />
		<widget name="curCh" position="270,455" size="665,40" transparent="1" font="Regular; 33" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="bottom" />
		<widget name="now_evnt" position="270,495" size="665,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="center" />
		<widget name="next_evnt" position="270,535" size="665,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="center" />
		<widget name="desc" position="20,625" size="915,348" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#141e28" halign="left" valign="top" zPosition="1" />
		<!-- <eLabel name="" text=" Audio Sources" position="985,210" size="900,40" transparent="1" font="Regular; 26" halign="left" foregroundColor="#eeff" /> -->
		<widget source="session.VideoPicture" render="Pig" position="195,115" size="550,310" backgroundColor="#ff000000" zPosition="11" />
		<widget name="picon" position="20,455" size="220,132" transparent="1" alphatest="blend" zPosition="11" />
		<widget source="global.CurrentTime" render="Label" position="1750,25" size="200,40" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#143447" valign="center" halign="center" transparent="1">
			<convert type="ClockToText">Format:%H:%M</convert>
		</widget>
		<!-- <widget name="int_statu" position="1800,10" size="80,60" transparent="1" alphatest="blend" zPosition="9" /> -->
		<widget name="audioSource" position="995,100" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#00eeff" backgroundColor="#141e28" halign="left" zPosition="2" />
		<widget name="info" position="995,140" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#00eeff" backgroundColor="#141e28" halign="left" zPosition="2" />
		<eLabel text="Close" backgroundColor="#183e51" position="78,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Server 1" backgroundColor="#183e51" position="475,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Server 2" backgroundColor="#183e51" position="875,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Reset" backgroundColor="#183e51" position="1275,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
	</screen>"""
	darkBlue_setup="""
<screen name="MenuSetup" position="center,center" size="1920,1080" title="..." backgroundColor="#141e28" flags="wfNoBorder">
		<widget name="config" position="985,115" size="920,400" itemHeight="40" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#141e28" backgroundColorSelected="#0a566d" foregroundColorSelected="#ffffff" />
		<ePixmap position="0,0" size="1920,1080" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/DarkBlueFHD.png" />
		<ePixmap position="273,563" size="400,320" zPosition="1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/setup_FHD.png" alphatest="blend" />
		<widget source="session.VideoPicture" render="Pig" position="195,115" size="550,310" backgroundColor="#ff000000" zPosition="11" />
		<!-- <widget name="status" position="1090,20" size="665,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#0a566d" halign="center" valign="center" /> -->
		<widget name="info" position="14,936" size="915,40" transparent="1" font="Regular; 30" foregroundColor="#00e5ff" backgroundColor="#141e28" halign="center" valign="center" zPosition="1" />
		<widget source="global.CurrentTime" render="Label" position="1750,25" size="200,40" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#143447" valign="center" halign="center" transparent="1">
			<convert type="ClockToText">Format:%H:%M</convert>
		</widget>
		<eLabel text="Close" backgroundColor="#183e51" position="78,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Save" backgroundColor="#183e51" position="475,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Update" backgroundColor="#183e51" position="875,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<eLabel text="Keyboard" backgroundColor="#183e51" position="1275,1030" size="300,40" transparent="1" font="Regular; 30" zPosition="1" halign="left" valign="center" />
		<widget name="Picture" position="1136,546" size="660,390" transparent="1" alphatest="off" zPosition="11" />
	</screen>"""

	dark="""
	<screen name="ap" position="center,center" size="960,900" title="..." backgroundColor="#222230" flags="wfNoBorder">
		<widget name="curCh" position="0,0" size="960,60" transparent="0" font="Regular; 33" foregroundColor="#ffffff" backgroundColor="#454556" halign="left" valign="center" />
		<widget name="now_evnt" position="20,75" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#454556" halign="left" valign="center" />
		<widget name="next_evnt" position="20,115" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#454556" halign="left" valign="center" />
		<widget name="list" position="10,250" size="940,520" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#222230" backgroundColorSelected="#454556" foregroundColorSelected="#c5c5c5" />
		<widget name="status" position="30,228" size="900,567" transparent="1" font="Regular; 33" foregroundColor="#ffffff" backgroundColor="#454556" halign="center" valign="center" zPosition="2" />
		<widget name="info" position="30,200" size="900,40" transparent="1" font="Regular; 33" foregroundColor="#00eeee" backgroundColor="#00000000" halign="left" valign="center" zPosition="99" />
		<widget name="audioSource" position="30,160" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#eeff" backgroundColor="#183e51" halign="left" zPosition="2" />
		<eLabel name="" text=" " position="890,20" size="60,30" transparent="1" font="di; 30" halign="center" valign="center" backgroundColor="#454556" zPosition="2" />
		<eLabel text="Close" backgroundColor="#222222" position="0,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Server 1" backgroundColor="#222222" position="240,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Server 2" backgroundColor="#222222" position="480,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Reset" backgroundColor="#222222" position="720,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" /> -->
		<eLabel name="r" position="0,885" size="240,15" transparent="0" backgroundColor="#ef4c4c" />
		<eLabel name="g" position="240,885" size="240,15" transparent="0" backgroundColor="#4cef83" />
		<eLabel name="y" position="480,885" size="240,15" transparent="0" backgroundColor="#efcf4c" />
		<eLabel name="b" position="720,885" size="240,15" transparent="0" backgroundColor="#4cc1ef" />
	</screen>"""
	dark_setup="""
	<screen name="MenuSetup" position="center,center" size="960,900" title="..." backgroundColor="#222230" flags="wfNoBorder">
		<eLabel name="" text=" SETUP" position="0,0" size="960,60" transparent="0" font="di; 33" halign="center" valign="center" backgroundColor="#454556" zPosition="2" />
		<widget name="config" position="30,92" size="900,300" itemHeight="45" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#0222230" backgroundColorSelected="#454556" foregroundColorSelected="#ffffff" />
		<widget name="info" position="30,777" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#00e5ff" backgroundColor="#0222230" halign="left" valign="center" zPosition="1" />
		<eLabel text="Close" backgroundColor="#222222" position="0,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" />
		<eLabel text="Save" backgroundColor="#222222" position="240,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" />
		<eLabel text="Update" backgroundColor="#222222" position="480,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" />
		<eLabel text="Keyboard" backgroundColor="#222222" position="720,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" />
		<eLabel name="r" position="0,885" size="240,15" transparent="0" backgroundColor="#ef4c4c" />
		<eLabel name="g" position="240,885" size="240,15" transparent="0" backgroundColor="#4cef83" />
		<eLabel name="y" position="480,885" size="240,15" transparent="0" backgroundColor="#efcf4c" />
		<eLabel name="b" position="720,885" size="240,15" transparent="0" backgroundColor="#4cc1ef" />
		<widget name="Picture" position="145,400" size="660,390" transparent="1" alphatest="off" zPosition="11" />
	</screen>"""
	black="""
	<screen name="ap" position="center,center" size="960,900" title="..." backgroundColor="#40000000" flags="wfNoBorder">
		<widget name="curCh" position="0,0" size="960,60" transparent="0" font="Regular; 33" foregroundColor="#ffffff" backgroundColor="#40145ba8" halign="left" valign="center" />
		<widget name="now_evnt" position="20,75" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#145ba8" halign="left" valign="center" />
		<widget name="next_evnt" position="20,115" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#145ba8" halign="left" valign="center" />
		<widget name="list" position="10,250" size="940,520" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#40000000" backgroundColorSelected="#40005090" foregroundColorSelected="#ffffff" />
		<widget name="status" position="30,228" size="900,567" transparent="1" font="Regular; 33" foregroundColor="#ffffff" backgroundColor="#145ba8" halign="center" valign="center" zPosition="2" />
		<widget name="info" position="30,200" size="900,40" transparent="1" font="Regular; 33" foregroundColor="#00eeee" backgroundColor="#00000000" halign="left" valign="center" zPosition="99" />
		<widget name="audioSource" position="30,160" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#eeff" backgroundColor="#183e51" halign="left" zPosition="2" />
		<eLabel name="" text=" " position="890,20" size="60,30" transparent="1" font="di; 30" halign="center" valign="center" backgroundColor="#145ba8" zPosition="2" />
		<eLabel text="Close" backgroundColor="#222222" position="0,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Server 1" backgroundColor="#222222" position="240,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Server 2" backgroundColor="#222222" position="480,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" /> -->
		<eLabel text="Reset" backgroundColor="#222222" position="720,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" /> -->
		<eLabel name="r" position="0,885" size="240,15" transparent="0" backgroundColor="#ef4c4c" />
		<eLabel name="g" position="240,885" size="240,15" transparent="0" backgroundColor="#4cef83" />
		<eLabel name="y" position="480,885" size="240,15" transparent="0" backgroundColor="#efcf4c" />
		<eLabel name="b" position="720,885" size="240,15" transparent="0" backgroundColor="#4cc1ef" />
	</screen>"""
	black_setup="""
	<screen name="MenuSetup" position="center,center" size="960,900" title="..." backgroundColor="#40000000" flags="wfNoBorder">
		<eLabel name="" text=" SETUP" position="0,0" size="960,60" transparent="0" font="di; 33" halign="center" valign="center" backgroundColor="#3478c1" zPosition="2" />
		<widget name="config" position="30,92" size="900,300" itemHeight="45" foregroundColor="#c5c5c5" scrollbarMode="showOnDemand" transparent="1" backgroundColor="#40000000" backgroundColorSelected="#40005090" foregroundColorSelected="#ffffff" />
		<widget name="info" position="30,777" size="900,40" transparent="1" font="Regular; 30" foregroundColor="#00e5ff" backgroundColor="#40000000" halign="left" valign="center" zPosition="1" />
		<eLabel text="Close" backgroundColor="#222222" position="0,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" />
		<eLabel text="Save" backgroundColor="#222222" position="240,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" />
		<eLabel text="Update" backgroundColor="#222222" position="480,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" />
		<eLabel text="Keyboard" backgroundColor="#222222" position="720,845" size="240,45" transparent="1" font="Regular; 27" zPosition="1" halign="center" valign="center" />
		<eLabel name="r" position="0,885" size="240,15" transparent="0" backgroundColor="#ef4c4c" />
		<eLabel name="g" position="240,885" size="240,15" transparent="0" backgroundColor="#4cef83" />
		<eLabel name="y" position="480,885" size="240,15" transparent="0" backgroundColor="#efcf4c" />
		<eLabel name="b" position="720,885" size="240,15" transparent="0" backgroundColor="#4cc1ef" />
		<widget name="Picture" position="145,400" size="660,390" transparent="1" alphatest="off" zPosition="11" />
	</screen>"""
	pastel="""
	<screen name="ap" position="center,center" size="960,840" title="..." backgroundColor="transparent" flags="wfNoBorder">
		<ePixmap position="0,0" size="960,840" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/skin-pastel.png" />
		<eLabel name="" text=" " position="842,24" size="80,40" transparent="1" font="di; 30" halign="center" valign="center" backgroundColor="#145ba8" zPosition="2" />

		<widget name="list" position="10,120" size="940,560" foregroundColor="#c5c5c5"
		scrollbarMode="showOnDemand" scrollbarWidth="10" scrollbarSliderBorderWidth="0"
		scrollbarSliderForegroundColor="#f7b9e0"
		selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/sel_back_green.png"
		transparent="1" backgroundColor="#374146"
		foregroundColorSelected="#ffffff" />

		<widget name="status" position="10,120" size="940,560" transparent="1" font="Regular; 33" foregroundColor="white" backgroundColor="#374146" halign="center" valign="center" zPosition="2" />
		<widget name="info" position="722,728" size="200,30" transparent="1" font="Regular; 24" foregroundColor="#8bc1a2" backgroundColor="#374146" halign="right" valign="center" zPosition="99" />
		<widget name="audioSource" position="30,730" size="650,30" transparent="1" font="Regular; 24" foregroundColor="#00a5d6e3" backgroundColor="#374146" halign="left" zPosition="2" />
		<eLabel text="Close" backgroundColor="#374146" position="30,777" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" /> --&gt;
		<eLabel text="Server 1" backgroundColor="#374146" position="269,777" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" /> --&gt;
		<eLabel text="Server 2" backgroundColor="#374146" position="508,777" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" /> --&gt;
		<eLabel text="Reset" backgroundColor="#374146" position="738,777" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" /> --&gt;
		<widget name="title" position="30,25" size="600,40" transparent="1" font="Regular; 30" foregroundColor="#ffffff" backgroundColor="#415259" zPosition="3" halign="left" valign="center" />

	</screen>"""
	pastel_setup="""
  <screen name="MenuSetup" position="center,center" size="960,840" title="..." backgroundColor="transparent" flags="wfNoBorder">
    <ePixmap position="0,0" size="960,840" zPosition="-1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/skin-pastel.png" />
    <eLabel name="" text=" SETUP" position="0,10" size="960,60" transparent="1" font="di; 33" halign="center" valign="center" backgroundColor="#3478c1" zPosition="2" />
    <widget name="config" position="20,120" size="900,262" itemHeight="50" foregroundColor="#c5c5c5"
	scrollbarMode="showOnDemand" scrollbarWidth="10" scrollbarSliderBorderWidth="0"
	scrollbarSliderForegroundColor="#f7b9e0"
	selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/images/sel_back_green.png"
	transparent="1" backgroundColor="#374146"
	foregroundColorSelected="#ffffff" />

	<widget name="info" position="104,729" size="770,30" transparent="1" font="Regular; 24" foregroundColor="#00e5ff" backgroundColor="#374146" halign="center" valign="center" zPosition="99" />
    <eLabel text="Close" backgroundColor="#374146" position="30,777" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" />
    <eLabel text="Save" backgroundColor="#374146" position="269,777" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" />
    <eLabel text="Update" backgroundColor="#374146" position="508,777" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" />
	<eLabel text="Keyboard" backgroundColor="#374146" position="738,777" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" /> --&gt;
    <!-- <eLabel text="" backgroundColor="#374146" position="603,645" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="center" valign="center" /> -->
    <!-- <eLabel text="" backgroundColor="#50000000" position="633,660" size="180,34" transparent="1" font="Regular; 24" zPosition="1" halign="left" valign="center" />-->
    <widget name="Picture" position="165,380" size="660,371" transparent="1" alphatest="off" zPosition="88" />
	</screen>"""
