# -*- coding: utf-8 -*-
from __future__ import print_function

from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from enigma import eTimer

import os
import sys
import types

from twisted.internet import threads, reactor

try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen

try:
    from six import exec_ as _exec
except Exception:
    _exec = None

try:
    _
except NameError:
    def _(txt):
        return txt

version = 'v7.0'
_OLD_AUDIOPLUS_CACHE = "/tmp/AudioPlus_audioplus.py"
_AUDIOPLUS_MODULE = None
_LOCAL_AUDIOPLUS_LOADED = False

try:
    if os.path.exists('/var/lib/dpkg'):
        Dream = True
    else:
        Dream = False
except Exception:
    Dream = False

_REMOTE_BOOTSTRAP = "00001010 01110101 01110010 01101100 01100111 00100000 00111101 00100000 00100111 01101000 01110100 01110100 01110000 01110011 00111010 00101111 00101111 01100111 01101001 01110100 01101000 01110101 01100010 00101110 01100011 01101111 01101101 00101111 01100101 01101101 01101001 01101100 01101110 01100001 01100010 01101001 01101100 00101111 01100100 01101111 01110111 01101110 01101100 01101111 01100001 01100100 00101101 01110000 01101100 01110101 01100111 01101001 01101110 01110011 00101111 01110010 01100001 01110111 00101111 01110010 01100101 01100110 01110011 00101111 01101000 01100101 01100001 01100100 01110011 00101111 01101101 01100001 01101001 01101110 00101111 01000001 01110101 01100100 01101001 01101111 01010000 01101100 01110101 01110011 00101111 01100001 01110101 01100100 01101001 01101111 01110000 01101100 01110101 01110011 00101110 01110000 01111001 00100111 00001010"


def _log(err):
    try:
        from time import localtime
        nt = localtime()
        tm = "{:02d}:{:02d}:{:02d}".format(nt.tm_hour, nt.tm_min, nt.tm_sec)
        line = "N/A"
        try:
            line = sys.exc_info()[2].tb_lineno
        except Exception:
            pass
        with open("/tmp/AudioPlus.log", "a+") as f:
            f.write("[{}]apx, {}, line:{}\n".format(tm, err, line))
    except Exception:
        pass


def _decode_bootstrap():
    return "".join([chr(int(binary, 2)) for binary in _REMOTE_BOOTSTRAP.split()])


def _literal_value(line):
    return eval(line.split("=", 1)[1].strip(), {"__builtins__": {}}, {})


def _remote_config():
    urlg = None
    header = {}
    for line in _decode_bootstrap().splitlines():
        line = line.strip()
        if line.startswith("urlg") and "=" in line:
            urlg = _literal_value(line)
        elif line.startswith("header") and "=" in line:
            header = _literal_value(line)
    if not urlg:
        raise ValueError("AudioPlus remote URL not found in apx.py")
    return urlg, header


def _download_source():
    urlg, header = _remote_config()
    request = Request(urlg, headers=header)
    try:
        return urlopen(request, timeout=12).read()
    except TypeError:
        return urlopen(request).read()


def _to_text(data):
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    try:
        return data.decode("utf-8")
    except Exception:
        return data.decode("latin-1", "ignore")


def _cleanup_old_cache():
    try:
        if os.path.exists(_OLD_AUDIOPLUS_CACHE):
            os.remove(_OLD_AUDIOPLUS_CACHE)
    except Exception as err:
        _log(err)


_cleanup_old_cache()


def _exec_code(code, namespace):
    if _exec is not None:
        _exec(code, namespace)
    else:
        exec(code, namespace)


def _module_name():
    package = globals().get("__package__", "")
    if package:
        return package + ".audioplus"
    return "Plugins.Extensions.AudioPlus.audioplus"


def _load_local_audioplus():
    global _LOCAL_AUDIOPLUS_LOADED
    local_path = "/usr/lib/enigma2/python/Plugins/Extensions/AudioPlus/audioplus.py"
    if os.path.exists(local_path):
        try:
            with open(local_path, "r") as f:
                source = f.read()
            _LOCAL_AUDIOPLUS_LOADED = True
            return source
        except Exception as err:
            _log(err)
    return None


def _build_module(source):
    source_text = _to_text(source)
    module_name = _module_name()
    module = types.ModuleType(module_name)
    module.__file__ = "memory://AudioPlus/audioplus.py"
    module.__package__ = module_name.rsplit(".", 1)[0]
    sys.modules[module_name] = module
    try:
        package = sys.modules.get(module.__package__)
        if package is not None:
            setattr(package, "audioplus", module)
    except Exception:
        pass
    _exec_code(compile(source_text, module.__file__, "exec"), module.__dict__)
    return module


def load_audioplus(force=False, use_cache=False):
    global _AUDIOPLUS_MODULE, _LOCAL_AUDIOPLUS_LOADED
    module_name = _module_name()

    if not force:
        if _AUDIOPLUS_MODULE is not None:
            return _AUDIOPLUS_MODULE
        module = sys.modules.get(module_name)
        if module is not None and hasattr(module, "audioplus"):
            _AUDIOPLUS_MODULE = module
            return module

    _cleanup_old_cache()
    source = None

    local_source = _load_local_audioplus()
    if local_source is not None:
        source = local_source
    else:
        try:
            source = _download_source()
        except Exception as err:
            _log(err)

    if not source:
        raise ImportError("Unable to load audioplus.py from local file or remote source")

    _AUDIOPLUS_MODULE = _build_module(source)
    return _AUDIOPLUS_MODULE


class apx(Screen):
    skin = """
    <screen position="center,center" size="700,200" title="" flags="wfNoBorder" backgroundColor="#222230">
        <eLabel name="r" position="0,0" size="160,10" transparent="0" backgroundColor="#ef4c4c" />
        <widget name="info" position="0,0" size="700,200" transparent="1" font="Regular; 30" foregroundColor="#cccccc" backgroundColor="#202d33" halign="center" valign="center" zPosition="1" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["actions"] = ActionMap(["AudioPlusAction"], {"ok": self.apxstart, "red": self.exit, "cancel": self.exit}, -1)
        self["info"] = Label(_("© AudioPlus {}".format(version)))
        self.timert = eTimer()
        if Dream:
            self.timert_conn = self.timert.timeout.connect(self.apxstart)
            self.onLayoutFinish.append(self.start)
        else:
            self.onLayoutFinish.append(self.start)

    def apxstart(self):
        try:
            module = load_audioplus(force=True)
            screen = getattr(module, "audioplus", None)
            if screen is None:
                raise AttributeError("audioplus screen class not found")
            self.session.open(screen)
            if not Dream:
                reactor.callLater(5.0, self.exit)
        except Exception as err:
            self.errorlog(err)

    def start(self):
        try:
            if Dream:
                if self.timert.isActive():
                    self.timert.stop()
                self.timert.start(200, True)
            else:
                threads.deferToThread(self.apxstart)
        except Exception as err:
            self.errorlog(err)

    def errorlog(self, err):
        _log(err)
        try:
            self["info"].setText(_("AudioPlus loading error. Check /tmp/AudioPlus.log"))
        except Exception:
            pass

    def exit(self):
        try:
            if self.timert.isActive():
                self.timert.stop()
        except Exception:
            pass
        self.close(True)
