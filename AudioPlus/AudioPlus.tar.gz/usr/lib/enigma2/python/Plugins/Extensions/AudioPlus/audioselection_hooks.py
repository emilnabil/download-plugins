# -*- coding: utf-8 -*-
"""
AudioPlus integration for Enigma2 AudioSelection.
Adds AudioPlus Server 1 / Server 2 streams to the native "Select audio track"
list and plays the selected external audio with the same AudioPlus GStreamer
settings.
"""
from __future__ import print_function

import datetime
import io
import json
import os
import sys
from time import localtime

try:
	from shlex import quote as _shell_quote
except Exception:
	try:
		from pipes import quote as _shell_quote
	except Exception:
		def _shell_quote(value):
			return "'%s'" % str(value).replace("'", "'\\''")

try:
	_
except NameError:
	def _(txt):
		return txt

AP_STREAM_TAG = "__AudioPlusStream__"
_PATCHED = False
_ORIG_FILL_LIST = None
_ORIG_KEY_OK = None
_FOCUS_STREAMS = None
_CONTAINER = None
_ALSA = None
_ALSA_READY = False
_DEFER_TIMER = None
_CURRENT = {"url": None, "name": None, "ref": None, "server": None, "service_ref": None}


def _log(err):
	try:
		nt = localtime()
		tm = "{:02d}:{:02d}:{:02d}".format(nt.tm_hour, nt.tm_min, nt.tm_sec)
		line = "N/A"
		try:
			line = sys.exc_info()[2].tb_lineno
		except Exception:
			pass
		with open("/tmp/AudioPlus.log", "a+") as f:
			f.write("[{}]AudioSelection, {}, line:{}\n".format(tm, err, line))
	except Exception:
		pass


def install():
	"""Install the AudioSelection monkey patch once per GUI session."""
	global _PATCHED, _ORIG_FILL_LIST, _ORIG_KEY_OK, _FOCUS_STREAMS
	if _PATCHED:
		return True
	try:
		import Screens.AudioSelection as audioselection_module
		AudioSelection = audioselection_module.AudioSelection
		if getattr(AudioSelection, "_audioplus_streams_patch", False):
			_PATCHED = True
			return True
		_ORIG_FILL_LIST = AudioSelection.fillList
		_ORIG_KEY_OK = AudioSelection.keyOk
		_FOCUS_STREAMS = getattr(audioselection_module, "FOCUS_STREAMS", None)

		def fillList_patched(self, *args, **kwargs):
			ret = _ORIG_FILL_LIST(self, *args, **kwargs)
			try:
				_append_audio_plus_streams(self)
			except Exception as err:
				_log(err)
			return ret

		def keyOk_patched(self, *args, **kwargs):
			try:
				payload = _get_current_audio_plus_payload(self)
				if payload:
					session = self.session
					data = dict(payload)
					try:
						self.close(0)
					except Exception:
						pass
					_defer_play_stream(session, data, 250)
					return
				# When the user chooses a normal DVB/IPTV audio track, restore the original device audio.
				if _is_audio_page(self) and _is_streams_focus(self):
					if _CURRENT.get("url"):
						reset_stream(self.session)
			except Exception as err:
				_log(err)
			return _ORIG_KEY_OK(self, *args, **kwargs)

		AudioSelection.fillList = fillList_patched
		AudioSelection.keyOk = keyOk_patched
		AudioSelection._audioplus_streams_patch = True
		_PATCHED = True
		return True
	except Exception as err:
		_log(err)
		return False


def _is_audio_page(screen):
	try:
		return screen.settings.menupage.value == "audio"
	except Exception:
		return True


def _is_streams_focus(screen):
	try:
		if _FOCUS_STREAMS is None:
			return True
		return getattr(screen, "focus", _FOCUS_STREAMS) == _FOCUS_STREAMS
	except Exception:
		return True


def _get_streams_source(screen):
	try:
		return screen["streams"]
	except Exception:
		return None


def _get_current_stream(screen):
	if not _is_streams_focus(screen):
		return None
	source = _get_streams_source(screen)
	if source is None:
		return None
	try:
		return source.getCurrent()
	except Exception:
		pass
	try:
		idx = source.getIndex()
		return source.list[idx]
	except Exception:
		pass
	try:
		idx = source.getSelectionIndex()
		return source.list[idx]
	except Exception:
		return None


def _get_current_audio_plus_payload(screen):
	cur = _get_current_stream(screen)
	try:
		payload = cur[0]
		if isinstance(payload, dict) and payload.get("tag") == AP_STREAM_TAG:
			return payload
	except Exception:
		pass
	return None


def _append_audio_plus_streams(screen):
	if not _is_audio_page(screen):
		return
	source = _get_streams_source(screen)
	if source is None:
		return
	streams = _get_streams_list(source)
	if streams is None:
		return
	# Remove stale AudioPlus entries before rebuilding the list.
	cleaned = []
	for item in streams:
		try:
			payload = item[0]
			if isinstance(payload, dict) and payload.get("tag") == AP_STREAM_TAG:
				continue
		except Exception:
			pass
		cleaned.append(item)
	streams = cleaned
	entries = _load_audio_plus_entries()
	if not entries:
		_set_streams_list(source, streams)
		return
	if _CURRENT.get("url"):
		streams = [_clear_selected_marker(x) for x in streams]
	counter = len(streams) + 1
	for server_no, item in entries:
		name = str(item.get("name", "")).strip()
		url = str(item.get("url", "")).strip()
		ref = str(item.get("ref", "")).strip()
		language = _display_language(item)
		if not name or not url:
			continue
		payload = {"tag": AP_STREAM_TAG, "server": server_no, "name": name, "url": url, "ref": ref, "language": language}
		# Native AudioSelection rows are: payload, icon, number, description, language, selected/status.
		# We use the same visible columns as: channel name, language, server number.
		streams.append((payload, "", str(counter), name, language, server_no))
		counter += 1
	_set_streams_list(source, streams)


def _get_streams_list(source):
	try:
		return list(source.list or [])
	except Exception:
		pass
	try:
		return list(source.getList() or [])
	except Exception:
		return None


def _set_streams_list(source, streams):
	try:
		source.setList(streams)
		return
	except Exception:
		pass
	try:
		source.list = streams
	except Exception:
		pass


def _clear_selected_marker(item):
	try:
		if len(item) >= 6:
			lst = list(item)
			lst[5] = ""
			return tuple(lst)
	except Exception:
		pass
	return item


def _load_audio_plus_entries():
	entries = []
	try:
		audioplus = None
		try:
			from . import apx
			audioplus = apx.load_audioplus(force=False)
		except Exception as err:
			_log(err)
		if audioplus is None:
			from . import audioplus
		server1 = []
		try:
			server1 = list(getattr(audioplus, "apj", [[]])[0])
		except Exception:
			server1 = []
		for item in _normalise_server_list(server1):
			entries.append(("1", item))
	except Exception as err:
		_log(err)
	try:
		for item in _normalise_server_list(_read_server2_json()):
			entries.append(("2", item))
	except Exception as err:
		_log(err)
	return entries


def _read_server2_json():
	path = "/etc/enigma2/audio.json"
	if not os.path.exists(path):
		return []
	with io.open(path, "r", encoding="utf-8") as f:
		data = json.load(f)
	if isinstance(data, list) and data and isinstance(data[0], list):
		return data[0]
	return data


def _display_language(item):
	language = ""
	try:
		for key in ("language", "Language", "lang", "Lang", "audio_language", "audioLanguage"):
			if key in item and item.get(key) is not None:
				language = str(item.get(key)).strip()
				break
	except Exception:
		language = ""
	if not language:
		return "Arabic"
	lower = language.lower()
	if lower in ("ar", "ara", "arabic", "العربية", "عربي"):
		return "Arabic"
	if lower in ("en", "eng", "english"):
		return "English"
	return language


def _normalise_server_list(data):
	items = []
	if not isinstance(data, list):
		return items
	for item in data:
		if not isinstance(item, dict):
			continue
		name = str(item.get("name", "")).strip()
		url = str(item.get("url", "")).strip()
		ref = str(item.get("ref", "")).strip()
		language = _display_language(item)
		if name and url:
			items.append({"name": name, "url": url, "ref": ref, "language": language})
	return items


def _get_current_service_ref(session=None):
	service_ref = None
	try:
		if session is not None:
			service_ref = session.nav.getCurrentlyPlayingServiceReference()
	except Exception:
		service_ref = None
	if service_ref:
		return service_ref
	try:
		import NavigationInstance
		return NavigationInstance.instance.getCurrentlyPlayingServiceReference()
	except Exception:
		return None


def _defer_play_stream(session, payload, delay_ms=250):
	global _DEFER_TIMER
	def _run():
		global _DEFER_TIMER
		try:
			play_stream(session, payload.get("url", ""), payload.get("name", ""), payload.get("ref", ""), payload.get("server", ""))
		except Exception as err:
			_log(err)
		try:
			if _DEFER_TIMER:
				_DEFER_TIMER.stop()
		except Exception:
			pass
		_DEFER_TIMER = None
	try:
		from enigma import eTimer
		_DEFER_TIMER = eTimer()
		try:
			_DEFER_TIMER.callback.append(_run)
		except Exception:
			_DEFER_TIMER.timeout.get().append(_run)
		_DEFER_TIMER.start(int(delay_ms), True)
	except Exception:
		_run()

def _get_container():
	global _CONTAINER
	if _CONTAINER is None:
		try:
			from enigma import eConsoleAppContainer
			_CONTAINER = eConsoleAppContainer()
		except Exception as err:
			_log(err)
			_CONTAINER = False
	return _CONTAINER


def _get_alsa():
	global _ALSA, _ALSA_READY
	if _ALSA_READY:
		return _ALSA
	_ALSA_READY = True
	try:
		from enigma import eAlsaOutput
		_ALSA = eAlsaOutput.getInstance()
	except Exception:
		_ALSA = None
	return _ALSA


def _build_gstreamer_command(url):
	try:
		from . import audioplus  # noqa: F401 - importing keeps config.plugins.ap defined.
	except Exception:
		pass
	from Components.config import config
	sync = "alsasink"
	buffer = 10
	volume = 0.5
	player = "Player MAIN"
	try:
		sync = config.plugins.ap.sync.value
		buffer = config.plugins.ap.buf.value
		volume = float(config.plugins.ap.vol.value) / float(10)
		player = config.plugins.ap.plyr.value
	except Exception:
		pass
	qurl = _shell_quote(url)
	user_agents = {
		"Player MAIN": "Tialiaudioolayer",
		"Player MAIN 2": "Lavf/60.3.100",
		"Player MAIN 3": "Lavf/57.83.100",
		"Player MAIN 4": "Lavf/59.27.100",
	}
	if player == "Player 1":
		return "gst-launch-1.0 playbin uri={} audio-sink={} volume={}".format(qurl, sync, volume)
	elif player == "Player 2":
		return "gst-launch-1.0 fdsrc fd=0 {} ! decodebin ! audioconvert ! audioresample ! {}".format(qurl, sync)
	elif player == "Player 3":
		return "(/usr/bin/gst-launch-1.0 fdsrc fd=0 {} ! decodebin ! queue2 use-buffering=true max-size-buffers={} max-size-bytes=0 max-size-time=0 ! {} device=hw:0)>/dev/null 2>&1".format(qurl, buffer, sync)
	else:
		user_agent = user_agents.get(player, user_agents["Player MAIN"])
		return "gst-launch-1.0 souphttpsrc location={} user-agent={} ! decodebin ! audioconvert ! audioresample ! queue max-size-buffers=500 max-size-time=0 max-size-bytes=0 ! {} sync=false".format(qurl, _shell_quote(user_agent), sync)


def play_stream(session, url, name="", ref="", server=""):
	if not url:
		return False
	try:
		reset_stream(session, keep_service=True)
		_CURRENT["service_ref"] = _get_current_service_ref(session)
		cmd = _build_gstreamer_command(url)
		container = _get_container()
		alsa = _get_alsa()
		if alsa:
			try:
				alsa.stop()
				alsa.close()
			except Exception:
				pass
			if container:
				container.execute(cmd)
		else:
			service_ref = _CURRENT.get("service_ref")
			if os.path.exists('/dev/dvb/adapter0/audio0') and service_ref:
				try:
					session.nav.stopService()
				except Exception:
					pass
				try:
					os.rename('/dev/dvb/adapter0/audio0', '/dev/dvb/adapter0/audio10')
				except Exception as err:
					_log(err)
				if container:
					container.execute(cmd)
				try:
					session.nav.playService(service_ref)
				except Exception as err:
					_log(err)
			else:
				# Safe fallback: never stop the video if the current service reference cannot be restored.
				if container:
					container.execute(cmd)
		_CURRENT.update({"url": url, "name": name, "ref": ref, "server": server})
		return True
	except Exception as err:
		_log(err)
		return False


def reset_stream(session=None, keep_service=False):
	try:
		os.system('killall -9 gst-launch-1.0 >/dev/null 2>&1')
	except Exception:
		pass
	try:
		container = _get_container()
		if container and container.running():
			container.kill()
	except Exception:
		pass
	try:
		alsa = _get_alsa()
		if alsa:
			try:
				alsa.stop()
				alsa.close()
			except Exception:
				pass
	except Exception:
		pass
	try:
		if session is not None and os.path.exists('/dev/dvb/adapter0/audio10'):
			if keep_service and _CURRENT.get("url"):
				# Switching from one AudioPlus stream to another: keep video untouched.
				return True
			service_ref = _CURRENT.get("service_ref") or _get_current_service_ref(session)
			try:
				session.nav.stopService()
			except Exception:
				pass
			try:
				os.rename('/dev/dvb/adapter0/audio10', '/dev/dvb/adapter0/audio0')
			except Exception as err:
				_log(err)
			try:
				if service_ref:
					session.nav.playService(service_ref)
			except Exception as err:
				_log(err)
	except Exception as err:
		_log(err)
	if not keep_service:
		_CURRENT.update({"url": None, "name": None, "ref": None, "server": None, "service_ref": None})
	return True
