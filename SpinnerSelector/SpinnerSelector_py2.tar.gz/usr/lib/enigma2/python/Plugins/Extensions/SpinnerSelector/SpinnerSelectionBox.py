from Screens.Screen import Screen
from Components.ActionMap import NumberActionMap
from Components.Label import Label
#from Components.ChoiceList import ChoiceEntryComponent, ChoiceList
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Plugins.Extensions.SpinnerSelector.Spinner import Spinner
from enigma import getDesktop
import os

DESKTOP_WIDTH = getDesktop(0).size().width()

class SpinnerSelectionBox(Screen):

	if DESKTOP_WIDTH <= 1280:
	  skin = """
<screen name="SpinnerSelectionBox" position="0,0" size="1280,720" flags="wfNoBorder" title=" " backgroundColor="#00000000">
  <widget backgroundColor="#0003001E" name="text" font="Regular;34" foregroundColor="#00ffffff" position="70,7" size="1000,46" transparent="1" halign="left" valign="center" />
  <widget source="global.CurrentTime" render="Label" backgroundColor="#0003001E" foregroundColor="#00ffffff" position="1138,17" size="100,28" font="Regular;26" halign="right" transparent="1" valign="center">
    <convert type="ClockToText">Default</convert>
  </widget>
  <widget backgroundColor="#00000000" name="list" position="70,80" size="354,540" font="Regular;22" foregroundColor="#00ffffff" foregroundColorSelected="#00ffffff" backgroundColorSelected="#000E0C3F" itemHeight="30" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="1" />
  <widget backgroundColor="#00000000" source="previewtext" render="Label" font="Regular;26" foregroundColor="#00ffffff" position="508,80" size="200,32" transparent="1" zPosition="1" />
  <widget backgroundColor="#00000000" name="bild" position="508,130" size="200,144" zPosition="1" transparent="1" />
  <widget source="session.VideoPicture" render="Pig" position="822,80" size="416,234" zPosition="3" backgroundColor="#ffffffff" />
  <ePixmap backgroundColor="#00000000" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/logo_1280.png" position="902,349" size="256,256" alphatest="blend" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/ibar_1280.png" position="0,640" size="1280,80" zPosition="-9" alphatest="blend" />
  <eLabel position="0,640" size="1280,2" backgroundColor="#001B1775" zPosition="-8" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/ibaro_1280.png" position="0,0" size="1280,59" zPosition="-9" alphatest="blend" />
  <eLabel position="0,58" size="1280,2" backgroundColor="#001B1775" zPosition="-8" />
  <eLabel backgroundColor="#00E61805" position="65,697" size="150,5" />
  <eLabel backgroundColor="#005FE500" position="315,697" size="150,5" />
  <eLabel backgroundColor="#00E5DD00" position="565,697" size="150,5" />
  <eLabel backgroundColor="#000082E5" position="815,697" size="150,5" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/key_ok_1280.png" position="1145,675" size="43,22" alphatest="blend" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/key_exit_1280.png" position="1195,675" size="43,22" alphatest="blend" />
</screen>
"""
	else:
	  skin = """
<screen name="SpinnerSelectionBox" position="0,0" size="1920,1080" flags="wfNoBorder" title=" " backgroundColor="#00000000">
  <widget backgroundColor="#0003001E" name="text" font="Regular;51" foregroundColor="#00ffffff" position="105,10" size="1500,69" transparent="1" halign="left" valign="center" />
  <widget source="global.CurrentTime" render="Label" backgroundColor="#0003001E" foregroundColor="#00ffffff" position="1707,25" size="150,42" font="Regular;39" halign="right" transparent="1" valign="center">
    <convert type="ClockToText">Default</convert>
  </widget>
  <widget backgroundColor="#00000000" name="list" position="105,120" size="531,810" font="Regular;32" foregroundColor="#00ffffff" foregroundColorSelected="#00ffffff" backgroundColorSelected="#000E0C3F" itemHeight="45" scrollbarMode="showOnDemand" enableWrapAround="1" transparent="1" />
  <widget backgroundColor="#00000000" source="previewtext" render="Label" font="Regular;38" foregroundColor="#00ffffff" position="762,120" size="300,48" transparent="1" zPosition="1" />
  <widget backgroundColor="#00000000" name="bild" position="762,195" size="300,216" zPosition="1" transparent="1" />
  <widget source="session.VideoPicture" render="Pig" position="1233,120" size="624,351" zPosition="3" backgroundColor="#ffffffff" />
  <ePixmap backgroundColor="#00000000" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/logo_1920.png" position="1353,523" size="384,384" alphatest="blend" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/ibar_1920.png" position="0,960" size="1920,120" zPosition="-9" alphatest="blend" />
  <eLabel position="0,960" size="1920,3" backgroundColor="#001B1775" zPosition="-8" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/ibaro_1920.png" position="0,0" size="1920,88" zPosition="-9" alphatest="blend" />
  <eLabel position="0,87" size="1920,3" backgroundColor="#001B1775" zPosition="-8" />
  <eLabel backgroundColor="#00E61805" position="97,1045" size="225,7" />
  <eLabel backgroundColor="#005FE500" position="472,1045" size="225,7" />
  <eLabel backgroundColor="#00E5DD00" position="847,1045" size="225,7" />
  <eLabel backgroundColor="#000082E5" position="1222,1045" size="225,7" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/key_ok_1920.png" position="1717,1012" size="65,33" alphatest="blend" />
  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/SpinnerSelector/images/key_exit_1920.png" position="1792,1012" size="65,33" alphatest="blend" />
</screen>
"""
	def __init__(self, session, title = "", list = []):
		Screen.__init__(self, session)

		self["text"] = Label(title)
		self.list = list #[]
		self.summarylist = []
		cursel = self.list[0]
		self.Bilder = []
		if cursel:
			for i in range(64):
				if (os.path.isfile("/usr/share/enigma2/Spinner/%s/wait%d.png"%(cursel[0],i+1))):
					self.Bilder.append("/usr/share/enigma2/Spinner/%s/wait%d.png"%(cursel[0],i+1))
		self["bild"] = Spinner(self.Bilder);
		self["list"] = MenuList(list = self.list) #, selection = selection)
		self["list"].onSelectionChanged.append(self.Changed)
		self["summary_list"] = StaticText()
		self.updateSummary()
				
		self["actions"] = NumberActionMap(["WizardActions","DirectionActions"], 
		{
			"ok": self.go,
			"back": self.cancel,
			"up": self.up,
			"down": self.down
		}, -1)
		self["previewtext"] = StaticText(_("Preview") + ":")

	def Changed(self):
		cursel = self["list"].l.getCurrentSelection()
		if cursel:
			self.Bilder = []
			for i in range(64):
				if (os.path.isfile("/usr/share/enigma2/Spinner/%s/wait%d.png"%(cursel[0],i+1))):
					self.Bilder.append("/usr/share/enigma2/Spinner/%s/wait%d.png"%(cursel[0],i+1))
			self["bild"].SetBilder(self.Bilder)
			
		
	def keyLeft(self):
		pass
	
	def keyRight(self):
		pass
	
	def up(self):
		if len(self["list"].list) > 0:
			while 1:
				self["list"].instance.moveSelection(self["list"].instance.moveUp)
				self.updateSummary(self["list"].l.getCurrentSelectionIndex())
				if self["list"].l.getCurrentSelection()[0][0] != "--" or self["list"].l.getCurrentSelectionIndex() == 0:
					break

	def down(self):
		if len(self["list"].list) > 0:
			while 1:
				self["list"].instance.moveSelection(self["list"].instance.moveDown)
				self.updateSummary(self["list"].l.getCurrentSelectionIndex())
				if self["list"].l.getCurrentSelection()[0][0] != "--" or self["list"].l.getCurrentSelectionIndex() == len(self["list"].list) - 1:
					break

	# runs the current selected entry
	def go(self):
		cursel = self["list"].l.getCurrentSelection()
		if cursel:
			self.goEntry(cursel[0])
		else:
			self.cancel()

	# runs a specific entry
	def goEntry(self, entry):
		if len(entry) > 2 and isinstance(entry[1], str) and entry[1] == "CALLFUNC":
			# CALLFUNC wants to have the current selection as argument
			arg = self["list"].l.getCurrentSelection()[0]
			entry[2](arg)
		else:
			self.close(entry)

	def updateSummary(self, curpos=0):
		pos = 0
		summarytext = ""
		for entry in self.summarylist:
			if pos > curpos-2 and pos < curpos+5:
				if pos == curpos:
					summarytext += ">"
				else:
					summarytext += entry[0]
				summarytext += ' ' + entry[1] + '\n'
			pos += 1
		self["summary_list"].setText(summarytext)

	def cancel(self):
		self.close(None)
