# -*- coding: utf-8 -*-
from __future__ import print_function
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer
from enigma import eServiceReference, eSize
from urllib.request import Request, urlopen
from urllib.parse import urljoin, urlparse
from html.parser import HTMLParser
import html
import re
import os
import hashlib

VERSION = "0.8.47"
BASE="https://shiavoice.com"
UA="Mozilla/5.0 (Linux; Enigma2) AppleWebKit/537.36 Chrome/120 Safari/537.36"

# In-memory cache: avoids repeating slow HTTP parsing when moving back and forth.
_PAGE_CACHE = {}
_RAW_CACHE_DIR = "/tmp/shiavoice_cache"
_RAW_CACHE_TTL = 12 * 3600
try:
    if not os.path.isdir(_RAW_CACHE_DIR): os.makedirs(_RAW_CACHE_DIR)
except Exception:
    pass

def _raw_cache_file(url):
    return os.path.join(_RAW_CACHE_DIR, hashlib.md5(url.encode("utf-8")).hexdigest()+".html")

def _read_raw_cache(url):
    try:
        fn=_raw_cache_file(url)
        if os.path.exists(fn) and (os.path.getmtime(fn) + _RAW_CACHE_TTL) > __import__('time').time():
            with open(fn,"r",encoding="utf-8",errors="ignore") as f:
                return f.read()
    except Exception:
        pass
    return None

def _write_raw_cache(url, data):
    try:
        fn=_raw_cache_file(url); tmp=fn+".tmp"
        with open(tmp,"w",encoding="utf-8") as f: f.write(data)
        os.replace(tmp,fn)
    except Exception:
        pass


# Known current site sections. The first category is also a guaranteed test.
CATEGORIES=[
 ("القرآن الكريم","/quran"),
 ("الأدعية والمناجيات","/ed3ie"),
 ("الزيارات","/zeyarat"),
 ("محاضرات إسلامية","/mohadrat"),
 ("خطب المعصومين","/khotab"),
 ("لطميات","/letmiat"),
 ("مواليد وأفراح","/afrah"),
 ("أناشيد وتواشيح","/enashid"),
 ("الكتب المسموعة","/kutub"),
 ("قصائد وأشعار","/qasaed"),
]

def get_html(path):
    url=path if path.startswith("http") else urljoin(BASE,path)
    # Persistent short-lived raw HTML cache: repeated navigation becomes local
    # and avoids blocking the Enigma2 GUI on the same HTTP requests.
    cached=_read_raw_cache(url)
    if cached is not None:
        return cached
    req=Request(url,headers={"User-Agent":UA,"Accept-Language":"ar,en;q=0.8","Connection":"keep-alive"})
    try:
        with urlopen(req,timeout=12) as r:
            data=r.read().decode("utf-8","ignore")
        _write_raw_cache(url,data)
        return data
    except Exception:
        # If the site is temporarily slow/offline, use an older cached page
        # rather than leaving the user staring at a blocked screen.
        try:
            fn=_raw_cache_file(url)
            if os.path.exists(fn):
                with open(fn,"r",encoding="utf-8",errors="ignore") as f: return f.read()
        except Exception:
            pass
        raise

def path_of(h):
    h=html.unescape((h or "").strip())
    if h.startswith("http://") or h.startswith("https://"):
        return urlparse(h).path
    if h.startswith("//"):
        return urlparse("https:"+h).path
    return urlparse(urljoin(BASE+"/",h)).path

def text_clean(s):
    return re.sub(r"\s+"," ",html.unescape(s or "")).strip()


class LinkParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self,convert_charrefs=True)
        self.items=[]
        self.href=None
        self.buf=[]
        self.img=None
        self.in_a=False
        self.in_h=False
        self.hbuf=[]
    def handle_starttag(self,tag,attrs):
        d=dict(attrs)
        tl=tag.lower()
        if tl=="a":
            self.href=d.get("href"); self.buf=[]; self.img=None; self.in_a=True
        elif tl=="img" and self.in_a:
            self.img=d.get("src")
        elif tl in ("h1","h2","h3","h4","h5","h6"):
            self.in_h=True; self.hbuf=[]
    def handle_data(self,data):
        if self.in_a: self.buf.append(data)
        if self.in_h: self.hbuf.append(data)
    def handle_endtag(self,tag):
        tl=tag.lower()
        if tl=="a" and self.in_a:
            self.items.append(("a",self.href,text_clean(" ".join(self.buf)),self.img))
            self.href=None; self.buf=[]; self.img=None; self.in_a=False
        elif tl in ("h1","h2","h3","h4","h5","h6") and self.in_h:
            self.items.append(("h",None,text_clean(" ".join(self.hbuf)),None))
            self.in_h=False; self.hbuf=[]


ARABIC_ORDER = "ابتثجحخدذرزسشصضطظعغفقكلمنهوي"

def arabic_sort_key(text):
    s=text_clean(text)
    # Ignore Arabic definite article at the beginning.
    if s.startswith("ال"):
        s=s[2:]
    # Normalize common Arabic variants for sorting only.
    trans={"أ":"ا","إ":"ا","آ":"ا","ٱ":"ا","ى":"ي","ئ":"ي","ؤ":"و","ة":"ه"}
    s="".join(trans.get(ch,ch) for ch in s)
    s=re.sub(r"[\u064B-\u065F\u0670]", "", s)
    ranks={ch:i for i,ch in enumerate(ARABIC_ORDER)}
    return ([ranks.get(ch,999) for ch in s], s)

def sort_arabic_entries(entries):
    # Sort only category/person entries; never reorder audio playback items.
    # Shiavoice sometimes emits a standalone Arabic letter "ا" as a tiny
    # anchor (copy/link UI). It is not a person or a category, so remove it.
    cats=[]
    for x in entries:
        if len(x)>1 and x[1]=="cat":
            title=text_clean(x[0])
            if title in ("ا", "أ"):
                continue
            cats.append(x)
    others=[x for x in entries if len(x)<=1 or x[1]!="cat"]
    cats.sort(key=lambda x: arabic_sort_key(x[0]))
    return cats+others

def parse_page(path, section=None):
    """Parse Shiavoice while preserving the site's hierarchy.

    Important site patterns:
      1) A main section (/ed3ie, /zeyarat, ...) -> its classifications.
      2) A classification page (e.g. /cat-550 أدعية الأيام) -> people who
         have recordings in THAT classification.
      3) A person/category page (e.g. عبدالباسط /cat-23) -> that person's
         own classifications.
      4) A recording page -> only the page's own audio items, never related
         recommendations appended by the site.
    """
    cache_key=path_of(path).rstrip("/")
    cached=_PAGE_CACHE.get(cache_key)
    if cached is not None:
        # Return a shallow copy so UI filtering/reordering never mutates the cache.
        return list(cached)
    raw=get_html(path)
    p=LinkParser(); p.feed(raw); links=p.items
    pth=path_of(path).rstrip("/")

    def cache_return(value):
        _PAGE_CACHE[cache_key]=list(value)
        return list(value)

    def is_cat(href):
        return bool(re.match(r"^/cat-(\d+)(?:/)?$", path_of(href)))

    def cat_item(href,title,img):
        target=path_of(href)
        return (title,"cat",urljoin(BASE,target),image_url(img))

    def stop_heading(title):
        t=title or ""
        return any(k in t for k in (
            "الأكثر استماعاً في النوع", "أحدث الإصدارات",
            "إصدارات ذات صلة", "المقاطع اليوم", "المقاطع ذات صلة",
            "استمع مجدداً"
        ))

    # ---------------------------------------------------------------
    # Main section pages: show the site's classifications exactly as the
    # website does. The Quran page is special because it has readers first.
    # ---------------------------------------------------------------
    root_paths=set(path_of(x[1]).rstrip("/") for x in CATEGORIES)
    if pth in root_paths and pth != "/quran":
        out=[]; seen=set()
        for kind,href,title,img in links:
            if kind=="h" and stop_heading(title):
                break
            if kind!="a" or not href or not title or not is_cat(href):
                continue
            # Exclude unrelated navigation links if they ever appear.
            target=path_of(href)
            if target == pth:
                continue
            key=target
            if key not in seen:
                seen.add(key); out.append(cat_item(href,title,img))
        if out:
            return cache_return(out)

    # ---------------------------------------------------------------
    # Quran landing page: readers first, then classifications.
    # ---------------------------------------------------------------
    if pth in ("/quran", "/cat-1"):
        start=-1; end=len(links)
        for idx,x in enumerate(links):
            if x[0]=="h" and "الرواديد والمحاضرون" in x[2]:
                start=idx+1
            elif start>=0 and x[0]=="h" and "التصانيف" in x[2]:
                end=idx; break

        readers=[]; cats=[]; seen_readers=set(); seen_cats=set()
        if start>=0:
            for kind,href,title,img in links[start:end]:
                if kind!="a" or not href or not title or not is_cat(href):
                    continue
                item=cat_item(href,title,img); key=item[2]
                if key not in seen_readers:
                    seen_readers.add(key); readers.append(item)

        # Keep only actual Quran classifications after the reader block.
        for kind,href,title,img in links[end:]:
            if kind=="h" and stop_heading(title):
                break
            if kind!="a" or not href or not title or not is_cat(href):
                continue
            if title not in ("English", "قراء آخرون"):
                item=cat_item(href,title,img)
                if item[2] not in seen_cats:
                    seen_cats.add(item[2]); cats.append(item)

        readers=sort_arabic_entries(readers)
        return cache_return(readers+cats)

    # ---------------------------------------------------------------
    # Classification page with "الرواديد والمحاضرون".
    # Example: أدعية الأيام -> people -> choose a person -> recordings.
    # The person links are category URLs (/cat-N), not generic profile URLs.
    # ---------------------------------------------------------------
    people_start=-1
    for idx,x in enumerate(links):
        if x[0]=="h" and "الرواديد والمحاضرون" in (x[2] or ""):
            people_start=idx+1; break
    if people_start>=0:
        out=[]; seen=set()
        for kind,href,title,img in links[people_start:]:
            if kind=="h" and stop_heading(title):
                break
            if kind!="a" or not href or not title or not is_cat(href):
                continue
            item=cat_item(href,title,img); key=item[2]
            if key not in seen:
                seen.add(key); out.append(item)
        return cache_return(sort_arabic_entries(out))

    # ---------------------------------------------------------------
    # Person page with "التصانيف": show ONLY that person's classifications.
    # Never include site-wide recommendations below it.
    # ---------------------------------------------------------------
    has_taxonomy=any(kind=="h" and "التصانيف" in (title or "") for kind,href,title,img in links)
    if has_taxonomy:
        out=[]; seen=set()
        for kind,href,title,img in links:
            if kind=="h" and stop_heading(title):
                break
            if kind!="a" or not href or not title or not is_cat(href):
                continue
            item=cat_item(href,title,img); key=item[2]
            if key not in seen:
                seen.add(key); out.append(item)
        return cache_return(out)

    # ---------------------------------------------------------------
    # Recording/category page: collect the main /play-* block from ALL
    # pagination pages.  The site currently uses /cat-N/page-2 etc.
    # and may expose 114 items over 5 pages.
    # ---------------------------------------------------------------
    def extract_audio_page(page_path):
        raw2=get_html(page_path)
        pp=LinkParser(); pp.feed(raw2)
        out2=[]; seen2=set(); started2=False
        # Use the structured anchor parser.  Duration is taken from the small
        # card area immediately after the audio link, avoiding the next card's
        # duration when the current card has no duration text.
        for idx,(kind,href,title,img) in enumerate(pp.items):
            if kind!="a" or not href or not title:
                continue
            p2=path_of(href)
            pm=re.match(r"^/play-([A-Za-z0-9_-]+)$",p2)
            if not pm:
                if started2 and kind=="a":
                    continue
                continue
            started2=True
            duration=""
            try:
                pos=raw2.find(href)
                if pos<0:
                    pos=raw2.find(p2)
                if pos>=0:
                    end_a=raw2.find("</a>",pos)
                    start_next=raw2.find("<a ",end_a if end_a>=0 else pos+1)
                    if end_a<0:
                        end_a=pos+len(href)
                    if start_next<0:
                        start_next=min(len(raw2),end_a+900)
                    else:
                        start_next=min(start_next,end_a+900)
                    chunk=html.unescape(re.sub(r"<[^>]+>"," ",raw2[end_a:start_next]))
                    # Accept both mm:ss and hh:mm:ss.  Prefer the first
                    # clock-looking value in this card tail.
                    times=re.findall(r"(?<![\d:])(?:\d{1,2}:)?\d{1,2}:\d{2}(?!\d)",chunk)
                    if times:
                        duration=times[0]
            except Exception:
                duration=""
            item=(title,"play",BASE+"/stream-"+pm.group(1),img,duration)
            if item[2] not in seen2:
                seen2.add(item[2]); out2.append(item)
        return out2, pp.items

    pages=[path_of(path)]
    basepath=path_of(path).rstrip("/")
    for kind,href,title,img in links:
        if kind=="a" and href:
            hp=path_of(href).rstrip("/")
            if re.match(r"^"+re.escape(basepath)+r"/page-[0-9]+$", hp) and hp not in pages:
                pages.append(hp)
    def page_num(x):
        m=re.search(r"/page-(\d+)$",x)
        return int(m.group(1)) if m else 1
    pages=sorted(pages,key=page_num)
    out=[]; seen=set()
    for pg in pages:
        try:
            page_items,_=extract_audio_page(pg)
            for item in page_items:
                if item[2] not in seen:
                    seen.add(item[2]); out.append(item)
        except Exception as e:
            print("[Shiavoice] page error:",pg,e)
    return cache_return(out)
def stop_audio():
    try:
        from Screens.InfoBar import InfoBar
        if getattr(InfoBar,"instance",None):
            InfoBar.instance.session.nav.stopService()
    except Exception:
        pass

class ShiavoiceKeyboard(VirtualKeyBoard):
    def shiftSelected(self):
        # In this plugin, Yellow changes the active keyboard layer persistently.
        # It must not revert after one character.
        if getattr(self, "locale", "").startswith("ar_"):
            if getattr(self, "shiftLevel", 0) < 2:
                self.shiftLevel = 2
            else:
                self.shiftLevel = 3 if self.shiftLevel == 2 else 2
            self.shiftHold = -1
            self.shiftCommon()
        else:
            self.capsLockSelected()

def page_profile_image(path, title=None):
    """Find the correct person/category image from a Shiavoice page.

    The Quran landing page lists an image immediately before each reader link,
    but LinkParser does not associate that image with the link. On the reader
    page itself the portrait is an <img> whose alt text is normally the reader
    name. Prefer that exact match so we never accidentally use the generic
    Quran image.
    """
    try:
        raw=get_html(path)
        matches=re.findall(r'<img\b[^>]*>', raw, re.I)

        def norm_text(v):
            try:
                v=html.unescape(v or "")
                v=v.replace("\u0640", "")
                v=re.sub(r"\s+", "", v)
                return v
            except Exception:
                return v or ""

        wanted=norm_text(title) if title else ""
        best=None
        best_score=-1
        for tag in matches:
            sm=re.search(r'\bsrc=["\']([^"\']+)["\']', tag, re.I)
            if not sm:
                continue
            src=sm.group(1)
            full=image_url(src)
            if not full or '/assets/img/cats/' not in full:
                continue
            altm=re.search(r'\balt=["\']([^"\']*)["\']', tag, re.I)
            alt=altm.group(1) if altm else ""
            nalt=norm_text(alt)
            score=0
            if wanted and nalt:
                if nalt == wanted:
                    score=100
                elif wanted in nalt or nalt in wanted:
                    score=80
            if score > best_score:
                best_score=score
                best=full
        if best:
            return best

        # Fallback for pages whose portrait has no useful alt text.
        for tag in matches:
            sm=re.search(r'\bsrc=["\']([^"\']+)["\']', tag, re.I)
            if sm:
                full=image_url(sm.group(1))
                if full and '/assets/img/cats/' in full:
                    return full
    except Exception as e:
        print("[Shiavoice] profile image parse error:",e)
    return None

def image_url(src):
    if not src:
        return None
    src=html.unescape(src.strip())
    if src.startswith("data:"):
        return None
    return urljoin(BASE,src)

def download_image(url):
    if not url:
        return None
    try:
        from urllib.request import Request, urlopen
        req=Request(url,headers={"User-Agent":UA})
        data=urlopen(req,timeout=15).read()
        if not data or len(data)>3*1024*1024:
            return None
        fn="/tmp/shiavoice_person.jpg"
        with open(fn,"wb") as f:
            f.write(data)
        return fn
    except Exception as e:
        print("[Shiavoice] image error:",e)
        return None

def _shiavoice_filter_ui_entries(entries, title=""):
    out=[]
    for e in entries:
        try:
            name=str(e[0]).strip()
        except Exception:
            out.append(e)
            continue
        if name in ("ا", "أ", "قراء آخرون", "قراء اخرون", "قراء آخر"):
            continue
        out.append(e)
    # For Abdulbasit, show only the two requested categories.
    if "عبدالباسط" in title or "عبد الباسط" in title:
        wanted=[e for e in out if str(e[0]).strip() in ("الترتيل", "التلاوة")]
        if wanted:
            out=wanted
    return out

def _shiavoice_ensure_abdulbasit(entries, title):
    if title != "القرآن الكريم":
        return entries
    if any("عبدالباسط" in str(e[0]) or "عبد الباسط" in str(e[0]) for e in entries):
        return entries
    return [("عبدالباسط عبدالصمد", "cat", BASE + "/cat-23", BASE + "/assets/img/cats/eabdalbasit-eibdalsimd-7aad6974.jpg")] + entries

def _shiavoice_insert_abdulbasit(entries, title):
    if title != "القرآن الكريم":
        return entries
    entries=list(entries)
    # Remove accidental duplicate/manual variants first.
    entries=[e for e in entries if "عبدالباسط عبدالصمد" not in str(e[0]) and "عبد الباسط عبد الصمد" not in str(e[0])]
    entries.insert(0, ("عبدالباسط عبدالصمد", "cat", BASE + "/cat-23", BASE + "/assets/img/cats/eabdalbasit-eibdalsimd-7aad6974.jpg"))
    return entries

class Browser(Screen):
    """Main Shiavoice interface: sections left, results center, audio player right."""
    skin="""
    <screen name="Shiavoice" position="0,0" size="1920,1080" backgroundColor="#061326">
      <widget name="logo" position="1450,12" size="440,145" alphatest="on" />
      <widget name="version" position="1450,145" size="440,32" font="Regular;20" halign="right" foregroundColor="#D8B04E" transparent="1" />
      <widget name="leftTitle" position="25,150" size="1070,52" font="Regular;30" halign="center" foregroundColor="#FFFFFF" transparent="1" />
      <widget name="crumb" position="25,150" size="1070,52" font="Regular;30" halign="center" foregroundColor="#FFFFFF" transparent="1" />
      <widget name="list" position="25,205" size="1070,710" font="Regular;30" itemHeight="50" scrollbarMode="showOnDemand" foregroundColor="#E6E6E6" backgroundColor="#07182B" selectionColor="#D8B04E" selectionForegroundColor="#07182B" halign="left" />
      <widget name="panel" position="1120,155" size="770,760" backgroundColor="#0B1B31" />
      <widget name="playerLogo" position="1320,180" size="370,300" alphatest="on" />
      <widget name="now" position="1160,490" size="690,55" font="Regular;31" halign="center" foregroundColor="#FFFFFF" transparent="1" />
      <widget name="artist" position="1160,545" size="690,42" font="Regular;23" halign="center" foregroundColor="#C9D2E3" transparent="1" />
      <widget name="progressBg" position="1170,610" size="670,28" backgroundColor="#132B45" />
      <widget name="progressFill" position="1170,610" size="1,28" backgroundColor="#D8B04E" />
      <widget name="time" position="1170,645" size="670,40" font="Regular;23" halign="center" foregroundColor="#E6E6E6" transparent="1" />
      <widget name="controls" position="1160,700" size="690,70" font="Regular;34" halign="center" foregroundColor="#D8B04E" transparent="1" />
      <widget name="status" position="1160,775" size="690,45" font="Regular;21" halign="center" foregroundColor="#C9D2E3" transparent="1" />
      <widget name="bottomExit" position="80,945" size="300,48" font="Regular;25" halign="center" foregroundColor="#E53935" transparent="1" />
      <widget name="bottomPlay" position="420,945" size="300,48" font="Regular;25" halign="center" foregroundColor="#35C759" transparent="1" />
      <widget name="bottomBouquet" position="760,945" size="430,48" font="Regular;25" halign="center" foregroundColor="#FFD60A" transparent="1" />
    </screen>
    """
    def __init__(self,session,title="Shiavoice - صوت الشيعة",entries=None,section=None):
        Screen.__init__(self,session)
        self.session=session
        self.section=section
        self.current_title=title
        self.entries=entries if entries is not None else [(n,"cat",p,None) for n,p in CATEGORIES]
        self.pages=[]
        # Keep the image associated with the current page while navigating deeper.
        self.current_image_src=None
        self.profile_image_src=None
        self.profile_owner_title=None
        self.profile_owner_path=None
        self.reader_image_cache={}
        self.is_root=(entries is None)
        self.side_entries=[(n,"cat",p,None) for n,p in CATEGORIES]
        self.play_item_ref=None
        self.paused=False
        self.elapsed=0
        self.length=0
        self.item_duration=0
        self._fallback_start=None
        self._fallback_pause_started=None
        self._native_stuck=0
        self._last_native_pos=None
        self.player_timer=eTimer()
        try:self.player_timer.callback.append(self.tick)
        except Exception:pass

        self["logo"]=Pixmap()
        self["playerLogo"]=Pixmap()
        self["version"]=Label("v"+VERSION+"   shiavoice.com")
        self["leftTitle"]=Label("الأقسام الرئيسية" if self.is_root else title)
        self["crumb"]=Label("الأقسام الرئيسية" if self.is_root else title)
        self.entries=_shiavoice_filter_ui_entries(self.entries,title) if not self.is_root else self.entries
        self["list"]=MenuList(self._display_entries(self.entries))
        try:
            self["list"].onSelectionChanged.append(self._selection_changed)
        except Exception:
            pass
        self["now"]=Label("اختر تسجيلاً للاستماع")
        self["artist"]=Label("مكتبة الصوتيات الشيعية")
        self["time"]=Label("00:00 / --:--")
        self["controls"]=Label("▶  تشغيل     ⏸  إيقاف مؤقت")
        self["status"]=Label("جاهز")
        self["bottomExit"]=Label("Exit")
        self["bottomPlay"]=Label("تشغيل")
        self["bottomBouquet"]=Label("إضافة إلى Bouquet")
        self["progressBg"]=Label("")
        self["progressFill"]=Label("")
        self._progress_width=670
        self._set_progress(0)
        self.load_logo()

        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{
            "ok":self.ok,
            "cancel":self.exit,
            "left":self.left,
            "right":self.right,
            "up":self.up,
            "down":self.down,
            "channelUp":self.prev_item,
            "channelDown":self.next_item,
            "red":self.exit,
            "green":self.play_from_remote,
            "yellow":self.add_selected_to_bouquet,
        },-1)
        self.onClose.append(self.cleanup)

        self._show_page(self.current_title, self.entries, root=self.is_root)

    def _display_entries(self, entries):
        # Keep titles clean and unnumbered.
        # Numbering caused bidi/spacing artifacts on some Enigma2 fonts.
        out=[]
        for item in entries:
            try: name=item[0]
            except Exception: name=str(item)
            out.append(name)
        return out

    def _show_page(self, title, entries, root=False):
        self.current_title=title
        self.entries=list(entries or [])
        if not root:
            self.entries=_shiavoice_filter_ui_entries(self.entries,title)
        self["list"].setList(self._display_entries(self.entries))
        self["list"].moveToIndex(0)
        self["leftTitle"].setText("الأقسام الرئيسية" if root else title)
        self._selection_changed()
        self["crumb"].setText("الأقسام الرئيسية" if root else title)
        self["bottomExit"].setText("Exit")
        self["bottomPlay"].setText("تشغيل")
        self["bottomBouquet"].setText("إضافة إلى Bouquet")

    def _selection_changed(self):
        """Update the right-side image as soon as the highlighted item changes.
        Abdulbasit's portrait is kept for his profile, ترتيل, تلاوة and all
        surahs/recordings shown inside those sections.
        """
        try:
            i=self["list"].getSelectionIndex()
            if i < 0 or i >= len(self.entries):
                return
            item=self.entries[i]
            title=str(item[0]) if len(item)>0 else ""
            img=item[3] if len(item)>3 else None
            path=str(item[2]) if len(item)>2 else ""

            # Quran reader names normally have no image attached to the
            # <a> element. Resolve the reader's own /cat-N page immediately
            # when the name is highlighted, so the portrait appears without OK.
            if self.current_title == "القرآن الكريم" and len(item)>1 and item[1] == "cat" and re.search(r"/cat-\d+", path):
                cached_img=self.reader_image_cache.get(path)
                if cached_img:
                    img=cached_img
                else:
                    try:
                        img=page_profile_image(path, title)
                        if img:
                            self.reader_image_cache[path]=img
                    except Exception as e:
                        print("[Shiavoice] reader image lookup error:",e)

            if "عبدالباسط" in title or "عبد الباسط" in title:
                img=BASE + "/assets/img/cats/eabdalbasit-eibdalsimd-7aad6974.jpg"
                self.profile_image_src=img
                self.profile_owner_title="عبدالباسط عبدالصمد"
            # Once a reader is selected, keep that reader's portrait for all
            # child pages (ترتيل, تلاوة, and every surah/recording).
            if self.profile_image_src and self.profile_owner_title and self.current_title != "القرآن الكريم":
                img=self.profile_image_src
            if img:
                self.load_player_image(img)
        except Exception as e:
            print("[Shiavoice] selection image error:",e)

    def _set_player_pixmap(self, path):
        try:
            if not path or not os.path.exists(path):
                return False
            if not hasattr(self, "player_picload"):
                from enigma import ePicLoad
                self.player_picload=ePicLoad()
            if not hasattr(self, "_player_picload_connected"):
                self._player_picload_connected=True
                self.player_picload.PictureData.get().append(self._player_image_decoded)
            self.player_picload.setPara((270,270,1,1,0,0,"#0B1B31"))
            self.player_picload.startDecode(path)
            return True
        except Exception as e:
            print("[Shiavoice] player image error:",e)
            return False

    def _player_image_decoded(self, picInfo=None):
        try:
            ptr=self.player_picload.getData()
            if ptr:
                self["playerLogo"].instance.setPixmap(ptr)
                self["playerLogo"].show()
        except Exception:
            pass

    def load_player_image(self, src):
        try:
            src=image_url(src) if src else None
            self.current_image_src=src
            if not src:
                return self._set_player_pixmap(os.path.join(os.path.dirname(__file__),"icon.png"))
            ext=os.path.splitext(urlparse(src).path)[1].lower()
            if ext not in (".jpg",".jpeg",".png",".webp"):
                ext=".jpg"
            cache="/tmp/shiavoice_img_"+hashlib.md5(src.encode("utf-8")).hexdigest()+ext
            if not os.path.exists(cache) or os.path.getsize(cache)<100:
                req=Request(src,headers={"User-Agent":UA})
                data=urlopen(req,timeout=6).read()
                if not data or len(data)>3*1024*1024:
                    raise ValueError("invalid image")
                with open(cache,"wb") as f: f.write(data)
            if not self._set_player_pixmap(cache):
                return self._set_player_pixmap(os.path.join(os.path.dirname(__file__),"icon.png"))
            return True
        except Exception as e:
            print("[Shiavoice] image download error:",e)
            return self._set_player_pixmap(os.path.join(os.path.dirname(__file__),"icon.png"))

    def load_logo(self):
        try:
            from enigma import ePicLoad
            path=os.path.join(os.path.dirname(__file__),"icon.png")
            if not hasattr(self,"logo_picload"): self.logo_picload=ePicLoad()
            if not hasattr(self,"player_picload"): self.player_picload=ePicLoad()
            def decoded_logo(picInfo=None):
                try:
                    ptr=self.logo_picload.getData()
                    if ptr:
                        self["logo"].instance.setPixmap(ptr); self["logo"].show()
                        # Use the plugin logo in the player panel only while
                        # there is no selected/person image. Never overwrite a
                        # person image that was just selected.
                        if not getattr(self,"current_image_src",None):
                            self["playerLogo"].instance.setPixmap(ptr); self["playerLogo"].show()
                except Exception: pass
            self.logo_picload.PictureData.get().append(decoded_logo)
            self.logo_picload.setPara((300,115,1,1,0,0,"#061326")); self.logo_picload.startDecode(path)
        except Exception as e:
            print("[Shiavoice] logo error:",e)

    def _set_progress(self, value):
        """Draw a reliable gold fill over a dark track.  This avoids skin/theme-specific ProgressBar rendering."""
        try:
            value=max(0,min(1000,int(value)))
            width=max(1,int(self._progress_width*value/1000.0)) if value else 1
            self["progressFill"].instance.resize(eSize(width,28))
        except Exception:
            pass

    def load_section(self,index):
        # Kept for compatibility; selecting a root section now opens a new page.
        if index<0 or index>=len(self.side_entries): return
        item=self.side_entries[index]
        self.open_category(item)

    def open_category(self,item):
        try:
            entries=parse_page(item[2])
            entries=_shiavoice_insert_abdulbasit(entries,item[0])
            entries=_shiavoice_filter_ui_entries(entries,item[0])
            self.pages.append((self.current_title, list(self.entries), self.current_image_src, self.profile_image_src, self.profile_owner_title, self.profile_owner_path))

            path=str(item[2]) if len(item)>2 else ""
            item_title=str(item[0]) if len(item)>0 else ""
            is_abdulbasit=("عبدالباسط" in item_title or "عبد الباسط" in item_title)
            is_profile=bool(re.search(r"/cat-\d+", path))

            # Entering any reader from the Quran: resolve and lock that
            # reader's portrait for every child page.
            if self.current_title == "القرآن الكريم" and is_profile:
                img=item[3] if len(item)>3 else None
                if not img:
                    img=self.reader_image_cache.get(path)
                if not img:
                    img=page_profile_image(path, item_title)
                if img:
                    self.profile_image_src=img
                    self.profile_owner_title=item_title
                    self.profile_owner_path=path
            elif self.current_title in ("القرآن الكريم", "الأقسام الرئيسية") and not is_abdulbasit:
                self.profile_image_src=None
                self.profile_owner_title=None
                self.profile_owner_path=None

            if is_abdulbasit and "cat-23" in path:
                self.profile_image_src=BASE + "/assets/img/cats/eabdalbasit-eibdalsimd-7aad6974.jpg"
                self.profile_owner_title="عبدالباسط عبدالصمد"
                self.profile_owner_path=path

            self._show_page(item[0], entries, root=False)

            if self.profile_image_src and self.profile_owner_title:
                self.load_player_image(self.profile_image_src)
            elif is_profile:
                img=item[3] if len(item)>3 else None
                if not img:
                    img=page_profile_image(item[2], item_title)
                if img:
                    self.load_player_image(img)
            self["status"].setText("اختر من الصفحة")
        except Exception as e:
            print("[Shiavoice] category error:",e); self["status"].setText("تعذر فتح الصفحة")

    def back_page(self):
        if not self.pages:
            self.exit(); return
        page=self.pages.pop()
        title,entries=page[0],page[1]
        previous_image=page[2] if len(page)>2 else None
        self.profile_image_src=page[3] if len(page)>3 else None
        self.profile_owner_title=page[4] if len(page)>4 else None
        self.profile_owner_path=page[5] if len(page)>5 else None
        if title == "القرآن الكريم" or not self.pages:
            # At the Quran reader list we want the highlighted reader image
            # to be resolved again by _selection_changed.
            if title == "القرآن الكريم":
                self.profile_image_src=None
                self.profile_owner_title=None
                self.profile_owner_path=None
        self._show_page(title, entries, root=(not self.pages))
        if self.profile_image_src and self.profile_owner_title:
            self.load_player_image(self.profile_image_src)
        elif previous_image:
            self.load_player_image(previous_image)
        else:
            self.load_player_image(None)
        self["status"].setText("اختر من الصفحة")

    def left(self):
        # Fast navigation with the remote: left/right jump by one visible page
        # of the current list. EXIT remains the dedicated back-to-previous-page key.
        try:
            self["list"].pageUp()
        except Exception:
            try:
                for _ in range(8): self["list"].up()
            except Exception: pass

    def right(self):
        try:
            self["list"].pageDown()
        except Exception:
            try:
                for _ in range(8): self["list"].down()
            except Exception: pass

    def up(self):
        try: self["list"].up()
        except Exception: pass

    def down(self):
        try: self["list"].down()
        except Exception: pass

    def play_from_remote(self):
        """Green button: play the selected recording, or resume a paused one."""
        try:
            if self.play_item_ref and self.paused:
                self.toggle_pause()
                return
            i=self["list"].getSelectionIndex()
            if i < 0 or i >= len(self.entries):
                return
            item=self.entries[i]
            if item[1] == "play":
                if self.play_item_ref and self.play_item_ref[2] == item[2]:
                    if self.paused:
                        self.toggle_pause()
                else:
                    self.play_item(item)
        except Exception:
            pass

    def _ensure_shiavoice_bouquet(self):
        """Create/load a dedicated TV bouquet named Shiavoice using Enigma2's
        normal bouquet editing API.  This mirrors ChannelSelection.addBouquet.
        """
        from enigma import eServiceCenter, eServiceReference, eDVBDB
        sh = eServiceCenter.getInstance()
        root_ref = eServiceReference(
            '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'
        )
        bouquet_name = "Shiavoice"
        bouquet_file = "userbouquet.shiavoice.tv"
        bouquet_ref = eServiceReference(
            '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.shiavoice.tv" ORDER BY bouquet'
        )

        # Check whether the bouquet is already present in bouquets.tv.
        root_list = sh.list(root_ref)
        if root_list is None:
            return None
        found = False
        it = root_list.getNext()
        while it.valid():
            if it.toString() == bouquet_ref.toString():
                found = True
                break
            it = root_list.getNext()

        if not found:
            mutable_root = root_ref.list().startEdit()
            if mutable_root is None:
                return None
            # eBouquet::addService returns 0 on success and non-zero on failure.
            if mutable_root.addService(bouquet_ref):
                try:
                    mutable_root.cancel()
                except Exception:
                    pass
                return None
            mutable_root.flushChanges()
            eDVBDB.getInstance().reloadBouquets()

        # Open the newly-created/known bouquet and set its visible name.
        bouquet_list = sh.list(bouquet_ref)
        if bouquet_list is None:
            return None
        editable = bouquet_list.startEdit()
        if editable is None:
            return None
        try:
            editable.setListName(bouquet_name)
            editable.flushChanges()
        except Exception:
            try:
                editable.cancel()
            except Exception:
                pass
            return None
        eDVBDB.getInstance().reloadBouquets()
        return sh.list(bouquet_ref).startEdit()

    def add_selected_to_bouquet(self):
        """Yellow: add the selected audio stream to a real OpenATV bouquet.
        Uses the same plain-text bouquet format already present on the box,
        which is reliable even when the Enigma2 bouquet editor API is unavailable
        or rejects a 4097 HTTP reference.
        """
        try:
            i=self["list"].getSelectionIndex()
            if i < 0 or i >= len(self.entries):
                return
            item=self.entries[i]
            if item[1] != "play":
                self["status"].setText("اختر تسجيلاً صوتيًا أولاً")
                return

            url=str(item[2]).strip()
            title=str(item[0]).strip() or "Shiavoice"
            # Keep bouquet syntax safe: the URL uses encoded ':' like normal
            # Enigma2 4097 IPTV entries, while slashes remain readable.
            service_url=url.replace(":","%3a")
            safe_title=re.sub(r"[\r\n]+"," ",title).replace(":"," - ").strip()
            bouquet_file="/etc/enigma2/userbouquet.shiavoice.tv"
            bouquets_tv="/etc/enigma2/bouquets.tv"
            bouquet_line='#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.shiavoice.tv" ORDER BY bouquet'
            service_line="#SERVICE 4097:0:0:0:0:0:0:0:0:0:%s:%s" % (service_url,safe_title)
            desc_line="#DESCRIPTION %s" % safe_title

            # Create the dedicated bouquet if it does not exist.
            if not os.path.exists(bouquet_file):
                with open(bouquet_file,"w",encoding="utf-8") as f:
                    f.write("#NAME Shiavoice\n")

            # Register the bouquet in the main TV bouquet index.
            try:
                with open(bouquets_tv,"r",encoding="utf-8",errors="ignore") as f:
                    root=f.read()
            except Exception:
                root=""
            if '"userbouquet.shiavoice.tv"' not in root:
                with open(bouquets_tv,"a",encoding="utf-8") as f:
                    if root and not root.endswith("\n"): f.write("\n")
                    f.write(bouquet_line+"\n")

            # Do not add the same stream twice.
            try:
                with open(bouquet_file,"r",encoding="utf-8",errors="ignore") as f:
                    existing=f.read()
            except Exception:
                existing=""
            if url in existing or service_url in existing:
                try:
                    from enigma import eDVBDB
                    eDVBDB.getInstance().reloadBouquets()
                except Exception:
                    pass
                self["status"].setText("موجود مسبقًا في Bouquet Shiavoice")
                return

            with open(bouquet_file,"a",encoding="utf-8") as f:
                f.write(service_line+"\n")
                f.write(desc_line+"\n")

            try:
                from enigma import eDVBDB
                eDVBDB.getInstance().reloadBouquets()
            except Exception:
                pass
            try:
                os.sync()
            except Exception:
                pass
            self["status"].setText("✓ تمت إضافة التسجيل إلى Bouquet Shiavoice")
            print("[Shiavoice] bouquet added:",safe_title,url)
        except Exception as e:
            print("[Shiavoice] bouquet error:",e)
            self["status"].setText("تعذر إضافة التسجيل إلى Bouquet")

    def pause_from_remote(self):
        """Yellow button: pause the current recording."""
        try:
            if self.play_item_ref and not self.paused:
                self.toggle_pause()
        except Exception:
            pass

    def ok(self):
        i=self["list"].getSelectionIndex()
        if i<0 or i>=len(self.entries): return
        item=self.entries[i]
        if item[1]=="play":
            if self.play_item_ref and self.play_item_ref[2]==item[2]:
                self.toggle_pause()
            else:
                self.play_item(item)
        elif item[1]=="cat":
            self.open_category(item)

    def play_item(self,item):
        try:
            self.play_item_ref=item; self.paused=False; self.elapsed=0; self.length=0; self.item_duration=0
            self._native_stuck=0; self._last_native_pos=None; self._fallback_pause_started=None
            try:
                if len(item)>4 and item[4]:
                    parts=[int(x) for x in str(item[4]).split(":")]
                    if len(parts)==2: self.item_duration=parts[0]*60+parts[1]
                    elif len(parts)==3: self.item_duration=parts[0]*3600+parts[1]*60+parts[2]
                    self.length=self.item_duration
            except Exception: self.item_duration=0
            self["now"].setText(item[0]); self["artist"].setText(self.current_title if self.current_title else "Shiavoice")
            if self.profile_image_src and self.current_title in ("عبدالباسط عبدالصمد", "الترتيل", "التلاوة"):
                self.load_player_image(self.profile_image_src)
            else:
                self.load_player_image(item[3] if len(item)>3 else None)
            ref=eServiceReference(4097,0,item[2]); ref.setName(item[0])
            self.session.nav.stopService(); self.session.nav.playService(ref)
            self._fallback_start=__import__('time').time()
            self["controls"].setText("⏸  إيقاف مؤقت")
            self["status"].setText("▶ يعمل الآن")
            self.player_timer.start(500)
        except Exception as e:
            print("[Shiavoice] play error:",e); self["status"].setText("تعذر تشغيل التسجيل")

    def get_position_length(self):
        pos=ln=None
        try:
            service=self.session.nav.getCurrentService(); seek=service and service.seek()
            if seek:
                r,p=seek.getPlayPosition()
                if not r: pos=p/90000.0
                r,l=seek.getLength()
                if not r and l>0: ln=l/90000.0
        except Exception: pass
        return pos,ln

    def fmt(self,sec):
        sec=max(0,int(sec)); return "%02d:%02d:%02d"%(sec//3600,(sec%3600)//60,sec%60) if sec>=3600 else "%02d:%02d"%(sec//60,sec%60)

    def tick(self):
        now=__import__('time').time()
        pos,ln=self.get_position_length()

        # Some 4097 HTTP streams expose a seek object but report position 0
        # forever.  Do not let that valid-looking zero freeze our clock.
        use_native=False
        if pos is not None:
            if pos > 0.2:
                use_native=True
                self._native_stuck=0
                self._last_native_pos=pos
            else:
                self._native_stuck += 1
                if self._native_stuck < 3 and self.elapsed <= 0.5:
                    use_native=True

        if use_native:
            self.elapsed=max(0,pos)
        elif self._fallback_start is not None and not self.paused:
            self.elapsed=max(0,now-self._fallback_start)

        if ln is not None and ln>0:
            self.length=ln
        elif self.item_duration>0:
            self.length=self.item_duration

        if self.length and self.elapsed>self.length:
            self.elapsed=self.length
        self["time"].setText(self.fmt(self.elapsed)+" / "+(self.fmt(self.length) if self.length else "--:--"))
        try:
            val=int((self.elapsed/self.length)*1000) if self.length else 0
            self._set_progress(max(0,min(1000,val)))
        except Exception:
            pass

    def toggle_pause(self):
        try:
            service=self.session.nav.getCurrentService(); pause=service and service.pause()
            if pause:
                now=__import__('time').time()
                if self.paused:
                    pause.unpause(); self.paused=False
                    if self._fallback_pause_started is not None and self._fallback_start is not None:
                        self._fallback_start += now-self._fallback_pause_started
                    self._fallback_pause_started=None
                    self["controls"].setText("⏸  إيقاف مؤقت"); self["status"].setText("▶ يعمل الآن")
                else:
                    pause.pause(); self.paused=True; self._fallback_pause_started=now
                    self["controls"].setText("▶  متابعة"); self["status"].setText("⏸ متوقف مؤقتاً")
        except Exception: pass

    def current_index(self):
        if not self.play_item_ref: return -1
        for i,e in enumerate(self.entries):
            if len(e)>2 and e[2]==self.play_item_ref[2]: return i
        return -1

    def prev_item(self):
        i=self.current_index()
        if i>0 and self.entries[i-1][1]=="play": self.play_item(self.entries[i-1])

    def next_item(self):
        i=self.current_index()
        if i>=0 and i+1<len(self.entries) and self.entries[i+1][1]=="play": self.play_item(self.entries[i+1])

    def exit(self):
        if self.pages:
            self.back_page()
        else:
            self.close()

    def cleanup(self):
        try:self.player_timer.stop()
        except Exception:pass
        stop_audio()


def main(session,**kwargs):
    session.open(Browser)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Shiavoice",
        description="صوت الشيعة v"+VERSION,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="icon.png",
        fnc=main)
