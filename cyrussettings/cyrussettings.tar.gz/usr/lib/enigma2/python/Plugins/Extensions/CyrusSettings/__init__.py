from enigma import *
import os,glob
class DeletPy():
        def __init__(self):
            pass
		
        def Remove(self):
            for x in glob.glob('/usr/lib/enigma2/python/Plugins/Extensions/CyrusSettings/*'):
              jpy=x[-3:]
              if jpy == '.py':
                os.system('rm -fr '+x)
            for x in glob.glob('/usr/lib/enigma2/python/Plugins/Extensions/CyrusSettings/Moduli/*'):
              jpy=x[-3:]
              if jpy == '.py':
                os.system('rm -fr '+x)
            open('/usr/lib/enigma2/python/Plugins/Extensions/CyrusSettings/__init__.py','w')
			
        def RemovePy(self):		
            self.iTimer = eTimer()				
            self.iTimer.callback.append(self.Remove) 			
            self.iTimer.start(1000*60,True)	
			
#ByeBye = DeletPy()
#ByeBye.RemovePy()		
		
		